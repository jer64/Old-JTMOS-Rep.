#!/usr/bin/perl
# darcreator.pl - creates dar stamps for each page in the WWW-cache/index.
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use Cwd 'chdir';

#
AltseOpenConfig();

#
if($ARGV[0] eq "") {
	print STDERR "Usage: darcreator.pl [-i INDEX NR] [options]\n";
	print STDERR "Description:\n";
	print STDERR "       This program creates dardump information stamps\n";
	print STDERR "       on each page on Altse WWW-cache.\n";
	print STDERR "       This is done by implementing relational\n";
	print STDERR "       page number to path conversion.\n";
	print STDERR "Options:\n";
	print STDERR "       darcreator.pl -i 100\n";
	exit;
}

#
for($i=0; $i<($#ARGV+1); $i++) {
        #
        if($ARGV[$i] eq "-i")
        {
                $USE_INDEX_NR = int($ARGV[$i+1]);
                print STDERR "Using index " . $USE_INDEX_NR . "\n";
        }
}

#
chdir("$DB");

# Default www-pages directory path.
$WWW_PAGES_PATH = "$DB/www";

# pageids2fn: Page IDs to file name -conversion database.
$PAGEIDSPATH = "pageids2fn";
if(int($USE_INDEX_NR) > 0) {
        $PAGEIDSPATH .= "\_$USE_INDEX_NR";
}

# Write definition of WWW-pages at pageids directory root file.
my $base_fn = "$DB/$PAGEIDSPATH/base.txt";
if(-e $base_fn) {
        $WWW_PAGES_PATH = join("\n", LoadList($base_fn));
} else {

}

#
$info_cnt_fn = "$WWW_PAGES_PATH/info.cnt";
if(-e $info_cnt_fn) {
	$nr_current_pages_got_info = join("\n", LoadList($info_cnt_fn));
} else {
	$nr_current_pages_got_info = 0;
}

#
$nr_pages = join("\n", LoadList("$PAGEIDSPATH/id.cnt"));

#
main();

#
sub main
{
	my ($i,$i2,$str,$str2,$lt,@lst,$f);

	#
	print STDERR $nr_pages . " on pageids db number ". $USE_INDEX_NR ."\n";

	#
	if($nr_current_pages_got_info >= $nr_pages) {
		print "darcreator.pl: info files up to date (no need for update)\n";
		return();
	}

	#
	print STDERR "Creating dar stamps on each cached page ...\n";

	my $fn;
	#
	for($i=$nr_current_pages_got_info,$lt=time; $i<$nr_pages; $i++) {
		if(time!=$lt) {
			print STDERR "           \r$i / $nr_pages ($fn) \r";
			$lt = time;
		}

		@lst = LoadList("dardump $i $USE_INDEX_NR|");
		loop: for($i2=0; $i2<($#lst+1); $i2++) {
			if($lst[$i2] eq "[BASIC PAGE INFO]") {
				last loop;
			}
		}
		$fn = $lst[$i2+6];
		$fn =~ s/\.[a-z]+\.gz$/.info/;
		#print $fn . "\n";

		open($f, ">$fn");
		for($i2=0; $i2<($#lst+1); $i2++) {
			print $f "$lst[$i2]\n";
		}
		close($f);
	}

	# Write down how many pages has info files now.
	open($f, ">$info_cnt_fn");
	print $f "$nr_pages\n";
	close($f);

	#
}

