#!/bin/bash
is "com" 1> /dev/null 2> /tmp/hm ; less /tmp/hm
