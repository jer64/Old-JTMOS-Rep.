//
#ifndef __INCLUDED_HTMLDUMP_H__
#define __INCLUDED_HTMLDUMP_H__

//
int HtmlDump(int sid,  BYTE *buf,int l_buf, int index_to_use);

#endif

