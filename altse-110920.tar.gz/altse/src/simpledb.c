// Simple Memory Based Database
#include <stdio.h>
#include "selib.h"

//
#define DB_MEM_SIZE	(1024*1024*1)

//
typedef struct
{
	//
	DBENT **den;
	int n_den;
	int max_den;
}DB;

//
void InitDB(DB *db)
{
	//
	memset(db, 0, sizeof(DB));

	//
	
}

//

