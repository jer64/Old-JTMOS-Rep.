// itemview.c - View single item from the page dump database.
#include <stdio.h>
#include "selib.h"
#include "dardump.h"

//////////////////////////////////////////////////////////////////////////////////////////
//
void ViewItem(DWORD gid, char *key,   int which_index)
{
        static char *dar,*str;
        char *content;
	int len,line_nr;

	//
	len = 1024*512;
	dar = malloc(len);
	str = malloc(len);

        //
        DarDump(gid, dar,len,   which_index);
	content = WliSearch(gid, key,  which_index);

        // Get host, path, title, preview nfo (dardump).
        for(line_nr=0; line_nr<100; line_nr++) {
                GetLine(dar,4900, line_nr, (BYTE*)str);
                if( !strcmp(str, "[BASIC PAGE INFO]") ) {
                        line_nr++;
                        break;
                }
        }

        //
        GetLine(dar,len, line_nr, str); printf("%s\n", str); line_nr++;
        GetLine(dar,len, line_nr, str); printf("%s\n", str); line_nr++;
        GetLine(dar,len, line_nr, str); printf("%s\n", str); line_nr+=2;
        RemoveControlCodes(content);
        printf("%s\n", content);
        GetLine(dar,len, line_nr, str); printf("%d, %s\n", gid, str);

	//
	free(dar); free(str);
}

//
int main(int argc, char **argv)
{
	DWORD gid,which_index;

	//
	AltseLoadConfig();

	//
	if(argc<4)
	{
		fprintf(stderr, "Usage: itemview [page id] [which index] [\"keyword(s)\"]\n");
		return 0;
	}

	//
	sscanf(argv[1], "%d", &gid);
	sscanf(argv[2], "%d", &which_index);
	ViewItem(gid, argv[3], which_index);

	//
	return 0;
}

//
