#ifndef __INCLUDED_HTMLPROC_H__
#define __INCLUDED_HTMLPROC_H__

//
void GetMetaTag(BYTE *h, char *tag, char *target);

#endif
