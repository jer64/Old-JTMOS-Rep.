#!/usr/bin/perl
require "tools.pl";

#
AltseOpenConfig();

#
sub killer
{
        my (@lst,$i,$i2,$str,$url,$host,$f,$orghost,$c,$x,$y,$z,$done,$r,@sp,$user,$pid,$mem);

        #
        @lst = LoadList("ps aux |grep 'crawl'|grep -v SCREEN|grep -v grep|");

        #
        for($i=0; $i<($#lst+1); $i++)
        {
                #
                @sp = split(" ", $lst[$i]);

                #
                $user = $sp[0];
                $pid =  $sp[1];
                $mem =  $sp[4];

		#
                #if($mem > $MAX_CRAWLER_MEMORY_USAGE_K)
                #{
		printf "$pid = %d Mb\n", ($mem/1024)+1;
                #        open($f, ">>$DB/terminate.log") || die "Can't write terminate.log\n";
                #        print $f "> Terminated process $pid - exceeded memory usage limit ($mem)$
                #        close($f);
                #        kill(1, $pid);
                #}
        }

}

#
killer();
