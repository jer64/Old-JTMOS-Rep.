//----------------------------------------------------------------------------
// syn.c - Synonym finder.
//----------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"
#include "gethtmlpage.h"

//
static char UserKey[8192];

//
int compare(char *s1, char *s2)
{
	int score,i,l;

	//
	score=0;
	score -= abs(strlen(s1)-strlen(s2));

	//
	if( strlen(s1)>strlen(s2) )
	{
		l = strlen(s2);
	}
	else
	{
		l = strlen(s1);
	}

	//
	for(i=0; i<l; i++)
	{
		if(s1[i]==s2[i]) score++;
	}

	//
	return score;
}

//
int SortFunc(const void *a,const void *b)
{
	char* ptra=*(char**)a;
	char* ptrb=*(char**)b;
	return compare(UserKey,ptra);
}

//----------------------------------------------------------------------------
//
void FindSynonym(char *key)
{
	FILE *f;
	static char str[8192],fn[8192];
	BYTE *buf;
	int sz,items,i,i2,i3,i4;
	DIXE *e;
	char **words;
	int n_words,record,record_pos;

	//
	words = malloc(1000000*4);

	//
	strcpy(UserKey, key);
//	UserKey[8]=0;
//	while(strlen(UserKey)<8) { strcat(UserKey,"_"); }

	//
	strcpy(fn, "/usr/share/dict/words");

	//
	f = fopen(fn, "rb");
	fseek(f,0,SEEK_END);
	sz = ftell(f);
	fseek(f,0,SEEK_SET);
	buf = malloc(sz);
	for(i=0; !feof(f); i++)
	{
		words[i] = malloc(128);
		fscanf(f, "%s", words[i]);
	}
	n_words = i;
	fclose(f);

	//
	for(i=0,record=0,record_pos=0; i<n_words; i++)
	{
		i2 = compare(UserKey, words[i]);
		if(i2>record)
		{
			record=i2;
			record_pos=i;
		}
		if( i2>0 && i2 > (strlen(UserKey)-2) )
		{
			fprintf(stdout, "%s\n",
				words[i]);
		}
	}

	//
	//fprintf(stderr, "%s\n", words[record_pos]);
/*	for(i=record_pos-5,i2=0; i<n_words && i2<10; i++)
	{
		//
		if( i>0 && i<n_words && strlen(words[i])>1 )
		{
			fprintf(stdout, "%s\n", words[i]);
			i2++;
		}
	}*/
}

//----------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
	//
	if(argc<2)
	{
		fprintf(stderr, "Usage: syn [word]\n");
		return 0;
	}

	//
	FindSynonym(argv[1]);

	//
	return 0;
}

//

