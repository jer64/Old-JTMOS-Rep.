/////////////////////////////////////////////////////////////////////////////
//
// inde_qd.c - quick database.
// (C) 2005-2013 by Jari Tuominen (jari@vunet.org).
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"

//
#define IDB_BLOCK_SZ	2048
#define N_MAX_IDBENT	2000000

//
typedef struct
{
	//
	BYTE letters[8];
	DWORD sz;
	DWORD res;
}IDBENT;

//
typedef struct
{
	//
	BYTE *cat=NULL;
	int n_cat;
}IDB;
IDB idb;

//
void inde_InitDatabaseSystem(void)
{
	IDB *i;

	//
	i = &idb;

	//
	i->cat = malloc(sizeof(IDBENT*N_MAX_IDBENT)
	i->n_cat = 0;
}

//


