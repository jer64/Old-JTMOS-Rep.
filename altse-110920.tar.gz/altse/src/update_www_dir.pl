#!/usr/bin/perl
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
AltseOpenConfig();

#
main();

#
sub main
{
	$ENV{'$done'} = 0;

	chdir("$DB/www");

	print STDERR "Updating list of web pages (this may take from minutes to tens+ minutes) ...\n";
	my $start_time = time;

	if(!($chpid = fork())) {
		for(; !$ENV{'done'}; ) {
			my $time_spent = (time - $start_time)+1;
			print STDERR "$time_spent secs spent on update ...    \r";
			sleep(1);
		}
	} else {
		system("cd ~/db/www; find . -type f -name '*.dump.gz' > list.txt");
		my $time_spent = (time - $start_time)+1;
		$ENV{'done'} = 1; sleep(2);
		print STDERR "\nUpdate took $time_spent second(s).\n";
		system("killall -14 update_www_dir.pl");
	}

	#
}
