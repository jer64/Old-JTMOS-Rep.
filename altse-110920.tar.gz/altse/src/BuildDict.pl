#!/usr/bin/perl
##########################################################################
#
# Dictionary archiver.
# Builds single files out of individual dictionaries.
#
##########################################################################
#
use POSIX;
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =          "$NWPUB_CGIBASE/sdb";   # search database root directory
$CID =          "$SDB/cid";             # central index
$LISTS =        "$SDB/cid/lists";       # list files directory
$DADI =         "$SDB/cid/data";        # data files
$DICT =         "$SDB/cid/dict";        # big index with dictionaries

#
main();

##################################################################################
#
sub LookAt
{
	my ($i,$i2,$i3,$i4,$str,@sp);

	#
	print "Searching for directories from level $_[0] ... \n";
	@lst = LoadList("find /home/vai/sdb/cid/data/$_[0] -type d|");

	#
	print "Launching indexer on dir(s) ...\n";
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		@sp = split(/\//, $lst[$i]);
		if($#sp==8)
		{
			print ">> $lst[$i]\n";
			system "inde $lst[$i]/*.wli";
		}
	}

	#
}

#
sub main
{
	my ($i,$i2,$i3,$i4,$str,@sp);

	#
	for($i=0; $i<50; $i++)
	{
		LookAt($i);
	}

	#
}
