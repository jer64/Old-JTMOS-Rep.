# (C) 2013-2016 Jari Tuominen
# GPL-licensed.
sub BuildChooseIndexHtml
{
	my ($i,$i2,$i3,$i4,@lst);

	@lst = LoadList("indexnames.txt");

	my $str = ("
<select name=\"indexnr\">
	");

	for($i=0; $i<($#lst); $i+=2) {
		if(int($so{'indexnr'})==int($lst[$i+0])) {
			$sel = "SELECTED";
		} else {
			$sel = "";
		}
		$str .= ("
<option $sel value=\"$lst[$i+0]\">$lst[$i+1]</option>
			");
	}

	$str .= ("
</select>
");

	#
	return $str;
}

1;

