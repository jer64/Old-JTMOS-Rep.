sub NoTracking
{
        #
        if($ENV{'REMOTE_HOST'} =~ /gov.cn/i) {
                return "1";
        }

        #
        if(GetCookie("vunetadmin") eq "true") { return "1"; }

        #
        if($ENV{'REMOTE_HOST'} =~ /cache/i || $ENV{'REMOTE_HOST'} =~ /proxy/i) #### || $so{'cookie_nick'} eq "")
        {
                return "0";
        }

        #
        if($ENV{'NO_TRACKING'} ne "") { return $ENV{'NO_TRACKING'}; }

        #
        if(_NoTracking() )
        {
                $ENV{'NO_TRACKING'} = "1";
        }
        else
        {
                $ENV{'NO_TRACKING'} = "0";
        }
        return $ENV{'NO_TRACKING'};
}

#
sub _NoTracking
{
        my ($str);
        my ($i,@igl);

        #
        for($i=0; $i<($#MASTER_IPS+1); $i++)
        {
                if( $ENV{'REMOTE_ADDR'} eq $MASTER_IPS[$i] )
                {
                        return 1;
                }
        }

        #
#       if( $ENV{'REMOTE_ADDR'} eq $MASTER_IP )
#       {
#               return 1;
#       }
#
        #
        @igl = LoadList("/home/vai/articles/cfg/notracking.txt");

        #
        for($i=0; $i<($#igl+1); $i++)
        {
                if($igl[$i] eq $ENV{'REMOTE_ADDR'})
                {
                        # This userid is being ignored.
                        return 1;
                }
        }
        return 0;
}

1;
