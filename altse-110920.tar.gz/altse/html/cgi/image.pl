#!/usr/bin/perl
#############################################################################
# Image search prototype pre-alpha.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2013 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "modules/settings.pm";
require "modules/ViewCache.pm";
require "modules/GetPageImages.pm";
require "modules/GetPageImagesFromCache.pm";
require "modules/ViewTextResults.pm";
require "modules/ViewImageResults.pm";
require "modules/QueryDB.pm";
require "modules/Logging.pm";
require "modules/Frontpage.pm";
require "modules/InterfaceOpenDP.pm";
require "modules/CacheResults.pm";

#
print "Content-type: image/jpeg\n\n";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush STDOUT buffer after each command
select(STDOUT);
$| = 1;

# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#
sub main
{
	
}
