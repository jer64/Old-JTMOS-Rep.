#!/bin/bash
#
# rm /home/vai/altse/html/cgi/cache/rss/*
# ^ Perhaps needed for a clean up.
#
PATH=$PATH:/home/vai/altse/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
export PATH

# 0-99		news
# 100-199	ftp
echo "Frontpages: Building list of web pages (this may take from minutes to tens+ mintues) ..."
cd ~/db/www
find . -name '*.dump.gz' -type f -printf "%C@ %p\n" | \
	sort > /home/vai/db/www_list.txt


# For websites.
buildpageids2fn.pl -i 0 -c -path /home/vai/db/www

# Create info files.
/home/vai/altse/bin/darcreator.pl -i 0

# Create news feeds . . .
/home/vai/altse/bin/news_feed_builder.pl  -i 0  > /tmp/_news.txt
if [[ -s /tmp/_news.txt ]] ; then
          cp /tmp/_news.txt /home/vai/altse/html/cgi/cache/rss/news.txt
fi

