#!/usr/bin/perl
# Superuser-side install script version 1.0.
#
# THE SCRIPT is still EXPERIMENTAL.
# This is a documented script.
#
require "bin/tools.pl";

#
main();

#
sub AskExit
{
	print STDERR "Enter \"y\" for yes to continue: ";
	my $ok = <STDIN>; chomp $ok;
	if($ok ne "y") {
		print STDERR "\n";
		exit;
	}
	print STDERR "\n";
}

#####################################################################
#
# Installation.
#
sub main
{
	# Introduction and WARNING.
	print "** Altse - superuser installation phase running **\n";
	print "WARNING! THIS IS AN EXPERIMENTAL SUPERUSER SCRIPT, DO YOU WANT TO RUN IT?\n";
	print "It is advicable to run it in a sandbox such as\n";
	print "local VMware or local Xen virtual machine or VirtualBox.\n";
	print "Use at your own responsibility only, no warranty guaranteed of any kind.\n";
	AskExit();

	# Check .bashrc first if it already has the sdb/bin in PATH.
	my (@lst,$i,$i2,$doneit);

	######### INSTALL THE DOZENS OF APT PACKAGES NEEDED TO RUN
	#
	system("./su_aptget_install.sh");

	######### UPDATE CRONTAB IF NECESSARY
	#
	@lst = LoadList("/etc/crontab");
	$doneit = 0;
	for($i=0; $i<($#lst+1); $i++) {
		if($lst[$i]=~/\# ALTSE crontab scripts/) {
			$doneit = 1;
		}
	}

	# Add path in .bashrc if needed.
	if(!$doneit) {
		open($f, ">>/etc/crontab") || die "Oops! Error. Can't write .bashrc\n";
		print $f "# ALTSE crontab scripts\n";
		print $f "0 * * * * vai /home/vai/sdb/crontab/hourly.sh\n";
		print $f "0 0,4,8,12,16,20 * * * vai /home/vai/sdb/crontab/quarterly.sh\n";
		print $f "20 0 * * * vai /home/vai/sdb/crontab/daily.sh\n";
		close($f);
		#
		print STDERR "Added necessary lines for automatic updates in the /etc/crontab -file.\n";
		print STDERR "Please revise scripts at sdb/crontab for changes of updates.\n";
	} else {
		print STDERR "No need to update /etc/crontab ...\n";
	}

	## MAKE LOG DIRECTORIES READABLE AND WRITABLE FOR EVERYONE
	#
	system("chmod a+rwx ~/db/logs");
	system("chmod a+rw ~/db/logs/*");

	#
	print "** Altse - superuser installation phase finished **\n\n\n";
}
