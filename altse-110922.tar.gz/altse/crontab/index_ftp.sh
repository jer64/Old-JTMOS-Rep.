#!/bin/bash
#
screen -d -m "wi -i 100 -o -c"

