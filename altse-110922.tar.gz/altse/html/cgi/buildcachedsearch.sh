#!/bin/bash
#
# You may add this to the crontab.
#

# www.vunet.org search cache build
export ALTSE_INDEXNR="4"
export ALTSE_Q="Libya"
./jsquery.pl > cache/www.vunet.org/libya.js
export ALTSE_Q="Laos"
./jsquery.pl > cache/www.vunet.org/laos.js
export ALTSE_Q="Vietnam"
./jsquery.pl > cache/www.vunet.org/vietnam.js
export ALTSE_Q="Kuuba"
./jsquery.pl > cache/www.vunet.org/kuuba.js
export ALTSE_Q="Kiina"
./jsquery.pl > cache/www.vunet.org/kiina.js
export ALTSE_Q="Korea"
./jsquery.pl > cache/www.vunet.org/korea.js
export ALTSE_Q="Fidel Castro"
./jsquery.pl > cache/www.vunet.org/fidel_castro.js
export ALTSE_Q="Raul Castro"
./jsquery.pl > cache/www.vunet.org/raul_castro.js

# www.kultakaivos.info search cache build
export ALTSE_INDEXNR="3"
export ALTSE_Q="Peter SChiff"
./jsquery.pl > cache/www.kultakaivos.info/peter_schiff.js
export ALTSE_Q="Jim Rogers"
./jsquery.pl > cache/www.kultakaivos.info/jim_rogers.js
