#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
require "./modules/SearchSubModule.pm";
require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# Call the main function.
PortalMenu();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub PortalMenu
{
	#
	print("
<TABLE width=\"100%\" align=\"center\"
style=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; width: 200; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;
        background-size: 200% 200%;\">
<TR>

<TD>

	");

	#
	$menu_fn = "cfg/PortalMenu.txt";
	#
	if(-e $menu_fn)
	{
		@lista = LoadList($menu_fn);
	}
	else
	{
		print "MENU NOT FOUND<BR>\n";
	}
	
	###########################################################
	for(my $i=0; $i<($#lista+1); $i++)
	{
		#
		@sp = split(/ & /, $lista[$i]);
		#
		$nicen = $i+1;
		print("
<TABLE align=\"left\" cellscaping=\"0\" cellpadding=\"4\">
<TR>

<TD>
	<A HREF=\"$sp[0]\" target=\"_blank\">
	<FONT STYLE=\"COLOR: black; font-size: 24px;\">
	$sp[1]
	</FONT>
	</A>
</TD>

</TR>
</TABLE>
		");
	}
	#
	print("
</TD>
</TR>
</TABLE>
	");
}


1;
