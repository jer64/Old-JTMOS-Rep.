//---------------------------------------------------------------------------
//
// direc.c - CGI program for directory.pl.
// Prints HTML output of a RDF index file.
//
// (C) 2003-2013 Jari Tuominen.
// This file is GPL-licensed.
//
#include <stdio.h>
#include "selib.h"

//
int CO=0;
static char LastUpdate[8192],updir[8192],Luokkia[8192];

//---------------------------------------------------------------------------
//
void ConvertTagsToASCII(char *s)
{
	char *reptab[]={
		"&lt;",		"   <",
		"&gt;",		">   ",
		"&quot;",	"     \"",
		"*","*"
	};
	int i,i2,i3,i4,l,x;

	//
	l = strlen(s);

	//
	for(i=0; i<l; i++)
	{
		for(x=0; strcmp(reptab[x],"*"); x+=2)
		{
			if( !strncmp(s+i,reptab[x],strlen(reptab[x])) )
			{
				strncpy(s+i, reptab[x+1], strlen(reptab[x+1]));
			}
		}
	}
}

//
void Spaces(char *astr)
{
	int i,i2,l;

	//
	l = strlen(astr);
	for(i=0; i<l; i++)
	{
		if(astr[i]=='_') { astr[i]=' '; }
	}
}

//---------------------------------------------------------------------------
//
void HandleTag(char *tag, char *content, char *fn)
{
	int i,i2,i3,i4,l;
	static char str[8192],str2[8192],
		ExternalPage[8192],
		astr[8192];
	static int NarrowMode=0,SymbolicMode=0,Title=0,
		narrow=0;

	//
	l = strlen(tag);
	for(i=0; i<l && tag[i]!='\"'; i++) { } i++;
	for(i2=0; i<l && tag[i]!='\"' && i2<8000; i++)
	{
		str[i2++] = tag[i];
	}
	str[i2]=0;

	//
	l = strlen(str);
	for(i=l-1; i>0 && str[i]!='/'; i--); i++;

	//
	strcpy(astr, str);
	Spaces(astr);

	//
/*	fprintf(stdout,
	"<font color=\"#000000\" size=1>tag=<u>\"%s\"</u> - content=<u>\"%s\"</u> (str=<u>\"%s\"</u>)</font><br>\n",
		tag, content, str);*/


	//
	if(!strncmp(tag, "narrow", 6))
	{
		//
		if(NarrowMode==0)
		{
			printf("<BR>");
		}

		//
		if(narrow==0)
		{
			printf("<TABLE width=640 bgcolor=#C0C0C0 cellpadding=8 cellspacing=0><TR>");
			printf("<TD><FONT color=#000000 size=5>%s</FONT></TD>", Luokkia);
			printf("</TD></TR></TABLE>");
		}

		//
		if((NarrowMode&3)==0)
		{
			printf("<TABLE width=640 bgcolor=#404040 cellpadding=8 cellspacing=0><TR>");
		}
		//
		printf("<TD width=25%>");
		printf("<IMG src=\"/images/RedBox.gif\" class=bulletin> ");
		printf("<a href=\"/%s/\"><font color=#FFFFFF>%s</font></a><br> \n",
			str,astr+i);
		printf("</TD>");

		//
		if( (NarrowMode&3)==3 )
		{
			printf("</TR></TABLE>");
		}

		//
		CO++;
		NarrowMode++;

		//
		narrow++;
		return;
	}
	else
	{
		if( NarrowMode )
		{
			i = NarrowMode&3;
			for(; i>=0; i--)
			{
				printf("<TD width=25%></TD>");
			}
			printf("</TR></TABLE><BR>");
			NarrowMode=0;
		}
	}

	//
	if(!strncmp(tag, "Target r:resource", 17))
	{
		//
		fprintf(stdout, "<li><a href=\"/%s/\">%s</a></li><br> \n",
			str,str+i);
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "ExternalPage ", 13))
	{
		//
		strcpy(ExternalPage, str);
	//	fprintf(stdout, "<li><a href=\"/%s/\">%s</a></li><br> \n",
	//		str,str);
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "topic", 5))
	{
		//
		if( strlen(ExternalPage) )
		{
			fprintf(stdout, "<img src=\"/images/link_icon.gif\" class=bulletin> ");
			fprintf(stdout, "<a href=\"%s\">%s</a><br>\n",
				ExternalPage,ExternalPage);
			strcpy(ExternalPage, "");
		}
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "newsGroup", 9))
	{
		//
		fprintf(stdout, "<li><a href=\"%s\">%s</a></li>\n",
			str,str);
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "link", 4))
	{
		//
	/*	fprintf(stdout, "<li><a href=\"%s\">%s</a></li>\n",
			str,str);*/
		return;
	}

	//
	if(!strncmp(tag, "symbolic", 6))
	{
		//
		if(SymbolicMode==0)
		{
			printf("<BR>");
		}
		if((SymbolicMode&3)==0)
		{
			printf("<TABLE width=100%% bgcolor=#0060A0 cellpadding=8 cellspacing=0><TR>");
		}
		//
		strcpy(str2, str);
		l = strlen(str2);
		for(i=0; i<l && str2[i]!=':'; i++) { }
		str2[i]=0;
		Spaces(str2);
		//
		printf("<TD width=25%>");
		printf("<IMG src=\"/images/RedBox.gif\" class=bulletin> ");
		printf("<A HREF=\"/%s/\"><FONT color=#00FFFF>%s</font></a>\n",
			str+i+1,str2);
		printf("</TD>");

		//
		if( (SymbolicMode&3)==3 )
		{
			printf("</TR></TABLE>");
		}

		//
		CO++;
		SymbolicMode++;
		return;
	}
	else
	{
		if( SymbolicMode )
		{
			i = SymbolicMode&3;
			for(; i>=0; i--)
			{
				printf("<TD width=25%></TD>");
			}
			printf("</TR></TABLE><BR>");
			SymbolicMode=0;
		}
	}

	//
	if(!strncmp(tag, "related", 7))
	{
		//
fprintf(stdout, "<a href=\"/%s/\"><img src=\"http://images.vunet.org/folder-empty.png\" class=bulletin border=0></a>",
	str);
fprintf(stdout, " <a href=\"/%s/\">%s</a><br>\n",
	str,astr);
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "letterbar", 9))
	{
		//
		fprintf(stdout, "<font size=6><a href=\"/%s/\">%s</a></font> \n",
			str,str+i);
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "altlang", 7))
	{
		//
	//	fprintf(stdout, "<a href=\"/%s/\">IN ALTERNATIVE LANGUAGE: %s</a><br> \n",
	//		str,str+i);
		CO++;
		return;
	}


	//
	if(!strncmp(tag, "editor", 6))
	{
/*		//
fprintf(stdout, "<TABLE align=left width=25%%><TR><TD>");
		fprintf(stdout, "<font size=1>Author: %s</font><br> \n",
			str,str+i);
fprintf(stdout, "</TD></TR></TABLE>");*/
		return;
	}

	//
	if(!strncmp(tag, "aolsearch", 9))
	{
		//
		return;
	}

	//
	if(!strncmp(tag, "dispname", 8))
	{
		//
		fprintf(stdout, "<font size=6>%s</font><br>\n",
			content);
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "d:Title", 7))
	{
		//
		Spaces(content);
		printf("<br");
		if(Title==0 && !strstr(fn, "/directory/"))
		{
		printf("<font size=6><b>%s</b></font><br>\n",
			content);
		}
		else
		{
		printf("<font size=5><b>%s</b></font><br>\n",
			content);
		}
		if(Title==0 && !strstr(fn, "/directory/"))
		{
			//
printf("<TABLE width=100%% cellpadding=2 cellspacing=0 bgcolor=#FF0000><TR><TD></TD></TR></TABLE><BR>");

			// 1234
			l = strlen(fn);
			for(i=18,i2=0,i3=i; i<l; i++)
			{
				if( !strncmp(fn+i, "index.rdf", 9) ) break;
				if(fn[i]=='/')
				{
					//
					if(!i2)
					{
printf("\
<a href=\"/Top/\">\
<IMG src=\"/images/home.gif\" hspace=4 border=0 class=bulletin> Top\
</a>\
");
					}

					// Get word.
					memset(str,0,8192);
					strncpy(str, fn+i3, i-i3);
					// Get path.
					strncpy(str2, fn+18, i-18);
					if(strlen(str)) { printf(" > "); }
					printf("<A HREF=\"/Top/%s/\">%s</A>", str2, str);
					i3 = i+1;
					i2++;
				}
			}
			printf("<BR>");
		}
		Title++;
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "d:charset", 9))
	{
		//
		return;
	}

	//
	if(!strncmp(tag, "d:Description", 13))
	{
		//
		ConvertTagsToASCII(content);
		fprintf(stdout, "<font size=3><b>%s</b></font><br>\n",
			content);
		CO++;
		return;
	}

	//
	if(!strncmp(tag, "catid", 5))
	{
		//
		return;
	}

	//
	if(!strncmp(tag, "lastUpdate", 10))
	{
		sprintf(LastUpdate, "Last update on %s.<br>\n", content);
		return;
	}

	//
/*	fprintf(stdout,
	"<font color=\"#FF0000\">UNHANDLED tag=<u>\"%s\"</u> - content=<u>\"%s\"</u> (str=<u>\"%s\"</u>)</font><br>\n",
		tag, content, str);*/
}

//---------------------------------------------------------------------------
//
int DirectoryView(char *fn)
{
	BYTE *buf;
	int l_buf,i,i2,i3,i4,oi,offs1,offs2;
	FILE *f;
	static char str[8192],str2[8192],str3[8192],str4[8192],
		str5[8192],str6[8192],path[8192];

	printf("<TABLE width=100%% cellpadding=0 cellspacing=0><TR><TD>");

	//
	strcpy(LastUpdate, "");

	//
	if( !strstr(fn, "/directory/") )
	{
		GetOnlyPath(fn+14, str);
		Spaces(str);
		GetOnlyPath(str, str2);
		GetOnlyPath(str2, str3);
		GetOnlyPath(str3, str4);
		GetOnlyPath(str4, str5);
		GetOnlyPath(str5, str6);
		strcpy(updir, str2);
	}

	//
	f = fopen(fn, "rb");
	if(f==NULL)
	{
	/*	printf("File not found: %s\n",
			fn); */
		return 0;
	}
	//
	fseek(f,0,SEEK_END);
	l_buf = ftell(f);
	buf = malloc(l_buf);
	fseek(f,0,SEEK_SET);
	fread(buf, l_buf,1, f);
	//
	fclose(f);

	//
	strcpy(path, fn+13);
//	fprintf(stdout, "<table><tr><td>");
//	fprintf(stdout, "%s", path);
//	fprintf(stdout, "</td></tr></table>");

	//
	for(i=0; i<l_buf; )
	{
		// Find '<'
		for(; buf[i]!='<' && i<l_buf; i++) { } i++;
		for(i2=0; buf[i]!='>' && i<l_buf; i++) { str[i2++]=buf[i]; }
		str[i2]=0;

		//
		offs1 = i+1;
		for(oi=i; buf[i]!='<' && i<l_buf; i++) { }
		offs2 = i;

		//
		for(i=offs1,i2=0; i<offs2; i++)
		{
			str2[i2++] = buf[i];
		}
		str2[i2]=0;
	
		//
		i = offs1;

		//
		if(str[0]!='/')
		{
			HandleTag(str,str2,fn);
		}
	}

	//
	if( strlen(LastUpdate) )
	{
fprintf(stdout, "<TABLE width=100%% cellpadding=4 cellspacing=0><TR><TD>");
fprintf(stdout, "<FONT color=#000000>%s</FONT>", LastUpdate);
fprintf(stdout, "</TD></TR></TABLE>");
	}

	#
	printf("</TD></TR></TABLE>");

	//
	return 0;
}

//---------------------------------------------------------------------------
//
int main(int argc, char **argv)
{	
	static char str[8192],str2[8192],str3[8192],str4[8192],
		str5[8192],str6[8192],path[8192];

	//
	CO = 0;

	//
	if(argc<3)
	{
		fprintf(stderr, "Usage: direc [RDF file]\n");
		return 0;
	}

	//
	strcpy(Luokkia, argv[2]);

	//
	DirectoryView(argv[1]);

	//
	if(!CO && !strstr(argv[1], "/directory/"))
	{
		GetOnlyPath(argv[1]+14, str);
		Spaces(str);
		GetOnlyPath(str, str2);
		GetOnlyPath(str2, str3);
		GetOnlyPath(str3, str4);
		GetOnlyPath(str4, str5);
		GetOnlyPath(str5, str6);
		strcpy(updir, str2);
//		printf("CO = %d", CO);
		printf("<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=/%s/\">",
			updir);
	}

	//
	return 0;
}

//

