#!/usr/bin/perl
#############################################################################
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2012 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "modules/settings.pm";
require "modules/ajaxloader.pm";
require "modules/ads.pm";
require "modules/kk_mainos.pm";
require "modules/FixScands.pm";
require "modules/ViewTextResults.pm";
require "modules/CacheResults.pm";
require "modules/QueryDB.pm";
require "modules/JsPrint.pm";
require "modules/ProduceNewsFeedsHTML.pm";

#
main();
#
sub main
{
        #
        if($so{'to'} ne "")
        {
                #
                print "Content-type: text/html\n\n";
                # Send error messages to the user, not system log
                open(STDERR,'<&STDOUT');  $| = 1;

                #
                Track($so{'to'});
                #
                print("
<meta http-equiv=\"refresh\" content=\"0; url=$so{'to'}\">
                        ");

                #
                exit();
        } else {
<meta http-equiv=\"refresh\" content=\"0; url=/\">
	}

}
