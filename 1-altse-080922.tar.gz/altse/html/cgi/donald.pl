#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
require "./modules/SearchSubModule.pm";
require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
IsTrumpLifeFP();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub IsTrumpLifeFP
{
	# Introduction and search engine form.
	print("



<BR>
<TABLE width=\"800\" align='center'>
<TR>
<TD>

<DIV align='center' style=\"color: #000000; font-size: 24;\">$PAGE_ENGINE_FOOTER</DIV>

<IMG SRC=\"$LOGO_FRONT\"
	loading=\"lazy\">

<H2>
<A HREF=\"/top500/\">Top 500</A> - 
<A HREF=\"/likes/\">Näytä tykkäykset</A>
</H2>

$PAGE_ENGINE_FOOTER2

<DIV align='center'>
<FORM ACTION=\"/?\" name=\"FORM1\” id=\"FORM1\">

<INPUT TYPE=\"TEXT\" VALUE=\"$so{'q'}\" NAME=\"q\" SIZE=\"20\" id=\"q\" maxlength=\"100\"
	style=\"width: 100%;
padding: 12px 20px; margin: 8px 0;
box-sizing: border-box; font-size: 24; box-sizing: content-box;
display: flex; float: none; line-height: normal; position: static; z-index: auto; \">
<INPUT TYPE=\"HIDDEN\" VALUE=\"$so{'indexnr'}\" NAME=\"indexnr\">
<INPUT TYPE=\"HIDDEN\" VALUE=\"go\" NAME=\"cmd\">
<INPUT TYPE=\"SUBMIT\" VALUE=\"$SEARCH_GO\"
style=\"width: 100;
padding: 12px 20px; margin: 8px 0;
box-sizing: border-box; font-size: 24; box-sizing: content-box;
display: flex; float: none; line-height: normal; position: static; z-index: auto;\">
</DIV>

</TD>
</TR>
</TABLE>
");

	##############################################################################################################C
	## AFTER THE SEARCH FORM !!!
	## Requires a table !!!
	##############################################################################################################C
	print("
<TABLE width=\"640\" align='center'>
<TR>
<TD>
<iframe width=\"560\" height=\"315\" src=\"https://www.youtube.com/embed/yIvai6_N8HE\" title=\"YouTube video player\" frameborder=\"0\"
allow=\"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen> loading=\"lazy\"</iframe>
</TD>
</TR>
</TABLE>
	");
	
	#
	print("
                <script language=\"javascript\">
                        document.getElementById('q').focus();
                </script>

<TABLE width=\"640\" align='center'>
<TR>
<TD>
");
	################
	#
	my (@lst) = LoadList("/home/vai/altse/html/cgi/cfg/recommended_searches.txt");
	#print $#lst;
	my ($i,@sp,$str);
	#
	print("
<BR>
<A NAME=\"recommended\"></A>
<TABLE width=\"100%\" align=\"center\"
style=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;
        width: 200;
        background-size: 100% 200%;\">
<TR>
<TD>
	");
	#
	print("
	<CENTER>
		<IMG SRC=\"/images/Internet-web-browser.svg\" alt=\"Internet\" title=\"Internet-hakuja\">
		<H1>Hakuja, tykkää uutisista tästä:</H2>
	</CENTER>
	");
	#
	print("
	<TABLE style=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: black;
        width: 200;
        background-size: 100% 200%;\">
	<TR>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		if(($i%3)==2)
		{
			print("</TR><TR>");
		}
		
		print("
		<TD>
		<H2>
		<A HREF=\"/?cmd=go&indexnr=0&q=$lst[$i]\"
			style=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;
        width: 200;\">
		$lst[$i]
		</A>
		</H2>
		</TD>
		");
	}
	print("
</TR>
</TABLE>

<!---- cut width/size table ends here --->
</TD>
</TR>
</TABLE>

<BR>
<BR>
	");





	#
	print("

</FORM>
<SCRIPT LANGUAGE=\"JAVASCRIPT\">
document.getElementById('q').requestFocus();
</SCRIPT>
");

print("
</TD>
</TR>
</TABLE>
");







	# Links to partner websites.
	my $style_for_div = (
"style=\"background: #C04040; font-size: 48px; a.color: #000000; color: #000000; padding: 10px; height: 35; \"
	");
	my $style_for_div_cap = (
"style=\"background: #E04040; font-size: 36px; a.color: #000000; color: #000000; padding: 10px; height: 35; \"  
        ");
	my $table_width = 640;
	my $td_width = "50%";
	my $td_width2 = "50%";
	my $a_style=" style=\" COLOR: yellow; TEXT-DECORATION: underline; font-size: 36px; \" target=\"_blank\" ";


	#
	print("
	<P>
	<TABLE width=\"640\" align=\"center\" cellpadding=\"4\" cellspacing=\"0\">
	<TR>
	<TD>
	
	<P><FONT style=\"font-size: 48px; \">Viimeksi ladattuja sivuja:</FONT></P>
	");
	
	# db/download.log
	my @dlog = reverse LoadList("tail -n 10000 $DB/download.log|");
	my ($i);
	#
	for($i=0,my $ic=0; $i<($#dlog+1) && $ic<25; $i++)
	{
		my @sp = split(/ /, $dlog[$i]);
		
		if( $sp[1] eq "downloaded" && int($sp[0])>=0 )
		{
			my $timeint1 = int($sp[0]);
			my $url1 = $sp[2];
			#my $timestr1 = strftime("%a %b %e %H:%M:%S %Y", $timeint1);
			   
			my	$urlbeginning = $url1;
				$urlbeginning =~ s/^(.{25}).*$/$1/;
			my $compacturl = $url1;
				$compacturl =~ s/^(.{25}).*$/$1/;
			my $compact_url_long = $url1;
				$compact_url_long =~ s/^(.{50}).*$/$1/;

			if(!$gotlogged{$urlbeginning} && $urlbeginning ne "")
			{
				$gotlogged{$urlbeginning}++;
				
				my $host = $url1;
				my $hostonly = $url1;

				$host =~ s/^(http[s]*:\/\/[^\/]*)\/*.*$/$1/i;
				$hostonly =~ s/^http[s]*:\/\/([^\/]*)\/*.*$/$1/i;
				$hostonly =~ s/^www\.//i;
				$hostonly =~ s/(\.com|\.net|\.org|\.info|\.fi)//gi;
				
				if(!$gothost{$host})
				{
					$gothost{$host}++;
					print ("
	<TABLE width=\"100%\" cellspacing=\"0\" cellpadding=\"4\"
		style=\"background: #E0E0E0\">
	<TR>
	<TD>
	<LI>
		<A HREF=\"/?cmd=go&q=$hostonly&st=text&indexnr=0&start=\" target=\"_blank\">
			<FONT style=\"color: red; font-size: 36px;\">
			<STRONG>Hae uutisista: </STRONG>
			<B>$hostonly</B> ...
			</FONT>
		</A>
	</LI>
	</TD>
	</TR>
	</TABLE>
	");
				}

				my $dumpfn = $sp[4];
				$dumpfn =~ s/\.html/\.dump/;
				@dumplist = LoadList("zcat $DB/www/$dumpfn|");
				my $compactstr = join(" - ", @dumplist);
				my $content_cutstr = $compactstr;
				   $content_cutstr =~ s/^(.{80}).*$/$1 .../;
				   $content_cutstr =~ s/_/ /g;
				   $content_cutstr =~ s/(\S{20})/$1 /g;
				
				
				print("
	<LI><A HREF=\"$url1\" target=\"_blank\">
		<font style=\"color: black; font-size: 36;\">
			<B>$content_cutstr :: $compact_url_long</B>
		</font>
	</A></LI>
	");
				$ic++;
			}
		}	
	}
	
	#
	print("
	</TD>
	</TR>
	</TABLE>
	</P>
	<BR>
	");
	#1660273676 downloaded http://www.varastoduunarit.com/forum/index.php?PHPSESSID=suvrn63dou42s1jslfs847pf12&topic=288.0 as var/www.varastoduunarit.com/24624.html.gz

	
	# LINKIT: Uutissyötteitä.
	$F1 = ("<FONT STYLE=\"font-size: 36px; color: #FFFFFF;\">");
	$F2 = ("</FONT>");
	
	#
	$TD__LINKS_STYLE_CONTENT = (" style=\"padding: 0; width: 100%;\" ");
	
	#
	print("

<!----------------- LINKS ------------------->

<TABLE width=\"800\" cellpadding=\"14\" cellspacing=\"0\" valign=\"top\" align=\"center\"
	style=\"background: #400000;\">

<TR valign=\"top\">
<TD style=\"padding: 0; width: 100; vertical-align: middle;\">
 <IMG SRC=\"/images/320px-Feed-icon.svg.png\" width=\"100\" height=\"100\" alt=\"Uutissyötteitä\" title=\"Uutissyötteitä\">
</TD>
<TD width=\"700\">
 <DIV $style_for_div_cap>
 <FONT style=\"color: #E8E8E8;\">Uutissyötteitä</FONT>
 </DIV>
</TD>
</TR>
</TABLE>

<TABLE style=\"background: black;
width: 800; cellpadding: 12; cellspacing: 0; valing: top; align: middle;\"
	align=\"center\">

<TR valign=\"top\">
<TD $TD__LINKS_STYLE_CONTENT>
 <A HREF=\"http://istrump.life\" $a_style>IsTrump.Life</A>
</TD>
</TR>
<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 $F1 - Vaihtoehtouutisten internet-hakukone. $F2
</TD>
</TR>

<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 <A HREF=\"http://www.vaihtoehtouutiset.com\" $a_style>Vaihtoehtouutiset.com</A>
</TD>
</TR>
<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 $F1 - Vaihtoehtouutiset (Vunet). $F2
</TD>
</TR>

<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 <A HREF=\"http://www.p4t1n.com\" $a_style>P4t1n.com</A>
</TD>
</TR>
<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 $F1 - Putin- ja bisnesuutiset. $F2
</TD>
</TR>

<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 <A HREF=\"https://www.facebook.com/sipila.heikki/\" $a_style>Heikki Sipilä FaceBook</A>
</TD>
</TR>
<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 - $F1 Bloggaaja, toimittaja. Ajankohtaisia uutisia päivittäin. $F2 
</TD>
</TR>

<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 <A HREF=\"https://www.facebook.com/hannu.rainesto\" $a_style>Hannu Rainesto FaceBook</A>
</TD>
</TR>
<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 $F1 - Bloggaaja, ajattelija, ja entinen yrittäjä. $F2
</TD>
</TR>

<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 <A HREF=\"https://www.facebook.com/jari.t.tuominen\" $a_style>Jari Tuominen Facebook</A>
</TD>
</TR>
<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 $F1 - Bloggaaja, toimittaja, ohjelmistoteollisuuden guru. $F2
</TD>
</TR>

<TR>
<TD $TD__LINKS_STYLE_CONTENT>
 <A HREF=\"https://www.youtube.com/vunet\" $a_style>youtube.com/vunet</A>
</TD>
</TR>
<TR>
<TD $TD__LINKS_STYLE_CONTENT>
  $F1 - Vunet - TV - Musiikkia ja tanssia slaavilaisteemalla. $F2
</TD>
</TR>


</TABLE>



<BR>
<DIV ALIGN=\"center\">
	<iframe width=\"800\" height=\"560\" src=\"/top500/\"
		frameborder=\"0\"  onload=\"resizeIframe(this)\"/
		loading=\"lazy\”>
	</iframe>
</DIV>

<BR>
<DIV ALIGN=\"center\">
	<iframe width=\"800\" height=\"560\" src=\"/likes/\"
		frameborder=\"0\"  onload=\"resizeIframe(this)\"/
		loading=\"lazy\”>
	</iframe>
</DIV>


	");


} # END OF istrump.life

1;
