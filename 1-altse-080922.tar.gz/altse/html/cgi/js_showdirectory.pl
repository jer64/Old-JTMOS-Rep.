!/usr/bin/perl
#############################################################################
# js.pl - ShowDirectory
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2013 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "./modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "./modules/settings.pm";
require "./modules/ajaxloader.pm";
require "./modules/ads.pm";
require "./modules/kk_mainos.pm";
require "./modules/FixScands.pm";

#
print "Content-type: text/javascript\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =           15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
ArgLineParse();
main();

#
main();

####################################################################################
#
sub ShowDirectory
{
	my (@lst,$i,$i2,$i3,$i4,$pathi,$pathi2,$fullpathi,$str,$str2,$PER_ROW);

	#
	$pathi = "$DB/directory/Top";
	$pathi2 = "$so{'q'}";
	$fullpathi = "$pathi/$so{'q'}";
	@lst = LoadList("find -L $fullpathi -type d -maxdepth 1|");
	@lst = sort @lst;

	#
	$PER_ROW = 2;
	$TABLE_WIDTH = "250";
	$CELL_WIDTH = $TABLE_WIDTH/$PER_ROW;

	#
	for($i=1,$i2=0; $i<($#lst+1); $i++,$i2++)
	{
		#
		if( ($i2%$PER_ROW)==0 ) {
			$gcon .= ("
<TABLE width=$TABLE_WIDTH cellspacing=0 cellpadding=4 style=\"word-wrap: break-word;\">
<TR> 
				");
		}

		#
		$str = $lst[$i];
		$str =~ s/^$pathi\///;
		$str2 = $str;
		$str =~ s/^$pathi2\///;
		$str =~ s/ä/�/g;
		$str =~ s/_/ /g;
		$str =~ s/\// \/ /g;
		$str =~ s/([^\s]{15})/$1 /g;

		#
		$gcon .= ("
<TD width=$CELL_WIDTH style=\"word-wrap: break-word;\">
<FONT SIZE=2>
<A HREF=\"/directory/?q=$str2\" class=dark>
<IMG SRC=\"$IMAGES_URL/FolderIcon.png\" border=0>
$str
</A>
</FONT>
</TD>
			");

		#
		if( ($i2%$PER_ROW)==1 ) {
			$gcon .= ("
</TR>
</TABLE>
				");
		}
	}

	#
	my @all = LoadList("find $fullpathi -type f -maxdepth 1 -name '*.rdf'|");
	#my $fn = "$fullpathi/index.rdf";
	my $fn;
	$gcon .=  "<div class=\"KonaBody\">\n";
	for($i=0; $i<($#all+1); $i++) {
		$fn = $all[$i];
		#$gcon .=  $fn . "<BR>\n";
		if(-e $fn) {
			my $ex = "/home/vai/altse/bin/direc $fn \"\"";
			$qcon .= join("\n", LoadList("$ex|"));
			if($i!=$#all) { $gcon .= ("<HR>\n"); }
		}
	}
	$gcon .=  "</div>\n";

	#
}

####################################################################################
#
sub main
{
	my ($i,$i2,$str,$lng,$host,$fo,$la);

	# TODO - SEPERATE TO A LANGUAGE MODULE
	$la = $ENV{'HTTP_ACCEPT_LANGUAGE'};
	$fo=0;

	# Check whether if a localization is available for this host.
	if($la =~ /^fi$/ || $ENV{'REMOTE_ADDR'} =~ /192\.168\./) { $try = "fi"; }
	if($la =~ /^se$/) { $try = "se"; }
	if($la =~ /^de$/) { $try = "de"; }
	if($la =~ /^nl$/) { $try = "nl"; }

	# Probe for availability.
	$lng = "$LANG/$try.txt";
	if(-e $lng) { LoadVars($lng); $fo=1; }
	# Use default "international" setting if none else works.
	if(!$fo) { LoadVars("$LANG/intl.txt"); }

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();
	if($so{'q'} eq "") {
		$so{'q'} = $ARGV[0];
	}

	#
	if($so{'q'} =~ /^\//) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /^\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\.\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\|/) {
		$so{'q'} = "";
	} 

	#
	my ($NAVI,@sp);
	$NAVI = "";
	@sp = ();
	#push(@sp, "Top");
#	if($so{'q'} eq "") {
#		push(@sp,"/");
#	}
	push (@sp, split(/\//, $so{'q'}));
	$linkki = "";
	$NAVI .= "<A HREF=\"?q=\" class=yellow>Home</A>";
	if($so{'q'} ne "") {
		$NAVI .= " / ";
	}
	for($i=0; $i<($#sp+1); $i++) {
		if($i!=0) { $linkki .= "/"; }
		$linkki .= "$sp[$i]";
		$NAVI .= "<A HREF=\"?q=$linkki\" class=yellow>$sp[$i]</A>";
		if($i!=$#sp) {
			$NAVI .= " / ";
		}
	}
	if($so{'q'} ne "") {
		$PAGE_TITLE = "ALTSE - " . $so{'q'};
	}


	# Parse string to something sensible.
	$so{'find'} =~ tr/[A-ZÄÖÅ]/[a-zäöå]/;
	$so{'find'} =~ s/[^a-zäöå0-9]/ /g;
	$so{'find'} =~ s/\s+/ /g;
	#$so{'find'} =~ s/ /_/g;
	# Make a query.
	my $MAX_DIR_RESULTS = 250;
	if($so{'find'} ne "") {
		$gcon .= ("
<DIV ID=\"SBOX\" NAME=\"SBOX\">
<BLINK><H2>$so{'W_SEARCHING'}</H2></BLINK>
</DIV>
		");
		@qlst = LoadList("grep -i \"$so{'find'}\" $DB/directory/Recreation.txt|");
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/News.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Health.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Science.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Sports.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Home.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Games.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Computers.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldSuomi.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldSvenska.txt|"));
		#push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldNederlands.txt|"));	## TOO BIG, skip it
		#push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldDeutsch.txt|"));		## TOO BIG, skip it
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopRegionalEuropeFinland.txt|"));
		# Build HTML of search results.
		$DIRECTORY_SEARCH_RESULTS = ("");
		for($i=0; $i<($#qlst+1) && $i<$MAX_DIR_RESULTS; $i++) {
			$qlst[$i] =~ s/^Top\///;
			$qlst[$i] =~ s/^(.+\/)(index\.rdf)$/$1/;
			my $entry = $qlst[$i];
			$entry=~s/^(.+)\/$/$1/;
			if(!$gotentry{$entry}) {
				$DIRECTORY_SEARCH_RESULTS .= ("
		<P><A HREF=\"?q=$entry\">$entry</A></P>
				");
				$gotentry{$entry}++;
			}
		}
		if($#qlst<=0) {
			$DIRECTORY_SEARCH_RESULTS = ("
	$so{'W_NO_MATCHES'}
"			);
		}
		$gcon .= ("
<SCRIPT language=\"JavaScript\">
document.getElementById('SBOX').style.display='none';
</SCRIPT>
			");
	}

	#
	$gcon .= ("
<!--<DIV name=ajaxloader id=ajaxloader>$LOADERHTML</DIV>-->

			");

	#
	ShowDirectory();



        #
	my $str = $gcon;
        $str =~ s/\n/\\\n/g;
        $str =~ s/[\t\r\s]/ /g;
        $str =~ s/\\/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;

        #
        #@sp = split(/(.{20}[^\\]{4})/, $str);
	
	#@sp = ();
	#push(@sp, $str);
        #for($i=0; $i<($#sp+1); $i++)
        #{
	#	$sp[$i] = FixScands($sp[$i]);
        #        if($sp[$i] ne "")
        #        {
        #                print(" document.write(\"$sp[$i]\");\n ");
        #        }
        #}
	if($so{'element'} eq "") {
		print(" document.write(\"$str\"); ");
	} else {
		print(" document.getElementById('$so{'element'}').innerHTML = \"$str\"; ");
	}
}

