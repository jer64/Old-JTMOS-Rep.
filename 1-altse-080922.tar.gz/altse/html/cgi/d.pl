#!/usr/bin/perl
#############################################################################
# cgi-text.pl - text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2013 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "./modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "./modules/SearchSubModule.pm";
require "./modules/DirectorySubModule.pm";

#
$so{'CURSEC'} = "directory";
$so{'section'} = "directory";

#
if( !$ENV{'newswire_conset'} )
{
	print "Content-type: text/html\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush STDOUT buffer after each command
select(STDOUT);
$| = 1;
# Flush STDERR buffer after each command
#select(STDERR);
#$| = 1;

###############################################################################
#
print("
<TABLE width=100% cellspacing=0 cellpadding=0 align=left valign=top>
<TR valign=top>
<TD width=210>
");
#
$ENV{'CURSEC'} = "directory";
#
print inc_menu("directory", "");

#
print("
</TD>
<TD width=100%>
");

#
main();

#
print("
</TD>

</TR>
</TABLE>
");

####################################################################################
#
sub main
{
	my ($i,$i2,$str,$lng,$host,$fo,$la);

	# TODO - SEPERATE TO A LANGUAGE MODULE
	$la = $ENV{'HTTP_ACCEPT_LANGUAGE'};
	$fo=0;

	# Check whether if a localization is available for this host.
	if($la =~ /^fi$/ || $ENV{'REMOTE_ADDR'} =~ /192\.168\./) { $try = "fi"; }
	if($la =~ /^se$/) { $try = "se"; }
	if($la =~ /^de$/) { $try = "de"; }
	if($la =~ /^nl$/) { $try = "nl"; }

	# Probe for availability.
	$lng = "$LANG/$try.txt";
	if(-e $lng) { LoadVars($lng); $fo=1; }
	# Use default "international" setting if none else works.
	if(!$fo) { LoadVars("$LANG/intl.txt"); }

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	$so{'q'} =~ s/^\/Top\///;

	#
	if($so{'q'} =~ /^\//) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /^\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\.\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\|/) {
		$so{'q'} = "";
	}

	#
	if($SDB_SERVICE_NOTIFICATION)
	{
		print("
		<div align=center>
		$SDB_SERVICE_NOTIFICATION
		</div>
		");
	}

	#
	if( $so{'WWW_SERVICE_STATE'}!=1 && 1!=1 )
	{
		print("
<div align=center>
<br>
<img src=http://images.vunet.org/tr_altse.png>
<table width=700 cellpadding=8 cellspacing=0 bgcolor=#FF0000>
<tr>
<td>
<img src=http://images.vunet.org/atwork.png align=left>
Service temporarily offline for maintenance work.<br>
Palvelu tilap�isesti poissa k�yt�st� huoltot�iden vuoksi.<br>
<br>
$ENV{'REMOTE_ADDR'}<br>
$ENV{'REMOTE_HOST'}<br>
Visit our <A HREF=\"http://freshmeat.net/projects/altse/\">FreshMeat WebSite</A> for more information<br>
</td>
</tr>
</table>
</div>

");
		return();
	}

	#
	my ($NAVI,@sp);
	$NAVI = "";
	@sp = ();
	#push(@sp, "Top");
#	if($so{'q'} eq "") {
#		push(@sp,"/");
#	}
	push (@sp, split(/\//, $so{'q'}));
	$linkki = "";
	$NAVI .= "<A HREF=\"?q=\" class=yellow>Home</A>";
	if($so{'q'} ne "") {
		$NAVI .= " / ";
	}
	for($i=0; $i<($#sp+1); $i++) {
		if($i!=0) { $linkki .= "/"; }
		$linkki .= "$sp[$i]";
		$NAVI .= "<A HREF=\"?q=$linkki\" class=yellow>$sp[$i]</A>";
		if($i!=$#sp) {
			$NAVI .= " / ";
		}
	}
	if($so{'q'} ne "") {
		$PAGE_TITLE = "ALTSE - " . $so{'q'};
	}

	#
	$NAVI_SEARCH = ("
<TABLE width=400 cellspacing=0 cellpadding=0>
<TR>
<TD width=10%>
$KK_MAINOS
</TD>
<TD width=90%>
<FORM ACTION=\"?\">
<INPUT TYPE=TEXT NAME=\"find\" VALUE=\"$so{'find'}\">
<INPUT TYPE=HIDDEN NAME=\"q\" VALUE=\"$so{'q'}\">
<INPUT TYPE=BUTTON VALUE=\"$so{'W_SEARCH_DIRECTORY'}\" $AJAXONBUTTON>
</FORM>
</TR>
</TABLE>
");

	# Parse string to something sensible.
	$so{'find'} =~ tr/[A-ZÄÖÅ]/[a-zäöå]/;
	$so{'find'} =~ s/[^a-zäöå0-9]/ /g;
	$so{'find'} =~ s/\s+/ /g;
	#$so{'find'} =~ s/ /_/g;
	# Make a query.
	my $MAX_DIR_RESULTS = 250;
	if($so{'find'} ne "") {
		print("
<DIV ID=\"SBOX\" NAME=\"SBOX\">
<BLINK><H2>$so{'W_SEARCHING'}</H2></BLINK>
</DIV>
		");
		@qlst = LoadList("grep -i \"$so{'find'}\" $DB/directory/Recreation.txt|");
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/News.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Health.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Science.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Sports.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Home.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Games.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Computers.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldSuomi.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldSvenska.txt|"));
		#push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldNederlands.txt|"));	## TOO BIG, skip it
		#push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldDeutsch.txt|"));		## TOO BIG, skip it
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopRegionalEuropeFinland.txt|"));
		# Build HTML of search results.
		$DIRECTORY_SEARCH_RESULTS = ("");
		for($i=0; $i<($#qlst+1) && $i<$MAX_DIR_RESULTS; $i++) {
			$qlst[$i] =~ s/^Top\///;
			$qlst[$i] =~ s/^(.+\/)(index\.rdf)$/$1/;
			my $entry = $qlst[$i];
			$entry = FixScands($entry);
			$entry=~s/^(.+)\/$/$1/;
			if(!$gotentry{$entry}) {
				$DIRECTORY_SEARCH_RESULTS .= ("
		<P><A HREF=\"?q=$entry\">$entry</A></P>
				");
				$gotentry{$entry}++;
			}
		}
		if($#qlst<=0) {
			$DIRECTORY_SEARCH_RESULTS = ("
	$so{'W_NO_MATCHES'}
"			);
		}
		print("
<SCRIPT language=\"JavaScript\">
document.getElementById('SBOX').style.display='none';
</SCRIPT>
			");
	}

	#
	my $NAVIGATION_BAR = ("
<TABLE cellspacing=0 cellpadding=4 width=100%
	style=\"background: #202080\"\">
<TR>

<TD width=30%>
<FONT COLOR=WHITE><H3>$NAVI</H3></FONT>
</TD>

<TD width=70%>

$NAVI_SEARCH

</TD>

</TR>
</TABLE>
");

	##
	#
	$CHOOSER_HTML = BuildChooseIndexHtml();
	$WEB_SEARCH_FORM_UPPER = ("
                <form method=\"get\" action=\"$CGICMD\" name=\"FORM1\" class=formx $DIS>   
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"text\" name=\"q\" size=\"40\" value=\"$ORGQ\" $DIS>
			$CHOOSER_HTML
                        <input type=\"submit\" value=\"$so{'W_SEARCH'}\" class=buttonx $AJAXONBUTTON $DIS>
                </form>
");

	#
	print(" <!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_URL/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"..$IMAGES_URL/altse.css\" title=\"Cool\">
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF8\" />
<title>
$PAGE_TITLE
</title>

$AJAXLOADERJS
</head>

<BODY $xtra bgcolor=$TVAR
	topmargin=0 leftmargin=0
	marginheight=0 marginwidth=0>
	");

	#
	SearchSubModule();

	#
	print("

</body>
		");
}

