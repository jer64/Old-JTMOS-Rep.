#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
require "./modules/SearchSubModule.pm";
require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

#
#
if($so{'frontpage'} eq "" && $so{'cmd'} eq "" && $so{'q'} eq "" && $so{'st'} eq "")
{
	# View Portal Menu.
#	print("
#<DIV ALIGN=\"center\">
#	<iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#		frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#		loading=\"lazy\”>
#	</iframe>
#</DIV>
#");
}

# Show pre-rendered front page from cache/index.html on a no-command query (usually /).
######################################################################################
if($so{'frontpage'} eq "" && $so{'cmd'} eq "" && $so{'q'} eq "" && $so{'st'} eq "")
{
	@lst = LoadList("cache/index.html");
	print @lst;
}



#
if($so{'frontpage'} eq "" && $so{'cmd'} eq "likes") {
}



#
if($so{'frontpage'} eq "" && $so{'cmd'} eq "menu")
{

}



# istrump.life
if($so{'frontpage'} eq "" && $so{'cmd'} eq "istrump.life") {
	#
	print("
<BR>
<DIV ALIGN=\"center\">
	<iframe width=\"850\" height=\"560\" src=\"/donald/\"
		frameborder=\"0\"  onload=\"resizeIframe(this)\"/
		loading=\"lazy\”>
	</iframe>
</DIV>

<BR>
	");
} # END OF istrump.life





# CGI functionality of a social like.
if($so{'cmd'} eq "like")
{
	#
	my ($f);
	#
	open($f, ">>$DB/likes.txt");
	print $f "$so{'pageid'}|$so{'indexnr'}|$so{'url'}\n";
	close($f);
	#
	print("
<meta http-equiv=\"refresh\" content=\"0; url=/#likes\">
 ");
 	goto endi;
 	#
}

#
#my $ON_TOP_MENU_HTML = ("
#<TABLE width=100% cellspacing=0 cellpadding=0 bgcolor=#000000
#	height=32>
#<TR valign=top>
#");
#my $width_for_td = 100/($#menu_items+1);
##for($i=0; $i<$#menu_items; $i++) {
##	print("
##<TD width=$width_for_td\% bgcolor=#000000>
#<A HREF=\"$menu_urls[$i]\">$menu_labels[$i]</A>
#</TD>
#		");
#}
#print("
#</TR>
#</TABLE>
#");
#

#
print("
$ON_TOP_MENU_HTML
");


#################################################################
#
if($so{'frontpage'} eq "") {
#	$so{'frontpage'} = "news";
}

print("
</TD>

</TR>
</TABLE>
");

#
if(($so{'noajax'} eq "" && $so{'q'} ne "") || ($so{'redirectsect'} ne "" && $so{'cmd'} eq "redirect"))
{
        # View Portal Menu.
#        print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

	if($so{'cmd'} eq "coresearch")
	{
			$redirect_to = "/?cmd=coresearch&q=$so{'q'}&st=$so{'st'}&indexnr=0&start=$so{'start'}&noajax=TRUE";
	}
	else
	{
		if($so{'redirectsect'} eq "")
		{
			$redirect_to = "/?cmd=go&q=$so{'q'}&st=$so{'st'}&indexnr=0&start=$so{'start'}&noajax=TRUE";
		}	
		else
		{	
			$redirect_to = "/?cmd=$so{'redirectsect'}";
		}
	}		
	my $job = $so{'q'};
	print("
<BR><BR>
<DIV ALIGN=\"CENTER\" id=\"ajax2\">
<FONT FACE=\"IMPACT\" size=6 color=\"#C00000\">$ALTSE_HOST - $job - Vaihtoehtouutisten hakukone</FONT><BR>
<A HREF=\"$redirect_to\">
<IMG SRC=\"/images/loader.gif\" alt=\"Odota hetki ...\">
</A>
<BR>
<A HREF=\"$redirect_to\">
<!---
$redirect_to
--->
</A>
<BR>
</DIV>
<meta http-equiv=\"refresh\" content=\"0; url=$redirect_to\">
");
	goto endi;
}

#
if($so{'q'} =~ /\//) {
	$so{'sec'} = $so{'q'};
}
if($so{'frontpage'} eq "news" || $so{'cmd'} eq "go" || $so{'cmd'} eq "vcache" 
|| $so{'cmd'} eq "preview" || $so{'cmd'} eq "previewimage" || $so{'cmd'} eq "coresearch"   ) {
	# Show main menu.
	MainSearchIndexModule();
} else {
	if($so{'sec'} eq "directory" || $so{'sec'} =~ /\//) {

		DirectorySubModule();
	} else {
		# Show specific section.
		if($so{'sec'} eq "directory" || $so{'sec'} =~ /\//) {

			DirectorySubModule();
		} else {
			#NewsFeedsView();
		}
	}
}

## ADD A NORMAL COPYRIGHT STATEMENT.
if($so{'frontpage'} eq "" && $so{'cmd'} eq "istrump.life") {
print("
<CENTER>
<TABLE width='550'>
<TR>
<TD>
<HR>
<CENTER>
	<FONT STYLE=\"font-size: 40; color: black;\">
	$COPYRIGHT
	</FONT>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>
");
}

endi:

#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();
