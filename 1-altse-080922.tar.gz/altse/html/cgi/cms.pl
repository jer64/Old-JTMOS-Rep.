#!/usr/bin/perl
#############################################################################
# ALTSE CONTENT MANAGEMENT SYSTEM
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
sub main
{
	my ($f);

	#
	$so{'q'} =~ s/[^0-9a-z]//g;
	#
	@lst = LoadList("$so{'q'}");
	# Create page if does not exist.
	open(">>cms/$so{'q'}");
	close($f);

	#
	@lst = LoadList("cms�/$so{'q'}");

	#
	print("
<script type=\"text/javascript\" src=\"http://www.html.am/html-editors/ckeditor/ckeditor_3.4/ckeditor.js\"></script> 
\");
}

