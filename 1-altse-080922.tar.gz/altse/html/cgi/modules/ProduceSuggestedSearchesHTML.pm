#
sub ProduceSuggestedSearchesHTML
{
        #
                my $suggested_fn = "cfg/$so{'indexnr'}_recommended.txt";
                my $suggested_html;
                if(-e $suggested_fn) {
                        my @suglst = LoadList($suggested_fn);
                        for($i=0; $i<($#suglst+1); $i++) {
                                $suggested_html .=
"<A HREF=\"$CGICMD?cmd=go&q=$suglst[$i]&indexnr=$so{'indexnr'}\" class=\"darkul\" target=\"_blank\">" .
"<LI class=golden_fade>$so{'W_SEARCH'} \"$suglst[$i]\"</LI></A>";
                        }
                } else {
                        #$con .= "NOT FOUND $suggested_fn<BR>";
                }
                @tmpar = LoadList("$DB/altse/bin/dictsize $so{'indexnr'}|");
                @sp = split(/\s/, $tmpar[0]);
                my $nicesz = $sp[0];
                if( !($nicesz=~/G$/) ) {
                $con .= ("
<P class=\"compact\">No results found, this is probably because the index is being built right now.</P>
");
                }
                $con .= "$suggested_html";
	return $con;
}

1;

