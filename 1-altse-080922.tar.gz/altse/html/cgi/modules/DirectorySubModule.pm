#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "./modules/AltseOpenConfig.pm";
require "./modules/settings.pm";
require "./modules/ajaxloader.pm";
require "./modules/kk_mainos.pm";
require "./modules/BuildChooseIndexHtml.pm";
require "./modules/InterfaceOpenDP.pm";
require "./modules/AltseMenuSystem.pm";

#
sub DirectorySubModule
{

	#
	$so{'CURSEC'} = "directory";
	$so{'section'} = "directory";
	###############################################################################
	#
	print("
	<TABLE width=100% cellspacing=0 cellpadding=0 align=left valign=top>
	<TR valign=top>
	<TD width=210>
	");
	#
	$ENV{'CURSEC'} = "directory";
	#
	print inc_menu("directory", "");

	#
	print("
	</TD>
	<TD width=100%>
	");

	#
	DirSubMain();

	#
	print("
	</TD>

	</TR>
	</TABLE>
	");
}

####################################################################################
#
# Shows current directory.
#
sub ShowDirectory
{
	my (@lst,$i,$i2,$i3,$i4,$pathi,$fullpathi,$str,$str2,$PER_ROW);

	#
	$pathi = "$DB/directory/Top";
	$fullpathi = "$pathi/$so{'q'}";
	$fullpathi_content = "$pathi/$so{'q'}";
	$fullpathi_content =~ s/(Top\/)/content\/$1/;
	@lst = LoadList("find -L $fullpathi -type d -maxdepth 1|");
	@lst = sort @lst;

	#
	$PER_ROW = 4;
	$TABLE_WIDTH = 700;
	$CELL_WIDTH = $TABLE_WIDTH/$PER_ROW;

	#
	for($i=1,$i2=0; $i<($#lst+1); $i++,$i2++)
	{
		#
		if( ($i2%$PER_ROW)==0 ) {
			print("
<TABLE width=$TABLE_WIDTH cellspacing=0 cellpadding=4 style=\"word-wrap: break-word;\">
<TR>
				");
		}

		#
		$str = $lst[$i];
		$str =~ s/^$pathi\///;
		$str2 = $str;
		$str =~ s/\// \/ /g;
		$str =~ s/([^\s|\_|\/]{20})/$1 /g;
		$str = FixScands($str);
		$str2 = FixScands($str2);

		#
		print("
<TD width=$CELL_WIDTH style=\"word-wrap: break-word;\">
<FONT SIZE=4>
<A HREF=\"?q=$str2\">
<IMG SRC=\"..$IMAGES_URL/FolderIcon.png\" border=0>
$str
</A>
</FONT>
</TD>
			");

		#
		if( ($i2%$PER_ROW)==3 ) {
			print("
</TR>
</TABLE>
				");
		}
	}

	#
	my @all = LoadList("find $fullpathi_content -type f -maxdepth 1 -name '*.rdf'|");
	#my $fn = "$fullpathi/index.rdf";
	my $fn;
	print "<div class=\"KonaBody\">\n";
	for($i=0; $i<($#all+1); $i++) {
		$fn = $all[$i];
		#print $fn . "<BR>\n";
		if(-e $fn) {
			#my $ex = "$DB/altse/bin/direc $fn \"\"";
			#system($ex);
			my @con = LoadList("$DB/altse/bin/direc $fn \"\"|");
			my $j = join(/\n/, @con);
			$j = FixScands($j);
			print $j;
			if($i!=$#all) { print("<HR>\n"); }
		}
	}
	print "</div>\n";

	#
}

####################################################################################
#
sub DirSubMain
{
	my ($i,$i2,$str,$lng,$host,$fo,$la);

	# TODO - SEPERATE TO A LANGUAGE MODULE
	$la = $ENV{'HTTP_ACCEPT_LANGUAGE'};
	$fo=0;

	# Check whether if a localization is available for this host.
	if($la =~ /^fi$/ || $ENV{'REMOTE_ADDR'} =~ /192\.168\./) { $try = "fi"; }
	if($la =~ /^se$/) { $try = "se"; }
	if($la =~ /^de$/) { $try = "de"; }
	if($la =~ /^nl$/) { $try = "nl"; }

	# Probe for availability.
	$lng = "$LANG/$try.txt";
	if(-e $lng) { LoadVars($lng); $fo=1; }
	# Use default "international" setting if none else works.
	if(!$fo) { LoadVars("$LANG/intl.txt"); }

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	$so{'q'} =~ s/^\/Top\///;

	#
	if($so{'q'} =~ /^\//) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /^\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\.\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\|/) {
		$so{'q'} = "";
	}

	#
	if($SDB_SERVICE_NOTIFICATION)
	{
		print("
		<div align=center>
		$SDB_SERVICE_NOTIFICATION
		</div>
		");
	}

	#
	if( $so{'WWW_SERVICE_STATE'}!=1 && 1!=1 )
	{
		print("
<div align=center>
<br>
<img src=http://images.vunet.org/tr_altse.png>
<table width=700 cellpadding=8 cellspacing=0 bgcolor=#FF0000>
<tr>
<td>
<img src=http://images.vunet.org/atwork.png align=left>
Service temporarily offline for maintenance work.<br>
Palvelu tilap�isesti poissa k�yt�st� huoltot�iden vuoksi.<br>
<br>
$ENV{'REMOTE_ADDR'}<br>
$ENV{'REMOTE_HOST'}<br>
Visit our <A HREF=\"http://freshmeat.net/projects/altse/\">FreshMeat WebSite</A> for more information<br>
</td>
</tr>
</table>
</div>

");
		return();
	}

	#
	my ($NAVI,@sp);
	$NAVI = "";
	@sp = ();
	#push(@sp, "Top");
#	if($so{'q'} eq "") {
#		push(@sp,"/");
#	}
	push (@sp, split(/\//, $so{'q'}));
	$linkki = "";
	$NAVI .= "<A HREF=\"?q=\" class=yellow>Home</A>";
	if($so{'q'} ne "") {
		$NAVI .= " / ";
	}
	for($i=0; $i<($#sp+1); $i++) {
		if($i!=0) { $linkki .= "/"; }
		$linkki .= "$sp[$i]";
		$NAVI .= "<A HREF=\"?q=$linkki\" class=yellow>$sp[$i]</A>";
		if($i!=$#sp) {
			$NAVI .= " / ";
		}
	}
	if($so{'q'} ne "") {
		$PAGE_TITLE = "ALTSE - " . $so{'q'};
	}

	#
	$OLD_NAVI_SEARCH = ("
<TABLE width=400 cellspacing=0 cellpadding=0>
<TR>
<TD width=10%>
$KK_MAINOS
</TD>
<TD width=90%>
<FORM ACTION=\"?\">
<INPUT TYPE=TEXT NAME=\"find\" VALUE=\"$so{'find'}\">
<INPUT TYPE=HIDDEN NAME=\"q\" VALUE=\"$so{'q'}\">
<INPUT TYPE=BUTTON VALUE=\"$so{'W_SEARCH_DIRECTORY'}\" $AJAXONBUTTON>
</FORM>
</TR>
</TABLE>
");

	# Parse string to something sensible.
	$so{'find'} =~ tr/[A-ZÄÖÅ]/[a-zäöå]/;
	$so{'find'} =~ s/[^a-zäöå0-9]/ /g;
	$so{'find'} =~ s/\s+/ /g;
	#$so{'find'} =~ s/ /_/g;
	# Make a query.
	my $MAX_DIR_RESULTS = 250;
	if($so{'find'} ne "")
	{
		print("
<DIV ID=\"SBOX\" NAME=\"SBOX\">
<BLINK><H2>$so{'W_SEARCHING'}</H2></BLINK>
</DIV>
		");
		@qlst = LoadList("grep -i \"$so{'find'}\" $DB/directory/Recreation.txt|");
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/News.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Health.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Science.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Sports.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Home.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Games.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/Computers.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldSuomi.txt|"));
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldSvenska.txt|"));
		#push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldNederlands.txt|"));	## TOO BIG, skip it
		#push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopWorldDeutsch.txt|"));		## TOO BIG, skip it
		push(@qlst, LoadList("grep -i \"$so{'find'}\" $DB/directory/TopRegionalEuropeFinland.txt|"));
		# Build HTML of search results.
		$DIRECTORY_SEARCH_RESULTS = ("");
		for($i=0; $i<($#qlst+1) && $i<$MAX_DIR_RESULTS; $i++) {
			$qlst[$i] =~ s/^Top\///;
			$qlst[$i] =~ s/^(.+\/)(index\.rdf)$/$1/;
			my $entry = $qlst[$i];
			$entry=~s/^(.+)\/$/$1/;
			if(!$gotentry{$entry}) {
				$DIRECTORY_SEARCH_RESULTS .= ("
		<P><A HREF=\"?q=$entry\">$entry</A></P>
				");
				$gotentry{$entry}++;
			}
		}
		if($#qlst<=0) {
			$DIRECTORY_SEARCH_RESULTS = ("
	$so{'W_NO_MATCHES'}
"			);
		}
		print("
<SCRIPT language=\"JavaScript\">
document.getElementById('SBOX').style.display='none';
</SCRIPT>
			");
	}

	#
	my $NAVIGATION_BAR = ("
<TABLE cellspacing=0 cellpadding=4 width=100%
	style=\"background: #202080\"\">
<TR>

<TD width=30%>
<FONT COLOR=WHITE><H3>$NAVI</H3></FONT>
</TD>

<TD width=70%>

$NAVI_SEARCH

</TD>

</TR>
</TABLE>
");

	##
	#
	$CHOOSER_HTML = BuildChooseIndexHtml();
	$WEB_SEARCH_FORM_UPPER = ("
                <form method=\"get\" action=\"$CGICMD\" name=\"FORM1\" class=formx $DIS target=\"sif\">   
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"text\" name=\"q\" size=\"40\" value=\"$ORGQ\" $DIS>
			$CHOOSER_HTML
                        <input type=\"submit\" value=\"$so{'W_SEARCH'}\" class=buttonx $AJAXONBUTTON $DIS>
                </form>
");

	#
	print("
<TABLE width=100% height=1 cellpadding=0 cellspacing=0
	bgcolor=\"0000C0\">
<TR>
<TD>
</TD>
</TR>
</TABLE>




<TABLE width=100% height=100 cellpadding=0 cellspacing=0
	background=\"/images/NewAltseLogo.gif\">
<TR>
<TD width=30% onClick=\"window.location.href='/';\"
	style=\"cursor: pointer; cursor: hand;\">
</TD>

<TD width=10%>
</TD>

<TD width=60%>
$WEB_SEARCH_FORM_UPPER

</TD>
</TR>
</TABLE>


<!--- Ajax loader animation --->
<DIV id=\"ldr\" align=center><IMG SRC=\"/images/loader.gif\" valign=middle></DIV>
<!--- temporarily invisible container --->
<DIV ID=\"maincontent\"
        style=\"display: none;\">


<TABLE width=100% height=1 cellpadding=3 cellspacing=0>
<TR>
<TD>
<A HREF=\".\" class=dark>
<FONT size=6>
$so{'W_WEB_DIRECTORY'}
</FONT>
</A>
</TD>
</TR>
</TABLE>

$KADS1

$NAVIGATION_BAR

<DIV ALIGN=\"center\">
        <iframe width=\"100%\" height=\"32\"
                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
                loading=\"lazy\”
                name=\"sif\" id=\"sif\">
        </iframe>
</DIV>

$DIRECTORY_SEARCH_RESULTS

<DIV>
<table width=700 bgcolor=$TVAR cellpadding=0 cellspacing=0>
<tr>
<td>

			");

	#
	if($so{'q'} eq "") {
		FinDirectorySections();
	} else {
		ShowDirectory();
	}

	#
	print("
<BR>
<DIV STYLE=\"position: absolute;\">
<iframe src=\"http://www.facebook.com/widgets/like.php?href=http://$ALTSE_HOST$ENV{'REQUEST_URI'}\"
        scrolling=\"no\" frameborder=\"0\"
        style=\"border:none; width:450px; height:80px\"></iframe>
</DIV>
<BR>

</td>
</tr>
</table>
<TABLE width=100% height=100 cellpadding=0 cellspacing=0
	background=\"/images/NewAltseLogo2.gif\">
<TR>
<TD>
</TD>
</TR>
</TABLE>
</DIV>

</DIV>
<SCRIPT LANGUAGE=\"JavaScript\">
document.getElementById('ldr').innerHTML = '';
document.getElementById('maincontent').style.display = 'block';
</SCRIPT>
");
}

TRUE;
