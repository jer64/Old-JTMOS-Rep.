#
sub PutThisToDlimLog {
        open($f, ">>$DB/sdb/logs/dlim.log");
        print $f "$_[0]\n";
        close($f);
}

1;

