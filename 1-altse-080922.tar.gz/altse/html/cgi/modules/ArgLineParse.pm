###########################################################################################
#
# Parses CGI query string and puts it's variables to %so -hashtable.
#
sub ArgLineParse
{
        my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co,@s,@s2,$change,$r,$l,@sp,@cookies,$p);

	#
#	$CGI_QUERY = new CGI;
	if($ARGLINEPARSE_DONE_ONCE) {
		return $ENV{'REQUEST_METHOD'};
	} else {
		$ARGLINEPARSE_DONE_ONCE = 1;
	}

	#
	$ENV{'NW_LANGUAGE'} = DetectLanguage();

        #
	$p = $ENV{'HTTP_REFERER'};
	$p =~ s/^http:\/\/www\.vunet\.org//;
	if($ENV{'HTTP_REFERER'}=~/www\.vunet\.org/ ||
	$ENV{'HTTP_REFERER'}=~/vuutiset\.info/)
	{
	        if($p=~/^\/uutiset/) { $ENV{'NW_LANGUAGE'} = "fi"; }
	        if($p=~/^\/xinwen/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/nieuws/) { $ENV{'NW_LANGUAGE'} = "nl"; }
	        if($p=~/^\/nyheter/) { $ENV{'NW_LANGUAGE'} = "se"; }
	        if($p=~/^\/swedish/) { $ENV{'NW_LANGUAGE'} = "se"; }
	        if($p=~/^\/favorites/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/404\.pl$/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/news/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/progressive/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/bush/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/picks/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/english/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/videos/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/downloads/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/section\=videos/) { $ENV{'NW_LANGUAGE'} = "en"; }
	        if($p=~/^\/TopTen\.pl/) { $ENV{'NW_LANGUAGE'} = "en"; }
	}

	#
	if($ENV{'NW_LANGUAGE'} eq "en") { $so{'FP_SECTION'} = "english"; }

        # Read in text.
        $ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
        if ($ENV{'REQUEST_METHOD'} eq "POST")
        {
		read(STDIN, $tmp, $ENV{'CONTENT_LENGTH'});
        }
        else
        {
	        # Get section argument.
	        $tmp = $ENV{'QUERY_STRING'};
        }

	#
        $tmp =~ s/\+/ /ig;
	$tmp =~ s/%3D/!FCE2E37B!/gi;
	$tmp =~ s/%26/!FF325136!/gi;
        $tmp =~ s/%(..)/pack("C", hex($1))/eg;

	#
        @s = split("\&", $tmp);

        # Section always defaults to none
        # (always show front page if no section= specified).
        $so{'section'} = "";
	# No redirection as default.
	$so{'redirect'} = "";

        #
        for($i=0,$change=0; $i<($#s+1); $i++)
        {
                #
                if($s[$i] =~ /\=/)
                {
                        #
                        $change = 1;

                        #
                        @s2 = split("\=", $s[$i]);

                        #
                        $so{$s2[0]} = $s2[1];
			$so{$s2[0]} =~ s/!FCE2E37B!/\=/g;
			$so{$s2[0]} =~ s/!FF325136!/\&/g;
                }
        }

        #
        if($change && !$DONT_AFFECT_DB) { SaveProfile(GetUserID()); }

	#
	$l = $so{'section'};
        if($l eq "english" || $l eq "videos" || $l eq "picks"
                || $l eq "commodore"
                || $l eq "software"
                || $l eq "progressive"
                || $l eq "global"
                || $l eq "bush")
	{
		$ENV{'NW_LANGUAGE'} = "en";
		if($so{'FP_SECTION'} eq "") { $so{'FP_SECTION'} = "english"; }
	}
        if($l eq "nyheter")
	{
		$ENV{'NW_LANGUAGE'} = "se";
		if($so{'FP_SECTION'} eq "") { $so{'FP_SECTION'} = "swedish"; }
	}

	# Fetch cookies.
	@cookies = split(/\;/, $ENV{'HTTP_COOKIE'});
	for($i=0; $i<($#cookies+1); $i++)
	{
		$str = $cookies[$i];
		@sp = split(/\=/, $str);
		$str = "\"cookie\_$sp[0]";
		$str =~ s/[^a-z0-9_]//g;
		$sp[1] =~ s/%(..)/pack("C", hex($1))/eg;
		$so{$str} = $sp[1];
	}

	#
	$ENV{'NW_LOGO_LANGUAGE'} = $ENV{'NW_LANGUAGE'};

	#
#	if($so{'cookie_language'} eq "English")    { $ENV{'NW_LANGUAGE'} = "en"; }
#	if($so{'cookie_language'} eq "Nederlands") { $ENV{'NW_LANGUAGE'} = "nl"; }
#	if($so{'cookie_language'} eq "Svenska")    { $ENV{'NW_LANGUAGE'} = "se"; }
#	if($so{'cookie_language'} eq "Suomi")      { $ENV{'NW_LANGUAGE'} = "fi"; }

        #
	return $ENV{'REQUEST_METHOD'};
}

1;
