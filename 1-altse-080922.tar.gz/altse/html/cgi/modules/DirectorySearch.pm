# Flush STDERR buffer after each command
#select(STDERR);
#$| = 1;
#
# Detailed Search
#
# Basics is this splits the query into words split / /.
#
sub DetailedCoreDirectorySearch
{
	my $find = $_[0];
	my ($i,@sp);

	$DIRECTORY_SEARCH_RESULTS = ("");
	#$DIRECTORY_SEARCH_RESULTS = ("
	#		<DIV ID=\"SBOX\" NAME=\"SBOX\">
	#		<BLINK><H2>$so{'W_SEARCHING'}</H2></BLINK>
	#		</DIV>
	#		");
	
	if( CoreDirectorySearch($find) < 0 )
	{
		#
		# No luck, try harder:
		#
		@sp = split(/\s/, $find);
		if($#sp >= 0)
		{
			for($i=0; $i<($#sp+1); $i++)
			{
				CoreDirectorySearch($sp[$i]);
			}
		}
		else
		{
    $DIRECTORY_SEARCH_RESULTS .= ("
                $so{'W_NO_MATCHES'}
                "                       );
		}
	}
	
	#
	return $DIRECTORY_SEARCH_RESULTS;
}

#########################################################
# CORE DIRECTORY SEARCH PROGRAM.
#########################################################
sub CoreDirectorySearch
{
	my ($i,$MAX_DIR_RESULTS);
	my $find;
	
	#
	$find = $_[0];
	
		# Parse string to something sensible.
		$find =~ tr/[A-ZÄÖÅ]/[a-zäöå]/;
		$find =~ s/[^a-zäöå0-9]/ /g;
		$find =~ s/\s+/ /g;
		#$find =~ s/ /_/g;
		# Make a query.
		my $MAX_DIR_RESULTS = 250;
		if($find ne "")
		{
			# Lets go.
			@qlst = LoadList("grep -i \"$find\" $DB/directory/Recreation.txt|");
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/News.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/Health.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/Science.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/Sports.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/Home.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/Games.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/Computers.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/TopWorldSuomi.txt|"));
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/TopWorldSvenska.txt|"));
			#push(@qlst, LoadList("grep -i \"$find\" $DB/directory/TopWorldNederlands.txt|"));	## TOO BIG, skip it
			#push(@qlst, LoadList("grep -i \"$find\" $DB/directory/TopWorldDeutsch.txt|"));		## TOO BIG, skip it
			push(@qlst, LoadList("grep -i \"$find\" $DB/directory/TopRegionalEuropeFinland.txt|"));
			# Build HTML of search results.
			for($i=0; $i<($#qlst+1) && $i<$MAX_DIR_RESULTS; $i++) {
				$qlst[$i] =~ s/^Top\///;
				$qlst[$i] =~ s/^(.+\/)(index\.rdf)$/$1/;
				my $entry = $qlst[$i];
				$entry = FixScands($entry);
				$entry=~s/^(.+)\/$/$1/;
				if(!$gotentry{$entry}) {
					$DIRECTORY_SEARCH_RESULTS .= ("
				<P><A HREF=\"?q=$entry\">$entry</A></P>
					");
					$gotentry{$entry}++;
				}
			}
		}
    
    #
#    print "<H1>qlst cnt = $#qlst</H1>";
    return $#qlst;
}

1;