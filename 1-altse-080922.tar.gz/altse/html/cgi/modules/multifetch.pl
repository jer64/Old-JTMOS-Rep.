#!/usr/bin/perl
# MULTI FETCH
# Fetches multiple results, instead of max. paired search normally.
##############################################################################
#
if($ENV{'HOME'} eq "" || $ENV{'HOME'} =~ /^\/root$/) {
        $ENV{'HOME'} = "/home/vai";
} else
{
}
#print "ENV/HOME = \"$ENV{'HOME'}\".\n";
require "$ENV{'HOME'}/altse/html/cgi/modules/AltseOpenConfig.pm";
require "$ENV{'HOME'}/altse/html/cgi/modules/LoadList.pm";
#
AltseOpenConfig();

#
main();

#
sub main
{
        my ($i,$i2,$i3,$i4,@results);
        
        #
        $quoted_searches = join(" ", @ARGV);
        $quoted_searches =~ s/'/\"/;
        my @q = split(/\".*\"/, $quoted_searches);
        #
        for($i=0; $i<($#q+1); $i++)
        {
                #
                push(@results, LoadList("$ENV{'HOME'}/altse/bin/is $q[$i] -mp 21 -f -i 0|"));
        } 

        #
        for($i=0; $i<($#ARGV+1); $i++)
        {
                if(
                        ($ARGV[$i] eq "www" ||
                        $ARGV[$i] eq "com" ||
                        $ARGV[$i] eq "org" ||
                        $ARGV[$i] eq "info" ||
                        $ARGV[$i] eq "net")
                ) { goto dont_search_this_one; }
        
                # Do a single word search first.
                push(@results, LoadList("$ENV{'HOME'}/altse/bin/is $ARGV[$i] -mp 21 -f -i 0|"));
                # Do search with pairs.
                my $inc_n = 0;
                if($ARGV[$i+1] ne "") {
                        # two words
                        push(@results, LoadList("$ENV{'HOME'}/altse/bin/is \"$ARGV[$i] $ARGV[$i+1]\" -mp 21 -f -i 0|"));
                        $inc_n ++;
                }
                if($ARGV[$i+2] ne "") {
                        # three words
                        push(@results, LoadList("$ENV{'HOME'}/altse/bin/is \"$ARGV[$i] $ARGV[$i+1] $ARGV[$i+2]\" -mp 21 -f -i 0|"));
                        $inc_n ++;
                }
                if($ARGV[$i+3] ne "") {
                        # four words
                        push(@results, LoadList("$ENV{'HOME'}/altse/bin/is \"$ARGV[$i] $ARGV[$i+1] $ARGV[$i+2] $ARGV[$i+3]\" -mp 21 -f -i 0|"));
                        $inc_n ++;
                }
                
                if($inc_n) {
                        $i += $inc_n;
                        continue;
                }
                

                #if($i>=1)
                #{
                        for($i2=0; $i2<($#results+1); $i2++)
                        {
                                my ($key,@sp);
                                @sp = split(/ /, $results[$i2]);
                                $key = $sp[1]; # key = page number
                                $al{$key} += $sp[0]; # add up the score
                                #print $sp[0]."\n";
                        }
                #}

                #
dont_search_this_one:
        }

        #
        my (@ent);
        
        #
        foreach $key (keys %al)
        {
                push(@ent, (sprintf "%1.8d %d", $al{$key},$key));
        }
        
        #
        @ent = reverse sort @ent;
        
        #
        for($i=0; $i<($#ent+1); $i++)
        {
                print $ent[$i] . "\n";
        }
        
        #
        
        #
        
}

#
