#
$freesms_html = ("
<style> .SubTableHeader { background-color: #ffcc33; font-family:Verdana, Geneva, Arial, Helvetica, sans-serif; font-size: 15; }
	.TableContents { background-color: #F2F2F2; height: 24px; font-family:Verdana, Geneva, Arial, Helvetica, sans-serif; font-size: 15; padding-left: 5px; }
	.FormElement { border: silver 1px solid; background-color: #F1F7F7; font-family:Verdana, Geneva, Arial, Helvetica, sans-serif; font-size: 15; }
	</style>

<form action=http://www.ilmainensms.fi/SMSForm.aspx method=post name=SMSForm onsubmit='return validate()' >
<input type=\"hidden\" name=\"AffiliateID\" value=\"26305\"> <input type=\"hidden\" name=\"ReturnURL\" value=\"http://www.medianews.today\">
<table width=\"300\" style=\"BORDER-RIGHT:black 1px solid; BORDER-TOP:black 1px solid; BORDER-LEFT:black 1px solid; BORDER-BOTTOM:black 1px solid\">
	<tr>
		<td class=\"SubTableHeader\" colspan=\"2\">
			<a href=\"http://www.freebiesms.co.uk\">
				Lähetä tekstiviesti
			</a>
		</td>
	</tr>
	<tr>
		<td class=\"TableContents\" valign=\"top\" style=\"WIDTH: 52px\">
			Vastaanottajan Numero
			:
		</td>
		<td>
			<input class=\"FormElement\" name=\"ToMobile\" value=\"00358\">
		</td>
	</tr>
	<tr>
		<td class=\"TableContents\" valign=\"top\" style=\"WIDTH: 52px\">
			Vastaanottajan Nimi
			:
		</td>
		<td>
			<input class=\"FormElement\" name=\"ToName\" maxlength=\"10\">
		</td>
	</tr>
	<tr>
		<td class=\"TableContents\" valign=\"top\" style=\"WIDTH: 52px\">
			Puhelimesta
			:
		</td>
		<td>
			<input class=\"FormElement\" name=\"FromMobile\" value=\"00358\">
		</td>
	</tr>
	<tr>
		<td class=\"TableContents\" valign=\"top\" style=\"WIDTH: 52px\">
			Lähettäjän nimi
			:
		</td>
		<td>
			<input class=\"FormElement\" name=\"FromName\" maxlength=\"10\">
		</td>
	</tr>
	<tr>
		<td class=\"TableContents\" valign=\"top\" colspan=\"2\">
			Viesti
			:
			<br>
			<textarea class=\"FormElement\" onkeydown=\"limitLength(this,140)\" name=\"Message\" rows=\"8\" cols=\"27\" name=\"Message\"></textarea>
		</td>
	</tr>
	<tr>
		<td style=\"WIDTH: 52px\">
			<input name=\"Migrated_AffiliateForm:Submit1\" type=\"submit\" id=\"Migrated_AffiliateForm_Submit1\" value=\"Lähetä\" onclick=\"validate\" />
		</td>
		<td align=\"right\">
			<a ONCLICK=\"alert('Please see www.freebiesms.co.uk for terms and conditions')\">T&amp;C</a>
		</td>
	</tr>
</table>
</form>
<script language=\"javascript\">
	
	function limitLength(textarea,maxlimit)
	{
		if (textarea.value.length > maxlimit) 
		textarea.value = textarea.value.substring(0, maxlimit);
	}
	
	function validate()
	{
		var Prefix = \"00358\"
		
		var ToMobile = window.document.SMSForm.ToMobile.value;
		var FromMobile = window.document.SMSForm.FromMobile.value;
		var ToName = window.document.SMSForm.ToName.value;
		var FromName = window.document.SMSForm.FromName.value;
		var Message = window.document.SMSForm.Message.value;
		
		// Ensure To-Mobile number is international format & from correct country
		if (ToMobile.indexOf(Prefix)!=0)
		{
			alert(ToMobile + \" Puhelinnumero ei kelpaa.\");
			return false;
		}
		// Ensure From-Mobile number is international format
		if (FromMobile.indexOf(\"00\")!=0)
		{
			alert(FromMobile + \" Puhelinnumero ei kelpaa.\");
			return false;
		}		
		
		// Ensure names are filled in
		if (ToName.length<3 || FromName.length<3)
		{
			alert(\"Nimesi tulee olla 3 - 11 kirjainta pitkä.\");			
			return false;
		}		
		
		// To and from cannot be the same.
		if (FromMobile == ToMobile)
		{
			alert(\"Viestin lähettäjä ja vastaanottaja eivät voi olla samoja\");
			return false;
		}
		
		if (Message.length==0)
		{
			alert(\"Viestisi on tyhjä. Ole hyvä ja kirjoita viesti siihen tarkoitettuun kenttään\");
			return false;
		}
		
		return true;
	}
	
</script>
");

1;