############################################################################################################
#
# Frontpage.pm - Search Engine Front Page.
# (C) 2016-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
#
# New feature: news feeds.
#
require "./modules/ajaxloader.pm";
require "./modules/kk_mainos.pm";
require "./modules/BuildChooseIndexHtml.pm";
require "./modules/JsPrint.pm";
require "./modules/ProduceNewsFeedsHTML.pm";
require "./modules/SearchFormModule.pm";

############################################################################################################
#
sub SearchFrontPage
{
	SearchFormModule("Frontpage");
}

################################################################
#
sub SubmitNewUrlForm
{
	if($so{'WWW_SERVICE_STATE'}!=1)
	{
#		$DIS = "disabled";
	}
	print ("
	<!---
		<table width=400 cellpadding=0 cellspacing=0>
		<tr>	
		<td>
                <form method=\"get\" action=\"$CGICMD\" name=\"FORM1\" class=formx>
			Submit following URL to the search engine:<br>
			URL: <input type=\"text\" name=\"q\" size=\"40\" value=\"$so{'q'}\" $DIS>
			<input type=\"hidden\" name=\"submit\" value=\"2\">
                        <br>
			<input type=\"submit\" value=\"Submit URL\" class=buttonx $AJAXONBUTTON $DIS>
		<DIV name=ajaxloader id=ajaxloader>$LOADERHTML</DIV>
                </form>
		</td>
		</tr>
		</table>
	----->

                <script language=\"javascript\">
                function altse_SearchFocusOnQueryString()
                {
                        document.FORM1.q.focus();
                }
                </script>

		");
}

########################################################################################
#
sub Hints
{
	my ($i,$i2,$str,$str2,@lst);

	#
	print("
		<br>

		<table cellpadding=1 cellspacing=0 border=0 bgcolor=#0000FF>
		<tr>
		<td>

		<table cellpadding=8 cellspacing=0 width=300 bgcolor=\"$TVAR\">
		<tr>
		<td>
		<div align=center>Hints</div>");

	#
	if( ($figure1=
($tmpvar=join("\n",LoadList("dictsize|")) 
)>0 || 1) ) {
		$dbsz_k =~ s/^([0-9]+).*$/$1/;
		if($dbsz_k<16) {
			goto skip_links_bar;
		}
	}
	@lst = LoadList("$DB/altse/hints.txt");
	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		$str = $lst[$i];
		$str =~ s/\(.*\)//g;

		#
		print("
			<div style=\"text-align: justify;\">
			<font size=2>
			<a href=\"$CGICMD?cmd=go&st=$so{'st'}&q=$str\" class=$FONTCC2>
			- $lst[$i]
			</a>
			</font>
		");
	}


	print("
		</div>
		");

skip_links_bar:
	print("

		</td>
		</tr>
		</table>

		</td>
		</tr>
		</table>

		");

}




########################################################################################
#
sub SubmitNewUrl
{
		#
		print("
			<table width=350 cellpadding=8 cellspacing=0
				bgcolor=\"#E0F0FF\">
			<tr>
			<td>
			");

		#
		if($so{'submit'}==1)
		{
			SubmitNewUrlForm();
		}
		else
		{
			#
			if(!($ORGQ=~/^.*\.../))
			{
				#
				print("
				Bad URL: \"<b>$ORGQ</b>\"<br>
				");
			#	if(!($so{'q'}=~/http/)) { 
			#		print("URL must begin with <b>http://</b><br>");
			#	}
				print("
				<a href=\"javascript:history.go(-1)\">
				> try again
				</a>
					");
			}
			else
			{
				#
				open($f, ">>$DB/suggested_urls.txt") || die "can't add";
				print $f "$ORGQ\n";
				close($f);

				#
				open($f, ">>$DB/todo.txt") || die "can't add 2";
				print $f "$ORGQ\n";
				close($f);

				#
				print("
					URL added successfully.<br>
					<br>
					The URL is queued to be processed.<br>
					<br>
					<div align=right>
					<a href=\"$CGICMD\" class=$FONTCC3>Click here to continue ...</a><br>
					<font size=2>
					<a href=\"$CGICMD?submit=1\" class=$FONTCC3>Or perhaps add another?</a>
					</font>
					</div>
					");
			}

			#
		}

		#
		print("
			</td>
			</tr>
			</table>
			");
}

#
sub AdminTools
{
	#
		print("
<br>
			");

		#
		if( $ENV{'REMOTE_ADDR'} eq $ADMIN_IP )
		{
			#
			print("
<div align=center>
<a href=\"/monitor/\" class=$FONTCC>
<img src=\"images/bb073.gif\" class=bulletin border=0>
Altse monitor
</a>
</div>

<div align=center>
<a href=\"/cgi-bin/admin/editart.pl?FILE=$SEARCH_LOG&RETURL=/search/\" class=$FONTCC>
<img src=\"images/bb073.gif\" class=bulletin border=0>
View search log
</a>
</div>

<div align=center>
<a href=\"/cgi-bin/admin/editart.pl?FILE=$DB/suggested_urls.txt&RETURL=/search/\" class=$FONTCC>
<img src=\"images/bb073.gif\" class=bulletin border=0>
View suggested URLs
</a>
</div>

				");

		}

		#
		if($ADVERTISE_ALTSE)
		{
		print("
<div align=center>
<a href=\"/archive\" class=$FONTCC>
<img src=\"images/bb073.gif\" class=bulletin border=0>
$so{'W_DOWNLOAD_ALTSE'}
</a>
</div>

<div align=center>
<a href=\"mailto:jari.t.tuominen\@gmail.com\" class=$FONTCC>
<img src=\"images/bb073.gif\" class=bulletin border=0>
$so{'W_ADD_NEW_URL'}
</a>
</div>
		");
		}

		#
		print("
		<TABLE bgcolor=#FFFF00 align=center>
		<TR>
		<TD>
		<div align=center>
		<font size=4 color=#C00000>
		$SITE_STATEMENT
		$COPYRIGHT
		</font>
		</div>
		</TD>
		</TR>
		</TABLE>
		<br>
		");
}

################################################################
#
# Text Search Beginning...
#
sub TextSearchForm
{
	#
	my ($i,$i2,$i3,$i4,$str,$str2,@sp);

	#
	if($so{'q'} eq "")
	{
		$BIM = "";
	}
	else
	{
		if($_[0]==1)
		{
			$BIM = $LOGO1;
		}
		if($_[0]==2)
		{
			$BIM = $LOGO2;
		}
	}

	#
	print("
$AJAXLOADERJS
<!---
		<DIV name=ajaxloader id=ajaxloader style=\"position:absolute; left: 6; top: 8;\">$LOADERHTML</DIV>
		-->

		<table width=\"100%\" height=\"96\" cellpadding=\"0\" cellspacing=\"0\"
			background=\"$BIM\">
		<tr valign=\"top\">

		<td width=\"20%\"
			class=\"withLink\">

		<table width=\"100%\" height=\"100%\"
			onClick=\"window.location.href='$CGICMD'\"
			class=\"withLink\">
		<tr class=\"withLink\”>
		<td class=\"withLink\">
-		</td>	
		</tr>
		</table>

		</td>

		<td width=10%>
		</td>

		<td width=60%>
		");

	#
	print("
		<div>
		");

		#
		@hak = LoadList("$DB/altse/bin/ts $DB/structure.dir $W[0] 2>/dev/null|");
		#
		if( $#hak >= 0 )
		{
			$sf2 = "<select name=q>\n";
			for($i=0; $i<($#hak+1); $i++)
			{
				@sp = split("/", $hak[$i]);
	$sf2 = "$sf2<option value=\"$hak[$i]\">$sp[$#sp-1] / $sp[$#sp]</option>\n";
			}
			$sf2 .= "</select>\n";
			$sf2 .= "<input type=\"submit\" value=\"$so{'W_GO_TO_DIRECTORY'}\" class=buttonx $AJAXONBUTTON>\n";
			$sf2 .= "<input type=\"hidden\" name=\"cmd\" value=\"go\">\n";
		}
		

		# DISABLED - OBSOLETE FOR NOW
		#@syn = LoadList("$DB/altse/bin/syn $W[0] 2>/dev/null|");
		#
		$sf = "";
		#
		if( $#syn >= 0 )
		{
			$sf = "$sf<select name=q>\n";
			for($i=0; $i<($#syn+1); $i++)
			{
				$sf = "$sf<option>$syn[$i]</option>\n";
			}
			$sf = "$sf</select>\n";
			$sf = "$sf<input type=\"submit\" value=\"$so{'W_SEARCH'}\" class=buttonx $AJAXONBUTTON>\n";
			$sf = "$sf<input type=\"hidden\" name=\"cmd\" value=\"go\">\n";
		}

		#
		if($so{'WWW_SERVICE_STATE'}!=1)
		{
#			$DIS = "disabled";
		}

		#
		if($so{'st'} ne "image") {
			$CHECKED1 = "checked";
			$CHECKED2 = "";
		} else {
			$CHECKED1 = "";
			$CHECKED2 = "checked";
		}

		#
		$CHOOSE_INDEX_HTML = BuildChooseIndexHtml();

		#
		print ("
		<table width=100% height=48>
		<tr>
		<td>

		<!-------------- MAIN SEARCH FORM (ACTIVE) ------------------->
                <form method=\"get\" action=\"$CGICMD\" name=\"FORM1\" class=formx $DIS>
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"text\" name=\"q\" size=\"40\" value=\"$ORGQ\" $DIS CLASS=\"altseform_text\"
                        	style=\"width: 300;
padding: 0px 0x; margin: 0px 0;
box-sizing: border-box; font-size: 24; box-sizing: content-box;
display: flex; float: none; line-height: normal; position: static; z-index: auto; \">
			<input type=\"radio\" name=\"st\" value=\"text\" $CHECKED1> $so{'W_TEXT'}
			<input type=\"radio\" name=\"st\" value=\"image\" $CHECKED2> $so{'W_IMAGE'}

			$CHOOSE_INDEX_HTML

                        <input type=\"submit\" value=\"$so{'W_SEARCH'}\" class=buttonx $AJAXONBUTTON $DIS
                        style=\"width: 150;
padding: 0px 0px; margin: 0px 0;
box-sizing: border-box; font-size: 16; box-sizing: content-box;
display: flex; float: none; line-height: normal; position: static; z-index: auto; \"
                        >
                </form>
		<form method=\"get\" action=\"/cgi-bin/directory.pl\" name=\"FORM2\" class=formx>
		$sf2
		</form>

		<form method=\"get\" action=\"$CGICMD\" name=\"FORM2\" class=formx>
		$sf
		</form>

		</td>
		</tr>
		</table>
		");

		#
		if($so{'q'} eq "")
		{
			print("
		                <script language=\"javascript\">
		                function altse_SearchFocusOnQueryString()
		                {
					document.FORM1.q.focus();
		                }
		                </script>
				");
		}

	#
	print("
		</div>
		");


	#
	print("

		</td>
		</tr>
		</table>
		");

}

##########################################################################################################
#
# View result.
#
sub ViewResult
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,
		$ap,$str,$str2,$fn,$t,$pm,$f,$sl,$o,
		$big,$score,$nfn,$tmp,$fn_ils,@ils,$host,$x,$y,@li);

	################################################
	$score = $_[1];
	$tree="";
	$lisa = "<br>";

	################################################
	#
	# Check other rules.
	#

	#
	$sl = 0; # ...

	#------------------------------------------------------------
	# Let's fetch the article...
        $sz = (stat("$altse/$_[0]"))[7];
	$title="";
	if($sz<=(1024*128))
	{
		#
		$nfn = $_[0];
		$nfn =~ s/^(.*)\.[a-z]*$/$1/g;
		$nfn = "$DB/altse/cid/data/$_[4]/x$_[3].dar";
		if(-e $nfn) { @li = LoadList($nfn); } else { print "not found: $nfn "; return(); }
	}
	else
	{
		#
		$title="Big file (>128K)";
	}

	#
#	print("
#		<table cellpadding=4 cellspacing=0 align=left>
#		<tr>
#		<td>
#		");
#	PrintImage($_[0], $_[3]);
#	print("
#		</td>
#		</tr>
#		</table>
#		");

	#------------------------------------------------------------
	# VIEW ARTICLE PREVIEW
	#------------------------------------------------------------
	#

	#
	$URL = "$_[0]";
	$URL =~ s/\.\///;
	$URL =~ s/^altse\//http:\/\//;
	$URL =~ s/(\/)index\.html/$1/;

	#
	$RURL = $URL;
	$RURL =~ s/^(.{30}).*(.{30})$/$1\.\.\.$2/;

	#
	if($title=~/^\s*$/ || $title eq "" || length($title)<3)
	{
		$title = "UNTITLED";
	}

	#
	$o=1;
	$str = $li[$o+3];
#	$str = SaneString($str);
	$str =~ tr/[A-Z���]/[a-z���]/;
	$tit = $li[$o+2];
	$tit =~ tr/[a-z���]/[A-Z���]/;
	$tit = SaneString($tit);
	$tit =~ s/\&[A-Z]*\;//g;
	if($tit=~/^\s*$/) { $tit = "UNTITLED"; }
	if($str=~/^\s*$/) { $tit = "No valid content available."; }
	print ("
			<br>
			<a href=\"http:\/\/$URL\" class=$FONTCC3><b>$tit</b></a><br>
			<font color=#C0C0C0>$str<br>
			<font size=2 color=\"#00A020\">$RURL - $pm</font><br>
			");
}

################################################################
#
sub Controls1
{
	#
	print("
                        <input type=\"hidden\" name=cmd   value=\"go\">
                        <input type=\"hidden\" name=q     value=\"$so{'q'}\">
			<input type=\"hidden\" name=start value=\"$_[0]\">
	");
			#<input type=\"hidden\" name=where value=\"$so{'where'}\">
			##<input type=\"hidden\" name=co    value=\"$so{'co'}\">
			##<input type=\"hidden\" name=st    value=\"$so{'st'}\">
                        ##<input type=\"hidden\" name=mis   value=\"$so{'mis'}\">
}

################################################################
#
sub Controls
{
	my ($i,$i2,$i3,$i4,$x,$x2,$v);

	#
	if($so{'st'} eq "image") {
		$SHOW = $images_per_page;
	}
	$i =  $so{'start'}-$SHOW; if($i<0){$i=0;}
	$i2 = $so{'start'}+1+$SHOW-1;

	#
	print("
				<br>
				<div align=center>

				<table width=300 cellpadding=0 cellspacing=0>
				<tr valign=top>
		");

	#
	if(1)
	{
		if($i >= 0 && $so{'start'} != 0) { $DIS=""; } else { $DIS="disabled"; }
		#
		print("<TD width=40>");
		if($DIS eq "")
		{
			print("
			<center><a href=\"$CGICMD?q=$so{'q'}&st=$so{'st'}&start=$i&cmd=go&indexnr=$so{'indexnr'}\"><< Edellinen - Previous Page</a></center>
				");
		}
		print("</TD>");
		$DIS = "";
	}

	#
	if(1)
	{
		#
		$sx = $so{'start'} - $SHOW*2; if($sx<0) { $sx=0; }
		for($x=$sx,$x2=0; $x2<5; $x+=$SHOW,$x2++)
		{
			#
			$v = $x/$SHOW;
			if( ($LAST_PAGE eq "" && $x<=$#results) || ($LAST_PAGE ne "" && $x<=($LAST_PAGE*10))  )
			{
				#
				if($x==$so{'start'}) { $for="dark"; } else { $for=""; }

				#
			print("<td width=20>
				<a href=\"$CGICMD?q=$so{'q'}&indexnr=$so{'indexnr'}&st=$so{'st'}&start=$x&cmd=go\"
				target=\"_blank\"
				style=\"COLOR: #000000; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;\">
				<center><font size=24> <IMG SRC=\"/images/485px-Simpleicons_Interface_magnifier-1.svg.png\" valign=\"middle\"
					width=\"20\" height=\"20\" alt=\"\" title=\"Sivu Numero $x - Page Number $x\">
				 Sivu $x</font></center>	 
				</a>
				</td>");
			}
		}
	}

	#
	if(1)
	{
		if($i >= 0 && $so{'start'} != 0) { $DIS=""; } else { $DIS="disabled"; }
		#
		print("<TD width=40>");
		if($DIS eq "")
		{
			print("
				<center><a href=\"$CGICMD?q=$so{'q'}&st=$so{'st'}&start=$i2&cmd=go&indexnr=$so{'indexnr'}\">Seuraava sivu - Next Page >></a></center>
				");
		}
		print("</TD>");
		$DIS = "";
	}

	#
	print("
				</tr>
				</table>
				</div>
				<br>
		");
}

################################################################
#
sub ResultInfo
{
	my ($i,$i2,$i3,$i4);

	#
	$NO_HITS = 0;

	#
	if($so{'st'} eq "image") {
		$SHOW = $images_per_page;
	}

	#
	$i =  $so{'start'}+1;
	$i2 = $so{'start'}+1+$SHOW-1;
	if($i2 > ($#results+1))
	{
		$i2 = $#results;
	}
	$i2++;
	$i3=sprintf "%d", $i2/10;
	$i3*=10;
	if($i3>=$i) { $i2=$i3; }

	#
	if($so{'st'} eq "0") { $WHERE_AM_I = "$so{'W_TEXT'}"; }
	if($so{'st'} eq "1") { $WHERE_AM_I = "$so{'W_AUDIO'}"; }
	if($so{'st'} eq "2") { $WHERE_AM_I = "$so{'W_VIDEO'}"; }
	if($so{'st'} eq "") { $WHERE_AM_I = "$so{'W_TEXT'}"; }
	if($so{'st'} eq "image") { $WHERE_AM_I = "$so{'W_IMAGE'}"; }

	#
	print("
		<table width=100% cellpadding=2 cellspacing=0
			bgcolor=\"#202080\">
		<tr>

		<td width=20%>


		<table width=48 cellpadding=0 cellspacing=0>
		<tr>
		<td>

		<div align=center>
		<font size=4 color=#FFFFFF class=Caps>
		<b>
		$WHERE_AM_I
		</b>
		</font>
		</div>

		</td>
		</tr>
		</table>


		</td>

		");

	#
	if($#results >= 0)
	{
		#
		$took = $QUERY_ET - $QUERY_ST;
		if($took==0)
		{
			$took = "(less than second)";
		}
		else
		{
			$took = "(<b>$took</b> secs)";
		}
	printf("
		<td width=80%>
		<div align=right>
		<font size=5 color=#FFFFFF>
$so{'W_RESULTS'} <b>$i - $i2</b> $so{'W_OF_ABOUT'} <b>%d</b> $so{'W_FOR'} <b>$so{'q'}</b>
		</font>
		</div>
		</td>
		",
		$#results+1);
	}
	else
	{
		print("
		<td width=80%>
		<div align=right>
		<font color=#FFFFFF>No hits.</font>
		</div>
		</td>
		");
		$NO_HITS = 1;
	}

	#
	print("
		</tr>
		</table>
		<br>
		");

	#
	if($NO_HITS && $Google_ads!=0)
	{
			#
			@lst = LoadList("$DB/altse/bin/google2.txt");
			for($i=0; $i<($#lst+1); $i++)
			{
				print "$lst[$i]\n";
			}
	}
}

##########################################################################################################
#
sub SearchNow
{
	my ($key,$comd);

	#
	$key = $_[0];

	#
	if($key eq "")
	{
		return;
	}

	#
	$query_st = time;
	$key =~ s/[^a-z���\.\:0-9\@\* ]//gi;
	if($so{'REFRESH'}==1) { $key="$key REFRESH"; }

	#
	QueryDB($key);

	#
#	Controls();
	#die "KYLLA KUTSUU $#results";
	ResultInfo();


	#
	print("
		<table width=\"100%\" cellpadding=4 cellspacing=0>
		<tr valign=top>
		<td>
		");

	#
	print("
				<table cellpadding=0 cellspacing=0 width=100%>
				<tr valign=top>

				<td width=100%>
<DIV>


      <DIV style='display: inline;
                                            float: left;
                                            width: 300px;
                                            border: 3px solid #FFFFFF;
                                            padding: 10px;'>
                                  
<A HREF=\"/\" class=\"black\" target=\"_blank\">
<FONT SIZE='4'>To The Front Page - Etusivulle</FONT>
</A>
	</DIV>



      <DIV style='display: inline;
                                            float: right;
                                            width: 300px;
                                            border: 3px solid #FFFFFF;
                                            padding: 10px;'>
                                  
<A HREF=\"/#likes\" target=\"_blank\">
<FONT SIZE='4'>Show likes - Näytä tykätyt</FONT>
</A>
	</DIV>



      <DIV style='display: inline;
                                            float: right;
                                            width: 300px;
                                            border: 3px solid #FFFFFF;
                                            padding: 10px;'>
                                  
<A NAME='WWWRESULTS'>
<FONT SIZE='4'>WWW results - Tulokset</FONT>
</A>
	</DIV>


      <DIV style='display: inline;
                                            float: right;
                                            width: 300px;
                                            border: 3px solid #FFFFFF;
                                            padding: 10px;'>
                                  
<A HREF='#WWWMENU'>
<FONT SIZE='4'>Show search tools - Näytä hakutyökalut</FONT>
</A>
	</DIV>

</DIV>
<BR>

		");

	if($so{'st'} ne "image") {
		print ViewTextResults($so{'indexnr'});
	} else {
		print ViewImageResults($so{'indexnr'});
	}

	# st = search type
	if($so{'cmd'} ne "")
	{
		Controls();

		my @queries = LoadList("cfg/Menu.txt");

		print("
<!--- EXAMPLES OF SEARCH KEYWORDS TO BE SHOWN TO THE USER --->
<DIV>

<A HREF='#WWWRESULTS'>
<FONT SIZE='6'>Go up to results</FONT>
</A>
</DIV>

<DIV>
<A NAME='WWWMENU'>
<FONT SIZE='6'>Menu</FONT>
</A>
</DIV>
                                        <DIV style='display: block;
                                            float: right;
                                            width: 100%;
                                            border: 3px solid #FFF;
                                            padding: 10px;'>


		");
		
		$current_blog = $so{'q'};
		for($i=0; $i<($#queries+1); $i++)
		{
			my $st;
			my @sp = split(/\=/, $queries[$i]);
			## Support the blogs !
			if( $sp[1]=~/^\@/ ) {
				$st = "text";
				#$sp[1] = s/^\@//;
			}
			else
			{
				$st = "image";
			}

			if( ($so{'q'}=~/^$sp[1]$/i) )
			{
				print("
<DIV style='display: inline;
                                            float: right;
                                            width: 100;
                                            border: 3px solid #FFF;
                                            padding: 10px;'>
<A HREF=\"/?q=$sp[1]&st=$st&cmd=go\" class=\"goldlink2\">
$sp[0]</A>
</DIV>
				");
			}
			else
			{
				print("
                                        <DIV style='display: inline;
                                            float: right;
                                            width: 230;
                                            border: 3px solid #FFF;
                                            padding: 10px;'>

<A HREF=\"/?q=$sp[1]&st=$st&cmd=go\" class=\"goldlink\">
$sp[0]</A>
 </DIV>
 
				");
			}

		}
		
		#
		print("
		</DIV>

");		
		#
		goto NO_DEBUG_PREVIEW;
		#
		@lst = reverse LoadList("cat $DB/wwwimages/already.txt |grep -iE \"putin|jinping|trump\"|sort -g|");
		
		#
		for($i=0,$i2=0; $i<($#lst+1) && $i2<25; $i++)
		{
			my @sp = split(/\|/, $lst[$i]);
			# At least 3,5 kilobytes, begins with https:// or http:// and is not a duplicate.
			if( $sp[0]>(1024*3+512) && !($alim{$sp[1]}) && $sp[1]=~/^http[s]*:\/\//
			&& !($sp[1]=~/\s/) )
			{
				$alim{$sp[1]}++;
				print ("
		<A HREF='$sp[1]'>
			<IMG SRC='$sp[1]' width='200' height='175'>
		</A>
				");
				$i2++;
			}
		}
NO_DEBUG_PREVIEW:

		#
		print("
</TD>
</TR>
</TABLE>");

# BLOG FEATURE
if($so{'st'} eq "blog" && $current_blog ne "") {
	#
	print("
<TABLE ALIGN=\"\"
	cellpadding=\"4\" cellspacing=\"0\"
	width=100%>
<TR>
<TD>
	");

	#
	my $fn_blog_html = "$current_blog";
	$fn_blog_html =~ s/^\@//;
	@lst = LoadList($fn_blog_html);
	for($i=0; $i<($#lst+1); $i++) {
		print $lst[$i] . "<BR>\n";
	}

	#
	print("
</TD>
</TR>
</TABLE>");
}



#print("
#<BR><BR>
#<BB<BR><BR>
#<BR><BR>
#<BR>
#
#");
	}
#	if($so{'st'} ne "image") {
#		print ViewTextResults($so{'indexnr'});
#	} else {
#		print ViewImageResults($so{'indexnr'});
#	}
	if($so{'start'} ne "") { goto past1; }
	print("

				</td>

				<td width=0%>



				</td>

				</tr>
				</table>
		");
past1:
	Controls();

	#
#	printf "%d result(s).<br>\n", $tulos;

	#
	if($so{'q'} ne "")
	{
		print("
		<center>
		<a href=\"mailto:jari.t.tuominen\@gmail.com\" class=$FONTCC3> <i>> $so{'W_SUGGEST_URL'}</i> </a>
		");
	}

	#
	print("
		<br>
		<font size=1>
		$COPYRIGHT
		</font>
		</center>
		");

	#
	print("

		</td>
		</tr>
		</table>
		");
}

1;
