#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
require "./modules/SearchSubModule.pm";
require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
SocialLikes();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub SocialLikes
{
	################
	#
	# LOAD UP THE ALTSE's SOCIAL LIKES.
	#
	if(-e "$DB/likes.txt")
	{
		@lst = reverse LoadList("$DB/likes.txt");
	}
	
	#
	print("
<TABLE style=\"width: 100%;\">
<TR>
<TD>
<A NAME=\"likes\">
	<CENTER><H1>Tykättyjä hakuja:</H2></CENTER>
	
	<DIV style=\"background: #FFFF40; font-size: 24; padding: 10; \">
	<A HREF=\"/?#recommended\" target=\"_blank\"
		style=\"background: #FFFF40; font-size: 24; padding: 10; \">
	<H2>Tykkää uutisia tästä.</H2></A>
	</DIV>
</A>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		@sp = split(/\|/, $lst[$i]);
		#
		my $str="$sp[0]/$sp[1]";
		if($dup{$str})
		{
			goto skip11;
		}
		$dup{$str}++;
		# > Load Preview From The Altse WWW Cache.
		my @dar = LoadList("$DB/altse/bin/dardump \"$sp[0]\" \"$sp[1]\" 2>/dev/null|");
		if($#dar == -1)
		{
			continue;
		}
		LoadVars("$DB/altse/bin/dardump \"$sp[0]\" \"$sp[1]\" 2>/dev/null|");
		#
		print("
		<H1>

		<A 
		<IMG SRC='/images/35-356815_red-thumbs-up-clipart-thumbs-up-icon-red.png'
	valign='left'
	title='Tykkää tästa uutisesta!' alt='Tykkää tasta uutisesta'
	width='40' height='30'
	loading=\"lazy\">

		<A HREF=\"http://$so{'host'}$so{'path'}\" target=\"_blank\">
		$so{'title'}
		</A>
		</H1>
		");
skip11:
	}
	#
	print("
</TD>
</TR>
</TABLE>
	");

}

1;
