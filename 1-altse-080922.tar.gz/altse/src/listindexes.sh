#!/bin/bash
cat ~/sdb/html/cgi/indexnames.txt
