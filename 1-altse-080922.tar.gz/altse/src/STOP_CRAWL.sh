#!/bin/bash
echo "> Stopping Central crawl control process ..."
killall ccr ## killall is okay, but there should be always one instance running at a time
sleep 2
echo "> Stopping crawl processes ..."
killall crawl
sleep 2
echo "2 seconds sleep"
echo "> Stopping lynx and wget processes ..."
killall lynx
killall wget
echo "2 seconds sleep"
sleep 2
echo "> Killing wget and lynx processes ..."
killall -9 wget
killall -9 lynx
