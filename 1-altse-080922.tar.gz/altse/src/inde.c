/////////////////////////////////////////////////////////////////////////////
//
// inde.c - index builder - primary functionality.
// (C) 2005-2022 by Jari Tapio Tuominen (jari.t.tuominen@gmail.com).
// Builds index files (DIC) out of word lists (WLI).
//
// Check out new fdeature:
// Time reward (search for it)
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "inde_loadwords.h"
#include "inde_saveresults.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"

// WORD_TYPE_AUDIO
// WORD_TYPE_VIDEO
// WORD_TYPE_IMAGE

//
int min_prisec=0,max_prisec=0; // f.e. 0,6
// DEBUGGING OPTIONS
char inde_debug=	FALSE;
char inde_debug_verbose=FALSE;
char inde_verbose=	FALSE;
//
INDE inde;
char GLOP[256]; // global path
DWORD persec;
//
int inde_start_time=	-1;
char *words_list[100000];

/////////////////////////////////////////////////////////////////////////////
//
char **LoadList(char *fn)
{
	//
}

/////////////////////////////////////////////////////////////////////////////
//
int LoadWord(char *fn_words_list, int *l_words_list)
{
	int i,i2,i3,i4,max_mem;
	char str[8192];
	FILE *f;

	//
	f = fopen(fn_words_list, "rt");

	//
	for(i=0; i<100000; i++) {
		fgets(&str, f, 8192);
		words_list[i] = str;
	}

	//
	fclose(f);

	//
}

/////////////////////////////////////////////////////////////////////////////
//
void InitInde(INDE *in)
{
	int i,i2,i3,i4,max_mem;
	char *p;
	FILE *f;

	// Assign X megabytes to the word list.
	max_mem = MAIN_MEM_BUF_SZ;

	////////////////////////////////////////////////////////
	//
	// Reset main structure.
	//
	memset(in, 0, sizeof(INDE));

	////////////////////////////////////////////////////////
	//
	// Allocate big buffer.
	//

	// Define limitations.
	in->max_ent =	10000000;
	// Reset entry count to zero.
	in->n_ent = 	0;

	// Allocate pointers.
	in->ent = (void*)imalloc(in->max_ent*4);
	memset(in->ent, 0, in->max_ent*4);

}

/////////////////////////////////////////////////////////////////////////////
//
DWORD IsImpWord(INDE *in,
        BYTE *s)
{
        DWORD wo,i,i2,i3,i4,found;

        // Generate 32-bit "word" to hunt word.
        wo = (s[0]<<24) | (s[1]<<16) | (s[2]<<8) | (s[3]);

        //
        for(i=0,found=0; i<in->n_imp; i++)
        {
                if(in->imp[i]==wo) { found=i+1; break; }
        }

        //
        return found;
}

/////////////////////////////////////////////////////////////////////////////
//
int CountWord(char *w1,char *w2,char *w3,char *w4,
	DWORD loc,DWORD gid, INDE *in, DWORD type,HOSTHASH host) //,HOSTHASH url)
{
	ENT *e;

	//
	e = AddNewWord(w1,w2,w3,w4, in);
	//
	e->loc = loc;
	e->gid = gid;
	e->type = type;
	//e->url = url;
	e->host = host;
	e->rank = in->rank;

	//
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
//
ENT *FindWord(char *str, int loc, INDE *in)
{
	DWORD i,i2,sum;
	ENT *e;

	//
	if(in->n_ent >= in->max_ent) { return NULL; }

	//
	sum = smart_csum((BYTE*)str,strlen((char*)str));

	//
	for(i=0; i<in->n_ent; i++)
	{
		e = in->ent[i];
		if( e->csum_w1==sum && (e->loc==loc || loc==-1) )
		{
			return e;
		}
	}

	//
	return NULL;
}

/////////////////////////////////////////////////////////////////////////////
//
ENT *AddNewWord(char *w1,char *w2,char *w3,char *w4,
	INDE *in)
{
	ENT *e;
	DWORD sum;
	int i,i2,i3,i4,l;

	//
	if(in->n_ent >= in->max_ent)
	{
		fprintf(stderr, "Out of word space (%d/%d)!\n",
			in->n_ent, in->max_ent);
		abort();
	}

	//
	e = imalloc(sizeof(ENT));
	in->ent[in->n_ent] = e;

	//
	l = strlen(w1);
	for(i=0; i<N_CHARS_MATTER; i++)
	{
		if(i>=l)
		{
			e->tiny[i]='_';
		}
		else
		{
			e->tiny[i]=w1[i];
		}
	}
	e->tiny[N_CHARS_MATTER] = 0;
	//
	e->csum_w1 = smart_csum((BYTE*)w1,strlen((char*)w1));
	e->csum_w2 = smart_csum((BYTE*)w2,strlen((char*)w2));
	e->csum_w3 = smart_csum((BYTE*)w3,strlen((char*)w3));
	e->csum_w4 = smart_csum((BYTE*)w4,strlen((char*)w4));

	//
	in->n_ent++;

	//
	return e;
}

/////////////////////////////////////////////////////////////////////////////
//
int GetGID(char *s)
{
	char str[256];
	int gid,i;

	//
	for(i=strlen(s); i>0 && s[i]!='/'; i--) { }
	i++;

	//
	gid=0;
	sscanf(s+i, "%d", &gid);
	return gid;
}

/////////////////////////////////////////////////////////////////////////////
//
// Get specific meta tag.
//
/*void GetMetaTag(BYTE *h, char *tag, char *target)
{
	int i,i2,l,found,l1,l2,l3;
	BYTE *p;
	static BYTE ftag[8192],content[8192];
	static BYTE match1[8192],
			match2[8192],
			match3[8192];

	//
	strcpy(target, "");

	//
	l = strlen((char*)h);

	//
	sprintf((char*)match1, "<meta name=\"%s\"",	tag);
	l1 = strlen((char*)match1);

	//
	for(i=0,found=0; i<l; i++)
	{
		//
		p = h+i;
		if(
			!strncmp((char*)p,(char*)match1,l1)
			)
		{
			for(i2=0; i2<8000 && p[i2]!='>' && p[i2]!=0; i2++)
			{
				ftag[i2] = p[i2];
			}
			ftag[i2++]='>';
			ftag[i2++]=0;
			found = TRUE;
			break;
		}
	}

	//
	if(found)
	{
		//
		strcpy((char*)content, "");
		//
		l = strlen((char*)ftag);
		for(i=0,i2=0; i<l; i++)
		{
			if(ftag[i]=='"') { i2++; }
			if(i2==3) { i++; break; }
		}
		if(i2==3)
		{
			for(i2=0; i<l && i2<8000; i++)
			{
				if(ftag[i]=='"') break;
				content[i2++] = ftag[i];
			}
			content[i2++]=0;
		}

		//
		strcpy((char*)target, (char*)content);
	//	fprintf(stderr, "%s = \"%s\"\n",
	//		tag,
	//		content);
	}

	//
}*/

/////////////////////////////////////////////////////////////////////////////
//
// /home/vai/altse/cid/data/1/006/69/66982.dar 
//
int GetRank(char *host, char *path, char *description1, char *keywords,
	int file_age)
{
	static char str[8192],fn[8192];
	static char country[8192],domain[8192];
	int rank,i,i2,l,s,c,l_good_words_list;
	char *ho;
	FILE *f;
	static char **good_words_list;
	char fn_good_words_list[1024];

	// Reward for good words in the article (f.e. "civilized" dictionary words).
	sprintf(fn_good_words_list, "%s/altse/cfg/goodwords.lst", database_path);
	good_words_list = LoadList(fn_good_words_list);
	// TODO: WORD EVALUATION OF WORDS IN description1 AND keywords.

	//------------------------------------------------------------------------
	//
	// Primary rank evaluation.
	//
	// The higher the better.
	//
	rank = 0;

	//
	ho = host;
	if(!strncmp(ho,"www.",4)) ho+=4;

	//
	sprintf(fn, "%s/www/%c%c/%s/rank.txt",
		database_path,
		ho[0],ho[1],
		host);
	f = fopen(fn, "rt");
	if(f!=NULL)
	{
		// Get rank.
		fscanf(f, "%d %d",
			&i,
			&rank);
		fclose(f);
	}

	//------------------------------------------------------------------------
	//
	// Secondary rank evaluation.
	//

	//
	l = strlen(host);
	for(i=l; i>0; i--)
	{
		if(host[i]=='.') { i++; break; }
	}
	strcpy(country, host+i);
	for(i-=2,c=0; i>0; i--,c++)
	{
		if(host[i]=='.') { i++; break; }
	}
	strncpy(domain,host+i, c);
	domain[c] = 0;

	//--------------------------------------------------------------
	//
	for(i=0; i,l_good_words_list; i++) {
		if( strstr(keywords,good_words_list[i]) ) {
			rank += 10000000*(i/4+1);
		}
	}

	//
	// Start rank calculation.
	//
	//
	if( strstr(host, "vaihtoehtouutiset.info") ) { rank+=4; }
	if( strstr(host, "kultakaivos.info") ) { rank+=4; }
	if( strstr(host, "vunet.org") ) { rank+=4; }
	if( strstr(host, "yandex.com") ) { rank+=4; }

	//
	if( 	strcmp(domain, "co") &&
		strcmp(domain, "edu") &&
		strcmp(domain, "gov") &&
		strcmp(domain, "int") &&
		strcmp(domain, "org") &&
		strcmp(domain, "net") &&
		strcmp(domain, "com") )
	{
		rank += 2;
	}

	// Time reward
	// We want to put better disclosure for newer pages.
	if( file_age >= 0 && file_age < (60*60*1) ) {
		// Single day to four days old at most.
		rank += 20;
	}
	if( file_age >= (60*60*1) && file_age < (60*60*2) ) {
		// Single day to four days old at most.
		rank += 16;
	}
	if( file_age >= (60*60*2) && file_age < (60*60*3) ) {
		// Single day to four days old at most.
		rank += 14;
	}
	if( file_age >= (60*60*3) && file_age < (60*60*4) ) {
		// Single day to four days old at most.
		rank += 12;
	}
	if( file_age >= (60*60*4) && file_age < (60*60*8) ) {
		// Single day to four days old at most.
		rank += 10;
	}
	if( file_age >= (60*60*12) && file_age < (60*60*24) ) {
		// Single day to four days old at most.
		rank += 8;
	}
	if( file_age >= (60*60*24) && file_age < (60*60*24 *4) ) {
		// Single day to four days old at most.
		rank += 6;
	}
	if( file_age >= (60*60*24 *4) && file_age < (60*60*24 *10) ) {
		// 4 to 10 days old.
		rank += 2;
	}
	if( file_age >= (60*60*24 *10) && file_age < (60*60*24 *30) ) {
		// It's not more than a month old.
		rank += 1;
	}

	//
	if(strlen(domain)==2)
	{
		rank += 4;
	}
	else
	if(strlen(domain)==3)
	{
		rank += 3;
	}
	else
	if(strlen(domain)==4)
	{
		rank += 2;
	}
	else
	{
		rank += (strlen(domain)/5);
	}


	l = strlen(path);
	//
	for(i=0; i<l; i++)
	{
		if(path[i]=='/') { rank++; }
		if(path[i]=='%') { rank++; }
		if(path[i]=='(') { rank++; }
		if(path[i]==')') { rank++; }
	}

	//
	l = strlen(host);
	//
	for(i=0; i<l; i++)
	{
		if(host[i]=='.') { rank++; }
	}
	// Forgive single dot.
	rank -= 1;

	// Shorter is more favorable.
	rank -= strlen(host)/10;
	rank -= strlen(path)/10;

	//
	if(	strstr(path, "index.") ||
		strstr(path, "default.")	)
	{
		rank += 2;
	}

	//
	if(	!strcmp(path, "")	)
	{
		rank += 100;
	}

	//---------------------------------------------------
	//
	// Divide result.
	//
	//rank /= 2;

	//
	if(rank<0) { rank=0; }

	//
	return rank;
}

/////////////////////////////////////////////////////////////////////////////
//
void SpecialWords(INDE *in, char *s, DWORD gid, DWORD type, HOSTHASH host) //, HOSTHASH url)
{
	int i,i2,i3,i4,l;
	static char str[2560],str2[2560];
	DWORD locfix;
	static char *wl[10000]; // word list
	int n_wl;
	BYTE *our;

	//
	our = imalloc(1024*512);

	//
	strcpy(our, s);
	LowerCaseString(our);

	//
	locfix = (type&0xFFF)*0x01000000;

	//
	l = strlen(our);

	//
	for(i=0,n_wl=0; i<l; )
	{
		// Search for an alphabet.
		for(; !isalnum1(our[i]) && i<l; i++) { }

		//
		if( isalnum1(our[i]) )
		{
			// Store to str until non-alphabet-or-number is encountered.
			for(i2=0; isalnum1(our[i]) && i<l; i++) { str[i2++] = our[i]; }
			str[i2] = 0;
			if(strlen(str)<250)
			{
				wl[n_wl] = imalloc(256);
				strcpy(wl[n_wl], str);
				n_wl++;
			}
		}
	}
	//
	strcpy(str,"");
	wl[n_wl+0] = str;
	wl[n_wl+1] = str;
	wl[n_wl+2] = str;

	//
	for(i=0; i<n_wl; i++)
	{
		// Add word ...
		CountWord(wl[i+0],wl[i+1],wl[i+2],wl[i+3], locfix+i, gid, in, type, host); //, url);
	}

	//
	for(i=0; i<n_wl; i++)
	{
		free(wl[i]);
	}

	//
	free(our);

	//
}

/////////////////////////////////////////////////////////////////////////////
//
//      URL2SpecialWords(f, 
//		in, gid, pgp|WORD_TYPE_AUDURL, hsum);
//
void URL2SpecialWords(FILE *f,
	INDE *in, DWORD gid, DWORD typ, DWORD hsum) //, DWORD url)
{
	static char str[4096];

	//
	for(; !feof(f); )
	{
		//
		strcpy(str,"");
		fgets(str, 4000, f);

		// Empty line means end of list.
		if(!strcmp(str, "")) { break; }

		// Accept only URLs beginning with "http://".
		if( strstr(str,"http://") )
		{
			SpecialWords(in, str+7, gid, typ, hsum);
			fprintf(stderr, "<> %s\n", str);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
//
void DisplayResults(INDE *in)
{
	int i;
	ENT *e;

	//
	for(i=0; i<in->n_ent; i++)
	{
		//
		e = in->ent[i];

		//
		printf("%s %x %d %d\n",
			(char*)e->tiny, e->csum_w1, e->loc, e->gid);
	}

	//	
}

/////////////////////////////////////////////////////////////////////////////
//
DWORD val2(DWORD ch)
{
	if(ch=='�' || ch=='�' || ch=='�') { ch-='�'; ch+='z'+1; }
	return ch-'0';
}

/////////////////////////////////////////////////////////////////////////////
//
DWORD val(char *s)
{
	int i;

	//
	return (val2(s[3])<<0) | (val2(s[2])<<8) | (val2(s[1])<<16) | (val2(s[0])<<24);
}

/////////////////////////////////////////////////////////////////////////////
//
int compare_ents(DWORD *a1, DWORD *a2)
{
	ENT *e1,*e2;

	//
	e1 = *a1;
	e2 = *a2;

	//
	return strcmp(e1->tiny, e2->tiny);
}

/////////////////////////////////////////////////////////////////////////////
//
void SortResults(INDE *in)
{
	int i,i2;
	ENT *e;

	//
	if(inde_verbose) {
		fprintf(stderr, ">> begin sort\n");
	}
	qsort(in->ent, in->n_ent, 4, compare_ents);
	if(inde_verbose) {
		fprintf(stderr, "<< end sort\n");
	}

	//
//	sleep(10000);
}

/////////////////////////////////////////////////////////////////////////////
//
void SortOnce(INDE *in, int lim)
{
	register int i;
	register ENT *e,*e1,*e2;

	//
	for(i=0; i<(lim-1); i++)
	{
		//
		e1 = in->ent[i+0];
		e2 = in->ent[i+1];

		//
		if(e1->tiny[0] > e2->tiny[0])
		{
			in->ent[i+0] = e2;
			in->ent[i+1] = e1;
		}
	}

	//
}

