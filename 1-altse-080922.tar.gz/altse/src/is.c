//////////////////////////////////////////////////////////////////////////////////////////
//
// Altse Internet Search.
// (C) 2005-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
// See is_main.c for command line interface functionality.
//
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
//#include <db.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "is_dicsinglefind.h"
#include "is_processresults.h"
#include "is_searchindexes.h"
#include "iscfg.h"

// Options.
int max_search_word_level = 0;
int quick_less_verbose = 0;
int or_mode = 0;

// For MAX_MEMORYSIZE see is.h.

// Debug ON (1), OFF (0).
int debug = 0;

//
DWORD work_began_at,OnlyPairsQualify=FALSE;

//
IS Is;

//
static char *buzzwords[]={
	"ftp",
	"www",
	"the",
	"org",
	"net",
	"org",
	"and",
	"an",
	"a",
	"*"
};

//
int max_results_per_host=2;
//
int MaxDivingDepth=0;

//
int RANK = 0;
int RankScore = 0;
DWORD lstab[1000];
// Search for specific type of media?
DWORD search_type=0;
//
FILE *flog=NULL;
//
int running_number=0;

//////////////////////////////////////////////////////////////////////////////////////////////
// Host query, this functino can be used to avoid duplicate host-based entries to display.
int HostQuery(IS *is, HOSTHASH hostsum, DWORD qid)
{
	int i,i2,len;

	//
	if(is->hosts_sum[qid]==NULL || is->hosts_cnt[qid]==NULL) {
		// calculate allocation length in bytes
		len = N_MAX_HOSTS*sizeof(void*)*2;
		// allocate buffers
		is->hosts_sum[qid] = imalloc(len);
		is->hosts_cnt[qid] = imalloc(len);
		// initialize buffers
		memset(is->hosts_sum[qid],0,len);
		memset(is->hosts_cnt[qid],0,len);
	}

	// Go through all hosts.
	for(i=0; i<is->n_hosts[qid]; i++)
	{
		if( is->hosts_sum[qid][i]==hostsum )
		{
			// ALREADY EXISTS, RETURN COUNT.
		/*	fprintf(stderr, "(%d) %s line %d: DUPLICATE HOST DETECTED: %.8x\n",
				running_number, __FUNCTION__, __LINE__,
				hostsum);*/
			running_number++;
			return is->hosts_cnt[qid][i]++;
		}
	}

	// CREATE NEW ENTRY.
	if(is->n_hosts[qid] >= N_MAX_HOSTS) { return 1000; }
	i = is->n_hosts[qid]++;

	//
	is->hosts_sum[qid][i] = hostsum;
	return is->hosts_cnt[qid][i]++;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
void WriteLog(const char *format, ...)
{
	va_list ap;

	//
	if(flog!=NULL)
	{
		va_start(ap,format);
		vfprintf(flog, format, ap);
		va_end(ap);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
//
DWORD GetIsTickCount(void)
{
	//
	return GetTickCount()-work_began_at;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int IsBuzzword(char *s)
{
	int i,i2,l;

	//
	for(i=0; ; i++)
	{
		//
		if(!strcmp(buzzwords[i],"*")) { break; }

		//
		if(!strcmp(buzzwords[i],s)) { return 1; }
	}

	//
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Whats the use for this buzz handler? Obsolete?
//
void BuzzwordHandler(IS *is)
{
	int i,i2;
	char *p1,*p2;

	//
	if( is->n_word < 2 )
		return;

	//
	//////////////for(i=0; i<(is->n_word-1); i++)
	for(i=0; i<1; i++)
	{
/*
		if( IsBuzzword(is->word[i]) )
		{
			// Make swap.
			p1 = is->word[i+0];
			p2 = is->word[i+1];
			//
			is->word[i+0] = p2;
			is->word[i+1] = p1;
			//
			fprintf(stderr, "Swap result: \"%s,%s\"\n",
				is->word[i+0],
				is->word[i+1]);
		}*/
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
//
char *SumToWord(IS *is, DWORD sum)
{
	int i;

	//
	for(i=0; i<is->n_word; i++)
	{
		if(is->wordsum[i]==sum) { return is->word[i]; }
	}

	//
	return NULL;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
ENTSCO *NewScoreEntry(IS *is, DWORD gid)
{
	int i,i2;
	ENTSCO *e;

	//
	if(is->n_entsco >= is->max_entsco)
	{
	//	fprintf(stderr, "Out of entry score array space.\n");
	//	abort();
		return NULL;
	}

	//
	e = is->entsco[is->n_entsco];
	is->n_entsco++;

	//
	e->gid = gid;
	e->score = 0;

	//
	return e;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
ENTSCO *GetScoreFor(IS *is, DWORD gid)
{
	int i,i2,found,bit;
	ENTSCO *e;
	int lid;

	//
	bit = gid&15;

	// Search through the quick search list.
	for(i=0,found=-1,e=NULL; i<is->n_list[bit]; i++)
	{
		//
		if( is->list_gid[bit][i]==gid)
		{
			//
			e = is->list_ent[bit][i];
			found=gid;
		}
	}

	//
	if(found!=gid)
	{
		// Create new score entry.
		e = NewScoreEntry(is, gid);

		// Add to quick search list.
		is->list_gid[bit][is->n_list[bit]] = gid;
		is->list_ent[bit][is->n_list[bit]] = e;
		is->n_list[bit]++;
	}

	//
	return e;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// 
// q = queue
// offs = from where to start scrolling forward
// repent = what to insert
// scroll_amount = how many times
//
int InsertToQueue(ENTSCO *q, int offs, int scroll_amount, EN *repent)
{
	int i,i2;
	EN *e;

	// Require at least one entry.
	if(q->n_occurs<1) { return 1; }

	//
	for(i2=0; i2<scroll_amount; i2++)
	{
		for(i=q->n_occurs; i>offs; i--)
		{
			//
			q->occur[i] = q->occur[i-1];
		}
		q->occur[offs] = repent;
		q->n_occurs++;
	}

	//
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
EN *NewQueueEntry(IS *is, ENTSCO *q, DWORD loc, DWORD sum, DWORD rnk)
{
	int i,i2,i3,i4,ec;
	EN *e;

	//----------------------------------------------------
	//
	if(q->n_occurs >= MAX_LOCS)
	{
	/*	printf("n_occurs %d > MAX_LOCS %d\n",
			q->n_occurs, MAX_LOCS);
		abort();*/
		return NULL;
	}

	//----------------------------------------------------
	// FIRST ENTRY?
	if(1 || q->n_occurs==0) // FAST FIX !!!!!!!!!!!!! TODO.
	{
		// Add entry to the end of queue.
		// Only done when the LOC integer is bigger than
		// the last entry on the queue or if the entry
		// is the first entry on the queue.
		ec = q->n_occurs++;
		goto AddNewEntry;
	}

	//----------------------------------------------------
	for(i=0,ec=-1; i<q->n_occurs; i++)
	{
		//
		e = q->occur[i];
		//
		if(e->loc > loc)
		{
			//
		//	printf("InsertToQueue(%x,%d,%d,%x);\n",
		//		q,i,1,NULL);
		//	abort();
			InsertToQueue(q,i,1,NULL);
			ec = i;
			break;
		}
		else
		{
		//	printf("%d: %d < %d\n",
		//		i, e->loc, loc);
		}
	}

	//
	if(ec==-1)
	{
		// Add at the end of the queue.
		ec = q->n_occurs++;
	}

	//----------------------------------------------------
	//
AddNewEntry:
	//
	if(q->occur[ec]==NULL) { q->occur[ec] = imalloc(sizeof(EN)); }
	return q->occur[ec];
}

//////////////////////////////////////////////////////////////////////////////////////////
//
void IncreaseScore(IS *is, DWORD how_much,
	DWORD gid, DWORD location, DWORD rnk, HOSTHASH host,
	DWORD w1,
	DWORD w2,
	DWORD w3,
	DWORD w4)
{
	ENTSCO *e;
	EN *pe;
	int i;
	int old_score,new_score;

	//
	e = GetScoreFor(is, gid);
	if(e==NULL) { return; }
	e->host = host;
	//e->url = url;
	old_score = e->score;
	e->score += how_much;
	if(e->score < old_score) {
		e->score = 0xFFFFFFFF;
	}

	//
	if(e->test!=MAGIC_NUMBER)
	{
		e->test = MAGIC_NUMBER;
		e->rnk = rnk;
	}

	// Add location of the word if possible.
	// This function automatically sorts the queue on the fly.
	pe = NewQueueEntry(is, e, location, w1, rnk);
	if(pe!=NULL)
	{
		//printf("NewQueueEntry returns 0x%x\n", pe);
		pe->loc =     location;
		pe->csum_w1 = w1;
		pe->csum_w2 = w2;
		pe->csum_w3 = w3;
		pe->csum_w4 = w4;
		pe->gid =     gid;
		pe->rnk =     rnk;
	}
	else
	{
	//	fprintf(stderr, "NewQueueEntry returns NULL. Exceeded MAX_LOC limit?\n");
	//	abort();
	}

	//
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// NewMatch function, adds a new match to the entry array.
//
int NewMatch(IS *is, EN *e)
{
	EN *de;

	//
	if(is->n_en >= is->max_en) { return 1; }

	//
	de = is->en[is->n_en];

	//
	memcpy(de,e, sizeof(EN));
	//
	///////de->rnk = is->PriSec;

	//
	is->resco++;

	//
	is->n_en++;

	//
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
IS *InitIS(int argc, char **argv)
{
	int i,i2,i3,i4,spend,l,ad,ad2;
	IS *is;
	EN *e;
	void *p;
	static char str[1024],str2[1024],str3[1024];
	FILE *f;

	////////////////////////////////////////////////////////////////////////////////
	//
	is = &Is;

	//
	memset(is, 0, sizeof(IS));

	//
	spend = RESULT_SPACE_BYTES;

	//
	is->l_buf2 = spend;
	is->n_entsco = 0;
	is->max_entsco = is->l_buf2/sizeof(ENTSCO);
/*
	is->buf2 = imalloc(is->l_buf2);
//	memset(is->buf2, 0, is->l_buf2);
	//
	for(i=0,p=is->buf2; i<is->max_entsco; i++,p+=sizeof(ENTSCO))
	{
		is->entsco[i] = p;
	}*/

	//
	is->entsco = imalloc(8*is->max_entsco);
	//
	for(i=0; i<is->max_entsco; i++)
	{
		is->entsco[i] = imalloc(sizeof(ENTSCO));
	}
	//
	is->l_buf = spend;
	is->buf = imalloc(is->l_buf);
	if(is->buf==NULL)
	{
		fprintf(stderr, "%s: Out of memory: can't allocate %d (%dM) bytes of memory\n",
			__FUNCTION__,
			is->l_buf,
			is->l_buf/(1024*1024));
		abort();
	}
	memset(is->buf, 0, is->l_buf);
	//
	is->max_en = is->l_buf/sizeof(EN);
	is->n_en = 0;
	is->en = imalloc(8*is->max_en);
	//
	for(i=0,p=is->buf; i<is->max_en; i++,p+=sizeof(EN))
	{
		is->en[i] = p;
	}

	//
	AltseLoadConfig();

        //------------ OPEN LOG FOR WRITING ---------------
	sprintf(str, "%s/logs/is.log", database_path);
        flog = fopen(str, "wt");
        if(flog==NULL) { fprintf(stderr, "Can't write log on file \"%s\". Do 'sudo chmod a+rw is.log'.\n", str); exit(1); }

	///////////////////////////////////////////////////////////////////////////////////////
	// FIRST PARAMENTER (ARGUMENT) IS ALWAYS SEARCH KEYWORD(S) IN A SINGLE STRING ARRAY.
	strcpy(str, argv[1]);
	l = strlen(str);
	if(strlen(argv[1])>255) {
		fprintf(stderr, "%s/%s: Search keyword is too long (Error!)\n",
			__FUNCTION__, __FILE__);
		exit(-100);
	}

	// Pick up keywords to search for from argv[1].
	for(i=0,i4=0; i<l; i4++)
	{
		//
		is->word[i4] = imalloc(256);
		is->ascii_word[i4] = imalloc(256);

		//
		for(i2=0; i<l; i++)
		{
			//
			if(i2==0 && str[i]==' ') { continue; }
			if(i2!=0 && str[i]==' ') { break; }

			//
			is->word[i4][i2++] = str[i];
		}
		is->word[i4][i2++]=0;

		//
		LowerCaseString(is->word[i4]);
		strcpy(is->ascii_word[i4], is->word[i4]);
		for(i2=0; i2<l; i2++)
		{
			if(is->ascii_word[i4][i2]=='�') { is->ascii_word[i4][i2]='a'; }
			if(is->ascii_word[i4][i2]=='�') { is->ascii_word[i4][i2]='o'; }
			if(is->ascii_word[i4][i2]=='�') { is->ascii_word[i4][i2]='a'; }
		}
	}
	is->n_word = i4;

	//
	BuzzwordHandler(is);

	//
	for(i=0; i<is->n_word; i++)
	{
		//
		is->wordsum[i] = smart_csum(is->word[i], strlen(is->word[i]));
		is->ascii_wordsum[i] = smart_csum(is->ascii_word[i], strlen(is->ascii_word[i]));
	}

	//
	MaxDivingDepth=MAX_DIVING_DEPTH / is->n_word;

	////////////////////////////////////////////////////////////////////////////
	//
#ifdef __DEBUG__
	fprintf(stderr, "%d words detected: ", is->n_word);
	for(i=0; i<is->n_word; i++)
	{
		fprintf(stderr, "%s,", is->word[i]);
	}
	fprintf(stderr, "\n");
	abort();
#endif

	////////////////////////////////////////////////////////////////////////////
	//
	// Get search options, if any.
	//
	search_type =	0;
	look_host =	0;
	look_host2 =	0;

	//
	for(i=1; i<argc; i++) {
		// define which index to use for searches,
		// f.e. -i 1 (default is 0)

		if( !strncmp(argv[i],"-v",2) ) {
			//
			inde_debug = 1;
			inde_verbose = 1;
		}

		if( !strncmp(argv[i],"-q",2) ) {
			//
			quick_less_verbose = 1;
		}

		if( !strncmp(argv[i],"-qq",3) ) {
			//
			quick_less_verbose = 2;
		}

		if( !strncmp(argv[i],"-mp",3) ) {
			//
			sscanf(argv[i]+4, "%d", &max_search_word_level);
		}

		if( !strncmp(argv[i],"-i",2) ) {
			//
			sscanf(argv[i]+3, "%d", &ActiveIndexNr);
		}

		// f.e. -h www.yle.fi
		if( !strncmp(argv[i],"-h",2) ) {
			//
			strcpy(str3, argv[i+1]);
			look_host = smart_csum(str3, strlen(str3));
			//
			strcat(str3, "\n");
			look_host2 = smart_csum(str3, strlen(str3));
		}
		if( !strncmp(argv[i],"-t",2) )
		{
			//
			strcpy(str3, argv[i]);
			if( strstr(str3+3, "txt") ) {  search_type = 0;  }
			if( strstr(str3+3, "aud") ) {  search_type = WORD_TYPE_AUDIO;  }
			if( strstr(str3+3, "vid") ) {  search_type = WORD_TYPE_VIDEO;  }
			if( strstr(str3+3, "img") ) {  search_type = WORD_TYPE_IMAGE;  }
		}
		// Force to show as much results as possible (aka unl = unlimited results).
		if( !strncmp(argv[i],"-f",2) )
		{
			max_results_per_host = 1000000;
		}
		// Multiple word OR_MODE
		if( !strncmp(argv[i],"-or",3) )
		{
			or_mode = 1;
		}
	}

	//
	OnlyPairsQualify = TRUE;

	//
	return is;
}

/////////////////////////////////////////////////////////////////////////////
//
int compare_occurs(EN *e1, EN *e2)
{
        //
        if(e1==NULL || e2==NULL) { return 0; }

        //
        return e2->loc - e1->loc;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int IsMatch(IS *is, DWORD sum, DWORD not_sum)
{
	int i,i2;
	DWORD su,ascii_su;

	//
	for(i=0; i<is->n_word; i++)
	{
		//
		su = is->wordsum[i];
		ascii_su = is->ascii_wordsum[i];
		if(su!=not_sum && su==sum) { return TRUE; }
		if(ascii_su!=not_sum && ascii_su==sum) { return TRUE; }
	}

	//
	return FALSE;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Especially rewards pairs of matching word occurances.
//
int RewardOnPairs(IS *is)
{
	int i,i2,i3,i4,ds,s1,s2,sum,x,y,f,match;
	static char str[1024],str2[1024],locs[1024];
	ENTSCO *e;
	EN *en;
	DWORD *ww;

	//
	WriteLog("[%d] CHECKING PAIRS\n",
		GetIsTickCount());

	//
	for(i=0; i<is->n_entsco; i++)
	{
		is->entsco[i]->type = 0;
	}

	//
	for(i=0; i<is->n_entsco; i++)
	{
		//
		e = is->entsco[i];

		//
		for(i2=0; i2<(e->n_occurs); i2++)
		{
			//
			en = e->occur[i2];
			f = 1;

			//
			match=0;
			//
			if(is->n_word>=2 && en->csum_w2==is->wordsum[1])
			{
				if(is->n_word==2) e->pairs++;
                		WriteLog("[%d] %s: Found pairs (2).\n",
		                        GetIsTickCount(),
                		        __FUNCTION__);
				match=1;
			}
			if(is->n_word>=3 && en->csum_w3==is->wordsum[2] && match==1)
			{
				if(is->n_word==3) e->pairs++;
                		WriteLog("[%d] %s: Found pairs (3).\n",
		                        GetIsTickCount(),
                		        __FUNCTION__);
				match=2;
			}
			if(is->n_word>=4 && en->csum_w4==is->wordsum[3] && match==2)
			{
				if(is->n_word==4) e->pairs++;
                		WriteLog("[%d] %s: Found pairs (4).\n",
		                        GetIsTickCount(),
                		        __FUNCTION__);
				match=3;
			//	printf("\nMATCH 3: gid=%d\n", e->gid);
			//	abort();
			}
			e->score += SCORE_FOR_PAIRS*f*(match*match*match);
		}
	}

past:

	//
	for(i=0; i<is->n_entsco; i++)
	{
		//
		e = is->entsco[i];

		//
		e->score += e->rnk*5000;
		e->score *= (e->rnk)+1;
		//fprintf(stderr, "lstab[%d] = %d\n", e->rnk, lstab[e->rnk]);
	}

	//
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
//
int compare_entscos(DWORD *a1, DWORD *a2)
{
        ENTSCO *e1,*e2;

	//
	if(*a1==NULL || *a2==NULL) {
		return 0;
	}

        //
        e1 = *a1;
        e2 = *a2;

	//
	if(e1==NULL || e2==NULL) {
		return 0;
	}

        //
        return e2->score - e1->score;
}


//////////////////////////////////////////////////////////////////////////////////////////
//
int SortResults(IS *is)
{
	//
	WriteLog("[%d] %s: qsort sorting %d entries ... ",
		GetIsTickCount(),
		__FUNCTION__, is->n_entsco);
	qsort(is->entsco, is->n_entsco, 4, compare_entscos);
	WriteLog("Done.\n");
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Displays results on stdout.
// Output format: score gid locs,.. rank host
//
int DisplayResults(IS *is)
{
	int i,i2,i3,i4,skipped,shown,dgid;
	static char str[1024],str2[1024],locs[1024];
	ENTSCO *e;
	//
	int dontdisp;

	//
	is->n_hosts[0] = 0;

	//
	WriteLog("[%d] %s: displaying %d entries\n",
		GetIsTickCount(),
		__FUNCTION__, is->n_entsco);

TryAgain:
	for(i=0,shown=0,skipped=0; i<is->n_entsco; i++)
	{
		//
		e = is->entsco[i];

		//
		dontdisp=0;
		if( is->n_word>1 && !e->pairs && OnlyPairsQualify )
		{
			if(debug)
				fprintf(stderr, "%s line %d: Only pairs qualify disqualifies %d\n",  __FUNCTION__, __LINE__, i);
			skipped++;
			dontdisp=1;
		}

		// Follow host-based display rules. Avoids too many entries per host to be displayed.
		if( HostQuery(is, e->host, 0) >= max_results_per_host )
		{
			if(debug)
				fprintf(stderr, "%s line %d: HostQuery disqualifies %d\n",  __FUNCTION__, __LINE__, i);
			skipped++;
			dontdisp=1;
		}

		// Get locs.
		strcpy(locs, "");
		for(i2=0,i3=0; i2<e->n_occurs; i2++)
		{
			//
		/*	if(is->n_word>1 && !e->occur[i2]->pairs || (e->occur[i2]->type&255)!=WORD_TYPE_REGULAR)
			{
				continue;
			}*/
			//
			sprintf(str, "%d,",
				e->occur[i2]->loc);
			strcat(locs, str);
			i3++;
		}

		//
		dgid = e->gid;
		//if(dgid >= 0 )
		//{
		if(dontdisp) {
			sprintf(str,
				"%.8d %d %s %d %x",
				e->score,
				e->gid,
				locs,
				e->rnk,
				e->host);
			WriteLog("%s\n", str);
		} else {
			sprintf(str,
				"%.8d %d %s %d %x",
				e->score,
				e->gid,
				locs,
				e->rnk,
				e->host);
			fprintf(stdout, "%s\n", str);
			//
			shown++;
		}
		//}
	}

	//
	if(shown<=0 && is->n_word>1 && OnlyPairsQualify==TRUE)
	{
		WriteLog("TRYING AGAIN with OnlyPairsQualify=FALSE.\n");
		OnlyPairsQualify = FALSE;
		goto TryAgain;
	}

	//
	WriteLog("[%d] %s: skipped %d similar entries\n",
		GetIsTickCount(),
		__FUNCTION__,skipped);

	//
	int cur_t = GetTickCount();
	fprintf(stderr, "%s: search took %d microsecond(s)\n",
		__FILE__, (cur_t-work_began_at)+1);

	//
	return i2;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int DisplayResults2(IS *is)
{
	int i,i2,i3,i4;
	static char str[1024],str2[1024],locs[1024];
	EN *e;

	//
	for(i=0; i<is->n_en; i++)
	{
		//
		e = is->en[i];

		// Get locs.
		strcpy(locs, "0,");

		//
		sprintf(str,
			"%.8d %d %s %d",
			1,
			e->gid,
			locs,
			e->rnk);

		//
		fprintf(stdout, "%s\n", str);
	}

	//
//	fprintf(stderr, "%d result(s) found.\n", is->n_entsco);

	//
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
void TimerThread(void)
{
	IS *is;
	
	//
	is = &Is;

	//
	for(is->tick=0; ;)
	{
		//
		is->tick++;

		//
		usleep(100);
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
//
void StartTimerThread(IS *is)
{
	pthread_t t;

	//
	is->tick=0;
	pthread_create(&t, NULL,
		TimerThread, NULL);
}

//

