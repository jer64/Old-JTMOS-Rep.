#!/bin/bash
#
# Database Directory Creation
#
# Altse is good for indexing individual websites, but this
# script demonstrates a long-term plan to build a search engine project
# capable of indexing an extensive amount (million) pages for
# to be searchable on an average VPS (refers to running: ccr).
#

# Make logs readable for every user.
chmod a+rw ~/sdb/logs/*

echo "Creating database directory ..."
mkdir -p ~/db

echo "Building database subdirectory structure ..."
cd ~/db
ln -f -s ~/sdb .
mkdir -p cid
mkdir -p cid/dict
mkdir -p cid/tmp
mkdir -p www
mkdir -p logs
mkdir -p tmp
touch site_completed.log
touch site.log
touch suggested_urls.txt
touch todo.txt

echo "Making database (db) directory public ..."
chmod a+rwx ~/db
chmod a+rw ~/db/*

cd ~/db
echo "Adding something to download at db/todo.txt ..."
echo "http://www.vunet.org" >> todo.txt
echo "http://www.skp.fi" >> todo.txt
echo "http://www.sosialismi.net" >> todo.txt
echo "http://www.freshmeat.net" >> todo.txt
echo "http://www.indymedia.org" >> todo.txt
echo "OK"
