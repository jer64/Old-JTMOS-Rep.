//--------------------------------------------------------------------------------------------
//
// wlidump.c
//
// TODO: add pageids_XX/base.txt support !!
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
//#include <zlib.h>
#include "selib.h"
#include "dardump.h"

int WLIDUMP_VERBOSE = 0;
#define DBPATH		"/home/vai/db"
#define MAX_PAGE_SIZE	16384
// * Wlidump debugging goes to stderr.
int wlidump_debugging = 0;

//--------------------------------------------------------------------------------------------
//
// buf will be stored following information:
// 0	host
// 1	path
// 2	title
// 3	preview
// 4	nfo
//
int WliDump(int sid,  BYTE *buf,int l_buf,int index_to_use)
{
	FILE *f;
	static char str[WLI_BLS],bigfn[8192],dbifn[8192],prepared_cmd[8192];
	DWORD offs,l,i,i2,d1;
	int fd,ch;
	// ..
	static char *filelist = NULL;
	static int l_filelist = 0;
	static char fn[512];
	// ..
	static int curpathnum = -1;
	static int curfilenum = -1;

	//
	static char dbpath_www[2048];

	// Check for base.txt.
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	strcpy(dbifn, "pageids2fn");
	if(index_to_use>0) {
		sprintf(str, "\_%d", index_to_use);
		strcat(dbifn, str);
	}
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	sprintf(fn, "%s/%s/base.txt",
		DBPATH, dbifn);
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	f = fopen(fn, "rb");
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	if(f != NULL) {
		fscanf(f, "%s", &dbpath_www);
		fclose(f);
	} else {
		sprintf(dbpath_www, "%s/www", DBPATH);
	}

	// FIRST CONVERT PAGE ID TO FILE NAME
	// 2000 entries per page id file, 200 different files per directory
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	int pathnum = sid/(2000*200);
	int filenum = sid/2000; // % 200;
	// Performance Fix
	// This *comparison makes a sort of cache in memory of current file list,
	// which avoids the possible scenario where the list has to be loaded
	// each time again and again.		* pathnum, filenum
	////if(WLIDUMP_VERBOSE) fprintf(stderr, "%d %d %d\n", filelist, pathnum, filenum);
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	if(pathnum != curpathnum && filenum != curfilenum) {
		if(WLIDUMP_VERBOSE) {
			fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
		}
		if(filelist!=NULL) {
			SafeFree(filelist);
			filelist = NULL;
		}
                strcpy(dbifn, "pageids2fn");
		if(WLIDUMP_VERBOSE) {
			fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
		}
                if(index_to_use>0) {
                        sprintf(str, "\_%d", index_to_use);
                        strcat(dbifn, str);
                }
       		sprintf(fn, "%s/%s/0/0/0/%d/%d.dat",
			DBPATH, dbifn, pathnum, filenum);
		f = fopen(fn, "rb");
                if(f==NULL) {
                                        fprintf(stderr, "%s (error): File not found: %s\n",
                                        __FUNCTION__, fn);
                        return 2;
                }
		if(WLIDUMP_VERBOSE) {
			fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
		}
		fseek(f,0,SEEK_END);
		l_filelist = ftell(f);
		fseek(f,0,SEEK_SET);
		filelist = imalloc(l_filelist);
		fread(filelist,l_filelist,1,f);
		fclose(f);
	}
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	if(filelist!=NULL) {
		GetLine(filelist,l_filelist,sid % 2000,fn);
	}

	// fn now contains (dump) file name of specified PAGE ID
	// f.e. ./1.b/1.bp.blogspot.com/1.dump.gz
	// which is convertible to an absolute path of
	// /home/vai/db/www/X

	// 
	if(WLIDUMP_VERBOSE)
		fprintf(stderr, "%s line %d: pageid2fn conversion result: \"%s\"\n", __FUNCTION__, __LINE__, fn);
	//sleep(1);

	//
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	memset(buf,0,l_buf);

	FILE *zf;

	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	// Load ".dump.gz" file using zlib zopen.
	sprintf(bigfn, "%s/%s", dbpath_www, fn);

        sprintf(prepared_cmd, "zcat %s", bigfn);

	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
        if(wlidump_debugging) {
                fprintf(stderr, "%s/%s/line %d: attempting popen(\"%s\", \"%s\");\n",
                                __FILE__, __FUNCTION__, __LINE__,
                                prepared_cmd, "r");
        }

	zf = popen(prepared_cmd, "r");
        if(zf==NULL) {
                if(WLIDUMP_VERBOSE || wlidump_debugging)   
                        fprintf(stderr, "%s (error): File not found: %s\n",     __FUNCTION__, fn);
                return 1;
        }
        if(wlidump_debugging) {
                fprintf(stderr, "%s/%s/line %d: popen opened a file handle (0x%x)\n",
                                __FILE__, __FUNCTION__, __LINE__,
                                zf);
        }

	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
        int LIM = 1024*1024;
	//char *temppi = imalloc(LIM);
	for(i=0; i<l_buf && i<(LIM); i++) {
		ch = fgetc(zf);
		if(ch>=0) {
			buf[i] = ch;
		} else {
			break;
		}
	}
	if(WLIDUMP_VERBOSE) {
		fprintf(stderr, "%s/%s/line %d: \n", __FUNCTION__, __FILE__, __LINE__);
	}
	if(WLIDUMP_VERBOSE)
		fprintf(stderr, "%s line %d: %d byte(s) load from \"%s\".\n",  __FUNCTION__, __LINE__, i, fn);
	pclose(zf);

	//
	return 0;
}


