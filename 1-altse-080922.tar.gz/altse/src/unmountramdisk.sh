#!/bin/bash
sudo umount /home/vai/sdb/cid/0
