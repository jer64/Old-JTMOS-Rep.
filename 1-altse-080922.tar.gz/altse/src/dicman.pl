#!/usr/bin/perl
##########################################################################
#
# dicman.pl -- Dictionary (DAR) Manipulation Tool.
#
##########################################################################
#
use POSIX;
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =		"$NWPUB_CGIBASE/sdb";	# search database root directory
$CID =		"$SDB/cid";		# central index
$LISTS =	"$SDB/cid/lists";	# list files directory
$DADI =		"$SDB/cid/data";	# data files
$DICT =		"$SDB/cid/dict";	# big index with dictionaries

#
main();

############################################################################
#
# Remove a specified section from the dictionary.
#
sub DicRemSec
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn,$c);

	#
	if( !(-e $_[0]) ) { return(); }

	#
	@lst = LoadList($_[0]);

	#
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		#
		if( $lst[$i] eq $_[1])
		{
			# Skip past this section.
			loop: for(; $i<($#lst+1); $i++)
			{
				if($lst[$i] eq "")
				{
					last loop;
				}
			}
		}
		else
		{
			# Copy to the result.
			loop: for(; $i<($#lst+1); $i++)
			{
				$lst2[$i2++] = $lst[$i];
				if($lst[$i] eq "")
				{
					last loop;
				}
			}
		}
	}

	# Write result over the old one.
	open($f, ">$_[0]") || die "can't write $_[0]";
	for($i=0; $i<($#lst2+1); $i++)
	{
		print $f "$lst2[$i]\n";
	}
	close($f);

	#
}

############################################################################
#
# dicman.pl remove $fn2 $dir
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn,$c);

	#
	$c = $ARGV[1];

	#
	if($c eq "")
	{
		print "Usage: dicman.pl [dictionary file] [command] [more parameters]\n";
		print "Example: dicman.pl dict.txt remove section\n";
		exit;
	}

	# Remove a dictionary section.
	if($c eq "remove")
	{
		# [dictionary file] [section]
		DicRemSec($ARGV[0], $ARGV[2]); 
		exit;
	}

	#
	print STDERR "Unknown command '$c'.\n";
}

