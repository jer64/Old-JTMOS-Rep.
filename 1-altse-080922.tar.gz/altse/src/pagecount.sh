#!/bin/bash
find . |grep html|wc -l
