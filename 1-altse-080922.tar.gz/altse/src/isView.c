//////////////////////////////////////////////////////////////////////////////////////////
//
// Altse Internet Search.
// (C) 2005 by Jari Tuominen (jari@vunet.org).
//
// Usage: isView "word1 word2 word3 word4" audio
// Use quotes.
//
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "iscfg.h"
#include "wlidump.h"
#include "dardump.h"

//////////////////////////////////////////////////////////////////////////////////////////
//
void ViewResult(IS *is, ENTSCO *e)
{
	static char dar[16384],str[16384],tmp[16384];
	char *content;
	int gid,line_nr;

	//
	gid = e->gid;

	//
	DarDump(gid, dar,16384, ActiveIndexNr);
	//content = WliSearch(gid, is->word[0]);

        // Get host, path, title, preview nfo (dardump).
        for(line_nr=0; line_nr<100; line_nr++) {
                GetLine(dar,4900, line_nr, (BYTE*)str);
                if( !strcmp(str, "[BASIC PAGE INFO]") ) {
                        line_nr++;
                        break;
                }
        }

	//
	GetLine(dar,16384, line_nr, str); printf("%s\n", str);	line_nr++; // host
	GetLine(dar,16384, line_nr, str); printf("%s\n", str);	line_nr++; // path
	GetLine(dar,16384, line_nr, str); printf("%s\n", str);	line_nr+=2; // title (jumps past desc.)
	RemoveControlCodes(content);
	printf("%s\n", content);
	GetLine(dar,16384,line_nr, str); printf("D%d - score %d - %s\n", gid, e->score, str); // page gen. info (one-liner)
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int ViewResults(IS *is, int only_important)
{
	int i,i2,i3,i4,l,skipped,shown;
	ENTSCO *e;

	//
	printf("%d\n\n", is->n_entsco);

	//
	for(i=0,skipped=0,shown=0; i<is->n_entsco && i<10; i++)
	{
		//
		e = is->entsco[i];

                //
                if( (is->n_word>1 && !e->pairs) && only_important )
                {
                        skipped++;
                        continue;
                }

                //
                if( HostQuery(is, e->host) >= max_results_per_host )
                {
                        skipped++;
                        continue;
                }

		//
		ViewResult(is, e);
		printf("\n");
		shown++;
	}

	//
	return shown;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int main(int argc, char **argv)
{
        int ret;
        IS *is;

        //
        work_began_at = GetTickCount();

        //
        AltseLoadConfig();
        is_LoadConfig();

        /////////////////////////////////////////////////////////////////////////////////////
        //
        if(argc<2)
        {
                fprintf(stderr, "Internet Search\n");
                fprintf(stderr, "Usage: is [search keyword] [mode] [host]\n");
                fprintf(stderr, "Examples:\n");
                fprintf(stderr, "is \"world\" text www.yle.fi\n");
                fprintf(stderr, "is \"apple\" image www.playboy.com\n");
                fprintf(stderr, "is \"culture\" video www.archive.org\n");
                fprintf(stderr, "is \"monkey\" audio www.mp3.com\n");
                return 0;
        }

        //
        is = InitIS(argc, argv);

        //
        SearchIndexes(is);

        //
        ProcessResults(is);

        //
        SortResults(is);

        //
	if( !ViewResults(is, TRUE) ) {
		ViewResults(is, FALSE);
	}

        //
        fclose(flog);

        //
        return 0;
}

