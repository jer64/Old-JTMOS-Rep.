//
#ifndef __INCLUDED_INDE_H__
#define __INCLUDED_INDE_H__

// Max words. Note: Large memory chunk-allocations make inde very slow.
#define MAX_WWW_PAGE_SZ	(1024*1024* 1)
#define MAX_WL          (1024*1024* 1) // x Mb for pointers of words,
					// which is cumulative to the
					// amount of memory consumed
					// but more than the pointers.

//
#define INDE_N_MAX_ENT	200000

//
#define MAX_IMP_WORDS   200000
//
//#define FN_IMP          "/db/sdb/quality/important-words.txt"

//
#define DIC_HDRSZ		64
// For inde.c and is.c.
#define DIC_ID                  0xFCE2E37B
// When creating new dictionary, how much preallocate space for it?
#define DIC_NEW_PREALCSZ        (1024*4)
// After first area is ran out, how much to allocate more then.
#define DIC_MORE_PREALCSZ       (1024*128)
// At how much left free space to trigger allocation of more space.
#define DIC_PREALC_TRIGGER      (DIC_NEW_PREALCSZ/4)

//
#define MAIN_MEM_BUF_SZ         (1024*1024*400) // 400 MB
#define KEYWORD_MIN_L           2
#define KEYWORD_MAX_L           48

//
int CountWord(char *w1,char *w2,char *w3,char *w4,
        DWORD loc,DWORD gid, INDE *in, DWORD type,HOSTHASH host); //,DWORD urlhash);
ENT *AddNewWord(char *w1,char *w2,char *w3,char *w4,
        INDE *in);
int FlushDic(INDE *in, int rnk);
int FlushDir(INDE *in, int rnk);
//int compare_ents(ENT *p1, ENT *p2);
extern char GLOP[256];
char inde_debug;
char inde_debug_verbose;
char inde_verbose;

//
int min_prisec,max_prisec;
char inde_debug;
INDE inde;
char GLOP[256]; // global path
DWORD persec;
//
int inde_start_time;
//
int GetRank(char *host, char *path, char *description1, char *keywords,
        int file_age);

#endif

