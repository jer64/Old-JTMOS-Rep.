// selib.h - Search Engine LIBrary...
#ifndef __INCLUDED_SELIB_H__
#define __INCLUDED_SELIB_H__

//
#include <stdint.h>
//
#define BYTE uint8_t
#define WORD uint16_t
#define DWORD uint32_t
#define QWORD uint64_t

//
#define FN_WORDS_LIST "/home/vai/sdb/cfg/wordslistfn.cfg"

/*
typedef unsigned char BYTE;
typedef unsigned short int WORD;
typedef unsigned long int DWORD;
typedef unsigned long long int QWORD;

*/
//
#define HOSTHASH	DWORD

//
#include "altse.h"

//
#define DAR_SZ		512
#define WLI_BLS		(1024*1024*1) // 1 Mb limit for page dumps.

//
#define TRUE			1
#define FALSE			0

//
#define DIC_HDRSZ               64


// INDIVIDUAL WORD PROPERTY
#define WORD_TYPE_REGULAR		1
#define WORD_TYPE_TITLE			2
#define WORD_TYPE_HOST			3
#define WORD_TYPE_URL			4
#define WORD_TYPE_META			5
#define WORD_TYPE_AUDURL		6
#define WORD_TYPE_VIDURL		7
#define WORD_TYPE_IMAURL		8
#define WORD_TYPE_PREVIEW		9
#define WORD_TYPE_META_DESCRIPTION	10
#define WORD_TYPE_META_KEYWORDS		11
#define WORD_TYPE_META_AUTHOR		12
#define WORD_TYPE_PAGEBEG		13
#define WORD_TYPE_PAGEEND		14

// PAGE WIDE PROPERTIES
// Additional bits of information.
// (tells whether if the page contains any
//  of the following content, e.g. audio files).
#define WORD_TYPE_AUDIO		0x10000000
#define WORD_TYPE_VIDEO		0x08000000
#define WORD_TYPE_IMAGE 	0x04000000
#define WORD_TYPE_HIGH_PROFILE	0x02000000 // e.g. /index.html		(important)
#define WORD_TYPE_PORTAL	0x01000000 // e.g. www.yahoo.com	(very important)

// For EN, DEN and others.
#include "altse_binary_structures.h"

//
extern int selib_seperate_prioritize_mode;

//
int fs(const char *fn);
DWORD csum(BYTE *buf, int l_buf);
void FixString(char *s);
DWORD n2i(char *fn);
void GoodWord(BYTE *s);
int isalnum1(BYTE ch);
void FixString1(char *s);
void OkWord(BYTE *s);
int ch2num(BYTE ch);
void GetLine(BYTE *buf, int l_buf, int which, BYTE *dst);
void RepNonOk(BYTE *s);
int isok(BYTE ch);
int isKeyChar(BYTE ch);
void fputd(DWORD d1, FILE *f);
void GetString(BYTE *buf, int l_buf, int which, BYTE *dst);
void *SafeFree(void *_ptr);

#endif

