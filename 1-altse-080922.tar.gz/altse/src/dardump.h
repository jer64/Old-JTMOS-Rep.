//
#ifndef __INCLUDED_DARDUMP_H__
#define __INCLUDED_DARDUMP_H__

//
char dardump_global_page_dump_fn[];
//
int DarDump(int sid,  BYTE *buf,int l_buf, int index_to_use);

#endif

