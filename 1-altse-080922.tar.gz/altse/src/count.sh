#!/bin/bash
./look.sh |xargs cat  |wc -l
