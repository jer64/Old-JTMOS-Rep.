//
#ifndef __INCLUDED_IS_H__
#define __INCLUDED_IS_H__

//
#define MAX_DIC_SINGLE_FIND_BYTES (1024*1024*200)

//
#define MAX_MEMORIZE		(1000*1000)

//
#define FN_DATABASE        "/db/sdb/tmp/is.db"

// SEE altse_binary_structures.h
//#define REAL_EN_SZ              (sizeof(DEN))
//
#define N_MAX_LOCS		100

//
#define TRUE                    1
#define FALSE                   0

//
#define MAGIC_NUMBER            0x8CAEBB32

// For EN, DEN, and other structures.
#include "altse_binary_structures.h"

// Entry score.
typedef struct
{
        //
        DWORD gid,rnk,score,test;
	HOSTHASH host,path,url;
        DWORD pairs;
	DWORD type;
        //
        EN *occur[N_MAX_LOCS];
        int n_occurs; // n_locs equals n_sums
}ENTSCO;

// Internet Search main structure.
typedef struct
{
        // Entry score table.
        ENTSCO **entsco;
        int n_entsco;
        int max_entsco;

        //
        EN **en;
        int n_en;
        int max_en;
        BYTE *buf;
        int l_buf;
        BYTE *buf2;
        int l_buf2;

        // Actual search keywords.
        char *word[50],*ascii_word[50];
        DWORD word_wild[50];
        DWORD wordsum[50];
        DWORD ascii_wordsum[50];
        DWORD word_resco[50];
        int n_word;
        DWORD curword;

        // Host hash (32-bit checksum).
        HOSTHASH *hosts_sum[10];
        // Number of times this host has occured so far.
        DWORD *hosts_cnt[10];
        int n_hosts[10];

	// imp = IMPortant words
	// Loaded from /db/sdb/quality/important-words.txt .
	DWORD *imp;
	DWORD n_imp;

        //
        int     n_list[16];
        DWORD   list_gid[16][100000];
        ENTSCO *list_ent[16][100000];

	//
	DWORD resco,word_level;

	//
	DWORD tick;
}IS;

//
extern IS Is;

//
void IncreaseScore(IS *is, DWORD how_much,
        DWORD gid, DWORD location, DWORD rnk, HOSTHASH host,//HOSTHASH url,
	DWORD w1,
	DWORD w2,
	DWORD w3,
	DWORD w4);
//
DWORD GetIsTickCount(void);
DWORD work_began_at;
FILE *flog;
int max_results_per_host;
DWORD lstab[1000];
int RANK;
// Debug ON (1), OFF (0).
int debug;

//
int max_search_word_level;
int quick_less_verbose;
int or_mode;

#endif


