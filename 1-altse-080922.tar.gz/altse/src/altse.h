// altse.h
// SEE ALSO iscfg.h
#ifndef __INCLUDED_ALTSE_H__
#define __INCLUDED_ALTSE_H__

//
#define ETC_ALTSE_CONF "/etc/altse.conf"

//
#include "selib.h"

//
extern char IS_CFG_FILE[];
extern char dictloc[];
extern char database_path[];
extern char WLI_BIGFN[];
//
extern int OPTIMIZE_FOR_SEARCH_SPEED;
//
extern int SCORE_FOR_PAIRS;
extern int SCORE_FOR_RANK;
extern DWORD MAX_DIVING_DEPTH;
extern DWORD RESULT_SPACE_BYTES;
extern int MAX_LOCS;
extern int MAX_RANK;
extern int N_MAX_SEARCH_WORDS;
extern int N_MAX_HOSTS;
extern int N_MIN_EXPECT_ENTRIES;
extern int N_CHARS_MATTER;
// Index used by is.c.
extern int ActiveIndexNr;
// Index used by inde.c, dicwipe.
extern int ProductionIndexNr;
//
extern int ALTSE_N_RANKS;
//
extern char inclusive_preview[];
extern char inclusive_title[];
extern char inclusive_path[];
extern char inclusive_host[];
extern char inclusive_keywords[];
extern char inclusive_description[];

#endif
