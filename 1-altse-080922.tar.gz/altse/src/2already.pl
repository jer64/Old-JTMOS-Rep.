#!/usr/bin/perl
# Builds already.txt files, DO NOT USE.
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use Cwd 'chdir';

#
AltseOpenConfig();

#
main();

#
sub hex_to_ascii ($)
{
	## Convert each two-digit hex number back to an ASCII character.
	(my $str = shift) =~ s/([a-fA-F0-9]{2})/chr(hex $1)/eg;
	return $str;
}

#
sub parsefn
{
        my $str = $_[0];
        $str =~ s/^(.+\/.+\/).+\.[a-z]+\.gz$/$1/;
        my $str2 = $_[0];
        $str2 =~ s/^.+\/.+\/(.+)\.[a-z]+\.gz$/$1/;
        $str2 = hex_to_ascii($str2);
        return $str2;
}

#
sub getfnhex
{
        my $str = $_[0];
        $str =~ s/^(.+\/.+\/).+\.[a-z]+\.gz$/$1/;
        my $str2 = $_[0];
        $str2 =~ s/^.+\/.+\/(.+)\.[a-z]+\.gz$/$1/;
        $str2 = hex_to_ascii($str2);
        return $str;
}

#
sub main
{
	my ($i,$i2,@lst,$str,$str2,$url,$f,$path,%ald,$n1,$n2,$n3,$n4,$hexx,$fn2);

	#
	@lst = LoadList("$DB/www/list.txt");

	#
	chdir("$DB/www");

	#
	loop: for($i=0; $i<($#lst+1); $i++) {
		if(!($lst[$i]=~/^.*\/[0-9]+\.[a-z]+\.gz$/)) { 
			$url = parsefn($lst[$i]);
			$hexx = getfnhex($lst[$i]);
			#print "$lst[$i]: $str\n";
			$str = $lst[$i];
			$str =~ s/^.+\/(.+)\/.+$/$1/;
			$id = $str;
			$id =~ s/^www\.//;
			$id =~ s/^(.{3}).*$/$1/;
			$fn = "$DB/www/$id/$str/already.txt";
			$path = "$DB/www/$id/$str/";
			if(-e $path) {
doitagain:
				if( !defined($ald{$fn}) || $ald{$fn} eq "") {
					$ald{$fn} = "0";
				} else {
					$ald{$fn}++;
				}
	
				$fn2 = $lst[$i];
				$fn2 =~ s/\.dump.gz/\.html\.gz/;
	
				$n1 = $lst[$i];
				$n1 =~ s/^(.+)\/[^\/]+$/$1/;
				$n1 .= "/$ald{$fn}";
				if(-e $n1) { goto doitagain; }
				$n2 = $n1;
				$n1 .= ".dump.gz";
				$n2 .= ".html.gz";
				print $lst[$i] . "\n";
				#print $fn2 . "\n";
				#print $n1 . "\n";
				#print $n2 . "\n";
				system("mv -f \"$lst[$i]\" \"$n1\"");
				system("mv -f \"$fn2\" \"$n2\"");

				# append to already.txt
				open($f, ">>$fn");
				# URL
				print $f "$url\n";
				close($f);
			}
		}
	}

	#
}

#

