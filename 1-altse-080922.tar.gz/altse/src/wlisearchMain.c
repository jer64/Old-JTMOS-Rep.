//--------------------------------------------------------------------------------------------
//
// wlisearch.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "wlisearch.h"

//--------------------------------------------------------------------------------------------
//
// wlisearch [WLI ID] "keywords list here"
//
int main(int argc, char **argv)
{
	char *res;
	int id,which_index;

        //
        if(argc<4)
        {
                //
                fprintf(stderr, "Usage: wlisearch [WLI ID] [which index] \"keywords list here\"\n");
                return 0;
        }

	//
	AltseLoadConfig();

        //
	sscanf(argv[1], "%d", &id);
	sscanf(argv[2], "%d", &which_index);
	res = WliSearch(id, argv[3], which_index);
	//
	printf("%s\n", res);

        //
        return 0;
}

