//////////////////////////////////////////////////////////////////////////////////////////
//
// Altse Internet Search.
// (C) 2005-2011 by Jari Tuominen (jari@vunet.org).
// See is_main.c for command line interface functionality.
//
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
//#include <db.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "is_dicsinglefind.h"
#include "is_processresults.h"
#include "is_searchindexes.h"
#include "iscfg.h"

// Use a specific host? (two choices)
HOSTHASH look_host=0,look_host2=0;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
int DicSingleFind(IS *is, char *dicfn, char *key, DWORD csum)
{
	BYTE *buf;
	DWORD l_buf,l_buf2,l_content,i,i2,rv,x,y,z,sz,fixed_sz,hits,hdrid,offs1,offs2,cnt,sum,
		found,guard,g1,g2,
		used,saved,items,item,dd,
		corrupted,max_load,load,tsz;
	void *p;
	DWORD *dp;
	EN *e;
	static char str[8192];
	static char letters[256],dirfn[1000],dixfn[1000];
	int Data,dir_sz;
	int fd,fdd,fd_dix;
	BYTE *dir;
	static DWORD START_OF_ENTRY,END_OF_ENTRY,END_OF_KEYS,MAX_LOAD;
	static BYTE tmp[256],*tmpbuf;

	//
	MAX_LOAD = MAX_DIC_SINGLE_FIND_BYTES;

	//
	strcpy(dirfn, dicfn);
	strncpy(dirfn+(strlen(dirfn)-3),"dir",3);
	strcpy(dixfn, dicfn);
	strncpy(dixfn+(strlen(dixfn)-3),"dix",3);

	//
	fdd = open(dirfn, O_RDONLY);
	if(fdd<0) { fprintf(stderr, "%s: file '%s' not found!\n", __FUNCTION__, dirfn); return 2; }

	//
	WriteLog("Opening DIX file (%s).",
		dixfn);
	fd_dix = open(dixfn, O_RDONLY);
	if( fd_dix >= 0 )
	{
		// USE DIX INDEX.
		//
		tsz = lseek(fd_dix,0,SEEK_END);
		lseek(fd_dix,0,SEEK_SET);
		tmpbuf = imalloc(tsz);
		read(fd_dix, tmpbuf, tsz);
		close(fd_dix);

		// Find place.
		items = tsz/16;
		for(i=0,p=tmpbuf,found=FALSE; i<items; i++,p+=16)
		{
			if( !strncmp(key,p,8) )
			{
				dp = p;
				offs1 = dp[2];
				offs2 = dp[3];
				WriteLog("%s: %.8X - %.8X\n",
					key,offs1,offs2);
				lseek(fdd, offs1, SEEK_SET);
				dir_sz = offs2-offs1;
				found = TRUE;
				break;
			}
		}

		//
		//if(!found) { goto slow_way; }
	}
	else
	{
slow_way:
		WriteLog("No DIX file (fd_dix = %d, %s) - reading whole shit.\n",
			fd_dix, dixfn);
		// SILLY. NO DIX FOUND.
		// READ WHOLE SHIT IN MEMORY AT ONCE.
		dir_sz = lseek(fdd,0,SEEK_END);
		lseek(fdd,0,SEEK_SET);
	}

	//
	dir = imalloc(dir_sz);
	WriteLog("[%d] %s: reading %dK of data from DIR-file %s\n",
		GetIsTickCount(),
		__FUNCTION__,
		((dir_sz/1024)+1),
		dirfn);
	read(fdd, dir, dir_sz);
	close(fdd);
	WriteLog("[%d] %s: read done\n",
		GetIsTickCount(),
		__FUNCTION__);

	//
	strncpy(str,dir+4,8); str[8]=0;
	WriteLog("   CONTENT  %s (dir_sz=0x%x): ",  str, dir_sz);
	for(i=0,dp=dir; i<(dir_sz>>2) && i<16; i++)
	{
		WriteLog("%.8X ",
			dp[i]);
	}
	WriteLog("\n");

	//
	START_OF_ENTRY = 0x12345678;
	END_OF_KEYS    = 0xFFFFFFFF;
	END_OF_ENTRY   = 0xAAAAAAAA;

	// LOADING

	//
	fd = open(dicfn, O_RDONLY);
	if(fd<0) { return 1; }

	//
	sz = lseek(fd,0,SEEK_END);
	//
	WriteLog("[%d] %s: (%d) %s (%d, %dK)\n",
		GetIsTickCount(),
		__FUNCTION__,
		is->n_en, dicfn, sz, (sz/1024)+1);
	//
	//items = sz/REAL_EN_SZ;
	//buf = imalloc(sz+100);
	//lseek(fd,DIC_HDRSZ,SEEK_SET);
	//read(fd, buf, sz);
	buf = imalloc(MAX_LOAD);

	//
	for(dp=dir,x=0,load=0; x<dir_sz; )
	{
		//
		if(*dp!=START_OF_ENTRY)
		{
cor:
			WriteLog("%s: Corruption detected at DIR:0x%X - reads = %X.\n",
				__FUNCTION__,
				x,
				*dp),
			exit(10);
		}
		//
		dp++; x+=4;

		//
		memcpy(letters,dp, 8);
		//
		dp+=2; x+=8;

		//
		offs1 = *dp;
		//
		dp+=1; x+=4;

		//
		if( strncmp(letters,key,8) )
		{
			// Keys...
			for(; *dp!=END_OF_KEYS && x<dir_sz; x+=4,dp++);
			for(; *dp!=END_OF_ENTRY && x<dir_sz; x+=4,dp++);
			dp++; x+=4;
			continue;
		}

		//
		WriteLog("[%d] %s: %s <-> %s\n",
			GetIsTickCount(),
			__FUNCTION__,
			letters,key);

		// Keys...
		for(; *dp!=END_OF_KEYS && x<dir_sz; x+=4,dp++)
		{
			//
			if(*dp==END_OF_KEYS) break;
		}
		//
		dp+=1; x+=4;

		//
		offs2 = *dp;
		//
		dp+=1; x+=4;

		//
		for(; *dp!=END_OF_ENTRY && x<dir_sz; x+=4,dp++);
		//
		dp++; x+=4;

		//
		WriteLog("[%d] %s: READ %X-%X (%dK, key=%s)\n",
			GetIsTickCount(),
			__FUNCTION__,
			offs1,offs2,
			((offs2-offs1)/1024)+1,
			key);
		if( (load+(offs2-offs1)) >= MAX_LOAD )
		{
			WriteLog("%s: MAX_LOAD exceeded\n",
				__FUNCTION__);
			break;
		}

		//
		offs1 = (((offs1-DIC_HDRSZ)/REAL_EN_SZ)*REAL_EN_SZ)+DIC_HDRSZ;
		offs2 = (((offs2-DIC_HDRSZ)/REAL_EN_SZ)*REAL_EN_SZ)+DIC_HDRSZ;

		//
		lseek(fd, offs1, SEEK_SET);
		read(fd, buf+load, (offs2-offs1));

		//
		load += (offs2-offs1);
	}

	//
	WriteLog("%s: %dK of data loaded\n",
		__FUNCTION__,
		(load/1024)+1);

	//
//	abort();

	//
	sz = load;
	items = sz/REAL_EN_SZ;

	//
	close(fd);

	//
	WriteLog("[%d] %s: read done\n",
		GetIsTickCount(),
		__FUNCTION__);


	// SEARCHING
	//
	WriteLog("SEARCHING WITH %d KEYWORD(S):\n",
		is->n_word);
	for(x=0; x<is->n_word; x++)
	{
		WriteLog("WORD %d: %s\n",
			x, is->word[x]);
	}

	//
	for(x=0,p=buf,hits=0,corrupted=0;
			x<items && hits<N_MIN_EXPECT_ENTRIES; x++,p+=REAL_EN_SZ)
	{
		//
		//fprintf(stderr, "p=%x\n", p);
		e = (void*)p;

		//
		if(e->rnk<0)
		{
			if(!corrupted)
			{
				WriteLog("%s [e=0x%x]: corrupted entry? e->rnk=%d\n",
					__FUNCTION__,
					e,
					e->rnk);
			}
			if(corrupted==1)
			{
				WriteLog("      ... more corrupted entries follow ...\n");
			}
			corrupted++;
			continue;
		}

		// csum,loc,gid

		// BROKEN TRICK TODO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
/*		if( (csum==0 || e->csum_w1==csum) &&
			(search_type==0 || (e->type&search_type)) &&
			(look_host==0  || (e->host==look_host || e->host==look_host2)) )
		{*/
		if(  (look_host==0  || (e->host==look_host || e->host==look_host2))  ) {
			//
			NewMatch(is, e);
			hits++;
		}
/*		}
		else
		{
			if(e->csum_w1==csum)
				WriteLog("host %.8x <> %.8x\n",
					look_host,e->host);
		}*/
	}

	//
	WriteLog("%s/%s line %d: %d hit(s) found from %d item(s).\n",
		__FUNCTION__, __FILE__, __FUNCTION__,
		hits, items);
	WriteLog("%s/%s line %d: %d/%d corrupted entries detected.\n",
		__FUNCTION__, __FILE__, __FUNCTION__,
		corrupted,x);

	//
	free(buf);

	//
	return hits;
}
