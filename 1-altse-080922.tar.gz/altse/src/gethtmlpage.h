//
#ifndef __INCLUDED_GETHTMLPAGE_H__
#define __INCLUDED_GETHTMLPAGE_H__

//
BYTE *GetHtmlPage(BYTE *host, BYTE *path);

#endif
