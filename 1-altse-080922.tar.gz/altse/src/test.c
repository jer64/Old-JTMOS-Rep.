//
#include <stdio.h>
#include <time.h>

//
int main()
{
	printf("%d\n", time(NULL));
	return 0;
}
