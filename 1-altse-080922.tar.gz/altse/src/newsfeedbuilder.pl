#!/usr/bin/perl
# newsfeedbuilder.pl
# Bulds a news feed of index.
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use Cwd 'chdir';
use Encode;

#
AltseOpenConfig();

#
if($ARGV[0] eq "") {
	print STDERR "Usage: newsfeedbuilder.pl [-i INDEX NR] [options]\n";
	print STDERR "Description:\n";
	print STDERR "       Creates a news feed out of an index\n";
	print STDERR "       of pageid2fn database of pages.\n";
	print STDERR "Options:\n";
	print STDERR "       newsfeewbuilder.pl -i 100\n";
	exit;
}

#
for($i=0; $i<($#ARGV+1); $i++) {
        #
        if($ARGV[$i] eq "-i")
        {
                $USE_INDEX_NR = int($ARGV[$i+1]);
                print STDERR "Using index " . $USE_INDEX_NR . "\n";
        }
}

#
chdir("$DB");

# Default www-pages directory path.
$WWW_PAGES_PATH = "$DB/www";

# pageids2fn: Page IDs to file name -conversion database.
$PAGEIDSPATH = "pageids2fn";
if(int($USE_INDEX_NR) > 0) {
        $PAGEIDSPATH .= "\_$USE_INDEX_NR";
}

# Write definition of WWW-pages at pageids directory root file.
my $base_fn = "$DB/$PAGEIDSPATH/base.txt";
if(-e $base_fn) {
	$WWW_PAGES_PATH = join("\n", LoadList($base_fn));
} else {

}

#
$nr_pages = join("\n", LoadList("$PAGEIDSPATH/id.cnt"));

#
$MAX_NR_ARTICLES_TO_SHOW = 15;

#
main();

#
sub FixScands
{
        my ($str);
        $str = $_[0];
        $str =~ s/ä/&auml;/g;
        $str =~ s/ö/&ouml;/g;
        $str =~ s/\ �\x{AC}/\'/g;
        $str =~ s/�/&auml;/g;
        $str =~ s/�/&Auml;/g;
        $str =~ s/�/&ouml;/g;
        $str =~ s/�/&Ouml;/g;
        $str =~ s/\|/&\#124;/g;
        $str =~ s/[^a-zA-Z������0-9\'\�\`\.\,\!\"\#\�\%\&\/\(\)\=\@\�\$\{\[\]\<\>\:\;\+\-\x{80}]\x{0000}\x{FF}\x{80}/ /g;

        my $chars = $str;
        my $octets = encode 'iso-8859-1', $chars;
        return $octets;
}

# [absolute path] [domain name]
sub ViewPageResult
{
	my ($i,$i2,$str,$str2,$lt,@lst,$f,$fn,@websites,$nr,
		$url,$cap,$description,$fn_regex,$filter_regex,$con,$age);

#[BASIC PAGE INFO]
#0 money.cnn.com
#1 /2012/06/12/investing/jpmorgan-jamie-dimon-testimony/index.htm
#2 Dimon: JPMorgan traders didn't understand risks - Jun. 12, 2012
#3 JPMorgan Chase CEO Jamie Dimon will tell Congress Wednesday that the bank's massive loss can be blamed on insufficient risk $
#4 341, 16K
#5 /home/vai/db/frontpages/./mon/money.cnn.com/53.html.gz
#6  [1]CNNMoney International U.S. [2]Log In [3]Log Out [4]CNN Submit [5]Home [6]Video [7]Markets [8]In
#7 jpmorgan chase, jamie dimon, ceo, banks, london whale, risk, heding, volcker rule, white whale, chief investment office, jpm$

	#
	$fn = $_[0] . ".info";
	$fn_dump = $_[0] . ".dump.gz";

	# Load filter regex.
	$fn_regex = "$SDB/html/cgi/cfg/$_[1].regex";
	if(-e $fn_regex) {
		$filter_regex = join("\n", LoadList($fn_regex));
	}

	#
	if(-e $fn) {
		#
		@lst = LoadList($fn);

		#
		loop: for($i=0; $i<($#lst+1); $i++) {
			if($lst[$i] eq "[BASIC PAGE INFO]") {
				$i++;
				last loop;
			}
		}

		#
		$age =		FileAge($fn_dump);
		$url =		"http://" . $lst[$i+0] . $lst[$i+1];
		$cap =		$lst[$i+2];
		$description =	$lst[$i+3];
$cap = FixScands($cap);
#$cap =~ s/\|/&brvbar;/g; ## poor pipe character
$cap =~ s/\|/&\#124;/g;
$cap =~ s/[^a-zA-Z������0-9\'\�\`\.\,\!\"\#\�\%\&\/\(\)\=\@\�\$\{\[\]\<\>\:\;\+\-\x{80}]\x{0000}\x{FF}\x{80}/ /g;
$cap =~ s/ä/�/g;
$cap =~ s/ö/�/g;
$cap =~ s/ä/�/g;
$cap =~ s/ö/�/g;
$cap =~ s/\ �\x{AC}/\'/g;

		$description =~ s/\|/&brvbar;/g;
$description = FixScands($description);
$description =~ s/\ �\x{AC}/\'/g;
$description =~ s/[^a-zA-Z������0-9\'\�\`\.\,\!\"\#\�\%\&\/\(\)\=\@\�\$\{\[\]\<\>\:\;\+\-]\x{80}]\x{0000}\x{FF}\x{80}/ /g;
$description =~ s/ä/�/g;
$description =~ s/ö/�/g;
$description =~ s/^\s+//;
$description =~ s/\s+$//;
		#$cap =~         s/[a-z0-9\-\,\.\+\?\%]/ /gi;
		#$description =~ s/[a-z0-9\-\,\.\+\?\%]/ /gi;

		#
		if($filter_regex ne "" && !($url=~/$filter_regex/)) {
			return "";
		}

		#
		$con .= sprintf("%.8d", $age) . " | ";
		$con .= "$cap" . " | ";
		$con .= "$description" . " | ";
		$con .= "$url" . " | \n";
	}
	return $con;
}

# [absolute path] [domain name] [walking number]
sub BuildNewsFeed
{
	my ($i,$i2,$str,$str2,$lt,@lst,$f,$fn,@websites,$nr,$con,@newsfeeds,$tmpstr,$nr);

	#
	@lst = LoadList("$_[0]/already.txt");

	#
	$con = "";
	for($i=$#lst,$nr=0,$walker=int($_[2]); $i>0 && $nr<$MAX_NR_ARTICLES_TO_SHOW; $i--) {
		if( ($tmpstr=ViewPageResult("$_[0]/".$i, $i)) ne "") {
			$con .= $tmpstr;
			$nr++;
		}
	}

	#
	return $con;
}

# Implements $WWW_PAGES_PATH.
sub main
{
	my ($i,$i2,$str,$str2,$lt,@lst,$f,$fn,@websites,@domains,@newsarray,$news_string);

	#
	$fn = "find $WWW_PAGES_PATH -maxdepth 2 -type d|";
	@lst = LoadList($fn);

	#
	for($i=0; $i<($#lst+1); $i++) {
		if($lst[$i] =~ /\.[a-z]{2}[a-z]*$/) {
			push(@websites, $lst[$i]);
			$str = $lst[$i]; # extract domain string from path
			$str =~ s/^.*\/(.+\.[a-z\.\-]{2}[\.\-a-z]*)$/$1/;
			push(@domains, $str);
		}
	}

	#
	$nr_cur_section = 0;
	$news_string = "";
	for($i=0; $i<($#websites+1); $i++,$nr_cur_section++) {
		$news_string .= BuildNewsFeed($websites[$i], $domains[$i], $nr_cur_section);
	}

	#
	my @sp = split(/\n/, $news_string);
	@sp = sort @sp;
	$news_string = join("\n", @sp);
	print $news_string;

	#
}

