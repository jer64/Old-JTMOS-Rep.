#!/bin/bash
cd bin
make
cd ..
