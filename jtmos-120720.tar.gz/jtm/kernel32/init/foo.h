/*
 * Foo's header file.
 */
#ifndef __INCLUDED_FOO_H__
#define __INCLUDED_FOO_H__

//
void foo (char *fmt, ...);

#endif
