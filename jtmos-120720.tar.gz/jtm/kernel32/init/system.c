//
#include "kernel32.h"

//
int systemStarted;
//
THREAD ShellThread;
THREAD ShellThread2;

