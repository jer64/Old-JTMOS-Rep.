//
xx(int a, int b)
{
	int c;

	//
	c = a * b;
}

//
la(void)
{
	//
	xx(10,20);
}
