// LIBC emulation
#include "kernel32.h"
#include "filedef.h"
#include "postman.h"

#define LIBCERROR panic
