// ../pictures/small.bmp - converted from binary to array
int loadingbmp_length=1;
unsigned char loadingbmp[]={
	10,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1  // 00000000
};
//end of array
