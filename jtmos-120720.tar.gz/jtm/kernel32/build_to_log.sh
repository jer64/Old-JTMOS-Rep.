#!/bin/bash
make 2>&1 > log.txt
