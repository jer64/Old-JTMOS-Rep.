#ifndef __INCLUDED_MALLOC_H__
#define __INCLUDED_MALLOC_H__


//
#include "mm.h"
#include "mmAlloc.h" // free malloc


#endif




