#ifndef __INCLUDED_WRITE_H__
#define __INCLUDED_WRITE_H__

#include "scs.h"
int scall_write(SYSCALLPAR);

#endif

