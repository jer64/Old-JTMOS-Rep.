#ifndef __INCLUDED_DIRDBINFORMATION_H__
#define __INCLUDED_DIRDBINFORMATION_H__

int dirdbInformation(void);

#endif


