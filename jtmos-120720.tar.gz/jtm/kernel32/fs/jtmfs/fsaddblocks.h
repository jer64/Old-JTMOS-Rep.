#ifndef __INCLUDED_FSADDBLOCKS_H__
#define __INCLUDED_FSADDBLOCKS_H__

//
int jtmfs_add_blocks_for_entry(int device_nr,
char *fname,int dblock,int amount);

#endif

