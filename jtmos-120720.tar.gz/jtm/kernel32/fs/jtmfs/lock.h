#ifndef __INCLUDED_LOCK_H__
#define __INCLUDED_LOCK_H__

//
#define LOCK static int granted_pid = 0; \
disable(); \
while(granted_pid!=0) { GetCurrentThread(); } \
granted_pid = GetCurrentThread(); enable();

//
#define UNLOCK granted_pid = 0;

#endif

