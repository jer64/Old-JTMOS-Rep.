//
#ifndef __INCLUDED_DIR_H__
#define __INCLUDED_DIR_H__

//
int jtmfs_dir(int device_nr, int which);

#endif


