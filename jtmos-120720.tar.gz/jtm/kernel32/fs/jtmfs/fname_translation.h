#ifndef __INCLUDED_FNAME_TRANSLATION__
#define __INCLUDED_FNAME_TRANSLATION__

int tell_fname(const char *fname, char *parsedfname);

#endif
