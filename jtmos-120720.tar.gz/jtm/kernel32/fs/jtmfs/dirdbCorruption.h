//
#ifndef __INCLUDED_DIRDBCORRUPTION_H__
#define __INCLUDED_DIRDBCORRUPTION_H__

//
void dirdbCorruptionCheck(void);

#endif



