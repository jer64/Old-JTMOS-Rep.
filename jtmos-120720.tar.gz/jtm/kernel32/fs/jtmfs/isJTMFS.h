//
#ifndef __INCLUDED_ISJTMFS_H__
#define __INCLUDED_ISJTMFS_H__

//
int isJTMFSBootBlock(int dnr, JTMFAT_INFOBLOCK *b);
void onNonJTMFSDrive(int dnr);

#endif


