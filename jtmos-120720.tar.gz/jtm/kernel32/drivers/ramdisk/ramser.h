//
#ifndef __INCLUDED_RAMSER_H__
#define __INCLUDED_RAMSER_H__

//
void ramServiceInit(void);
void ramDriverMain(void);
void ramDriverInit(void);

#endif





