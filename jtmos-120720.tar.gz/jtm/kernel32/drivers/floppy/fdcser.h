//
#ifndef __INCLUDED_FDCSER_H__
#define __INCLUDED_FDCSER_H__

//
void fdcServiceInit(void);
void fdcDriverMain(void);
void fdcDriverInit(void);

#endif





