//
#ifndef __INCLUDED_TCPMAIN_H__
#define __INCLUDED_TCPMAIN_H__

//
int TcpProcess(void);

#endif

