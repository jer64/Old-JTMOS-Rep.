#ifndef __INCLUDED_INITSYSTEM_H__
#define __INCLUDED_INITSYSTEM_H__

//
void InitSystem(void);
void InitSystem1(void);
BYTE *vesa_frame_buf;
void Bingoo(void);

#endif
