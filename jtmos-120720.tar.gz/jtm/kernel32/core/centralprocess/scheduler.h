//---------------------------------------------------------------------------------
#ifndef __INCLUDED_SCHEDULER_H__
#define __INCLUDED_SCHEDULER_H__

//
void idle_moment(void);
void LLSchedule(void);
void TaskPitHandler(void);

#endif
//---------------------------------------------------------------------------------

