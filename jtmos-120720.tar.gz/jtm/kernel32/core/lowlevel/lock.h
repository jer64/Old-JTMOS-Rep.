//
#ifndef __INCLUDED_LOCK_H__
#define __INCLUDED_LOCK_H__

//
void Lock(int lockID);
void Unlock(lockID);

#endif



