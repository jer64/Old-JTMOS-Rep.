#ifndef __INCLUDED_STACK_H__
#define __INCLUDED_STACK_H__

void *RenderStack(char *esp, DWORD pc,
        int pid, WORD ss, WORD cs, WORD ds);

#endif



