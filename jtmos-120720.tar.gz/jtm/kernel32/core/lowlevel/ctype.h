#ifndef __INCLUDED_CTYPE_H__
#define __INCLUDED_CTYPE_H__

#ifndef toupper
#define toupper(c)   ((c)>='a'&&(c)<='z'?(c)-('a'-'A'):(c))
#define tolower(c)   ((c)>='A'&&(c)<='Z'?(c)+('a'-'A'):(c))
#endif

#endif
