#ifndef __INCLUDED_INTGDT_H__

//
void update_gdt_for_appthread(void);

#endif

//


