//
#ifndef __INCLUDED_LOGGING_H__
#define __INCLUDED_LOGGING_H__

//
void initSystemLogging(void);
void LoggerThreadProgram(void);
void initSystemLog(void);
void WriteSystemLog(const char *msg);

#endif




