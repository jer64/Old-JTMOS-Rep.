#ifndef __INCLUDED_SPEAKER_H__
#define __INCLUDED_SPEAKER_H__

//
void sound(int freq);

#endif
