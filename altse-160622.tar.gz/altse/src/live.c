//
#include <stdio.h>
#include "selib.h"

//
int main(int argc, char **argv)
{
	DWORD st;

	//
	st = GetTickCount();

	//
	for(; ;)
	{
		fprintf(stderr, "\r%.8d ",
			GetTickCount()-st);
	}

	//
	return 0;
}
