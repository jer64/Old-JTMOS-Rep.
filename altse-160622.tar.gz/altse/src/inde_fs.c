/////////////////////////////////////////////////////////////////////////////
//
// inde_fs.c - index builder - file system functions for database.
// (C) 2005-2011 by Jari Tuominen (jari@vunet.org).
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"

// fd = file descriptor
int fdx[MAX_FDX_RANKS];
int fdxdir[MAX_FDX_RANKS];
BYTE *fdx_fn[MAX_FDX_RANKS];
BYTE *fdx_buf[MAX_FDX_RANKS];
DWORD fdx_offs[MAX_FDX_RANKS];
BYTE *fdxdir_buf[MAX_FDX_RANKS];
DWORD fdxdir_offs[MAX_FDX_RANKS];
BYTE *fdx_letters[MAX_FDX_RANKS];

/////////////////////////////////////////////////////////////////////////////
// Open dictionary (for writing).
int OpenDic(INDE *in, BYTE *s, DWORD iiii,
		int rank)
{
	static char path[10][2048],path2[512],path3[256],path4[256],*upath;
	static char fn_dic[512];
	static char fn_dir[512],str[1024];
	int fd,ch;
	DWORD sz,offs;
	DWORD id,four_chars1,four_chars2;
	BYTE *tmp;

	//
	if(inde_debug_verbose) {
		fprintf(stderr, "%s/%s line %d: I was called with parameters :  in=%1.8x, s=%1.8x, iiii=%d, rank=%d\n",
			__FILE__, __FUNCTION__, __LINE__,
			in,s,iiii,rank);
	}

	//
	if( strncmp((char*)fdx_letters[rank],(char*)s,3) ) // N_CHARS_MATTER
	{
		char fname[8192];

                // Verbose.
                sprintf(path[0], "%s/%d",                       GLOP, ProductionIndexNr);
                sprintf(path[1], "%s/%d/%c",                    GLOP, ProductionIndexNr, s[0]);
                sprintf(path[2], "%s/%d/%c/%c",                 GLOP, ProductionIndexNr, s[0], s[1]);
                sprintf(path[3], "%s/%d/%c/%c/%c",              GLOP, ProductionIndexNr, s[0], s[1], s[2]);
                if(inde_debug_verbose) {
                    fprintf(stderr, "%s/%s line %d: path for the dictionary index level iles: %s\n",
                            __FILE__, __FUNCTION__, __LINE__,
                            path[0]);
                }       
                                                                                                                                                                                        
		//
		strncpy(fname, s, 3);

		// Create output index directory.
		mkdir(path[0],  0777);
		//
		if( fdx[rank]!=-1 )
		{
			CloseDic(in, rank, TRUE);
			fdx[rank] = -1;
		}
		//
		strcpy((char*)fdx_letters[rank], (char*)s);

		// *** USUALLY IMPLEMENTED ***
		upath = path[0]; // 3

		//
		if(N_CHARS_MATTER!=8) {
			fprintf(stderr, "N_CHARS_MATTER %d not supported\n", N_CHARS_MATTER);
			abort();
		}
		//
		strncpy(str,s,3);
		str[N_CHARS_MATTER]=0;
		// may produce gibberish -- ch = tolower( str[0] );
		sprintf((char*)fdx_fn[rank],
			"%s/%s-%d",
			(void*)upath,
			str,
			rank);
		LowerCaseString(fdx_fn[rank]);
		//
		sprintf(fn_dic, "%s.dic", fdx_fn[rank]);
		sprintf(fn_dir, "%s.dir", fdx_fn[rank]);
		fprintf(stderr, "%s/%s, line %d: fn_dic='%s', fn_dir='%s', upath='%s'\n",
			__FUNCTION__,__FILE__, __LINE__,
			fn_dic,
			fn_dir,
			upath);
	}
	else
	{
		CloseDic(in, rank, FALSE);
		fd = fdx[rank];
		offs = lseek(fd, 0, SEEK_CUR);
		goto skip;
	}

	//
	fdxdir[rank] = open(fn_dir, O_CREAT|O_RDWR, 0666);
	if(fdxdir[rank]<0)
	{
		fprintf(stderr, "can't write %s (%s,%s)\n",
			fn_dir,
			path,path2);
		sleep(2);
		return -1;
	}
	// To the end of DIR file.
	lseek(fdxdir[rank], 0, SEEK_END);

	//
	fd = open(fn_dic, O_RDWR, 0666);
	if(fd<0)
	{
		// CREATE NEW FILE.
		fd = open(fn_dic, O_CREAT|O_RDWR, 0666);
		if(fd<0)
		{
			fprintf(stderr, "can't write %s (%s,%s)\n",
				fn_dic,
				path,path2);
			sleep(2);
			return -1;
		}

		// Create header.
		id = DIC_ID;
		offs = DIC_HDRSZ;
		lseek(fd,0,SEEK_SET);
		write(fd, &id, 4);
		write(fd, &offs, 4);
		// Allocate some space.
		if(inde_debug) fprintf(stderr, "PREAL {\n");
		PreAlDic(fd, offs, DIC_NEW_PREALCSZ);
		if(inde_debug) fprintf(stderr, "} PREAL\n");
	}
	fdx[rank] = fd;

	// READ HEADER
	lseek(fd,0,SEEK_SET);
	// Read ID.
	read(fd, &id, 4);
	// Read offset.
	read(fd, &offs, 4);

	//
	sz = lseek(fd, 0, SEEK_END);

	//
	if( ((sz-offs)-DIC_HDRSZ) <= DIC_PREALC_TRIGGER )
	{
		//
		PreAlDic(fd, offs, DIC_MORE_PREALCSZ);
	}

	//
	lseek(fd, offs, SEEK_SET);

skip:
	//
	four_chars1 = (s[0]<<0) | (s[1]<<8) | (s[2]<<16) | (s[3]<<24);
	four_chars2 = (s[4]<<0) | (s[5]<<8) | (s[6]<<16) | (s[7]<<24);
	// Guard number.
	WriteDir(in,rank, 0x12345678);
	// Data.
	WriteDir(in,rank, four_chars1);
	WriteDir(in,rank, four_chars2);
	WriteDir(in,rank, fdx_offs[rank] + lseek(fd, 0, SEEK_CUR)); // START OFFSET

	//
	return fd;
}

//
void inde_fs_init(INDE *in, int n_ranks)
{
	int r;

	//
	if(inde_verbose) {
		fprintf(stderr, "%s: Buffer initialization.\n",
			__FUNCTION__);
	}
	// Initialize buffers.
	for(r=0; r<n_ranks; r++)
	{
		fdx[r]=-1;
		fdxdir[r]=-1;
		fdx_buf[r] = malloc(FDX_BUF_SZ);
		if(fdx_buf[r]==NULL) { fprintf(stderr, "Error: malloc returned NULL (1)\n"); abort(); }
		fdxdir_buf[r] = malloc(FDX_BUF_SZ);
		if(fdxdir_buf[r]==NULL) { fprintf(stderr, "Error: malloc returned NULL (2)\n"); abort(); }
		fdx_fn[r] = malloc(1024);
		if(fdx_fn[r]==NULL) { fprintf(stderr, "Error: malloc returned NULL (3)\n"); abort(); }
		fdx_letters[r] = malloc(1024);
		if(fdx_letters[r]==NULL) { fprintf(stderr, "Error: malloc returned NULL (4)\n"); abort(); }
		strcpy((char*)fdx_buf[r], "");
		strcpy((char*)fdx_fn[r], "");
		strcpy((char*)fdx_letters[r], "");
		fdx_offs[r] = 0;
		fdxdir_offs[r] = 0;
	}
}

//
void inde_fs_end(INDE *in, int n_ranks)
{
	int r;

	//
	for(r=0; r<n_ranks; r++)
	{
		//
		if(fdx[r]!=-1)
		{
			//
			CloseDic(in, r, TRUE);
			//
			SafeFree(fdx_buf[r]);
			SafeFree(fdxdir_buf[r]);
			SafeFree(fdx_fn[r]);
			SafeFree(fdx_letters[r]);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// Write to dictionary.
int WriteDic(INDE *in, int rnk, DWORD val)
{
	DWORD *dp;

	//
	dp = fdx_buf[rnk]+fdx_offs[rnk];
	*dp = val;
	fdx_offs[rnk] += 4;

	//
	if( fdx_offs[rnk] >= (FDX_BUF_SZ-FDX_BUF_OVERFLOW) )
	{
		//
		FlushDic(in, rnk);
	}

	//
}

/////////////////////////////////////////////////////////////////////////////
//
int WriteDir(INDE *in, int rnk, DWORD val)
{
	DWORD *dp;

	//
	////////write(fdxdir[rnk], &val, 4);

	//
	dp = (fdxdir_buf[rnk]+fdxdir_offs[rnk]);
	*dp = val;
	fdxdir_offs[rnk] += 4;

	//
	if( fdxdir_offs[rnk] >= (FDX_BUF_SZ-FDX_BUF_OVERFLOW) )
	{
		//
		FlushDir(in, rnk);
	}

	//
}

/////////////////////////////////////////////////////////////////////////////
//
int FlushDic(INDE *in, int rnk)
{
	DWORD offs;

	//
	if( fdx_offs[rnk] > 0 )
	{
		//
		write(fdx[rnk], fdx_buf[rnk], fdx_offs[rnk]);
		// Reset buffer byte counter.
		fdx_offs[rnk] = 0;
	}

	//
}

/////////////////////////////////////////////////////////////////////////////
// Flush directory.
int FlushDir(INDE *in, int rnk)
{
	//
	if( fdxdir_offs[rnk] > 0 )
	{
		//
		write(fdxdir[rnk], fdxdir_buf[rnk], fdxdir_offs[rnk]);
		// Reset buffer byte counter.
		fdxdir_offs[rnk] = 0;
	}

	//
}

/////////////////////////////////////////////////////////////////////////////
// Close dictionary.
int CloseDic(INDE *in, int id, int really_close)
{
	DWORD offs,fd,x;

	//
	fd = fdx[id];

	// Flush.
	if(really_close)
	{
		//
		FlushDic(in, id);

		// Write header.
		offs = lseek(fd, 0, SEEK_CUR);
		//
		lseek(fd,4,SEEK_SET);
		write(fd, &offs, 4);
	}
	else
	{
		// Figure out real offset without flush.
		offs = fdx_offs[id] + lseek(fd, 0, SEEK_CUR);
	}

	// WRITE TO DIRECTORY FILE:
	// Signal end of key list.
	WriteDir(in, id, 0xFFFFFFFF);
	// end offset:
	WriteDir(in, id, offs); // END OFFSET
	// guard number
	WriteDir(in, id, 0xAAAAAAAA);
	//
	// DEBUG* 	fprintf(stderr, "%s line %d: end of key list at %1.8x\n",  __FUNCTION__, __LINE__, offs);

	//
	if(really_close)
	{
		//
		FlushDir(in, id);

		//
		close(fdx[id]);
		close(fdxdir[id]);

		//
		fdx[id] = -1;
		fdxdir[id] = -1;
	}
}

/////////////////////////////////////////////////////////////////////////////
//
// PreAlDic(fd, offs, DIC_PREALCSZ);
//
int PreAlDic(int fd, DWORD offs, DWORD to_al)
{
	BYTE *tmp;

	//
	//tmp = malloc(to_al);
	//if(tmp==NULL) { fprintf(stderr, "Out of memory: tried to allocate %d bytes\n", to_al); abort(); }
	//memset(tmp, 0, to_al);
	lseek(fd, offs, SEEK_SET);
	//write(fd, tmp, to_al);
	//SafeFree(tmp);
}

