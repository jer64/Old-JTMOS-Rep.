//
#include <stdio.h>
#include "selib.h"

//
int main(int argc, char **argv)
{
	int ch,i;

	//
	for(i=0; !feof(stdin); i++ )
	{
		if( i>=80 )
		{
			fputc('\n', stdout);
			i=0;
		}
		else
		{
			ch = fgetc(stdin);
			if( !isalnum1(ch) ) { ch='.'; }
			fputc(ch, stdout);
		}
	}

	//
	return 0;
}

