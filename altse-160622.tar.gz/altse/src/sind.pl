#!/usr/bin/perl
# sind.pl - SQL-based indexer.
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use String::CRC::Cksum qw(cksum);
#
AltseOpenConfig();

#
$indexprefix = "index1";
$flush_on_memory_size_k = "100000"; # 100 Mb

#
main();

#------------------------------------------------------------------------------
# Return max mem we are willing to use
#------------------------------------------------------------------------------
sub get_mem {
    my @kmeminfo = LoadList("/proc/meminfo");
    my $ram_total = @kmeminfo[3];
    return (.7 * $ram_total) * .06;
}

#
sub get_my_mem_usage {
	my @tmp = LoadList("ps aux|grep sind.pl|grep -v grep|");
	my @sp = split(" ", $tmp[0]);
	#print STDERR "==" . @sp . "\n";
	return $sp[4];
}

#
sub indext_tablecount
{
	my $query = "SELECT COUNT(*) FROM $_[0]";
	if($SQL_DEBUG != 0) { print $query . "\n"; }
	my $sth = $dbh->prepare($query);
	$sth->execute();

	#
	my @tmp = $sth->fetchrow_array();
	$sth->finish();
	# Return table count.
	my $len = $tmp[0]; if($len eq "") { $len=0; }
	return $len;
}

# Create index table.
# Usage: [table]
sub indext_create
{
	my $query;

        # Delete table first.
	if($_[1] eq "" || !defined($_[1]))
	{
		$query = ("DROP TABLE IF EXISTS `altse`.`$_[0]`;");
		if($SQL_DEBUG != 0) { print $query . "\n"; }
	        $sth = $dbh->prepare($query);
	        $sth->execute();
	        $sth->finish();
	}
        # Create it.
	$query = ("CREATE TABLE `altse`.`$_[0]` (
  `id` BIGINT NOT NULL AUTO_INCREMENT,
  `pageid` BIGINT,
  `wordcsum1` INT default NULL,
  `wordcsum2` INT default NULL,
  `wordcsum3` INT default NULL,
  `wordcsum4` INT default NULL,
  PRIMARY KEY USING BTREE (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
        $sth = $dbh->prepare($query);
        $sth->execute();
        $sth->finish();
}

# Read a string from index table.
# Usage: [table] [pageid]
sub indext_get
{
	my @tmp;
        my $query = "SELECT pageid,wordcsum1,wordcsum2,wordcsum3,wordcsum4 FROM $_[0] WHERE pageid='$_[1]';";
	if($SQL_DEBUG != 0) {
		print "s_get: $query\n";
	}
	#if($SQL_DEBUG != 0) { print $query . "\n"; }
        $sth = $dbh->prepare($query);
        $sth->execute() or return "";
#       if(NoTracking()) { print "<LI>$query</LI><BR>"; }

        #
        @tmp = $sth->fetchrow_array();
        $sth->finish();
        # Return 'value'.
        return $tmp[1];
}

# Read a row from index table.
# Usage: [table] [item]
sub indext_get_row
{
	my @tmp;
        my $query = "SELECT pageid,wordcsum1,wordcsum2,wordcsum3,wordcsum4 FROM $_[0] WHERE pageid='$_[1]';";
	if($SQL_DEBUG != 0) {
		print "s_get_row: $query\n";
	}
	#print $query . "\n";
        $sth = $dbh->prepare($query);
        $sth->execute() or return();
#       if(NoTracking()) { print "<LI>$query</LI><BR>"; }

        #
        @tmp = $sth->fetchrow_array();
        $sth->finish();
        #
        return @tmp;
}

# Write to index table.
# Usage: [table] [pageid] [word1 csum] [word2 csum] [word3 csum] [word4 csum]
sub indext_put
{
        #
	my $val = $_[2];
	$val =~ s/%/\\\%/;
        my $query = ("DELETE FROM $_[0] WHERE pageid='$_[1]';");
	if($SQL_DEBUG != 0) {
	        print "indext_put: $query\n";
	}
	#print $query . "\n";
        $sth = $dbh->prepare($query);
        $sth->execute() or print "#1 failed on $i ($DBI::errstr)\n";
        $sth->finish();

        #
	#if(indext_get($_[0], $_[1]) eq "") {
		##
	        my $query = ("INSERT INTO $_[0]
	(pageid,wordcsum1,wordcsum2,wordcsum3,wordcsum4)
	values
	('$_[1]','$_[2]','$_[3]','$_[4]','$_[5]');
	");
		if($SQL_DEBUG != 0) {
		        print "indext_put: $query\n";
		}
	        $sth = $dbh->prepare($query);
	        $sth->execute() or print "#2 failed on $i ($DBI::errstr)\n";
	        $sth->finish();
	#}
}

# pageid, hash1,hash2,hash3,hash4
sub addWord
{
	my ($tblname,$c,$pushcontent);

	#
	$tblname = "$indexprefix\_" . $_[0];
	#if($tc = indext_tablecount($tblname)<=0) {
	#	indext_create($tblname);
	#}
	#print "tc = " . $tc . "\n";
	#indext_put($tblname, "$_[0]", "$_[1]", "$_[2]", "$_[3]", "$_[4]");
	$pushcontent = "$_[1]";
	$pushwords{$pushcontent} .= "($_[0],$_[1],$_[2],$_[3],$_[4]),";
	#print ">> $pushwords{$pushcontent}\n";
}

# Flush words to SQL database.
sub flushWords
{
	my ($pushcontent,$pageid,$values);

	#
	foreach $pageid (sort(keys %pushwords)) {
		#
		$pushcontent = $pushwords{$pageid};
		$values = $pushcontent;
		#die "values = $values\n";

		#
		my $tc;
		if($tc = indext_tablecount("$indexprefix\_".$pageid)<=0) {
			indext_create("$indexprefix\_".$pageid);
		}
	        #
		my $val = $_[2];
		$val =~ s/%/\\\%/;
	        my $query = ("DELETE FROM $indexprefix\_$pageid WHERE pageid='$_[1]';");
		if($SQL_DEBUG != 0) {
		        print "flushWords: $query\n";
		}
		#print $query . "\n";
	        $sth = $dbh->prepare($query);
        	$sth->execute() or print "#1 failed on $i ($DBI::errstr)\n";
	        $sth->finish();

	        #
		#if(indext_get($_[0], $_[1]) eq "") {
		##
		$values =~ s/^(.+)\,$/$1/;
	        my $query = ("INSERT INTO $indexprefix\_$pageid
		(pageid,wordcsum1,wordcsum2,wordcsum3,wordcsum4)
		values
		$values
		");
		#('$_[1]','$_[2]','$_[3]','$_[4]','$_[5]');
			#if($SQL_DEBUG != 0) {
			#        print "flushWords: $query\n";
			#}
		        $sth = $dbh->prepare($query);
		        $sth->execute() or print "#2 failed on $i ($DBI::errstr)\n";
		        $sth->finish();
		#}


	}


	#
	undef(%pushwords);
}

# [file name of page] [page ID]
sub indexer
{
	my (@lst,$str,$str2,$i,$i2,@words,%have,$w1,$w2,$w3,$w4);

	#
	print $_[0] . "\n";
	@lst = LoadList("zcat $_[0]|");

	#
	for($i=0,$str=""; $i<($#lst+1); $i++) {
		#if(!$have{$lst[$i]}) {
			$have{$lst[$i]}++;
			$str = $str . " " . $lst[$i];
		#}
	}

	#
	$str =~ s/[^a-zA-Z0-9]/ /g;
	$str =~ s/\s+/ /g;

	#
	@words = split(/ /, $str);

	#
	for($i=0; $i<($#words+1); $i++) {
		$w1 = $words[$i+0];
		$w2 = $words[$i+1];
		$w3 = $words[$i+2];
		$w4 = $words[$i+3];
		if(!defined($w1)) { $w1=""; }
		if(!defined($w2)) { $w2=""; }
		if(!defined($w3)) { $w3=""; }
		if(!defined($w4)) { $w4=""; }
		addWord($_[1],
			cksum($w1),
			cksum($w2),
			cksum($w3),
			cksum($w4));
	}
}

#
sub main
{
	my ($i,$i2,$f,$str,$str2);

	#
	#print("Building list of files ...\n");
	#system("find $DB/www -type f -name '*.dump.gz' > $DB/list.txt");

	#
	print("Indexing ...\n");
	open($f, "$DB/list.txt");

	#
	s_create("pageresolve");

	#
	for($i=0; !eof($f); $i++) {
		s_put("pageresolve", "$i","$str");
		my $str = <$f>; chomp $str;
		indexer($str,$i);
		my $size = get_my_mem_usage();
		#print STDERR "my size = " . $size . "k\n";
		if($size > $flush_on_memory_size_k) {
			print STDERR "Flush: ";
			flushWords();
			print STDERR "Done.\n";
		}
	}
	flushWords();

	#
	close($f);

	#
}

