#!/usr/bin/perl
open($f, "multimedia.txt");
for(; !eof($f); )
{
  $str = <$f>;
  if(!$ald{$str})
  {
    $ald{$str}++;
    print $str;
  }
}
close($f);
