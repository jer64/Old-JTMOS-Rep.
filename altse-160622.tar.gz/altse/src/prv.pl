######################################################################
#
sub zSaneString
{
        my ($str);

        #
        $str = $_[0];
	$str =~ s/\[.*?\]//g;
        $str =~ s/[^0-9a-z������\%\&\[\]\(\)\{\}\-\+\*\.\,\'\"\#\=\:\;\/\\\ ]/ /gi;
        $str =~ s/\ \ /\ /g;
        return $str;
}

##############################################################################
#
sub zNiceString
{
	my ($body);

	#
	$body = $_[0];
	$body =~ s/\[[0-9]*\]//g;
	$body =~ s/[^0-9a-zA-Z������\ ]/ /g;
	return $body;
}


######################################################################
#
sub PrvCompress
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn);

	#
	@lst = @LYNX_DUMP;
	#
	for($i=0,$str=""; $i<($#lst+1); $i++) { $str="$str $lst[$i]"; }

	# Remove some unnecessary spaces.
	$str =~ s/^\s*//g;
	$str =~ s/\s*$//g;
	$str = zSaneString($str);
	$str =~ s/^[^a-z������0-9]*//gi;
	$str =~ s/\s+/ /g;
	$str =~ s/ +/ /g;
	$str =~ s/\-+/\-/g;
	$str =~ s/\=+/\=/g;

	#	
	$str =~ s/^(.{200}).*$/$1/;
	if(length($str)==200) { $str="$str ..."; }

	#
	return $str;
}

######################################################################
#
sub PrvInfo
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn,
		$sz,$t,$pm,$score);

	#
	$sz = (stat("$_[0]"))[7];
	$t = (stat("$_[0]"))[9];

	#
	$pm = POSIX::strftime("%d.%m.%Y", localtime($t));
	if($score<0) { $score="n/a"; } else { $score=sprintf "%d",$score; }
	$pm = sprintf "%dK - %s", ($sz/1024)+1, $pm;	

	#
	return $pm;
}

######################################################################
#
sub PrvGetHL
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn);

	#
	@lst = LoadList($_[0]);
	#
	for($i=0,$str=""; $i<($#lst+1); $i++) { $str="$str $lst[$i]"; }

	#
	$str =~ s/file:\/\/localhost\/home\/vai\/crawler\///g;

	# Remove some unnecessary spaces.
	$str =~ s/^\s*//g;
	$str =~ s/\s*$//g;
	$str =~ s/[\t|\n]/ /g;
	$str =~ s/\ \ / /g;

	#
	if($str=~/^.*<title>.*<\/title>.*$/i)
	{
		$str =~ s/^.*<title>(.*)<\/title>.*$/$1/i;
	}
	else
	{
		$str = "Untitled";
	}

	#
	return $str;
}

######################################################################
#
# PRV [FN_HTML]
#
sub PRV
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn);

	#
	print PrvGetHL($_[0])."\n";
	$str = PrvCompress("lynx -dump -force_html \"$fn\" 2>/dev/null|");
	$str2 = Info($fn);
	$str = "$str\n$str2\n";
	return $str;
}

##############################################################################
#
sub ProcessWords
{
	my ($i,$i2,$str,$wrd);

	##########################################################
	# Split into words.
	#
	@WORDS = split(" ", $_[0]);

	#
	for($i=0,$wrd=""; $i<($#WORDS+1); $i++)
	{
		# Words can begin with an alpha or a number.
		$WORDS[$i] =~ s/^[^a-zA-Z������0-9]*//g;
		$wrd = "$wrd $WORDS[$i]";
	}
	return $wrd;
}

##############################################################################
#
sub WOEX
{
	my ($i,$i2,$str,$str2,@sp,$a1,$a2,$body,$head,@prv,$l);

	################################################
	#

	# Load source text file.
	@src = @LYNX_DUMP;

	##########################################################
	#
	# Make the whole article a single string.
	#
	$l = $#src+1;
	loop: for($i=0,$body=""; $i<$l; $i++)
	{
		if($src[$i] eq "References" &&
			$src[$i+1] eq "" &&
			$src[$i+2] ne "")
		{
			last loop;
		}
		$body = "$body $src[$i] ";
	}

	# Article body.
	$body = zNiceString($body);

	#
	return ProcessWords($body);
}

#

