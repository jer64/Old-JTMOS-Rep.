#!/bin/bash
cd ~/sdb/cid
rm -rfv already/*
rm -rfv dict/*
rm -rfv data/*
rm -rfv lists/*
rm -rfv tmp/*
rm -rfv ~/sdb/pickup/*
rm -fv ~/sdb/tmp/*
mkcid
echo "0" > gid.txt
#find data/ -type d ; xargs rm -rfv 
#find lists/ -type d ; xargs rm -rfv 
dicwipe
