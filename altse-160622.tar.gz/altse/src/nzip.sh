#!/bin/bash
gcc -w -O3 -m32 -o nzip nzip.c
#echo "Installing binary ..."
#su -c 'cp nzip /bin'

