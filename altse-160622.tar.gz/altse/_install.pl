#!/usr/bin/perl
# Install script version 1.1.
#
# Note for advanced users:
#         Altse requires various libraries not installed here.
#         For functionality these libraries are vital.
#
require "bin/tools.pl";

	#
	system("mkdir -p ~/db/www");
	print STDERR "Creating central index (cid) paths ...\n";
	system("mkdir -p ~/altse/cid");
	system("mkdir -p ~/altse/cid/tmp");
	system("mkdir -p ~/altse/cid/data");
	system("mkdir -p ~/altse/cid/dict");
	system("mkdir -p ~/altse/cid/dict/0");
	system("cp -i ~/altse/ads.pl ~/"); ## ads for Altse

	system("./build_binaries.sh");

	system("bin/mkdb.sh");

	# Check .bashrc first if it already has the altse/bin in PATH.
	my (@lst,$i,$i2,$doneit);
	@lst = LoadList("$ENV{'HOME'}/.bashrc");
	$doneit = 0;
	for($i=0; $i<($#lst+1); $i++) {
		if($lst[$i]=~/\:\/home\/vai\/altse\/bin/) {
			$doneit = 1;
		}
	}

	# Add path in .bashrc if needed.
	if(!$doneit) {
		open($f, ">>$ENV{'HOME'}/.bashrc") || die "Oops! Error. Can't write .bashrc\n";
		print $f "PATH=$PATH:/home/vai/altse/bin\n";
		print $f "export PATH\n";
		print $f "export http_proxy=http://localhost:3128/\n";
		print $f "export ftp_proxy=http://localhost:3128/\n";
		close($f);
	} else {
	}

	#
	system("sudo perl root_install.pl");
	print STDERR "END OF INSTALLATION\n";

