#!/bin/bash
nzip welcome.raw ; nzip -d welcome.raw.nz


