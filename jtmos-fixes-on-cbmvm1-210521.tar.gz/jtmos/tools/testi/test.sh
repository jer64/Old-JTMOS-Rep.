#!/bin/bash
gcc -o test test.c 

