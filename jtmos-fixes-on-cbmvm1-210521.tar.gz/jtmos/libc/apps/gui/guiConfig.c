// =========================================================
// GRAOS CONFIGURATION FILE
// =========================================================
#include <stdio.h>
#include "config.h"

// Show system meters on the top of the screen
int XON_SYSTEM_METERS = FALSE;

//



