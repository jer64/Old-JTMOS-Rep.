//
#include <stdio.h>

//
#define HAVE_STRING


