// Some emulation.
// (BWBASIC needed this.)
#define HAVE_UNISTD

//

