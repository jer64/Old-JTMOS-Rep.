//
#ifndef __INCLUDED_NUMBERS_H__
#define __INCLUDED_NUMBERS_H__

//
void p8(char v);
void p16(int v);
void p32(long v);
void p32z(long v);
void pdh32(long v);
void pd32(long v);
void pdz32(long v);

//
#endif

//
