#ifndef __INCLUDED_JTMLIBC_QSORT_H__
#define __INCLUDED_JTMLIBC_QSORT_H__

void qsort(void *base, size_t nmemb, size_t size,
              int (*compar)(const void *, const void *));

/*
qsort(base,nel,width,compare)
char *base;
int     nel,width;
int     (*compare)();

*/

#endif


