// DJGPP compatibility * TODO
