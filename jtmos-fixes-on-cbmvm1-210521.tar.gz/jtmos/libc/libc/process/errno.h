//
#ifndef __INCLUDED_ERRNO_H__
#define __INCLUDED_ERRNO_H__

//
extern int errno;

#endif





