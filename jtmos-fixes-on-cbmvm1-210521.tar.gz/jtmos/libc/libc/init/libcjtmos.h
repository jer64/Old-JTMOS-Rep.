// LIBC BUILD TIME STDIO EMULATION LIBRARY
#define JTMOS
#define DJGPP
#define MSDOS

//
#include "dataproc.h"
#include "basdef.h"
#include "file.h"
#include "console.h"
#include "process.h"
#include "string.h"
#include "modal.h"
#include "init.h"

