#ifndef __INCLUDED_SBRK_H__
#define __INCLUDED_SBRK_H__

void *sbrk(int req);

#endif


