#!/usr/bin/perl
#############################################################################
#
# ifeditart.pl
# Iframe-based Edit article.
#
# Called by a HTML form:
# ifeditart.pl?FILE=&RETURL=&CAPTION=
# Called by itself:
# ifeditart.pl?FILE=&RETURL=&CAPTION=&CMD=
#
#############################################################################

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
require "modules/AltseOpenConfig.pm";

# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#######################################################
# Go to main loop.
#
main();

#######################################################
sub EditArticleForm
{
	my $i,$i2,$i3,$i4,$str,$WARNING;

	#
#	print "$so{'FILE'}<BR>\n";
	@art = LoadList($fname);
#	open(f5, $fname) || die "article file not found";
#	@art = <f5>;
#	close(f5);

	#
	for($i=0; $i<($#art+1); $i++)
	{
		#
		if($art[$i] =~ /\<o\:p\>/i)
		{
			$WARNING = 1;
		}
	}


	#
	if($so{'CAPTION'} eq "")
	{
		$so{'CAPTION'} = "Artikkelin muokkaaminen";
	}	
	
	#
	print("
		<div align=center>
		<font size=\"6\">
		<b>
		$so{'CAPTION'}
		</b>
		</font>
		</div>
		<br>
		");

	#
	if($WARNING)
	{
		print("
			WARNING! Complex HTML format detected. Edit with YOUR OWN RESPONSIBILITY.<br>
			This article should probably be edited with a bare HTML editor.<br><br>
			");
	}

	#
	print("
		<form method=\"post\" action=\"ifeditart.pl\">

		<input type=\"hidden\" name=\"cmd\" value=\"cmdeditart123894\">

		<input type=\"hidden\" name=\"PLAIN\" value=\"$so{'PLAIN'}\">
		<input type=\"hidden\" value=\"$fname\" name=\"FILE\">
		<input type=\"hidden\" value=\"$so{'RETURL'}\" name=\"RETURL\">

		<textarea name=\"CONTENT\" cols=\"82\" rows=\"20\" class=\"textarea\" id=ta>");


	#
	if($so{'CONTENT'})
	{
		print("$so{'CONTENT'}");
	}
	else
	{
		#
		if($so{'PLAIN'} eq "true")
		{
			for($i=0; $i<($#art+1); $i++)
			{
				$art[$i] =~ s/\r//g;
				$art[$i] =~ s/\n//g;
				$art[$i] =~ s/<br>/\n/ig;
			}
		}

		#
		for($i=0,$str=""; $i<($#art+1); $i++)
		{
			if( !($art[$i]=~/^\s*$/ && $art[$i+1]=~/^\s*/) ) {
				print $art[$i];
				if($so{'PLAIN'} ne "true") { print"\n"; }
				if($so{'PLAIN2'} ne "true") { print"\r\n"; }
			}
		}
	}

	#
	print("</textarea>
		<br>
		<br>

		<input type=\"submit\" value=\"save\">

		</form>

		<script language=\"Javascript\">
		document.getElementById('ta').focus();
		</script>

		<a href=\"$so{'RETURL'}\"><p>> Peruuta</p></a>

		<br>
		");
}

#######################################################
#
# The actual image adding process.
#
sub AddImage1
{
	#
	open(f, ">$fname\_imageurl.txt") || die "can't add image url";
	print f "$imageurl";
	close(f);
}

#######################################################
#
# Image add web form application.
#
sub EditArt
{
	#
	

	# Print form if no command detected.
	#
	EditArticleForm();
}

###################################################################################################################################
#
sub SaveArticle
{
	#####################################################################
	#
	@l = split("\n", $so{'CONTENT'});

	#
	$l[0] =~ s/\n//g;
	$l[0] =~ s/\r//g;

	#
	if($l[0] eq "")
	{
		print "<blink>First line must always contain the article subject.</blink><br><br>\n";
		EditArticleForm();
	}
	else
	{
	}

	#####################################################################
	#
	if($so{'PLAIN'} eq "true")
	{
		#
		@l = split("\n", $so{'CONTENT'});
		#
		$so{'CONTENT'} = "";
		for($i=0; $i<($#l+1); $i++)
		{
			$l[$i] =~ s/^(.*)\s$/$1/;
			$so{'CONTENT'} = "$so{'CONTENT'}$l[$i]<br>\n";
		}
	}

	#
####	$so{'CONTENT'} =~ s/<br \/>/<br>/gi;

	# SAVE ARTICLE DATA.
	open(f6, ">$fname") || print "Can't write $fname<BR>\n";;
	print f6 $so{'CONTENT'};
	close(f6);

	#
	system("$ENV{'DOCUMENT_ROOT'}/cgi/admin/Kaikki.sh");


	#
#        print("
#		<script language=\"JavaScript\">
#		document.getElementById('keho').style.visibility = 'hidden';
#		l = parent.window.location;
#		parent.window.location = l;
#		</script>
 #        ");
#
	#
	print("
Tallenetaan ...<BR><BR>
		");

	#
	if($so{'PLAIN'} eq "")
	{
		#
		#@lst = LoadList("$ENV{'DOCUMENT_ROOT'}/cgi/admin/update_titles.sh 2>&1|");
		#@lst = LoadList("$ENV{'DOCUMENT_ROOT'}/cgi/admin/CPtitles.sh 2>&1|");
	}

	#
	if($so{'RETURL'} eq "")
	{
		print("
<a href=\"Javascript:self.close();\" class=dark>
KIITOS. MUUTOKSESI ON TALLENNETTU.<BR>
<BR>
> SULJE IKKUNA TASTA<BR>
</a>
		");
	}
	else
	{
		print("
<a href=\"$so{'RETURL'}\" class=dark>
KIITOS. MUUTOKSESI ON TALLENNETTU.<BR>
<BR>
> SIIRRY T�ST� TAKAISIN ARTIKKELIIN<BR>
</a>
		");
	}

	#
}

#######################################################
sub main
{
	my ($i,$i2,$str,$str2,@sep);

	#
	if($so{'RETURL'} eq "")
	{
		$so{'RETURL'} = "/";
	}


	#
	$str = $ENV{'DOCUMENT_ROOT'};
	if( !($so{'FILE'}=~/$str/) && !($so{'FILE'}=~/^\//) )
	{
		$so{'FILE'} = "$ENV{'DOCUMENT_ROOT'}/articles/$so{'FILE'}";
	}
	#
	$fname = $so{'FILE'};
#	if( !($ENV{'REMOTE_HOST'}=~/\.fi$/) )
#	{
#		print "njet... qin wode pigu!";
#		exit;
#	}

	#
	print("
<head>
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$IMAGES_BASE/uutiset.css\" title=\"Cool\">
  <title>$so{'FILE'}</title>
</head>

<body id=keho>

		<table width=715 cellpadding=16 cellspacing=0>
		<tr align=top>
		<td>
		");

	#
	if($so{'cmd'} eq "")
	{	
		
		#
		if($so{'BAREHTML'} ne "true")
		{
		}

		#
		EditArt();
	}
	else
	{
		#
		if($so{'cmd'} =~ /cmdeditart123894/)
		{
			# POST ARTICLE.
			SaveArticle();
		}
		else
		{
			#
			print "Unknown request.\n";
		}
	}

	#
	print("
		</td>
		</tr>
		</table>

</body>
		");
}


