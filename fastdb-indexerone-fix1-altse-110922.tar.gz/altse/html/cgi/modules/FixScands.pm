#
use Encode;

#
sub FixScands
{
	my ($str);
	$str = $_[0];
	$str =~ s/ä/&auml;/g;
	$str =~ s/ö/&ouml;/g;
	$str =~ s/\ �\x{AC}/\'/g;
	$str =~ s/�/&auml;/g;
	$str =~ s/�/&Auml;/g;
	$str =~ s/�/&ouml;/g;
	$str =~ s/�/&Ouml;/g;
	$str =~ s/\|/&\#124;/g;
	$str =~ s/[^a-zA-Z������0-9\'\�\`\.\,\!\"\#\�\%\&\/\(\)\=\@\�\$\{\[\]\<\>\:\;\+\-\x{80}]\x{0000}\x{FF}\x{80}/ /g;

	my $chars = $str;
	my $octets = encode 'iso-8859-1', $chars;
	return $octets;
}

1;

