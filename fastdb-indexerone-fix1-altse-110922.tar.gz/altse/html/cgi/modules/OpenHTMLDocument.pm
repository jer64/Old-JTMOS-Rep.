#################################################################
#
sub OpenHTMLDocument
{
print("
<!DOCTYPE html>

<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"/images/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"/images/altse.css\" title=\"Cool\">

  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
<!--- iso-8859-1 --->

<meta name=\"google-site-verification\" content=\"IL1bs0eDAEFwROhwR_foI2w6lCw7Y5YJ9reoyWmAvCM\" />

  <meta name=\"revisit-after\" content=\"1 days\">
  ");
  if($so{'q'} eq "")
  {
	  print("
  <meta name=\"description\" content=\"$PAGE_COMMERCIAL_TEXT_SHORT\">
  ");
  }
  else
  {
	  print("
  <meta name=\"description\" content=\"$PAGE_COMMERCIAL_TEXT_SHORT: $so{'q'}\">
  ");
  }
  print("
  <meta name=\"keywords\" content=\"$so{'q'}, $PAGE_KEYWORDS}\">
  <meta name=\"author\" content=\"Jari Tapio Tuominen\">

  <meta name=\"google-site-verification\" content=\"jyAYuR14wFvkF0LjVP6W63jh6y-lIX3Qa2FNoahjEkE\" />

<script>
  function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.documentElement.scrollHeight + 'px';
  }
</script>

<title>
");
if($so{'q'} eq "")
{
        print "$PAGE_TITLE";
}
else
{
        print "$so{'q'} - $PAGE_TITLE - ".int($so{'start'})."";
}
print("
</title>

</head>



<script async src=\"https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4178289363390566\"
     crossorigin=\"anonymous\"></script>

<BODY $xtra bgcolor=$TVAR
        topmargin=0 leftmargin=0
        marginheight=0 marginwidth=0>

        ");
}

sub CloseHTMLDocument
{
  print("
</body>
</html>
");
}
1;
