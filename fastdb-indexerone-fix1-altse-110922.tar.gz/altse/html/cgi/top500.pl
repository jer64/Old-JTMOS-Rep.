#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();

# MENU.
#print("
#<DIV ALIGN=\"center\">
#        <iframe width=\"100%\" height=\"32\" src=\"/menu/\"
#                frameborder=\"0\"  onload=\"resizeIframe(this)\"/
#                loading=\"lazy\”>
#        </iframe>
#</DIV>
#");

# Call the main function.
Top500();


#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub Top500
{
	#
	print("
<TABLE width=\"640\" align=\"center\" bgcolor=\"black\">
<TR>

<TD>
	");
	
	################
	#
	# LOAD UP THE ALTSE's Search log slog.txt.
	#
	
	#
	if(-e "$DB/slog.txt")
	{
		@lst = reverse LoadList("$DB/slog.txt");
	}
	
	#
	my (%gotit,%jackpot);
	for(my $i=0; $i<($#lst+1); $i++)
	{
		#
		my @sp = split(/ & /, $lst[$i]);
		# sp[0]         sp[1]              sp[2]                        sp[3]
		#1660383048 & 87.95.85.45 & 87-95-85-45.bb.dnainternet.fi & <markkinatalous>
		$sp[3] =~ s/^\s//;
		$sp[3] =~ s/\s$//;
		$sp[3] =~ s/[\<\>]//g;
		my $what = "$sp[1].$sp[3]";
		if(!$gotit{$what})
		{
			$gotit{$what}++;
			
			$jackpot{$sp[3]}++;
			#print "<P>$what</P>\n";
		}
		
		#foreach $hash_key (keys %nd_results)
	}
	
	#
	my (@lista,$key,$i);
	$i = 0;
	foreach $key (keys %jackpot)
	{
		my $tmpstr = sprintf "%1.8d & %s", $jackpot{$key}, $key;
		$lista[$i++] = $tmpstr;
		#print "<p>$tmpstr</p:";
	}
	@lista = sort @lista; @lista = reverse @lista;
	
	#
	print("
<A NAME=\"#top500\">
	<CENTER><H1><FONT STYLE=\"color: WHITE;\">Top 500 haut:</FONT></H1></CENTER>
</A>

	");
	for(my $i=0; $i<($#lista+1); $i++)
	{
		#
		@sp = split(/ & /, $lista[$i]);
		#
		$nicen = $i+1;
		print("
<TABLE width=100%
style=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;\">
<TR>

<TD>
	<A HREF=\"/?cmd=go&q=$sp[1]\">
	<FONT STYLE=\"COLOR: black; TEXT-DECORATION: underline; font-weight: normal; height: 32; background-image: url(/images/GoldenBackground.png);
        font-family:arial,helvetica,sans-serif; margin:4; padding:4px 4px 4px 4px;
        border-width: 2px;
        border-spacing: 4px;
        border-style: solid;
        border-color: yellow;\">
	$nicen. $sp[1]
	</FONT>
	</A>
</TD>

</TR>
</TABLE>
		");
	}
	#
	print("
</TD>
</TR>
</TABLE>
	");
}


1;
