#################################################################
#
sub OpenHTMLDocument
{
print("
<!DOCTYPE html>

<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"/images/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"/images/altse.css\" title=\"Cool\">

  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
<!--- iso-8859-1 --->

<meta name=\"google-site-verification\" content=\"IL1bs0eDAEFwROhwR_foI2w6lCw7Y5YJ9reoyWmAvCM\" />

  <meta name=\"revisit-after\" content=\"1 days\">
  ");
  if($so{'q'} eq "")
  {
	  print("
  <meta name=\"description\" content=\"Vaihtoehtouutisten talousuutisten internet-hakukone. | Tr4mp.com\">
  ");
  }
  else
  {
	  print("
  <meta name=\"description\" content=\"Internet-haku: $so{'q'} - Vaihtoehtouutisten talousuutisten internet-hakukone. | Tr4mp.com\">
  ");
  }
  print("
  <meta name=\"keywords\" content=\"talousuutiset, kapitalismi, Trump, Donald J. Trump, Donald Trump, talous, inflaatio, hyperinfaatio, romahdus, riski, sijoittaminen, sijoitus, sijoitustoiminta, Fed, Federal Reserve, BOC, Bank of America, capitalism, News, Uutiset, Pörssi, Stock Exchamge, Equities, Market Risk, Analysis, Search, Web, Web Search, internet, internet-hakukone, julkinen, public, noterization, search stocks, Tr4mp.com, P4t1n.com, Vaihtoehtouutiset.com, Vaihtoehtouutiset, Kultakaivos, Kutakaivos.info, 1920, 1930, 1920-luku, 1930-luku, uhka, romahtaa, pörssi, dollari, raha, euro, dollar, monetization, käteinen, cash, $so{'q'}\">
  <meta name=\"author\" content=\"Jari Tapio Tuominen\">

  <meta name=\"google-site-verification\" content=\"jyAYuR14wFvkF0LjVP6W63jh6y-lIX3Qa2FNoahjEkE\" />

<script>
  function resizeIframe(obj) {
    obj.style.height = obj.contentWindow.document.documentElement.scrollHeight + 'px';
  }
</script>

<title>
");
if($so{'q'} eq "")
{
        print "Vaihtoehtouutiset - talousuutisten internet-hakukone. | Tr4mp.com";
}
else
{
        print "Vaihtoehtouutiset: $so{'q'} - internet-hakukone. | Tr4mp.com";
}
print("
</title>

</head>



<script async src=\"https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4178289363390566\"
     crossorigin=\"anonymous\"></script>

<BODY $xtra bgcolor=$TVAR
        topmargin=0 leftmargin=0
        marginheight=0 marginwidth=0>

        ");
}

sub CloseHTMLDocument
{
  print("
</BODY>

</html>
");
}
1;
