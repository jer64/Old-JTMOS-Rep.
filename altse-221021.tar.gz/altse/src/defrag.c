///////////////////////////////////////////////////////////////////////////
//
// defrag.c - KEYWORD INDEX defragmentation tool.
//
///////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "iscfg.h"

//
typedef struct
{
	//
	char keyword[10];
	DWORD offs1,offs2;
	DWORD *csum;
	int n_csum;
}KENT;

//
typedef struct
{
	//
	KENT **ent;
	int n_ent;
}DEFRAG;
DEFRAG Defrag;

/////////////////////////////////////////////////////////////////////////////
//
int compare_ents(DWORD *a1, DWORD *a2)
{
        KENT *e1,*e2;

        //
        e1 = *a1;
        e2 = *a2;

        //
        return strcmp(e1->keyword, e2->keyword);
}

/////////////////////////////////////////////////////////////////////////////
//
int Defragment(char which, int rank)
{
	static DWORD i,i2,i3,i4,x,xc,c,sx,n,da1,da2,persec,t,lt,count,lcount,
		sz,sz1,sz2,tc,
		new_offs1,new_offs2;
	static int fd,fd2,fd3,fd4,fd5,rv;
	static char fndic[512],fndir[512];
	static char ofndic[512],ofndir[512];
	static char str[8192];
	DEFRAG *de;
	BYTE *buf;
	int l_buf;
	DWORD *dp;
	void *p;
	KENT *e;
	BYTE hdr[1024];
	FILE *f3;

	//
	de = &Defrag;
	memset(de, 0, sizeof(DEFRAG));

	//
	n = 4000000;
	de->ent = malloc(n*4);

        // Source
        sprintf(str, "%s/cid/dict/%d/%c-%d",
                database_path, ProductionIndexNr, which, rank);
	//
	sprintf(fndic, "%s.dic", str);
	sprintf(fndir, "%s.dir", str);
	//
	sprintf(ofndic, "%c-0.dic", which);
	sprintf(ofndir, "%c-0.dir", which);

	//
	fd = open(fndir, O_RDONLY);
	if(fd<0)
	{
		fprintf(stderr, "%s: dir-file not found: %s\n",
			__FUNCTION__, fndir);
		return 0;
	}

	//
	sz = lseek(fd,0,SEEK_END);

	//
	if(sz<=0) { 
		return 0;
	}
	fprintf(stderr, "%s: dir-file %s size %dK\n",
		__FUNCTION__,
		fndir,
		(sz/1024)+1);

	//
	l_buf = sz;
	buf = malloc(l_buf);
	lseek(fd,0,SEEK_SET);
	read(fd, buf, l_buf);

	//
	close(fd);

	//--------------------------------------------------------------------
	xc = l_buf>>2;
	for(x=0,dp=buf,c=0; x<xc; )
	{
		//
		de->ent[c] = malloc(sizeof(KENT));
		e = de->ent[c];

		// FIND START OF ENTRY
		for(; dp[x]!=0x12345678 && x<xc; x++); x++;
		//
		memcpy(e->keyword,dp+x, 8);
		e->keyword[8]=0; x+=2;
		//
		e->offs1 = dp[x]; x++;
		// FIRST COUNT
		for(i=0,sx=x; dp[x]!=0xFFFFFFFF && x<xc; x++,i++)
		{
		}
		// ALLOCATE
		e->n_csum = i;
		e->csum = malloc(4*e->n_csum);
		// THEN GATHER
		for(i=0,x=sx; dp[x]!=0xFFFFFFFF && x<xc; x++,i++)
		{
			e->csum[i] = dp[x];
		}
		x++;
		//
		e->offs2 = dp[x]; x++;
		// FIND END OF ENTRY
		for(; dp[x]!=0xAAAAAAAA && x<xc; x++); x++;
		//
		c++;

		// Fix offsets.
		e->offs1 = (((e->offs1-DIC_HDRSZ)/REAL_EN_SZ)*REAL_EN_SZ)+DIC_HDRSZ;
		e->offs2 = (((e->offs2-DIC_HDRSZ)/REAL_EN_SZ)*REAL_EN_SZ)+DIC_HDRSZ; //+DIC_HDRSZ;

		//
	//	fprintf(stderr, "%s\n", e->keyword);
	}
	//
	de->n_ent = c;

	//
	free(buf);

	//
	fprintf(stderr, "%s: %d entries detected in dir-file\n",
		__FUNCTION__,
		de->n_ent);

	//
	fprintf(stderr, "%s: sorting ...\n",
		__FUNCTION__);
	//
	qsort(de->ent, de->n_ent, 4, compare_ents);
	//
	fprintf(stderr, "%s: Done.\n",
		__FUNCTION__);

	//--------------------------------------------------------------------
	//
	// Open dic file for reading.
	//
	fd = open(fndic, O_RDONLY);
	fd2 = open(ofndic, O_WRONLY | O_CREAT, 0666);
	f3 = fopen(ofndir, "wb");
	if(fd<0 || fd2<0 || f3==NULL)
	{
		fprintf(stderr, "%s: Can't open dic file: %s\n",
			__FUNCTION__,
			fndic);
	}
	//
	sz = lseek(fd,0,SEEK_END);
	//
	fprintf(stderr, "%s: dic-file %s size %dK\n",
		__FUNCTION__,
		fndic,
		(sz/1024)+1);

	// Preallocate.
	lseek(fd2,sz,SEEK_SET);
	i=0; write(fd2,&i,4);

	//
	lseek(fd,0,SEEK_SET);
	read(fd,hdr,DIC_HDRSZ);
	lseek(fd2,0,SEEK_SET);
	write(fd2,hdr,DIC_HDRSZ);

	//
	for(i=0,persec=0,tc=0,lt=0,count=0,lcount=0; i<de->n_ent; i++)
	{
		//
		t = time(NULL);
		if(t!=lt)
		{
			persec = count;
			lt = t;

			//
		/*	fprintf(stderr, "%s: Defragmenting %d/%d   %dM /s  count=%d     \n",
				__FUNCTION__,
				i, de->n_ent,
				(persec/(1024*1024))+1,
				count);*/

			//
			count = 0;
		}

		//
		e = de->ent[i];

		//
		sz1 = e->offs2 - e->offs1;

		// PRINT OUT WHATS GOING ON
		fprintf(stdout, "%s: %.8X-%.8X - %d bytes (%s -> %s * %s)\n",
			e->keyword,
			e->offs1,
			e->offs2,
			sz1,
			fndic,ofndic,ofndir
			);

		//
		buf = malloc(sz1);
		rv = lseek(fd, e->offs1, SEEK_SET);
		c = read(fd, buf, sz1);
		new_offs1 = lseek(fd2,0,SEEK_CUR);
		write(fd2, buf, sz1);
		new_offs2 = lseek(fd2,0,SEEK_CUR);
		count += c;
		tc += c;
		free(buf);

		//
		fputd(0x12345678, f3);
		fwrite(e->keyword, 8,1, f3);
		fputd(new_offs1, f3);

		//
		for(i2=0; i2<e->n_csum; i2++)
		{
			fputd(e->csum[i2], f3);
		}

		//
		fputd(0xFFFFFFFF, f3);
		fputd(new_offs2, f3);
		fputd(0xAAAAAAAA, f3);
	}
	fprintf(stderr, "\n");

	//
	fprintf(stderr, "%s: Defragmentation completed. tc = %dM.\n",
		__FUNCTION__,
		(tc/(1024*1024))+1);

	//
	close(fd);
	close(fd2);
	fclose(f3);

	//--------------------------------------------------------------------
	//
	return 0;
}

///////////////////////////////////////////////////////////////////////////
//
void defragAll(void)
{
        char *lst="0123456789abcdefghijklmnopqrstuvwxyz���";
        int i,l;
        char str[256],str2[256];

        //
        l = strlen(lst);
        //

	int rank_walk,last_rank;
	last_rank=21;
	if(!OPTIMIZE_FOR_SEARCH_SPEED) {
		last_rank = 1;
	}

	for(rank_walk=0; rank_walk<last_rank; rank_walk++)
	{
	        for(i=0; i<l; i++)
       	 	{
			sprintf(str, "%s/cid/dict/%d/def", database_path, ProductionIndexNr);
			mkdir(str, 0777);
			chdir(str);
			sprintf(str, "defrag %c -i %d -l %d",
				lst[i], 
				ProductionIndexNr,
				rank_walk);
			fprintf(stderr, "%s/%s: running command: %s\n",
				__FUNCTION__,__FILE__, str);
			system(str);
			sprintf(str, "mv -f %s/cid/dict/%d/def/* %s/cid/dict/%d/",
				database_path,
				ProductionIndexNr,
				database_path,
				ProductionIndexNr);
			fprintf(stderr, "%s/%s: running command: %s\n",
				__FUNCTION__,__FILE__, str);
			system(str);
        	}
	}
        fprintf(stderr, "\nDone.\n");
}

//
