#!/usr/bin/perl
use DBI;

#
main();

#
sub main
{
	#
	my ($dsn) = "DBI:mysql:vunet:localhost";
	my ($user_name) = "root";
	my ($password) = "vf3890X";
	my ($dbh, $sth);
	my (@ary);

	#
	$dbh = DBI->connect($dsn, $user_name, $password, {RaiseError => 1});

	# Load article.
	@lst = LoadList($ARGV[0]);
	# Load thumbs.
	@thumbs = LoadList("$ARGV[0]_thumbs.txt");
	# Load article options.
	LoadVars("$ARGV[0]_options.txt");

	#
	$subject = $lst[0];
	$subject =~ s/<[^\>]*>//g;
	$subject =~ s/^\s*//;
	$subject =~ s/\s*$//;
	$subject =~ s/\'/\\\'/g;

	#
	for($i=1,$body=""; $i<($#lst+1); $i++)
	{
		$body = "$body $lst[$i]";
	}
	$body =~ s/\'/\\\'/g;

	#
	$fname = $ARGV[0];

	#
	if($so{'release_date'} eq "")
	{
	}

	#
	$sth = $dbh->prepare("INSERT INTO articles
			(subject, body, release_date,
			section, fname, thumbs,
			image_url, image_url2,
			mirror,stream,commir,lyrics,geoloc)
			values
			('$subject', '$body', '$so{'release_date'}',
			'$section' '$fname', '$thumbs[0]',
			'$so{'image_url'}', '$so{'image_url2'}',
			'$so{'mirror'}','$so{'stream'}','$so{'commir'}',
			'$so{'lyrics'}','$so{'geoloc'}'
			);");
	$sth->execute() or print "failed on $ARGV[0] ($DBI::errstr)\n";
	$sth->finish();

	#
	$dbh->commit();

	#
}
