// ts.c - text search.
#include <stdio.h>
#include "selib.h"

//
void TS(char *fn, char *key)
{
	FILE *f;
	int i,i2,i3,i4,ch,hits;
	static char str[8192],str2[8192];

	//
	f = fopen(fn, "rb");
	if(f==NULL) { return; }

	//
	for(i=0,hits=0; !feof(f) && i<50000; i++)
	{
		fscanf(f, "%s", &str);
		strcpy(str2, str);
		LowerCaseString(str2);
		if( strstr(str2, key) )
		{
			fprintf(stdout, "%s\n", str);
			hits++;
			if(hits>=10) { break; }
		}
	}

	//
	fclose(f);
}

//
int main(int argc, char **argv)
{
	//
	if(argc<3)
	{
		fprintf(stderr, "Usage: [file] [keyword]\n");
		return 0;
	}

	//
	TS(argv[1], argv[2]);

	//
	return 0;
}
