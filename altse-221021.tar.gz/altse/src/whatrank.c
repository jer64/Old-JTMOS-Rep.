//
#include <stdio.h>
#include <string.h>

//
int main(int argc, char **argv)
{
	FILE *f;
	int rank,i,t;

	//
	if(argc<2) { return 0; }

	//
	for(i=1; i<argc; i++)
	{
		f = fopen(argv[i], "rt");
		if(f==NULL) { continue; }
		rank = 0;
		fscanf(f, "%d", &t);
		fscanf(f, "%d", &rank);
		fclose(f);

		//
		printf("%d %s\n",
			rank, argv[i]);
	}

	//
	return 0;
}

//

