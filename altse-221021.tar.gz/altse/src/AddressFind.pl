#!/usr/bin/perl
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
AltseOpenConfig();

#
$FN_JOBS_LEFT = "$DB/jobs/fe.txt";

#
main();

#
sub main
{
	my ($i,$i2,$str,$str2,@lst,$n);

	#
	open($f, "find $DB/www/ -type f -name 'already.txt'|");

	#
	open($f2, ">$DB/street-addresses.txt");

	#
	for($sn=0; !eof($f); $n++)
	{
		#
		$fn_already = <$f>;
		chomp($fn_already);
		$path = $fn_already;
		$path =~ s/^(.*\/)[^\/]*$/$1/;

		#
		print "Checking $path :\n";

		#
		if(1)
		{
			#
			#open($f, ">$FN_JOBS_LEFT");
			#print $f $n;
			#close($f);

			#
			@lst = LoadList($fn_already);
	
			#
			for($i=0; $i<($#lst); $i+=2)	
			{
				@lst2 = LoadList("addressgrep $path$lst[$i+1]|");
				if( $#lst2>=0 )
				{
					for($i2=0; $i2<($#lst2+1); $i2++)
					{
						$em = $lst2[$i2];
						if($emails{$em} eq "")
						{
							print STDERR "new address found:  $em\n";
							$address{$em}++;
							print $f2 "$em\n";
						}
					}
				}
			}
		}

		#
	}

	#
	close($f2);

	#
	close($f);

	#
}


