#!/usr/bin/perl
##########################################################################
#
# Dictionary archiver.
# Builds single files out of individual dictionaries.
#
##########################################################################
#
use POSIX;
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =          "$NWPUB_CGIBASE/sdb";   # search database root directory
$CID =          "$SDB/cid";             # central index
$LISTS =        "$SDB/cid/lists";       # list files directory
$DADI =         "$SDB/cid/data";        # data files
$DICT =         "$SDB/cid/dict";        # big index with dictionaries

#
main();

############################################################################
#
sub ArchiveDir
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$fn,$f,$name);

	#
	@lst = LoadList("find $_[0] -name '*.dic'|");

	#
	if($#lst<0)
	{
		return();
	}

	#
	$fn = "$_[0]/common.dar";
	print STDERR "$fn:\n";

	#
	open($f, ">>$fn") || die "can't write $fn";
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		@lst2 = LoadList($lst[$i]);

		#
		$name = $lst[$i];
		$name =~ s/^.*\/(.*)$/$1/;

		#
		print $f "$name\n";
		for($i2=0; $i2<($#lst2+1); $i2++)
		{
			if($lst2[$i2] ne "")
			{
				print $f "$lst2[$i2]\n";
			}
		}
		print $f "\n";
		#
		print STDERR "- $lst[$i]\n";

		# Remove file afterwards.
		remove($lst[$i]);
	}
	close($f);
}

############################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,$str);

	# Read list of directories.
	print STDERR "Scanning $DICT ...\n";
	@lst = LoadList("find $DICT -type d|");
	print STDERR "Done ($#lst entries found).\n";

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$str = $lst[$i];
		if( $str =~ /\/dict\/[0-9]*\/[0-9]*$/ )
		{
			ArchiveDir($str);
		}
	}
}
