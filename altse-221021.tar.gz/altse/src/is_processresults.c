//////////////////////////////////////////////////////////////////////////////////////////
//
// is_processresults.c - Altse Internet Search.
// (C) 2005-2011 by Jari Tuominen (jari@vunet.org).
//
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
//#include <db.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "is_processresults.h"
#include "iscfg.h"


//////////////////////////////////////////////////////////////////////////////////////////
//
int ProcessResults(IS *is)
{
	int i,i2,i3,i4,steppi,OnlyTopHits;
	EN *e;
	ENTSCO *ee;

	//
	if(is->n_en > 99999 && is->n_word==1)
	{
		OnlyTopHits = TRUE;
		WriteLog("- Enabling OnlyTopHits option.\n");
	}
	else
		OnlyTopHits = FALSE;

	//
	WriteLog("[%d] Processing results (OnlyTopHits=%d)...\n",
		GetIsTickCount(), OnlyTopHits);

	// Create rank score table.
	for(i=0; i<MAX_RANK; i++)
	{
		lstab[i] = SCORE_FOR_RANK/(i+1);
	}

	//////////////////////////////////////////////////////////////
	//
	// Convert from EN array to ENTSCO array.
	//

	//
	WriteLog("[%d] %s: - Creating score entry tables (n_en = %d).\n",
		GetIsTickCount(),
		__FUNCTION__,
		is->n_en);

	// This loop takes ALOT time when n_en equals thousands.
	//

	//
	if( is->n_en>(MAX_MEMORIZE-1) && is->n_word<=1 )
	{
		steppi = is->n_en/(MAX_MEMORIZE>>1);
		WriteLog("%s line %d: is steppi set to %d because of memorization limitation reasons.\n",  __FUNCTION__, __LINE__, steppi);
	}
	else
		steppi = 1;
	//
	WriteLog("[%d] %s: steppi = %d, is->n_en=%d\n",
		GetIsTickCount(),
		__FUNCTION__,
		steppi,
		is->n_en);
	//
	for(i=0; i<(is->n_en); i+=steppi)
	{
		//
		e = is->en[i];

		//
		if(e->rnk<0) { continue; }

		//
		//fprintf(stderr, "rnk = %d\n", e->rnk);

		//
		switch( (e->type&255) )
		{
			//
			case WORD_TYPE_META_KEYWORDS:
			IncreaseScore(is, 90000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			case WORD_TYPE_META_DESCRIPTION:
			IncreaseScore(is, 100000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;

			//
			case WORD_TYPE_TITLE:
			IncreaseScore(is, 80000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			case WORD_TYPE_URL:
			IncreaseScore(is, 95000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			case WORD_TYPE_IMAURL:
			IncreaseScore(is, 10000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			case WORD_TYPE_PAGEBEG:
			IncreaseScore(is, 10000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			case WORD_TYPE_PAGEEND:
			IncreaseScore(is, 9000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			case WORD_TYPE_HOST:
			if( (e->type&WORD_TYPE_PORTAL) || (e->type&WORD_TYPE_HIGH_PROFILE) )
			{
				//printf("HOST MATCH.\n");
				IncreaseScore(is, 5000000, e->gid, e->loc, e->rnk, e->host, //e->url,
						e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			}
			else
			{
				if(is->n_word==1)
				{
					IncreaseScore(is, 500000, e->gid, e->loc, e->rnk, e->host, //e->url,
							e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
				}
				else
				{
					IncreaseScore(is, 1000000, e->gid, e->loc, e->rnk, e->host, //e->url,
							e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
				}
			}
			break;
			//
			case WORD_TYPE_PREVIEW:
			IncreaseScore(is, 20000, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			case WORD_TYPE_REGULAR:
			if(!OnlyTopHits)
			IncreaseScore(is, 1, e->gid, e->loc, e->rnk, e->host, //e->url,
					e->csum_w1,e->csum_w2,e->csum_w3,e->csum_w4);
			break;
			//
			default:
			WriteLog("[%d] ?? Unknown entry type for %d (type=%.8x, host=%.8x, loc=%x, rnk=%x, w1=%x).\n",
					GetIsTickCount(),i,
					e->type, e->host, e->loc, e->rnk, e->csum_w1);
			break;
		}
	}

	//////////////////////////////////////////////////////////////
	//
	if(is->n_word>1) {
		WriteLog("[%d] %s: Rewarding on pairs.\n",
			GetIsTickCount(),
			__FUNCTION__);
		RewardOnPairs(is);
	}

	//
	WriteLog("[%d] %s: Completed processing results.\n",
		GetIsTickCount(),
		__FUNCTION__);

	//
	return 0;
}
