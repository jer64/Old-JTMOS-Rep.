// htmlParse.c
#include <stdio.h>
#include "selib.h"
#include "gethtmlpage.h"

// Verbose error reporting option.
#define HTMLPARSE_REPORT_ERRORS		0

/////////////////////////////////////////////////////////////////////////////
//
BYTE *GetHtmlPage(BYTE *host, BYTE *path)
{
	static char url[8192];
	static char cachepath[8192],
			fn_already_txt[8192],
			found_url[8192],
			found_name[8192],
			fn_html[8192],
			popen_cmd[8192];
	BYTE *ho;
	FILE *f;
	int found;
	BYTE *buf;
	int l_buf,i,i2,ch1;
	FILE *gzf;

	//
	ho = host;
	if(!strncmp((char*)ho,"www.",4)) { ho+=4; }

	//
	strcpy(url, "http://");
	strcat(url, (char*)host);
	strcat(url, "/");
	strcat(url, (char*)path);

	//
	for(i=0,i2=0; i<strlen(ho); i++) {
		if( isalnum1(ho[i]) || ho[i]=='.' || ho[i]=='-' ) { i2++; }
	}
	if(i2!=strlen(ho)) {
		if(HTMLPARSE_REPORT_ERRORS)
			fprintf(stderr, "%s, line %d (error): host string is invalid: \"%s\"\n", __FUNCTION__, __LINE__, ho);
		return NULL;
	}

	//
	if(strlen(ho)>=3)
	{
		sprintf(cachepath, "%s/www/%c%c%c/%s",
			database_path,
			ho[0],ho[1],ho[2],
			host);
	}
	else
	//
	if(strlen(ho)==2)
	{
		sprintf(cachepath, "%s/www/%c%c/%s",
			database_path,
			ho[0],ho[1],
			host);
	}
	else
	//
	if(strlen(ho)==1)
	{
		sprintf(cachepath, "%s/www/%c/%s",
			database_path,
			ho[0],
			host);
	}
	else
		return NULL;

	//
	sprintf(fn_already_txt, "%s/already.txt",
		cachepath);
	f = fopen(fn_already_txt, "rt");
	if(f==NULL)
	{
		if(HTMLPARSE_REPORT_ERRORS)
			fprintf(stderr, "%s: NOT FOUND: %s\n",
			__FUNCTION__,
			fn_already_txt);
		return NULL;
	}
	for(found=FALSE; !feof(f); )
	{
		fgets(found_url, 8000, f);
		fgets(found_name, 8000, f);
		FixString(found_url);
		FixString(found_name);

		if(!strcmp(found_url, url)) { found=TRUE; break; }
	}
	fclose(f);

	// HERE'S SOME BUG - TODO
	if(found)
	{
		//
		fprintf(stderr, "cachepath=%s\n", cachepath);
		fprintf(stderr, "found_name=%s\n", found_name);
		sprintf(fn_html, "%s/%s",
			cachepath,
			found_name);
		if( !strstr(fn_html, ".gz") )
		{
			strcat(fn_html, ".gz");
		}
		f = fopen(fn_html, "rb");
		if(f==NULL)
		{
			if(HTMLPARSE_REPORT_ERRORS)
				fprintf(stderr, "%s: NOT FOUND: %s\n",
				__FUNCTION__,
				fn_html);
			return NULL;
		}
		else	fclose(f);

		//
		sprintf(popen_cmd, "zcat %s", fn_html);
		f = popen(popen_cmd, "rb");
		if(f==NULL)
		{
			if(HTMLPARSE_REPORT_ERRORS)
				fprintf(stderr, "%s: POPEN FAILED: %s\n",
				__FUNCTION__,
				fn_html);
			return NULL;
		}
		l_buf = 1024*64;
		buf = imalloc(l_buf);
		for(i=0; i<(l_buf-4) && !feof(gzf); i++)
		{
			ch1 = fgetc(f);
			buf[i] = ch1;
		}
		buf[i] = 0;
		fclose(f);
		return buf;
	}

	//
	return NULL;
}

