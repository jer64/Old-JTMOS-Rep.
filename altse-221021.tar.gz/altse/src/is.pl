#!/usr/bin/perl
#######################################################
#
# is.pl - Vunet Instant Searcher.
#
#######################################################

#
use POSIX;
#use String::CRC::Cksum qw(cksum);
#use String::Approx 'amatch';

#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

# How many seconds to keep a cached result?
$max_cache_age = (60*60*1);
$CACHE_ENABLED = 1;

# Path to the central index.
$SDB = "/home/vai/sdb";
$CID = "$SDB/cid/dict";

#
main();

################################################################
sub IsCGI
{
	if($ENV{'REMOTE_ADDR'} ne "") { return 1; } else { return 0; }
}

################################################################
#
# nid, hits, keyword, score
#
sub Hit
{
	my ($nid,$hitz,$_sk,$score,$loc,$domain,$str,$q,$q2,$path1);

	#
	$nid = $_[0];
	$hitz = $_[1];
	$_sk = $_[2];
	$score = $_[3];
	$loc = $_[4];
	$domain = $_[5];
	$path1 = $_[6];

	#
	$q = "$nid:$domain:$path1";
	$q2 = "$nid:$domain:$loc";
	#
	$hits{$q} += $hitz*$score;
	#
#	$loc =~ s/([0-9]*,)/$_[7].$1/g;
	$locs_w{$q2} = $_[7];
	$locs{$q} = "$loc$locs{$q}";

	# mk = matching keywords
	if( !($mk{$q}=~/\[$_sk\]/) )
	{
		#
		$mk{$q} = "$mk{$q} [$_sk] ";
	}
}

################################################################
#
# Search using fast index technology.
#
# Parameters:
# key, domain.dic, domain name
#
sub FastSearch
{
	my ($i,$i2,$i3,$i4,$fn,@com,@cat,$f,$str,$skey,$key,$key1,$lkey,
		$found,$t,$findex,$chr,$chr1,$chr2,$chr3,$chr4,@hf,$dicfn,
		$score,@sp,@sp2,@lst,$x,$y,$z,$zz,$hi,$lfn,
		$loc);

	###############################################################################
	#
	# The actual search loop.
	#

	#
	$chr1 = $_[0];
	$chr1 =~ s/^(\S).*$/$1/;
	$chr2 = $_[0];
	$chr2 =~ s/^\S(\S).*$/$1/;
	$chr3 = $_[0];
	$chr3 =~ s/^\S\S(\S).*$/$1/;
	$chr4 = $_[0];
	$chr4 =~ s/^\S\S\S(\S).*$/$1/;
	if($chr2 eq "" || length($chr2)>1) { $chr2 = "_"; }
	if($chr3 eq "" || length($chr3)>1) { $chr3 = "_"; }
	if($chr4 eq "" || length($chr4)>1) { $chr4 = "_"; }

	# Read files list.
	$str = $glst[$gi++];
	@hf = split(/\|/, $str);

##	@hf = LoadList($lfn);
##	$lfn = "$SDB/cid/lists/$_[2]\.lst";
##	if( !(-e $lfn) ) { return(); }

	#
	loop2: for($key="",$lkey="",$z=0; $gi<($#glst+1); $gi++,$z++)
	{
		# Empty line means end of section.
		if($glst[$gi] eq "") { last loop2; }

		#
		@sp = split(" ", $glst[$gi]);

		#
		$key =~ $sp[0];
			
		# The search keyword in ASCII format.
		$sk = $_[0];
	
		#
		$score = 0;

		# Compare checksums.
		if($sp[0] eq $_[1]) { $score+=2; }

		#
		if($score>0)
		{
			#
			$hi = $sp[1];
			$loc = $sp[2];
			$nid = $sp[3];

			# nid, hits, keyword, score
			Hit($nid,$hi,$sk,$score,$loc,$_[2], $hf[$nid], $_[1]);
		}
skip11:
	}
past:	

	#
}

################################################################
#
sub SaveResult
{
	my ($key,$fn,$f,$i,$i2);

	#
	$key = $_[0];

	#
	$fn = GetCacheFileName($key);

	#
	open($f, ">$fn");
	for($i=0; $i<($#tl+1); $i++)
	{
		print $f "$tl[$i]\n";
	}
	close($f);
}

################################################################
#
sub GetCacheFileName
{
	my ($key,$fn);

	#
	$key = $_[0];
	$key =~ tr/[A-Z���]/[a-z���]/;
	$key =~ s/:/\_KP\_/g;
	$key =~ s/ /_/g;
	$key =~ s/[^0-9_a-z���]//gi;
	$fn = "$SDB/tmp/cached\_$key\_co$so{'co'}.txt";
	return $fn;
}

################################################################
#
sub IsOldCache
{
	my ($t,$ct);

	#
	$t = (stat($_[0]))[9];
	$ct = time;
	if( ($ct-$t) >= $max_cache_age )
	{
		# Already expired.
		return 1;
	}

	# Fresh entry...
	return 0;
}

################################################################
#
sub GetCachedResult
{
	my ($key,$fn);
	my ($t,$ct);

	#
	$key = $_[0];

	#
	$fn = GetCacheFileName($key);
	#
	if(-e $fn)
	{
		#
		$t = (stat($fn))[9];
		$ct = time;
		$cage = ($ct-$t);

		# Cache expires...
		if( IsOldCache($fn) ) { return 0; }

		#
		@tl = LoadList($fn);

		# Cached result found and is loaded!
		return 1;
	}

	# No cached result found.
	return 0;
}

################################################################
#
sub SearchNow1
{
	my ($i,$i2,$i3,$i4,$f,$key,@alst,$x,$y,$z,$zz,
		$sec,$chr1,$chr2,$chr3,
		$loc,$fn,$t,@sp,@sp2,$nid);

	#
	$key = $_[0];

	#
	#
	$chr1 = $key;
	$chr1 =~ s/^(\S).*$/$1/;
	$chr2 = $key;
	$chr2 =~ s/^\S(\S).*$/$1/;
	$chr3 = $key;
	$chr3 =~ s/^\S\S(\S).*$/$1/;
	$chr4 = $key;
	$chr4 =~ s/^\S\S\S(\S).*$/$1/;
	if($chr2 eq "" || length($chr2)>1) { $chr2 = "_"; }
	if($chr3 eq "" || length($chr3)>1) { $chr3 = "_"; }
	if($chr4 eq "" || length($chr4)>1) { $chr4 = "_"; }
	$dicpa = sprintf "$CID/%s/%s", $chr1, $chr2;
#	if(!IsCGI()) { print STDERR "$dicpa\n"; }
	if( !(-e $dicpa) ) { return(); }

	#
	$try1 = "$dicpa/$chr3/$chr4-common.dic";
	$try2 = "$dicpa/$chr3-common.dic";
	#
	@glst = ();
	if(-e $try1)
	{
#		if(!IsCGI()) { print STDERR "Found $try1.\n"; }
		@glst = LoadList($try1);
	}
	if(-e $try2)
	{
#		if(!IsCGI()) { print STDERR "Found $try2.\n"; }
		@glst = LoadList($try2);
	}

	# Search section by section.
	for($gi=0; $gi<($#glst+1); $gi++)
	{
		#
		if( $glst[$gi]=~/^\[\S*\]$/ )
		{
			#
			$sec = $glst[$gi];
			$sec =~ s/^.*\///;
			$sec =~ s/\.dic$//;
			$sec =~ s/^\[(.*)\]$/$1/;

			# search keyword, domain name
			$gi++;
			# key, sum
			FastSearch($_[0],$_[1], $sec);
		}
	}
#	if(!IsCGI()) {  print STDERR "\n"; }

	#
	$gi--;

	#
	return $tulos;
}

################################################################
#
sub SearchNow
{
	my ($key);

	#
	$key = $_[0];

	#
	if($key eq "")
	{
		return;
	}


	#
	$query_st = time;

        # Try to get a cached result.
        if( $CACHE_ENABLED==1 && $so{'REFRESH'} ne "1" && GetCachedResult($key) )
        {
		goto done;
        }
        else
        {
#		if(!IsCGI()) { print STDERR "Refreshing.\n"; }
        }

	#
	%hits = ();
	%locs = ();

	#
	@tl = ();
	for($i=0; $i<($#W+1); $i++)
	{
		SearchNow1($W[$i], $W_SUM[$i]);
	}

	# Extract entries from %hits to @tl;
	#
        foreach $nid (keys %hits)
        {
		#
		@sp = split(/:/, $nid);
		$rnid =		$sp[0];
		$domain =	$sp[1];
		$path1 =	$sp[2];

		#
		@sp = split(/ /, $mk{$nid});
		$i = $#sp+1;
		$loc = $locs{$nid};
		$fn = "$domain/$path1";
		$t = (stat("$fn"))[9];

		# Determine if any words connect.
		@sp2 = split(/,/, $loc);
		for($x=0,$zz=1,$str2=""; $x<($#sp2); $x++)
		{
			# Determine distance between words.
			$i2=$sp2[$x]-$sp2[$x+1];
			if($i2<0) { $i2 = -$i2; }
			if($i2<=1)
			{
				$zz+=10;
			}
		}		

		#
		$str = sprintf "%.12d & %s & %d & %s & %s & %s & %s",
			($hits{$nid}*$i+($i*20))*$zz, $fn, $t, $domain, $rnid, $loc, "";
		$tl[$#tl+1] = $str;
		$tulos++;
        }

	#
	@tl = sort(@tl);
	#
	SaveResult($key);

	#
done:
	$query_et = time;
}

################################################################
#
sub ProcessSearchString
{
	my ($str,$i,$i2);

	# Split into search words.
	$str = $so{'q'};
	# Do not allow dots, slashes or stars.
	$str =~ s/[^0-9a-z���\_\- ]/ /gi;
	#
	$str =~ tr/[A-Z���]/[a-z���]/;
	#
	@W = split(" ", $str);

	#
	$str =~ s/\-/ /g;
	@AW = split(" ", $str);

	# Remove impractical words.
	for($i=0; $i<($#W+1); $i++)
	{
		#
		if(length($W[$i])<2)
		{
			$W[$i] = "";
		}
		else
		{
			$W_SUM[$i] = cksum($W[$i]);
		}
	}
}

################################################################
#
sub main
{
	my ($i,$i2,$str,$took);

	#
	if($ARGV[0] eq "") { return(); }

	#
	$so{'q'} = "$ARGV[0] $ARGV[1] $ARGV[2] $ARGV[3] $ARGV[4] $ARGV[5] $ARGV[6] $ARGV[7]";

	# Make the search string abit more nicer ...
	$so{'q'} =~ s/\[|\]|{|}/ /g;
	$so{'q'} =~ s/\?/ /g;
	$so{'q'} =~ s/^\s*//;
	$so{'q'} =~ s/\s*$//;

	#
	if($so{'q'} =~ /\sREFRESH$/)
	{
		$so{'q'} =~ s/\sREFRESH$//;
		$so{'REFRESH'} = 1;
	}

	#
	if($so{'q'} eq "" && $so{'searchstring'} ne "")
	{
		$so{'q'} = $so{'searchstring'};
	}
	if($so{'q'} eq "*")
	{
		$TIME_ORDER = 1;
	}
	#
	ProcessSearchString();

	# Get options.
	#
	$set = $so{'q'};
	$set =~ s/\?/\ /;

	#
	SearchNow($so{'q'});

	#
	$took = $query_et-$query_st;

	# Dump results to STDOUT.
	for($i=0; $i<($#tl+1); $i++)
	{
		if($tl[$i] ne "" && !($tl[$i]=~/^\s*$/))
		{
			print STDOUT "$tl[$i]\n";
		}
	}

	#
#	if(!IsCGI()) { print STDERR "Found $#tl result(s) in $took second(s).\n"; }
}

