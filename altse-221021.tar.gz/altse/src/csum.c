// csum.c
#include <stdio.h>
#include "selib.h"

//
int main(int argc, char **argv)
{
	DWORD cs;

	//
	if(argc<2)
	{
		fprintf(stderr, "Usage: csum [lower-case word]\nNote: implements smart checksum calculation using bit-rotation.\n");
		return 0;
	}

	//
	cs = smart_csum(argv[1], strlen(argv[1]));
	fprintf(stderr, "%s: %.8X\n",
		argv[1], cs);

	//
	return 0;
}

