//
#include <stdio.h>
#include <stdlib.h>
#include "selib.h"

//
int dirdump(char *fname)
{
	FILE *f;
	int len,i,i2,i3,i4,poll;
	DWORD *dp;
	BYTE tmp[8192];
	DWORD d1,d2,d3,d4,
		start_offset,end_offset,csum;
	char eight_letters[10];

	//
	f = fopen(fname, "rb");
	if(f==NULL) {
		return 1;
	}

	//
	for(i=0,poll=0; poll<10000000 && !feof(f); poll++)
	{
		// Read one entry from 0x1234567 to 0xFFFFFFFF.
		for(; ; )
		{
			// Find beginning indicator DWORD 0x1234567
			for(; !feof(f) && poll<10000000; poll++) {
				fread(&d1, 1,4, f);
				if(d1==0x12345678) {
					// Beginning found
					break;
				}
			}
			// Read key list beginning DWORD
			while(!feof(f)) {
				fread(&eight_letters, 1,8, f);
				eight_letters[8]=0;

				fread(&start_offset, 1,4, f);
				fread(&end_offset, 1,4, f);
				do { fread(&d1, 1,4, f);
				} while(d1!=0xFFFFFFFF);
				fread(&d1, 1,4, f);
				if(d1!=0xAAAAAAAA) {
					fread(&d1, 1,4, f);
					if(d1!=0xAAAAAAAA) {
						fprintf(stderr, "%s line %d: expecting 0xFFFFFFFF - format error, corruption at %.8x ?\n",
							__FUNCTION__,__LINE__,ftell(f)-4);
						goto end_loop;
					} else { csum = d1; }
				} else {
					csum = 0;
				}

				fprintf(stdout, "%s %.8x - %.8x\tfirst word csum %.8x\t(at .dic (dictionary) file)\n",
					eight_letters,
					start_offset,end_offset,csum);
				break;
			}

			//
		}
	}
end_loop:

	//
	fclose(f);
}

// dirdump [file name]
int main(int argc, char **argv)
{
	//
	if(argc<2) {
		printf("Usage: dirdump [DIR-file]\n");
		return 0;
	}

	//
	dirdump(argv[1]);

	//
	return 0;
}
