#!/bin/bash
find Top/Computers > Computers.txt
find Top/Games > Games.txt
find Top/Health > Health.txt
find Top/Home > Home.txt
find Top/News > News.txt
find Top/Recreation > Recreation.txt
find Top/Reference > Reference.txt
find Top/Science > Science.txt
find Top/Sports > Sports.txt
find Top/World/Suomi > TopWorldSuomi.txt
find Top/World/Svenska > TopWorldSvenska.txt
find Top/World/Deutsch > TopWorldDeutsch.txt
find Top/World/Nederlands > TopWorldNederlands.txt
find Top/Regional/Europe/Finland > TopRegionalEuropeFinland.txt

