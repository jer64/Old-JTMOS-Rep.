#!/usr/bin/perl
# Install script version 1.1.
#
# Note for advanced users:
#         Altse requires various libraries not installed here.
#         For functionality these libraries are vital.
#
require "$ENV{'HOME'}/sdb/html/cgi/modules/AltseOpenConfig.pl";
require "$ENV{'HOME'}/sdb/html/cgi/modules/LoadList.pl";

#
main();

#
sub AskExit
{
	print STDERR "Enter \"y\" for yes to continue: ";
	my $ok = <STDIN>; chomp $ok;
	if($ok ne "y") {
		print STDERR "\n";
		exit;
	}
	print STDERR "\n";
}

#####################################################################
#
# Installation.
#
sub main
{
	print STDERR "Welcome to ALTSE INSTALLATION (1.1)\n";
	print STDERR "The alternative search engine for small\n";
	print STDERR "businesses and organizations.\n";
	print STDERR "\n";
	print STDERR "Note: this script is usually used for\n";
	print STDERR "first time installations only.";
	print STDERR "NOTE!: NO WARRANTY OF ANY KIND IS PROVIDED,\n";
	print STDERR "USE AT YOUR OWN RISK ONLY!";
	print STDERR "\n";
	print STDERR "ALTSE is at an experimental stage, you can\n";
	print STDERR "only use it as UN*X user \"vai\",\n";
	print STDERR "you must place it in /home/vai -directory\n";
	AskExit();

	#
	system("mkdir -p ~/db/www");
	print STDERR "Creating central index (cid) paths ...\n";
	system("mkdir -p ~/sdb/cid");
	system("mkdir -p ~/sdb/cid/tmp");
	system("mkdir -p ~/sdb/cid/data");
	system("mkdir -p ~/sdb/cid/dict");
	system("mkdir -p ~/sdb/cid/dict/0");
	system("cp -i ~/sdb/ads.pl ~/"); ## ads for Altse

	if(-e "$ENV{'HOME'}/db") {
		print STDERR "Looks like the database directory already exists !\n";
		print STDERR "Do you want to continue?";
		AskExit();
	}

	print STDERR "Building binaries for Altse ...\n";
	system("./build_binaries.sh");

	print STDERR "Creating database directory (db) and buddies ...\n";
	system("bin/mkdb.sh");

	# Check .bashrc first if it already has the sdb/bin in PATH.
	my (@lst,$i,$i2,$doneit);
	@lst = LoadList("$ENV{'HOME'}/.bashrc");
	$doneit = 0;
	for($i=0; $i<($#lst+1); $i++) {
		if($lst[$i]=~/\:\/home\/vai\/sdb\/bin/) {
			$doneit = 1;
		}
	}

	# Add path in .bashrc if needed.
	if(!$doneit) {
		open($f, ">>$ENV{'HOME'}/.bashrc") || die "Oops! Error. Can't write .bashrc\n";
		print $f "PATH=$PATH:/home/vai/sdb/bin\n";
		print $f "export PATH\n";
		print $f "export http_proxy=http://localhost:3128/\n";
		print $f "export ftp_proxy=http://localhost:3128/\n";
		close($f);
		print STDERR "Updated .bashrc: please relogin to your shell to get effects\n";
	} else {
		print STDERR "No need to update .bashrc: looks like .bashrc already has Altse (sdb) in PATH, that's good.\n";
	}

	#
	print("Please enter password for the superuser to make system wide changes\n");
	system("su && perl root_install.pl");

	# done in root mode
	#system("chmod a+rwx ~/db/logs");
	#system("chmod a+rw ~/db/logs/*");

	#
	print STDERR "END OF INSTALLATION\n";
	print STDERR "Read INSTALL -file for further instructions.\n";
	print STDERR "NOTE for crawling: please install squid proxy and configure\n";
	print STDERR "                   wgetrc and lynx.cfg HTTP_PROXY -variables\n";
	print STDERR "                   accordingly for acceptable peformance.\n";
	print STDERR "\n";
	print STDERR "To proceed, please relogin your user account, to do so type: logout\n";
}
