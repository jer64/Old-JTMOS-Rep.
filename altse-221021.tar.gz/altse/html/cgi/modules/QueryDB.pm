#
if($ENV{'HOME'} eq "") {
	$ENV{'HOME'} = "/home/vai";
}
# REMEMBER TO a+rw altse/logs/* !
require "./modules/NoTracking.pm";

sub GetCookies
{
        my (@cookies,$_cl);

        #
        $_cl = $ENV{'HTTP_COOKIE'};
        #
        @cookies = split /;/, $_cl;

        #
        return @cookies;
}

#
sub GetCookie1
{
        my ($i,@cookies);

        #
        @cookies = GetCookies();

        #
        for($i=0; $i<($#cookies+1); $i++)
        {
                #
                if($cookies[$i] =~ /$_[0]\=/)
                {
                        return $cookies[$i];
                }
        }

        #
        return "";
}

#
sub GetCookie
{
        my ($tmp);

        #
        $tmp = GetCookie1($_[0]);
        $tmp =~ s/$_[0]\=//g;
        return $tmp;
}

##########################################################################################################
#
# Make a search database query.
#
sub QueryDB1
{
	my ($key,$comd,$fn,$i,$i2,$site,$EXTRA,$OR_MODE);

	$p1 = $HOSTPAR;
	$p2 = $EXTRA;
	$p3 = $EXTRA2;
	$p4 = $_[1];
	$p1 =~ s/[^a-zA-Z0-9\-]/_/g;
	$p2 =~ s/[^a-zA-Z0-9\-]/_/g;
	$p3 =~ s/[^a-zA-Z0-9\-]/_/g;
	$p4 =~ s/[^a-zA-Z0-9\-]/_/g;

	#
	$key = $_[0];

	#
	$site = $so{'site'};
	$site =~ s/[^a-z������A-Z0-9\-]/_/g;
	$fn = "/home/vai/altse/tmp/cache\_$so{'indexnr'}\_\_$key\_$p1\_$p2\_$p3\_$p4\_$site.txt";

	if( CacheQuery("$fn") )
	{
			# Found cached result.
			#print "CACHED.";
	}
	else
	{
		#
		$keyword =~ s/[^a-zA-Z0-9]/ /g;
		# ******************************************************************************
		# Core-search query.
		if($so{'site'} ne "") { $EXTRA = ""; }
		if($so{'st'} eq "image") { $EXTRA = ""; }
		$fnfn = "cfg/$so{'indexnr'}_is.cfg";
		my $EXTRA2;
		if(-e $fnfn) {
			$EXTRA2 = join(" ", LoadList($fnfn));
		}
		if($so{'site'} ne "") {
			$HOSTPAR = "-h \"$so{'site'}\"";
		}
		#$comd = "$ENV{'HOME'}/altse/bin/is \"$keyword\" -t txt -i $so{'indexnr'} $HOSTPAR $EXTRA $EXTRA2 $_[1] -mp 10 2>/dev/null|";
		
		# Enable support for AI search "multi-fetch":
		$comd = "$ENV{'HOME'}/altse/html/cgi/modules/multifetch.pl \"$keyword\" 2>/dev/null|";
				
		#Bif(NoTracking()) {
		# 	print "<LI>" . $comd . "</LI>";
		#}
		@results = LoadList($comd);
		
		
		
		#print "<PRE>".$results[1]."</PRE>";
		

		#
		my ($f,$i);
		open($f, ">$fn");
		for($i=0; $i<($#results+1); $i++)
		{
			print $f $results[$i] . "\n";
		}
		close($f);

		#
	}
	return @results;
}

##########################################################################################################
#
# Make a search database query.
#
sub QueryDB
{
	my ($key,$comd,$fn,$i,$i2,$site,$EXTRA,$OR_MODE);

	#
	my ($p1,$p2,$p3,$p4,$p5,$p6);
	#print "$fn \"$site\"<br>\n";

	#
	$QUERY_ST = time;

	#
	$key = $_[0];

	#
	if($key=~/\sOR\s/) {
		$OR_MODE = 1;
	}

	#
	#print $fn;
	# CACHE OR NOT
	# *TODO*
	# Do not use cache because it does not support multiple indexes yet.
	if($OR_MODE) {
		$key =~ s/\sOR\s/ /g;
		my @keywords = split(/ /, $key);
		for($i=0; $i<($#keywords+1); $i++) {
			push(@results, QueryDB1($keywords[$i],$_[1],1));
		}
		@results = sort @results;
	} else {
		@results = QueryDB1($key,$_[1],0);
	}

	#
	#SaveCache($fn)


	# Remove duplicate results.
	my (@duplicates,%nd_results,$hash_key,$nice_results); ## nd=non-duplicated results
	@duplicates = @results;
	for($i=0; $i<($#duplicates+1); $i++) {
		$nd_results{$duplicates[$i]}++;
	}
	$i = 0;
	foreach $hash_key (keys %nd_results) {
		$nice_results[$i] = $hash_key;
		#print $nice_results[$i] . "<BR>\n";
		$i++;
	}

	# Finally got the results we wanted.
	@results = reverse sort @nice_results;

	#
	$QUERY_ET = time;
}

1;
