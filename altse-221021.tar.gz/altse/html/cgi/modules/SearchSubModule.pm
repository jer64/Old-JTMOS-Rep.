#=======================================================================
# SearchSubModule.pm - the front page.
# Call MainSearchIndexModule.
# (C) 2005-2016 by Jari Tuominen (jari.t.tuominen@gmail.com).
#=======================================================================
require "./modules/settings.pm";
require "./modules/ViewCache.pm";
require "./modules/GetPageImages.pm";
require "./modules/ViewTextResults.pm";
require "./modules/ViewImageResults.pm";
require "./modules/QueryDB.pm";
require "./modules/Logging.pm";
require "./modules/Frontpage.pm";
require "./modules/InterfaceOpenDP.pm";
require "./modules/CacheResults.pm";
require "./modules/FixScands.pm";
require "./modules/ProduceSuggestedSearchesHTML.pm";
require "./modules/AltseMenuSystem.pm";
require "./modules/ViewNewsFeed.pm";
require "./modules/NewsFeedsView.pm";
require "./modules/ViewImageSection.pm";
require "./modules/PreviewImage.pm";

##############################################################################
#
sub UrlToHost
{
        my ($host);

        #
        $host = $_[0];
        $host =~ s/^[a-z]*:\/\///;
        $host =~ s/^([a-z0-9\-\.]*)\/.*$/$1/;
        return $host;
}

#
sub SaneString {
	my ($str);

	#
	$str = $_[0];
	$str =~ s/[^0-9a-z���\*\%\&\[\]\(\)\{\}\-\+\*\.\,\'\"\#\=\:\;\/\\\ ]/ /gi;
	$str =~ s/\ \ /\ /g;
	return $str;
}

################################################################
#
sub ProcessSearchString
{
	my ($str,$i,$i2,@WW);

	# Split into search words.
	$str = $keyword;
	$str =~ s/[^a-z���0-9A-Z���\* ]/ /g;
	@WW = split(" ", $str);

	#
	for($i=0,$i2=0; $i<($#WW+1); $i++)
	{
		if( !(length($WW[$i])<=1) )
		{
			$W[$i2++] = $WW[$i];
		}
	}

	#
	for($i=0,$i2=0; $i<($#W+1); $i++)
	{
		$W[$i] =~ s/site:\S*//;
	}
}

################################################################
#
sub SearchMain
{
		#
		TextSearch_Main();
}

################################################################
#
sub IsAdmin
{
	#
	if( $ENV{'REMOTE_ADDR'} eq "192.168.0.2" ) { return 1; }
	if( $ENV{'REMOTE_HOST'} =~ /aur.*inet/ ) { return 1; }

	#
	return 0;
}

################################################################
#
sub BeamMeUp
{
	my ($str);

	#
	$str = $so{'b'};
	$str =~ s/[^0-9]//g;

	#
	if($str eq "") { return(); }

	#
	@lst = LoadList("dardump $str|");

	#
	print("
<HEAD></HEAD>
<BODY>
<META HTTP-EQUIV=Refresh CONTENT=\"0; URL=http://$lst[0]/$lst[1]\">
</BODY>
		");
}

####################################################################################
#
sub NewsOnly()
{


	#
	
	
}

####################################################################################
# ViewWWWIMAGESGallery [gallery index id]
sub ViewWWWIMAGESGallery
{
	my ($i,$i2,$str,$lng,$host,$fo,$la,@lst);

	#
	@lst = LoadList("find $DB/wwwimages_$_[0]/$_[1]/ -name '*.jpg' -type f 2>/dev/null|");

	#
	for($i=0; $i<($#lst+1) && $i<1; $i++) {
		#
		my $imgurl = $lst[$i];
		$imgurl =~ s/^$DB//;
		$imgurl =~ s/^\/wwwimages_[0-9]+\/$_[1](.*)$/\/$_[0]\/$_[1]\/$1/;
		print("
<A HREF=\"$imgurl\">
<IMG SRC=\"$imgurl\" border=1>
</A>
");
	}

	#
}

sub ViewStocks
{
	#
	print("
<CENTER>
<a href=\"http://www.monex.com/prods/gold.html\" title=\"Monex Gold Bullion Prices\">
<img src=\"http://www.monex.com/widgets/GBX_LINE_45DAY_CUSTOM_WIDGET.PNG\" border=\"0\"
	title=\"Monex Live Gold Price\" alt=\"Monex Live Gold Price\"></a>
<a href=\"http://www.monex.com/prods/silver.html\" title=\"Monex Silver\">
<img src=\"http://www.monex.com/widgets/SB_LINE_45DAY_CUSTOM_WIDGET.PNG\" border=\"0\"
	title=\"Monex Live Silver Price\" alt=\"Monex Live Silver Price\"></a>
<a href=\"http://www.monex.com/prods/palladium.html\" title=\"Monex Palladium\">
<img src=\"http://www.monex.com/widgets/PA_LINE_45DAY_CUSTOM_WIDGET.PNG\" border=\"0\"
	title=\"Monex Live Palladium Price\" alt=\"Monex Live Palladium Price\"></a>
<a href=\"http://www.monex.com/prods/platinum.html\" title=\"Monex Platinum\">
<img src=\"http://www.monex.com/widgets/PL_LINE_45DAY_CUSTOM_WIDGET.PNG\" border=\"0\"
	title=\"Monex Live Platinum Prices\" alt=\"Monex Live Platinum Prices\"></a>
<BR>
<a href=\"http://ycharts.com/indices/%5EIXIC/chart/#/?securities=include:true,type:index,id:^IXIC,,&calcs=&zoom=1&format=real\">
<img src=\"http://media.ycharts.com/charts/c3be3eb462875c976beb5cecd872b74a.png\" alt=\"^IXIC Chart\" />
</a>
<p style=\"font-size: 10px;\"><a href=\"http://ycharts.com/indices/%5EIXIC\">^IXIC</a> data by <a href=\"http://ycharts.com\">YCharts</a></p>
</CENTER>
	");
}

####################################################################################
#
sub MainSearchIndexModule
{
	my ($i,$i2,$str,$lng,$host,$fo,$la);

	#
	$la = $ENV{'HTTP_ACCEPT_LANGUAGE'};
	$fo=0;

	# Check whether if a localization is available for this host.
	if($la =~ /^fi$/ || $ENV{'REMOTE_ADDR'} =~ /192\.168\./) { $try = "fi"; }
	if($la =~ /^se$/) { $try = "se"; }
	if($la =~ /^de$/) { $try = "de"; }
	if($la =~ /^nl$/) { $try = "nl"; }

	# Probe for availability.
	$lng = "$LANG/$try.txt";
	if(-e $lng) { LoadVars($lng); $fo=1; }
	# Use default "international" setting if none else works.
	if(!$fo) {
		LoadVars("$LANG/intl.txt");
		#print "Loading international language file ...: $LANG/intl.txt";
	}

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();

	#
	if($so{'news'} eq "true") {
		NewsOnly();
	}

	#
	if($so{'site'} ne "")
	{
		$so{'q'} = "$so{'q'} site:$so{'site'}";
	}

	#
	if($so{'b'} ne "")
	{
		BeamMeUp();
		return();
	}

	#
	if(($so{'RC'}<10 || $so{'RC'} > 200) && $so{'rendering'} eq "")
	{
		$so{'RC'} = $DEFAULT_RESULTS_PER_PAGE;
	}

	#
	if($so{'st'} eq "")
	{
		$so{'st'} = 0;
	}

	#
	if($so{'mis'} eq "")
	{
		$so{'mis'} = $REQ_MIN_IMG_SIZE;
	}

	#
	if($altse_SERVICE_NOTIFICATION)
	{
		print("
		<div align=center>
		$altse_SERVICE_NOTIFICATION
		</div>
		");
	}

	#
	if( $so{'WWW_SERVICE_STATE'}!=1 && 1!=1 )
	{
		print("
<div align=center>
<br>
<img src=http://images.vunet.org/tr_altse.png>
<table width=400 cellpadding=8 cellspacing=0 bgcolor=#FF0000>
<tr>
<td>
<img src=http://images.vunet.org/atwork.png align=left>
Service temporarily offline for maintenance work.<br>
Palvelu tilap�isesti poissa k�yt�st� huoltot�iden vuoksi.<br>
<br>
$ENV{'REMOTE_ADDR'}<br>
$ENV{'REMOTE_HOST'}<br>
Visit our <A HREF=\"http://freshcode.com/projects/altse/\">FreeCode WebSite</A> for more information<BR>
</td>
</tr>
</table>
</div>

");
		return();
	}


	#
	if($so{'il'}==1)
	{
		# Image search.
		$IS_PL = "is.pl";

		#
		$SHOW = $MAX_IMGS_PER_PAGE;
	}
	else
	{
		#
		$SHOW = $so{'RC'};
	}

	# Make the search string abit more nicer ...
	$so{'q'} =~ s/^\s*//;
	$so{'q'} =~ s/\s*$//;
	$ORGQ = $so{'q'};
#	$so{'q'} =~ s/\[|\]|{|}/ /g;
#	$so{'q'} =~ s/\?/ /g;
	$so{'q'} =~ s/[^a-zA-Z������0-9\.\-\:\*]/ /g;
	if(!($so{'q'}=~/site:/))
	{
		$so{'q'} =~ s/\-/ /g;
	}

	if($so{'site'} eq "" && $so{'q'} =~ / site:/)
	{
	        $so{'site'} = $ORGQ;
	        $so{'site'} =~ s/^.*\ssite:([a-z0-9\-\.]*).*$/$1/;
	}

	#
	if($ORGQ =~ /site:\S*/)
	{
		$site = $ORGQ;
		$site =~ s/^.*\ssite:(\S*).*$/$1/;
	}
	$keyword = $ORGQ;
	$keyword =~ s/^(.*)\ssite:\S*.*$/$1/;

	#
	if($so{'q'} =~ /\sREFRESH$/)
	{
		$so{'q'} =~ s/\sREFRESH$//;
		$so{'REFRESH'} = 1;
	}

	#
	if($so{'q'} eq "" && $so{'searchstring'} ne "")
	{
		$so{'q'} = $so{'searchstring'};
	}
	if($so{'q'} eq "*")
	{
		$TIME_ORDER = 1;
	}
	#
	ProcessSearchString();
	if($so{'q'} ne "" && $#W < 0)
	{
#		print "ILLEGAL SEARCH";
#		die;
	}

	# Get options.
	#
	$set = $so{'q'};
	$set =~ s/\?/\ /;

	#
	if($so{'q'} eq "") { $xtra="onload=sf()"; }

	#
#	$WEATHER_HTML = ("
#<script language=\"JavaScript\" type=\"text/javascript\"> 
# document.write('<script language=\"JavaScript\" src=\"http://www.worldweatheronline.com/widget/v2/weather-widget.ashx?locid=742592&root_id=740780&wc=LOCAL_WEATHER&map=~/helsinki-weather-widget/western-finland/fi.aspx&width=220&custom_header=Helsinki Weather, Finland&num_of_day=6&title_bg_color=020202&title_text_color=FFFFFF&widget_bg_color=FFFFFF&widget_text_color=020202&type=js&cb=' + Math.random() + '\" type=\"text/javascript\"><\/scr' + 'ipt>');
# </script><noscript><a href=\"http://www.worldweatheronline.com\" alt=\"7 day Helsinki Weather, Finland weather\">7 day Helsinki Weather, Finland weather</a> provided by <a href=\"http://www.worldweatheronline.com\">World Weather Online</a></noscript>
#
#<script language=\"JavaScript\" type=\"text/javascript\"> 
# document.write('<script language=\"JavaScript\" src=\"http://www.worldweatheronline.com/widget/v2/weather-widget.ashx?locid=742592&root_id=740780&wc=LOCAL_WEATHER&map=~/jyvaskyla-weather-widget/western-finland/fi.aspx&width=220&custom_header=Jyvaskyla Weather, Finland&num_of_day=6&title_bg_color=020202&title_text_color=FFFFFF&widget_bg_color=FFFFFF&widget_text_color=020202&type=js&cb=' + Math.random() + '\" type=\"text/javascript\"><\/scr' + 'ipt>');
# </script><noscript><a href=\"http://www.worldweatheronline.com\" alt=\"7 day Jyvaskyla Weather, Finland weather\">7 day Jyvaskyla Weather, Finland weather</a> provided by <a href=\"http://www.worldweatheronline.com\">World Weather Online</a></noscript>
#");

	#
	my @inames = LoadList("indexnames.txt");
	my $SELECTOR_HTML = "";
	my $SEL_OPTION;
	for($i=0; $i<($#inames); $i+=2) {
		if($so{'indexnr'}==$inames[$i]) {
			$SEL_OPTION = " SELECTED";
		} else {
			$SEL_OPTION = "";
		}
		$SELECTOR_HTML .= ("<OPTION VALUE=\"$inames[$i]\"$SEL_OPTION>$inames[$i+1]</OPTION>\n");
	}

	#
	my $SEARCH_FORM_HTML = ("
<FORM action=\"/\">
<INPUT TYPE=TEXT NAME=\"q\" VALUE=\"$so{'q'}\">
<INPUT TYPE=SUBMIT NAME=\"SUBMIT\" VALUE=\"Find\">
<INPUT TYPE=HIDDEN NAME=\"cmd\" VALUE=\"go\">
<SELECT NAME=\"indexnr\">
$SELECTOR_HTML
</SELECT>
</FORM>
");

	### HARDCODED USER INTERFACE
        #
        if($so{'frontpage'} eq "news" && $so{'cmd'} eq "") {
		$VUNET_HTML = ("
<CENTER>
<A HREF=\"http://www.vunetnews.org\"><IMG SRC=\"/vunet.jpg\"></A><BR>
<IMG SRC=\"/uusilogo2.jpg\">
</CENTER>
");
	}
                print("
<TABLE width=100% height=1 cellpadding=0 cellspacing=0
	bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<TABLE width=300 height=1 cellpadding=0 cellspacing=0
	bgcolor=#000000 align=right>
<TR>
<TD>
$WEATHER_HTML
</TD>
</TR>
</TABLE>
<!--- Above: Squirrel --->


<table width=100% bgcolor=$TVAR cellpadding=0 cellspacing=0>
<tr>
<td>


			");

	#
	if($so{'submit'} ne "")
	{
		SubmitNewUrl();
		goto past;
	}
	if($so{'cmd'} eq "vcache")
	{
		ViewCache($so{'indexnr'});
		goto past;
	}
	# $image_action_url = "/?cmd=previewimage&imageurl=$origurl&fulltitle=$title&noajax=TRUE";
	if($so{'cmd'} eq "previewimage")
	{
		PreviewImage();
		goto past;
	}
	if($so{'cmd'} eq "vimages")
	{
		ViewImages($so{'indexnr'});
		goto past;
	}
	if(($so{'cmd'} eq "go" || $so{'cmd'} eq "searchnow") && $so{'q'} ne "")
	{
		# NOTE: DEFAULTING TO MAX. 5 CGI-INTERFACES RENDERING AT ONCE.
		# INCREASE THIS IF THE MACHINE CAN HANDLE MORE OR LESS.
	        if( ($i=IsRunning("index.pl")>5) || IsRunning("$DB/altse/bin/is")>4 )
	        {
	                #
	                print("
				<H1><BLINK>SEARCH ENGINE IS OVERLOADED. TRY AGAIN AFTER APPROXIMATELY 30 SECONDS.<br>
				Will try again automatically after a minute.</BLINK></H1><br>
				<meta http-equiv=\"refresh\" content=\"60\">
	                        ");
	                return();
	        }
	        #
	        $i = sprintf("%d", $i);

		#
		TextSearchForm(1);
		LogThisSearch();
		SearchNow($set);
		TextSearchForm(2);
	}
	else
	{
		#
        #
	if($so{'frontpage'} eq "news" && $so{'sec'} eq "") {

		######
		#
		print("
<TABLE width=800>
");
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF>

<H3>
<A HREF=\"?sec=entertainment&frontpage=news&frontpage=news&frontpage=news\" class=blue>Entertainment &raquo;</A>
</H3>
");

        $so{'sec'} = "entertainment";
	print ViewWWWIMAGESGallery(2,4);
	print ViewNewsFeed(2);
	print("</TD>
</TR>");

	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF>
<H3>
<A HREF=\"?sec=finnish&frontpage=news&frontpage=news\" class=blue>Finnish &raquo;</A>
</H3>
");

       $so{'sec'} = "finnish";
	print ViewWWWIMAGESGallery(0,0);
	print ViewNewsFeed(0);
	print("</TD>
</TR>");

	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF>

<A HREF=\"?sec=finance&frontpage=news&frontpage=news\" color=black>
<H3>Finance &raquo;</H3>
</A>
");
        $so{'sec'} = "finance";
	print ViewWWWIMAGESGallery(1,0);
	print ViewNewsFeed(1);
	print("
</TD>
</TR>");

	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

<A HREF=\"?sec=weather&frontpage=news&frontpage=news\" color=black>
<H3>Weather &raquo;</H3>
</A>
");
        $so{'sec'} = "weather";
	print ViewWWWIMAGESGallery(3,0);
	print ViewNewsFeed(3);
	print("
</TD>
</TR>");

	my $extra_html = ("
<A HREF=\"http://kultakaivos.info/ngc1999_hst.jpg\">
<IMG SRC=\"http://kultakaivos.info/ngc1999_hst.jpg\" align=right vspace=8 hspace=8 width=32 height=32 border=2
	ALT=\"NGC 1999: Reflection Nebula in Orion  Credit:  Hubble Heritage Team (STScI) and NASA\">
</A>
");
#	print "<TABLE ALIGN=RIGHT><TR><TD>$extra_html</TD></TR></TABLE>";
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF>

$extra_html
<A HREF=\"?sec=space&frontpage=news&frontpage=news\" color=black>
<H3>Space &raquo;</H3>
</A>
");
        $so{'sec'} = "space";
	print ViewWWWIMAGESGallery(4,0);
	print ViewNewsFeed(4);
	print("
</TD>
</TR>");

	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

<A HREF=\"?sec=news_from_russia&frontpage=news&frontpage=news\" color=black>
<H3>News from Russia &raquo;</H3>
</A>
");
        $so{'sec'} = "news_from_russia";
	print ViewWWWIMAGESGallery(5,0);
	print ViewNewsFeed(5);
	print("
</TD>
</TR>");

	#
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

<A HREF=\"?sec=dprk&frontpage=news&frontpage=news\" color=black>
<H3>DPRK &raquo;</H3>
</A>
");
        $so{'sec'} = "dprk";
	print ViewWWWIMAGESGallery(8,0);
	print ViewNewsFeed(8);
	print("
</TD>
</TR>");

	#
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

<A HREF=\"?sec=music&frontpage=news&frontpage=news\" color=black>
<H3>Music &raquo;</H3>
</A>
");
        $so{'sec'} = "music";
	print ViewWWWIMAGESGallery(9,201);
	print ViewNewsFeed(9);
	print("
</TD>
</TR>");

	#
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

<A HREF=\"?sec=china&frontpage=news&frontpage=news\" color=black>
<H3>News from China &raquo;</H3>
</A>
");
        $so{'sec'} = "china";
	print ViewWWWIMAGESGallery(10,0);
	print ViewNewsFeed(10);
	print("
</TD>
</TR>");

	#
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

<A HREF=\"?sec=uk&frontpage=news&frontpage=news\" color=black>
<H3>News from UK &raquo;</H3>
</A>
");
        $so{'sec'} = "uk";
	print ViewWWWIMAGESGallery(11,0);
	print ViewNewsFeed(11);
	print("
</TD>
</TR>");

	#
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

$extra_html

<A HREF=\"?sec=itjobs&frontpage=news&frontpage=news\" color=black>
<H3>IT jobs &raquo;</H3>
</A>
");
        $so{'sec'} = "itjobs";
	print ViewWWWIMAGESGallery(12,0);
	print ViewNewsFeed(12);
	print("
</TD>
</TR>");

	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

<A HREF=\"?sec=science&frontpage=news&frontpage=news\" color=black>
<H3>Science &raquo;</H3>
</A>
");
        $so{'sec'} = "science";
	print ViewWWWIMAGESGallery(6,0);
	print ViewNewsFeed(6);
	print("
</TD>
</TR>");

	my $extra_html = ("
<A HREF=\"http://img.izismile.com/img/img5/20121023/640/japanese_women_do_cosplay_best_rNp2k_640_01.jpg\">
<IMG SRC=\"http://img.izismile.com/img/img5/20121023/640/japanese_women_do_cosplay_best_rNp2k_640_01.jpg\" align=right vspace=8 hspace=8 width=32 height=32 border=2
	ALT=\"NGC 1999: Reflection Nebula in Orion  Credit:  Hubble Heritage Team (STScI) and NASA\">
</A>
");
	#
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF\">

$extra_html

<A HREF=\"?sec=adult&frontpage=news&frontpage=news\" color=black>
<H3>Adult &raquo;</H3>
</A>
");
        $so{'sec'} = "adult";
	print ViewWWWIMAGESGallery(7,7);
	print ViewNewsFeed(7);
	print("
</TD>
</TR>");

print("
</TABLE>");


		}
		if($so{'frontpage'} eq "news" && $so{'sec'} ne "") {
			
		######################################################
		#
		# Section specific.
		#
		my $next_page = $so{'start'} + 100;
		$OTSIKKO = $so{'sec'};
		$OTSIKKO =~ s/[^a-z0-9A-Z\-]/ /g;
		print("
<TABLE width=800>
");
	print("
<TR VALIGN=TOP>
<TD bgcolor=\#C0FFFF>

<A HREF=\"?sec=$so{'sec'}&frontpage=news\" class=blue>$so{'sec'} &raquo;</A>
<H3><font style=\"text-transform:capitalize;\">$OTSIKKO</font></H3>
</A>
");

	if($so{'sec'} eq "stocks") {
		ViewStocks();
		goto past;
	}

	print ViewWWWIMAGESGallery(100,0);
	print ViewNewsFeed(100);
	if($ViewNewsFeed_VIEW_COUNT >= 100) {
		print("
		<A HREF=\"?sec=$so{'sec'}&start=$next_page&frontpage=news\">
		> next page (100 more news)
		</A>
		");
	}
	print("</TD>
</TR>");

print("
</TABLE>");
		
		}

		SearchFrontPage();
	}
past:

	#
	print("
</td>
</tr>
</table>

		");
}

TRUE;
