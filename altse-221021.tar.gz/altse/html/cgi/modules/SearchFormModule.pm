# Options: ["Frontpage"]
sub SearchFormModule
{
	#
	@inames = LoadList("indexnames.txt");

	#
	@lst = LoadList("$LANG/items.lst");

	#
	$Search = "/?cmd=go&";

	#
	my $infostr = FixForJS( join("<BR>", LoadList("cfg/altse_info.txt")) );
	my $TellMoreJs = ("
<SCRIPT LANGUAGE=\"JavaScript\">
function TellMore()
{
	var infostr = \"<P><A HREF=\\\"JavaScript:TellLess()\\\" class=yellow>> Hide</A></P><FONT color=#FFFFFF>$infostr</FONT>\";

	document.getElementById('INFOBOX').innerHTML = infostr;
}
function TellLess()
{
	var infostr = \"<A HREF=\\\"JavaScript:TellMore()\\\" class=bright>$so{'W_ABOUT_ALTSE_FRONT_PAGE'}</A>\";

	document.getElementById('INFOBOX').innerHTML = infostr;
}
</SCRIPT>
");

	#
	print("
$TellMoreJs

		<DIV name=ajaxloader id=ajaxloader>$LOADERHTML</DIV>

			<DIV ALIGN=LEFT>
			<TABLE width=800 height=109 cellpadding=0 cellspacing=0
				background=\"images/new_altse_2.gif\">
			<tr valign=top>
			<td>
			</td>
			</tr>
			</table>
			</DIV>

			<TABLE width=100% cellpadding=1 cellspacing=0 align=center
				bgcolor=\"#000000\">
			<tr valign=top>
			<td>

			<table width=100% cellpadding=0 cellspacing=0 align=center
				bgcolor=\"#FFFFFF\">
			<tr>
			<td>

			<table width=100% cellpadding=16 cellspacing=0 bgcolor=#000000>
			<tr valign=top>
			<td width=30%>
			<font color=yellow>
			<b>$so{'W_FRONT_PAGE'}</b>
			</font>
			</td>

			<td width=70%>
				<DIV NAME=\"INFOBOX\" ID=\"INFOBOX\">
<A HREF=\"JavaScript:TellMore()\" class=bright>
$so{'W_ABOUT_ALTSE_FRONT_PAGE'}</A>
				</DIV>
			</td>
			</tr>
			</table>

		<!--	<BR>
			<div align=center>$gid $so{'W_WEB_PAGES_CRAWLED'}</div>
			<div align=center>$indgid $so{'W_WEB_PAGES_INDEXED'}</div> -->
		");

	#
	if($so{'q'} eq "")
	{
		$BIM = "";
	}
	else
	{
		$BIM = "$THIS_BIM";
	}

	#
	print("
		<table width=\"100%\" height=48 cellpadding=0 cellspacing=0
			background=$BIM>
		<tr valign=top>

		<td>
		");

	#
	if($so{'WWW_SERVICE_STATE'}!=1)
	{
#		$DIS = "disabled";
		$DISMSG = "<FONT COLOR=RED>Service disabled temporarily due to maintenance work.</FONT>";
	}

	#
	$CHOOSE_INDEX_HTML = BuildChooseIndexHtml();

	#
	my ($SUGGESTED_IMAGE_SEARCHES_HTML);

	#
	for($i=0; $i<$#inames; $i+=2) {
		my $fn = $DB . "/wwwimages_" . $inames[$i+0];
		if(-e $fn) {
		$SUGGESTED_IMAGE_SEARCHES_HTML .= ("
<A HREF=\"gallery/?cmd=go&q=&indexnr=$inames[$i+0]\" class=darkul>$inames[$i+1]</A>
");
		}
	}

	# News feeds
	$NEWS_FEEDS_HTML .= ("
<TABLE width=100% cellspacing=0 cellpadding=0 border=0>
<TR>
<TD>

<TABLE width=100% cellspacing=0 cellpadding=8 border=1>
<TR valign=top>






<!---- NEWS CELL LEFT SIDE (1) ---->
<TD>

$content

<!---------------
<STRONG><P>Altse finance - latest news update - updated hourly</P></STRONG>

<SCRIPT LANGUAGE=\"JavaScript\" src=\"$CGICMD./jsnewsfeeds/?c=30\"><
</SCRIPT>

<BR>
<A HREF=\"finance/\" class=\"darkul\">\> Show more finance news</A><BR>

<HR>

<STRONG><P>Altse Suomi - viimeisin uutisp�ivitys - p�ivitet��n joka tunti</P></STRONG>

<SCRIPT LANGUAGE=\"JavaScript\" src=\"$CGICMD./jsnewsfeeds/?c=30&sec=finnish\"><
</SCRIPT>

<BR>
<A HREF=\"finance/?sec=finnish\" class=\"darkul\">\> N�yt� lis�� otsikoita</A><BR>


---->
</TD>




<!---- NEWS CELL RIGHT SIDE (1) ---->
<TD>

$content2

<!-----

<B><P>CNBC news - updated hourly</P></B>
	");
	#$NEWS_FEEDS_HTML .= ProduceNewsFeedsHTML();
	$NEWS_FEEDS_HTML .= ProduceNewsFeedsJSBOXHTML();

	#
	$NEWS_FEEDS_HTML .= ("

--->

</TD>



</TR>
</TABLE>

</TD>
</TR>
</TABLE>

<BR>
	");

	#
	print ("

		<div align=center>
		<table width=800 height=48>
		<tr>
		<td>

		<TABLE width=100% cellspacing=0 cellpading=0>
		<TR valign=top>
		<TD width=50%>

		$so{'W_TEXT_SEARCH_TITLE'}<BR>
                <form method=\"get\" action=\"$CGICMD\" name=\"FORM1\" class=formx $DIS>
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"text\" name=\"q\" size=\"40\" value=\"$ORGQ\" $DIS>
			$CHOOSE_INDEX_HTML

                        <input type=\"submit\" value=\"$so{'W_SEARCH'}\" class=buttonx $AJAXONBUTTON $DIS>
                </form>

		$SUGGESTED_TEXT_SEARCHES_HTML

		<BR>

		</TD>
		<TD width=50%>
		$so{'W_IMAGE_SEARCH_TITLE'}<BR>
		<form action=\"gallery/?\">
                        <input type=\"hidden\" name=\"cmd\" value=\"go\">
                        <input type=\"text\" name=\"q\" size=\"40\" value=\"$ORGQ\" $DIS>

			$CHOOSE_INDEX_HTML

                        <input type=\"submit\" value=\"$so{'W_BROWSE_IMAGES'}\" class=buttonx $AJAXBUTTON $DIS>
		</form>

		$SUGGESTED_IMAGE_SEARCHES_HTML

		</TD>
		</TR>
		</TABLE>


		</td>
		</tr>
		</table>

		$NEWS_FEEDS_HTML


<TABLE width=100% cellspacing=0 cellpadding=0>
<TR valign=top>
<TD width=50%>

<A HREF=\"d/?q=World\">
<IMG SRC=\"images/demo.jpg\">
</A>
</TD>

<TD WIDTH=50%>
		$KK_MAINOS2
</TD>
</TR>
</TABLE>
		<HR>
<TABLE width=220 cellpadding=0 cellspacing=0>
<TR>
<TD>
		$KK_MAINOS
</TD>
<TD>
		$KK_MAINOS_PERSONAL
</TD>
</TR>
</TABLE>
<p><a href=\"http://co.nr/\">Domain provided by CO.NR.</a></p>
		$DISMSG

		</td>
		</tr>
		</table>
		</div>


		");

	#
	if($so{'q'} eq "")
	{
		print("
	                <script language=\"javascript\">
	                function altse_SearchFocusOnQueryString()
	                {
				document.FORM1.q.focus();
	                }
	                </script>
			");
	}

	#
	print("

		</td>
		</tr>
		</table>
		");

	#
	if( $WEB_DIRECTORY )
	{
		if( $ENV{'REMOTE_HOST'} =~ /.fi$/i || $ENV{'REMOTE_ADDR'} =~ /192\.168\./ )
		{
			FinDirectorySections();
		}
		else
		{
			EngDirectorySections();
		}
	}

	#
	AdminTools();

	##############################################################
	#
	print("
		</td>
		</tr>
		</table>
		");

	#
	print("
		</td>
		</tr>
		</table>
		");
}

#
TRUE;
