# Uses $so{'sec'} as a parameter.
sub ViewNewsFeed
{
	my ($content);

	#
	$MAX_VIEW_COUNT = $_[0];

	#
	if($so{'sec'} eq "finnish") {
		$which_index = 0;
	}
	if($so{'sec'} eq "finance") {
		$which_index = 1;
	}
	if($so{'sec'} eq "entertainment") {
		$which_index = 2;
	}
	if($so{'sec'} eq "weather") {
		$which_index = 3;
	}
	if($so{'sec'} eq "space") {
		$which_index = 4;
	}
	if($so{'sec'} eq "news_from_russia") {
		$which_index = 5;
	}
	if($so{'sec'} eq "science") {
		$which_index = 6;
	}
	if($so{'sec'} eq "adult") {
		$which_index = 7;
	}

	#
	my $fn = "cache/rss/$so{'sec'}.txt";
	if( !(-e $fn) ) {
		print "<P>$fn not found</P>\n";
	} else {
		#print "<P>$fn found</P>\n";
	}
	@lst = LoadList($fn);
	my $startti = $so{'start'};
	if($startti < 0) { $startti = 0; }
	for($i=$startti; $i<($#lst+1) && $i<$MAX_VIEW_COUNT; $i++) {
		@sp = split(/ \| /, $lst[$i]);
		#print $lst[$i] . "<BR>\n";
		my $age = $sp[0];
		my $title = $sp[1];
		my $description = $sp[2];
		my $niceurl = $sp[3];
		my $url = $sp[3];
		$url =~ s/ \|$//;
		$niceurl =~ s/^http:\/\/([^\/]+).*$/$1/;

		my $nice_age;
		if($age >= 86400) {
			my $days = int($age/86400);
			if($days==1) {
				$nice_age = $days . " day ago";
			} else {
				$nice_age = $days . " days ago";
			}
		} else {
			my $hour = int($age/3600);
			if($hour<=1) {
				$nice_age = "an hour ago";
			} else {
				$nice_age = $hour . " hours ago";
			}
		}
		$age_html = "<font size=1 color=\"#808080\">  - " . $nice_age . "</font>";

		if($title =~ /^\s*$/) { goto skip; }

		if( !($title=~/&h.*\&/) ) {
			#$title =~		s/[^a-z0-9\.\,\-\[\]\(\)\!\?]\'\�\`/ /gi;
		}
		if( !($description=~/&h.*\&/) ) {
			#$description =~		s/[^a-z0-9\.\,\-\[\]\(\)\!\?]\'\�\`/ /gi;
		}
		if($alreadytitle{$title} ne "") {
			goto skip;
		} else {
			$alreadytitle{$title}++;
		}

## Have to know page ID in order to display images ($thumb_html).
#                       @lst = LoadList("dardump $page $_[0]|");
#			#
#			for($i=0; $i<($#lst+1); $i++)
#			{
#				#
#				if($lst[$i+0] ne "image") {
#					goto skip;
#				}
#
#				#
#				ViewImageURL($lst[$i+0]);
#skip:
#                       }

		$source_name_html = ("
<font size=1 color=\"#808080\"> - $niceurl</font>");

		$content .= ("
<TABLE width=100% cellpadding=8 cellspacing=0 bgcolor=\"#FFFFFF\">
<TR valign=top>
<TD>
<A HREF=\"$url\" class=darkul><B>
$title</B></A> $source_name_html $age_html
</TD>
</TR>
</TABLE>
			");
		if( length($description)>5 && $so{'js'} eq ""  ) {
		$content .= ("
<TABLE width=100% cellpadding=8 cellspacing=0 bgcolor=\"#FFFFFF\"> <!--- used to be grey --->
<TR valign=top>
<TD>
$thumb_html $description<BR>
</TD>
</TR>
</TABLE>

			");
		}

		#
skip:
	}

	#
	$ViewNewsFeed_VIEW_COUNT = $i;

	#
	if($so{'js'} eq "") {}
	#
	return $content;
}

TRUE;
