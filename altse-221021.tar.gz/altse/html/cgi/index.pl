#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2016 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;

#
require "./modules/AltseOpenConfig.pm";
require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
require "./modules/SearchSubModule.pm";
require "./modules/DirectorySubModule.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
my @menu_items = (
	"0", # 0
	"1", # 1
	"2", # 2
	"3", # 3
	"4", # 4
	"5", # 5
	"6", # 6
	"7", # 7
	"8", # 8
	"9", # 9
);

my @menu_labels = (
	"", # 0
	"", # 1
	"", # 2
	"", # 3
	"", # 4
	"", # 5
	"", # 6
	"", # 7
	"", # 8
	"", # 9
);

my @menu_urls = (
	"", # 0
	"", # 1
	"", # 2
	"", # 3
	"", # 4
	"", # 5
	"", # 6
	"", # 7
	"", # 8
	"", # 9
);

#################################################################
#
print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"http://images.vunet.org/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"/altse.css\" title=\"Cool\">
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
<meta name=\"google-site-verification\" content=\"IL1bs0eDAEFwROhwR_foI2w6lCw7Y5YJ9reoyWmAvCM\" />
  <meta name=\"revisit-after\" content=\"1 days\">
  ");
  if($so{'q'} eq "")
  {
	  print("
  <meta name=\"description\" content=\"TYKKAA.INFO PUTIN-hakukone: Tykkaa Putinista ja kaverista!\">
  ");
  }
  else
  {
	  print("
  <meta name=\"description\" content=\"TYKKAA.INFO PUTIN-hakukone: $so{'q'}\">
  ");
  }
  print("
  <meta name=\"keywords\" content=\"$so{'q'}\">
  <meta name=\"author\" content=\"Jari Tuominen\">
  <meta name=\"google-site-verification\" content=\"jyAYuR14wFvkF0LjVP6W63jh6y-lIX3Qa2FNoahjEkE\" />
<title>
");
if($so{'q'} eq "")
{
        print "$PAGE_TITLE";
}
else
{
        print "$so{'q'} - $PAGE_TITLE - ".int($so{'start'})."";
}
print("
</title>
</head>

<BODY $xtra bgcolor=$TVAR
        topmargin=0 leftmargin=0
        marginheight=0 marginwidth=0>

");

past:

if($so{'frontpage'} eq "" && $so{'cmd'} eq "") {
#
print("
<BR>
<TABLE width=\"350\" align='center'>
<TR>
<TD>

<H1><DIV align='center'>Putin-hakukone TYKKAA.INFO</DIV></H1>
Tykkaa Putinia, ja muita maailman johtajia:

<DIV align='center'>
<FORM ACTION=\"/?\">
<INPUT TYPE=\"TEXT\" VALUE=\"$so{'q'}\" NAME=\"q\" SIZE=10 id=\"q\">
<INPUT TYPE=\"HIDDEN\" VALUE=\"$so{'indexnr'}\" NAME=\"indexnr\">
<INPUT TYPE=\"HIDDEN\" VALUE=\"go\" NAME=\"cmd\">
<INPUT TYPE=\"SUBMIT\" VALUE=\"Go!\" class=\"buttonx\">
</DIV>

</TD>
</TR>
</TABLE>
");
	################
	#
	my (@lst) = LoadList("/home/vai/altse/html/cgi/cfg/recommended_searches.txt");
	#print $#lst;
	my ($i,@sp,$str);
	#
	print("
<BR>
<TABLE width=\"550\" align=\"center\">
<TR>
<TD>
	");
	#
	print("
	<CENTER><H1>Kokeile ja tykkaa naita hakuja!</H2></CENTER>
	");
	#
	print("
	<TABLE>
	<TR>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		if(($i%4)==3)
		{
			print("</TR><TR>");
		}
		
		print("
		<TD>
		<H2>
		<A HREF=\"/?cmd=go&indexnr=0&q=$lst[$i]\">
		$lst[$i]
		</A>
		</H2>
		</TD>
		");
	}
	print("
</TR>
</TABLE>

<BR>
<BR>
	");

	################
	#
	#
	if(-e "$DB/likes.txt")
	{
		@lst = reverse LoadList("$DB/likes.txt");
	}
	
	#
	print("
	<CENTER><H1>Tykattyja hakuja</H2></CENTER>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		@sp = split(/\|/, $lst[$i]);
		#
		my $str="$sp[0]/$sp[1]";
		if($dup{$str})
		{
			goto skip11;
		}
		$dup{$str}++;
		#
		my @dar = LoadList("$DB/altse/bin/dardump \"$sp[0]\" \"$sp[1]\" 2>/dev/null|");
		LoadVars("$DB/altse/bin/dardump \"$sp[0]\" \"$sp[1]\" 2>/dev/null|");
		#
		print("
		<H1>
		<IMG SRC='https://www.pngitem.com/pimgs/m/35-356815_red-thumbs-up-clipart-thumbs-up-icon-red.png'
	valign='left'
	title='Tykkaa tasta uutisesta!' alt='Tykkaa tasta uutisesta'
	width='20' height='13'>

		<A HREF=\"$so{'host'}$so{'path'}\">
		$so{'title'}
		</A>
		</H1>
		");
skip11:
	}
	#
	print("
</TD>
</TR>
</TABLE>
	");

	#
	print("

</FORM>
<SCRIPT LANGUAGE=\"JAVASCRIPT\">
document.getElementById('q').requestFocus();
</SCRIPT>
");

print("
</TD>
</TR>
</TABLE>
");

}

#
if($so{'cmd'} eq "like")
{
	#
	my ($f);
	#
	open($f, ">>$DB/likes.txt");
	print $f "$so{'pageid'}|$so{'indexnr'}|$so{'url'}\n";
	close($f);
	#
	print("
<meta http-equiv=\"refresh\" content=\"0; url=/\">
 ");
 	goto endi;
 	#
}

#
#my $ON_TOP_MENU_HTML = ("
#<TABLE width=100% cellspacing=0 cellpadding=0 bgcolor=#000000
#	height=32>
#<TR valign=top>
#");
#my $width_for_td = 100/($#menu_items+1);
##for($i=0; $i<$#menu_items; $i++) {
##	print("
##<TD width=$width_for_td\% bgcolor=#000000>
#<A HREF=\"$menu_urls[$i]\">$menu_labels[$i]</A>
#</TD>
#		");
#}
#print("
#</TR>
#</TABLE>
#");
#

#
print("
$ON_TOP_MENU_HTML
");


#################################################################
#
if($so{'frontpage'} eq "") {
#	$so{'frontpage'} = "news";
}


#
print("


</TD>

</TR>
</TABLE>

</body>
");

#
if($so{'noajax'} eq "" && $so{'q'} ne "")
{
my $redirect_to = "/?cmd=go&q=$so{'q'}&st=$so{'st'}&indexnr=0&start=$so{'start'}&noajax=TRUE";
my $job = $so{'q'};
print("
<BR><BR>
<DIV ALIGN=\"CENTER\" id=\"ajax2\">
<FONT FACE=\"IMPACT\" size=6 color=\"#C00000\">Tykkaa.info - $job - Putin-hakukone</FONT><BR>
<A HREF=\"$redirect_to\">
<IMG SRC=\"/images/ajaxloader2.gif\" alt=\"Loading ...\">
</A>
<BR>
<A HREF=\"$redirect_to\">
<!---
$redirect_to
--->
</A>
<BR>
</DIV>
<meta http-equiv=\"refresh\" content=\"0; url=$redirect_to\">
");
	goto endi;
}

#
if($so{'q'} =~ /\//) {
	$so{'sec'} = $so{'q'};
}
if($so{'frontpage'} eq "news" || $so{'cmd'} eq "go" || $so{'cmd'} eq "vcache" 
|| $so{'cmd'} eq "preview" || $so{'cmd'} eq "previewimage"  ) {
	# Show main menu.
	MainSearchIndexModule();
} else {
	if($so{'sec'} eq "directory" || $so{'sec'} =~ /\//) {
		DirectorySubModule();
	} else {
		# Show specific section.
		if($so{'sec'} eq "directory" || $so{'sec'} =~ /\//) {
			DirectorySubModule();
		} else {
			#NewsFeedsView();
		}
	}
}

print("
<CENTER>
<TABLE width='550'>
<TR>
<TD>
<HR>
<CENTER>
<H3>
$COPYRIGHT
</H3>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>
");

endi:
