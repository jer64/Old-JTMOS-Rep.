#!/usr/bin/perl
#############################################################################
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# JavaScript-based search query output.
# Ex. /jsfeed/?q=finance&indexnr=6
# (C) 2003-2013 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "modules/settings.pm";
require "modules/ajaxloader.pm";
require "modules/FixScands.pm";
require "modules/ViewTextResults.pm";
require "modules/CacheResults.pm";
require "modules/QueryDB.pm";
require "modules/JsPrint.pm";
require "modules/ProduceNewsFeedsHTML.pm";
require "modules/ProduceNewsFeedHTML.pm";
require "modules/SearchSubModule.pm";

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =           15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
if($ENV{'ALTSE_INDEXNR'} ne "") {
	$so{'indexnr'} = $ENV{'ALTSE_INDEXNR'};
}
ArgLineParse();

local $| = 1;

main();

#
sub main
{
	my ($i,$i2,$str,$lng,$host,$fo,$la,$gcon);

	#
	$gcon = "";

	# TODO - SEPERATE TO A LANGUAGE MODULE
	$la = $ENV{'HTTP_ACCEPT_LANGUAGE'};
	$fo=0;

	# Check whether if a localization is available for this host.
	if($la =~ /^fi$/ || $ENV{'REMOTE_ADDR'} =~ /192\.168\./) { $try = "fi"; }
	if($la =~ /^se$/) { $try = "se"; }
	if($la =~ /^de$/) { $try = "de"; }
	if($la =~ /^nl$/) { $try = "nl"; }

	# Probe for availability.
	$lng = "$LANG/$try.txt";
	if(-e $lng) { LoadVars($lng); $fo=1; }
	# Use default "international" setting if none else works.
	if(!$fo) { LoadVars("$LANG/intl.txt"); }

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();
	if($so{'q'} eq "") {
		$so{'q'} = $ARGV[0];
	}

	#
	if($so{'q'} =~ /^\//) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /^\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\.\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\|/) {
		$so{'q'} = "";
	} 

	if($so{'q'} ne "") {
		$PAGE_TITLE = "ALTSE - " . $so{'q'};
	}


	#
	$gcon = ProduceNewsFeedHTML($so{'q'});
        # Display results.
	print JsPrint($gcon);

        #
        #@sp = split(/(.{20}[^\\]{4})/, $str);
	#@sp = ();
	#push(@sp, $str);
        #for($i=0; $i<($#sp+1); $i++)
        #{
	#	$sp[$i] = FixScands($sp[$i]);
        #        if($sp[$i] ne "")
        #        {
        #                print(" document.write(\"$sp[$i]\");\n ");
        #        }
        #}
}

