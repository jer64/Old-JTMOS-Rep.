IMG -- The Disk Image Creation Utility

	Hello Fellow Comrades!

	This is one of my small utilities I created for my self,
	but I can sense that someone might need this kind of utilities as well.

	Note: this program currently supports only 1.44M disks, 
	80 tracks per side, 2 sides(160 tracks)
                  = 2880 sectors (512 bytes per each) = 1440K(1.44M 3.5").

	Just execute './install.sh' to compile & install it(requires you to do 'su') !
	or you can always manually install it anyway by copying the binary executable file(img)
	to your binary executable files folder !


Programmed by Jari Tapio Tuominen(jer64@kolumbus.fi)
