#!/bin/sh
gcc -W -o img img.c
