#!/bin/sh
clear
less readme.txt
