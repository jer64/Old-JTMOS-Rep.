#!/bin/sh
./u.sh
./copytodisk.sh
