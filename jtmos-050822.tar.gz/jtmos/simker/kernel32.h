#ifndef __INCLUDED_KERNEL32_H__
#define __INCLUDED_KERNEL32_H__

#include "simker.h"

//
#define DEBUGLINE //
#define FFCHECK //
#define dprintk //

#endif
