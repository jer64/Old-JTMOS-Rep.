#!/bin/bash
date +'%d/%m/%y'
