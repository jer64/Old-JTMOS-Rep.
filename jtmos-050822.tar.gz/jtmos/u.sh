clear

cd boot32
./upd.sh
cd ..

cd kernel32
./upd.sh
cd ..

./buildimage.sh
