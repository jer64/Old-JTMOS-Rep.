// filedir.c - Directory related functions
#include <stdio.h>

// TODO for mult. args.
int mkdir(const char *path, ...)
{
	//
	scall(SYS_mkdir, path,0,0, 0,0,0);
}

// TODO
int rmdir(const char *path, ...)
{
	//
	printf("%s: FUNCTION NOT YET SUPPORTED IN JTMOS LIBC\n",
		__FUNCTION__);
	return 0;
}

