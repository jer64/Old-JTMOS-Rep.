#ifndef __INCLUDED_HEXDUMP_H__
#define __INCLUDED_HEXDUMP_H__

//
extern void hexdump(BYTE *,long);

#endif