#ifndef __INCLUDED_JTMLIBC_STRNCAT_H__
#define __INCLUDED_JTMLIBC_STRNCAT_H__

char *strncat(char *s1, const char *s2, int n);

#endif

