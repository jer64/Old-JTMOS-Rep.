#ifndef __INCLUDED_ISASCII_H__
#define __INCLUDED_ISASCII_H__

//
int isascii(int c);

#endif
