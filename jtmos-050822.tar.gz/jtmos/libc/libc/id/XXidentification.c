//
#include <stdio.h>
#include "XXidentification.h"

// JTMOS binary executable identification object file
char *XXidentificationString="[VALID JTMOS EXECUTABLE BINARY FILE FCE2E37BE38BA000]";
