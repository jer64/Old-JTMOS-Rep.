#ifndef __INCLUDED_MKANBMP_H__
#define __INCLUDED_MKANBMP_H__

//
int jtm_loadbmp(const char *fname,const char *frame);

#endif


