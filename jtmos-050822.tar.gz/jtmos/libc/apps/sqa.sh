#!/bin/bash
gcc -o sqa sqa.c sqaMain.c
