#!/bin/bash
nzip clear.bin
nzip lar.bin
nzip memconfig.bin
nzip nzip.bin
nzip rf.bin
nzip runner.bin
nzip top.bin
nzip cp.bin
nzip ls.bin
nzip mkdir.bin
nzip ps.bin
nzip rm.bin
nzip sqsh.bin


