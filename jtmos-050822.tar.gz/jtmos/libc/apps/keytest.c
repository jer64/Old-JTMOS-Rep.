//
#include <stdio.h>

//
int main(int argc,char **argv)
{
	//
	puts("Please press any key to continue ...\n");
	getch();
	puts("Thank you.\n");

	//
	return 0;
}
