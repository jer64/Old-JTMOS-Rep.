#ifndef __INCLUDED_GUIAPP_H__
#define __INCLUDED_GUIAPP_H__

#include "graos.h"
void guiApplicationCall(VMODE *v);

#endif
