// windowOrder.c
#include <stdio.h>
#include "graos.h"
#include "windowOrder.h"

// Put window on top (visibility)
int putWindowOnTop(VMODE *v, WINDOW *w)
{
	// Increase top Z-coordinate
	wdb.top_z++;

	// Define window on top
	w->z = wdb.top_z;
}

//



