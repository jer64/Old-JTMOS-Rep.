nasm -f bin boot.asm
mv boot boot.bin
ls -la boot.bin
