#!/bin/bash
qemu -curses -m 256 -fda jtm32.img
