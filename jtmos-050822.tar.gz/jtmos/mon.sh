#!/bin/bash
su -c 'tcpdump -X -i sl0'
