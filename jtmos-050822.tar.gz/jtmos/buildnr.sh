#!/bin/bash
cat kernel32/init/buildnr.h |less
