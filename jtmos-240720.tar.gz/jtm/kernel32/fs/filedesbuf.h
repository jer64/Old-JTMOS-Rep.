#ifndef __INCLUDED_FILEDESBUF_H__
#define __INCLUDED_FILEDESBUF_H__

int FlushFDBuffers(int fd);

#endif
