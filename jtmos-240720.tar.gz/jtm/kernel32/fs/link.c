#include <stdio.h>

// Unsupported
int link(const char *oldpath, const char *newpath)
{
	return 0;
}

// Unsupported
// already defined in file.c
/*int unlink(const char *pathname)
{
	return 0;
}*/

