#ifndef __INCLUDED_MKDIR_H__
#define __INCLUDED_MKDIR_H__

//
#include "scs.h"
#include "_opensocket.h"

//
int msdos_mkdir(SYSCALLPAR);

#endif

