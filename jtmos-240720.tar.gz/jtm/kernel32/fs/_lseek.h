//
#ifndef __INCLUDED_LSEEK_H__
#define __INCLUDED_LSEEK_H__

//
int msdos_lseek(SYSCALLPAR);

#endif



