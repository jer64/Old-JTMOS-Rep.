//
#ifndef __INCLUDED_BIOSFUNC_H__
#define __INCLUDED_BIOSFUNC_H__

//
int GetBiosBootDrive(void);
void SetBiosBootDrive(int drv);

#endif



