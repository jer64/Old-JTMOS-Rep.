/*** CPU modes ***/
#ifndef __INCLUDED_CPU_H__
#define __INCLUDED_CPU_H__
#define disable() asm("cli")
#define enable() asm("sti")
#define nop() asm("nop")

#endif