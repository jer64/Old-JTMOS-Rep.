//
#ifndef __INCLUDED_USERADMIN_H__
#define __INCLUDED_USERADMIN_H__

//
// NOTE ! NOTE !
//
// DEFAULT_USER_NAME
// and
// DEFAULT_SYSTEM_NAME
// are defined in kernel32.h
//

//
void GetMachineName(char *s);
void GetCurrentUser(char *s);

#endif
