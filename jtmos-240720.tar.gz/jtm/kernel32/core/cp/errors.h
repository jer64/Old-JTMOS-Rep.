#ifndef __INCLUDED_ERRORS_H__
#define __INCLUDED_ERRORS_H__

void stack_violation(void);

#endif


