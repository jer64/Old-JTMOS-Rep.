#ifndef __INCLUDED_DELAY_H__
#define __INCLUDED_DELAY_H__

#include "basdef.h"

extern void delay(DWORD duration);
extern void xsleep(DWORD duration);

#endif
