//
#ifndef __INCLUDED_DEVSYSPREF_H__
#define __INCLUDED_DEVSYSPREF_H__

//
#define N_MAX_DEVICES           200

//
#endif
