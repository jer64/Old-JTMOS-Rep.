//
#include "kernel32.h"
#include "driver_sys.h"
#include "driver_api.h"
#include "driver_BlockCache.h"

//
BCACHE bc;

//
int cacheRB(int dnr, int bnr, BYTE *buf)
{
	//
	
}





