#ifndef __INCLUDED_HDCACHEFLUSH_H__
#define __INCLUDED_HDCACHEFLUSH_H__

//
void hdFlushWriteBack(void);

#endif



