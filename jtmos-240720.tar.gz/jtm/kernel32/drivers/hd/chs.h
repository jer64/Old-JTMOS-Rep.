//
#ifndef __INCLUDED_CHS_H__
#define __INCLUDED_CHS_H__

//
#include "hd.h"

//
extern int isValidCHS(HD *h, int cylinder,int head,int sector);
void LinearToCHS(HD *hd, int blocknr,
        int *c,int *h,int *s);

#endif



