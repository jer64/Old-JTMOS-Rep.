/*** System Miscellaneous Routines ***/  
#ifndef _SYSMISC_H_
#define _SYSMISC_H_
  halt ();

#endif	/*  */
