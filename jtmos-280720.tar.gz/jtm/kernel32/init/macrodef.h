/*** Macro like functions ***/
#ifndef __INCLUDED_MACRODEF_H__
#define __INCLUDED_MACRODEF_H__
//
#define cli() asm("cli")
#define sti() asm("sti")
#define nop() asm("nop")
#endif
