//
#ifndef __INCLUDED_INITSYSTEM_H__
#define __INCLUDED_INITSYSTEM_H__

//
int InitSystem(void);
//
BYTE *vesa_frame_buf;
void Bingoo(void);

#endif
