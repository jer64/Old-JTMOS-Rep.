#ifndef __INCLUDED_CALLAPP_H__
#define __INCLUDED_CALLAPP_H__

void
    callapp(void *appcode);

void
    callapp1(void *appcode, char waitUntilExits);

//
void ps(void);

#endif

