/*** System Global Variables Header File ***/
#include "sysglvar.h"
GLVAR glvar;
