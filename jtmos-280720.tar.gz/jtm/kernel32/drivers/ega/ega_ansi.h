#ifndef __INCLUDED_EGA_ANSI_H__
#define __INCLUDED_EGA_ANSI_H__

#include "kernel32.h"
#include "screen.h"
void HandleAnsiCode(SCREEN *s);

#endif
