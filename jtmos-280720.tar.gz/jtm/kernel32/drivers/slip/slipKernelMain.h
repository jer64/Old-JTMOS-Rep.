#ifndef __INCLUDED_SLIPKERNELMAIN_H__
#define __INCLUDED_SLIPKERNELMAIN_H__

//
int SlipProcess(void);

#endif 
