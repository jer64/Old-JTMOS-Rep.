#ifndef __INCLUDED_CORRUPTION_H__
#define __INCLUDED_CORRUPTION_H__

void SetCorruptionCheck(BYTE *buf);
int GetCorruptionCheck(BYTE *buf);

#endif

