// just a quickly made header file :)
#include "malloc.h"
#include "scanmem.h"
