#ifndef __INCLUDED_CENTRALPROCESSINIT_H__
#define __INCLUDED_CENTRALPROCESSINIT_H__


//
void centralprocessInit(void);


#endif



