#ifndef __INCLUDED_REBOOT_H__
#define __INCLUDED_REBOOT_H__

//
void system_reset1(void);
void system_reset(void);
void SystemReboot(void);

#endif

