#ifndef __INCLUDED_DEBUGAPP_H__
#define __INCLUDED_DEBUGAPP_H__

//
int debug_app(int argc, char **argv);

#endif
