//
#include <stdio.h>

//
int getopt(int argc, char * const argv[],
                  const char *optstring)
{
    
}

