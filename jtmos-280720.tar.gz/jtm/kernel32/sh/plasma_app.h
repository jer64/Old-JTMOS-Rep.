#ifndef __INCLUDED_PLASMA_APP_H__
#define __INCLUDED_PLASMA_APP_H__

//
int plasma_app(int argc, char **argv);

#endif
