#!/usr/bin/perl
#############################################################################
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# JavaScript-based search query output.
# Ex. /jq/?q=fish&indexnr=6
# (C) 2003-2012 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "modules/settings.pm";
require "modules/ajaxloader.pm";
require "modules/ads.pm";
require "modules/kk_mainos.pm";
require "modules/FixScands.pm";
require "modules/ViewTextResults.pm";
require "modules/CacheResults.pm";
require "modules/QueryDB.pm";
require "modules/JsPrint.pm";

#
if($ENV{'ALTSE_Q'} eq "") {
	print "Content-type: text/javascript\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;
#
$AMOUNT_OF_ARTICLES_TO_SHOW =           15;
$DONT_AFFECT_DB = 1;
$gotn = 0;
if($ENV{'ALTSE_Q'} ne "") {
	$so{'q'} = $ENV{'ALTSE_Q'};
}
if($ENV{'ALTSE_INDEXNR'} ne "") {
	$so{'indexnr'} = $ENV{'ALTSE_INDEXNR'};
}
ArgLineParse();

local $| = 1;

main();

#
sub TextResultsCount
{
	my ($str);

	#
	$str .= "<LI>";
	$str .= $#results+1 . " results";
	$str .= "</LI>";
	return $str;
}

#
sub DisplaySearch
{
	my ($i,$i2,$str,$lng,$host,$fo,$la,$con);

	#
	$keyword = $so{'q'};
	$SHOW = 20;
	QueryDB("", "-q -mp 21 -f");
	if($so{'start'} >= ($#results) && $so{'start'} ne "") {
		return ("ERROR
<meta http-equiv=\"refresh\" content=\"0;url=/\">");
	}
	$EMBEDDED_SEARCH = 1;
	$con .= TextResultsCount();
	$con .= ViewTextResults();
	$con .= TextResultsCount();

	#
	return $con;
}

#
sub main
{
	my ($i,$i2,$str,$lng,$host,$fo,$la,$gcon);

	#
	$gcon = "";

	# TODO - SEPERATE TO A LANGUAGE MODULE
	$la = $ENV{'HTTP_ACCEPT_LANGUAGE'};
	$fo=0;

	# Check whether if a localization is available for this host.
	if($la =~ /^fi$/ || $ENV{'REMOTE_ADDR'} =~ /192\.168\./) { $try = "fi"; }
	if($la =~ /^se$/) { $try = "se"; }
	if($la =~ /^de$/) { $try = "de"; }
	if($la =~ /^nl$/) { $try = "nl"; }

	# Probe for availability.
	$lng = "$LANG/$try.txt";
	if(-e $lng) { LoadVars($lng); $fo=1; }
	# Use default "international" setting if none else works.
	if(!$fo) { LoadVars("$LANG/intl.txt"); }

        # Search arguments line for options.
	$DONT_AFFECT_DB = 1;
        ArgLineParse();
	if($so{'q'} eq "") {
		$so{'q'} = $ARGV[0];
	}

	#
	if($so{'q'} =~ /^\//) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /^\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\.\./) {
		$so{'q'} = "";
	} 
	if($so{'q'} =~ /\|/) {
		$so{'q'} = "";
	} 

	if($so{'q'} ne "") {
		$PAGE_TITLE = "ALTSE - " . $so{'q'};
	}


        # Display results.
	$ajax_open_html = ("
<DIV ALIGN=CENTER id=\"ajaxldr\">
<IMG SRC=\"images/ajaxloader.gif\"> searching
</DIV>
	");
	print JsPrint($ajax_open_html);

	#
	$gcon .= DisplaySearch();

	$ajax_open_html = ("
<SCRIPT LANGUAGE=\"JavaScript\">
document.getElementById('ajaxldr').style.display = 'none';
</SCRIPT>
	");
	print JsPrint($ajax_open_html);

        # Display results.
	print JsPrint($gcon);

        #
        #@sp = split(/(.{20}[^\\]{4})/, $str);
	#@sp = ();
	#push(@sp, $str);
        #for($i=0; $i<($#sp+1); $i++)
        #{
	#	$sp[$i] = FixScands($sp[$i]);
        #        if($sp[$i] ne "")
        #        {
        #                print(" document.write(\"$sp[$i]\");\n ");
        #        }
        #}
}

