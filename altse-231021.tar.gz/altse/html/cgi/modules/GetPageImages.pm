##############################################################################################
#
# Get images from a single page.
#
sub GetPageImages
{
	my ($i,$i2,$str,$str2,@lst,@lst2);

	#
	open($f, ">>$DB/altse/logs/dardump_gpimages.log") || print STDERR "Why this software even write to logs?? (GetPageImages.pm)\n";
	print $f "Attempting to run dardump ...\n";
	close($f);

	# MODIFY THIS LATER
	@lst = LoadList("$DB/altse/bin/dardump $_[0] $so{'indexnr'} 2>/dev/null|");
	@g_cached_page_info = @lst;

	#
	open($f, ">>$DB/altse/logs/dardump_successful_dardump.log") || print STDERR "Why this software even write to logs?? (GetPageImages.pm)\n";
	my $data1 = split("\n", @lst);
	$data1 =~ s/^(.100).*$/$1/;
	print $f time() . ": $data1 ...\n";
	close($f);

	if($lst[1] eq "")
	{
		$lst[1] = "/";
	}

	#
	open($f, ">>$DB/altse/logs/dardump_gpimages.log") || print STDERR "Why this software even write to logs?? (GetPageImages.pm)\n";
	print $f time() . ": Attempting to run dardump ...\n";
	close($f);

	# Collect images
	my ($nri,$imgs);
	loop: for($i=0; $i<($#lst+1); $i++) {
		if($lst[$i] eq "[MULTIMEDIA AND OTHER CONTENT]") {
			#die "hello world\nMultimedia and other content FOUND!\n";
			$i++;
			last loop;
		}
	}
	for($nri=0; $i<($#lst+1); $i+=4)
	{
		my $mmtype = $lst[$i+0];
		if($mmtype eq "image") {
			$imgs[$nri++] = $lst[$i+1];
		}
	}

	# goti - got image URL
	##my %goti;
	my @imgz;
#	print $nri . "<BR>\n";
	for($i=0,$i2=0; $i<$nri; $i++)
	{
		my $imgurl;
		$imgurl = $imgs[$i];
		if(!($imgurl=~/^http[s]*:\/\//)) {
			if($imgurl=~/^\//) {
				$imgurl = "$lst[0]" . $imgurl;
			} else {
				$lst[1] =~ s/^(.*\/)[^\/]+/$1/;
				$imgurl = "$lst[0]$lst[1]" . $imgurl;
				#$imgurl =~ s/\/\//\//g;
			}
			if(!($imgurl=~/^http[s]*:\/\//)) {
				$imgurl = "http://$imgurl";
			}
		}
		if(!$gotimz{$imgurl}) {
			if($imgurl=~/^http[s]*:\/\//) {
				$imgurl =~ s/^(http[s]*:\/\/\[BASIC PAGE INFO\]host\=)(.*)$/$2/;
				if(!($imgurl=~/^http[s]*:\/\//)) {
					$imgurl = "http://$imgurl";
				}
				$imgz[$i2++] = $imgurl;
				$gotimz{$imgurl}++
			}
		}
	}

	$IMAGE_COUNT = $nri;

	return @imgz;
}

1;
