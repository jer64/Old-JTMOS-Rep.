## Altse Configuration File
## (C) 2021 Jari Tapio Tuominen (jari.t.tuominen@gmail.com).

#
$ALTSE_HOST = "www.tykkaa.info";

# see altse/cfg/is.cfg for configuration
$LANG = "$DB/altse/lang";
#$altse_SERVICE_NOTIFICATION = "(!) 100% reindexing in progress - DIRECTORY WORKS - TRY IT.";
#
$IMAGES_URL = "/";
$GALLERY_URL = "/altsegallery";
#
$CGICMD = "/";
# Keep this off!
$SEARCH_LOG = "$DB/slog.txt";

# This affects image search view
$images_per_page = 250;

## INTERFACE SETTINGS
#
$SEARCH_FRONT_PAGE_TABLE_WIDTH = 640;
$SUBMIT_TABLE_WIDTH = 640;

#
$IMP_MESSAGE = "<font size=1><i>News Search P4T1N.COM - Putin-Trump-Jinping - Towards Better Broadcasts.</i></font><br>";

#
$ADMIN_IP = "192.168.0.2";
# FEATURES
$Google_ads = 0;
$WEB_DIRECTORY = 0;
$PAGE_TITLE = "P4T1N.COM: News Search :: Putin-Trump-Jinping :: Searching The Unknown: Altse Technology";
$ADVERTISE_ALTSE = 0;
$IGNORE_DUPLICATE_URLS = 0;
$IGNORE_DUPLICATE_HOSTS = 0;

# IMAGE SETTINGS
$LOGO1 =	"/";
$LOGO2 =	"/";
$LOGO_FRONT =	"/";

$MOB_LOGO1 =		"/images/mobile_NewAltseLogo.png";
$MOB_LOGO2 =		"/images/mobile_NewAltseLogo2.png";
$MOB_LOGO_FRONT =	"/images/mobile_NewAltse.png";

$BIM = "/images/newaltse.jpg";
# LAYOUT
$CSS_URL="/images/altse.css";

# Result view settings.
$DEFAULT_RESULTS_PER_PAGE = 10;

#
$IS_PL = "is.pl";

# Image search.
$MAX_IMGS_PER_LINE = 5;
$MAX_IMGS_PER_PAGE = 2*$MAX_IMGS_PER_LINE;
$REQ_MIN_IMG_SIZE = 8192;
$IMG_SS = 175;

#
$FONTCC =  "dark";
$FONTCC2 = "dark";
$FONTCC3 = "dark";
$TVAR = "#FFFFFF";

#
$SITE_STATEMENT = "<P>A non-profit open source project based on BSD-license.</P>";
$COPYRIGHT = "(C) 2003-2020 Jari Tuominen (<A HREF=\"mailto:jari.t.tuominen\@gmail.com\">jari.t.tuominen [AT] gmail.com</A>). All rights reserved.";

#
$altse = "$NWPUB_CGIBASE/altse";    # search database root directory
$CID = "$altse/cid";              # central index
$DATA = "$altse/cid/data";
$LISTS = "$altse/cid/lists";          # list files directory
$TMP = "$DB/tmp";

1;
