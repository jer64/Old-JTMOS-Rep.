################################################################
#
# View cached page.
#
sub ViewCache
{
	my ($i,$i2,$str,$str2,@lst,@lst2);

	#
	print("

<A href='/'>
	<IMG SRC='/images/newaltse.jpg'>
</A>

		<TABLE border=0 width=100% cellpadding=4 cellspacing=0 style=\"background:blue;\">
		<tr>
		<td>
		<font color=white>$so{'W_VIEWING_CACHE'}:</font>
		</td>
		</tr>
		</TABLE>
		");


	# For security reasons remove non-numerics.
	$so{'id'} =~ s/[^0-9]//g;
	#
	@lst2 = LoadList("$DB/altse/bin/dardump $so{'id'} $_[0] 2>/dev/null|");
	if($lst2[1] eq "")
	{
		$lst2[1] = "/";
	}
	@lst = LoadList("$DB/altse/bin/htmldump $so{'id'} $_[0] 2>/dev/null|");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$lst[$i] = EmphasizeKeywordsYellow($lst[$i],0);
		print("$lst[$i]\n");
	}

}

1;
