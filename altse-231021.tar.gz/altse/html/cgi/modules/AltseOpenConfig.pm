#
################################################################
my (@web);

#
#use Time::localtime;
#use File::stat;
#use Crypt::Rot13;
use IO::Zlib;
#use CGI;

#use DBI;
##require "altse_sqlconfig.pm"; # A) enable or disable MySQL
##require "altse_easysql.pm";   # B) enable or disable MySQL
# SQL not needed at the time.

######################################################################
#
# Load a list (text file) into array.
# Supports also compressed files, but in these cases
# the file name must be properly named ending as ".gz".
#
sub LoadList
{
        my ($fc,@_ulst,$ich,$ich2,$str);

        #
        if( !open($fc, $_[0]) )
	{
		$str = "Can't open $_[0]";
	        $str =~ s/(.{8})/$1 /g;
		print STDERR ("<font size=2 color=\"#000000\">$str</font>\n");
		return;
	}
        @_ulst = <$fc>;
        close($fc);

	#
	for($ich=0; $ich<($#_ulst+1); $ich++)
	{
		chomp $_ulst[$ich];
		$_ulst[$ich] =~ s/\r//g;
		$_ulst[$ich] =~ s/\n//g;
	}

	#
	return @_ulst;
}

#
sub AltseOpenConfig
{
	#
	if( !open(f, "/etc/altse.conf") )
	{
		if( !open(f, "$ENV{'HOME'}/.altserc") )
		{
			if( !open(f, "$ENV{'SF_PATH'}/cgi-bin/.altserc") )
			{
				return 1;
			}
			else
			{
				print STDERR "$ENV{'HOME'}.altserc found\n";
			}
		}
	}
	$DB =          <f>;    # search database root directory
	print STDERR $DB . "\n";
	chomp($DB);
	$altse = "$DB/altse";
	close(f);
	LoadVars("$DB/altse/cfg/is.cfg");
	#
	system("export http_proxy=");
        system("export ftp_proxy=");
	#
	return 0;
}

# Load variables to %so tree.
sub LoadVars
{
        my ($i,$str,$str2,$str3,$str4,@tmp);

        #
        open(f, "$_[0]") || return 0;
        close(f);
        @opt = LoadList("$_[0]");

	#
#	%so = "";

        #
        for($i=0; $i<($#opt+1); $i++)
        {
                $str = $opt[$i];
                @tmp = split("\=", $str);
                $varname = $tmp[0];
                $varvalue = $tmp[1];
                if($varname ne "" && $varvalue ne "")
                {
                        $so{$varname} = $varvalue;
                }
        }

	#
        return 1;
}

##########################################################
#
sub ArgLineParse
{
        my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co,@s,@s2,$change);

        # Read in text
        $ENV{'REQUEST_METHOD'} =~ tr/a-z/A-Z/;
        if ($ENV{'REQUEST_METHOD'} eq "POST")
        {
		read(STDIN, $tmp, $ENV{'CONTENT_LENGTH'});
        }
        else
        {
	        # Get section argument.
	        $tmp = $ENV{'QUERY_STRING'};
        }

	#
        $tmp =~ s/\+/ /ig;
	$tmp =~ s/%3D/!FCE2E37B!/gi;
	$tmp =~ s/%26/!FF325136!/gi;
        $tmp =~ s/%(..)/pack("C", hex($1))/eg;

	#
	if($ENV{'CFG_LOADED'} eq "" && !$DONT_AFFECT_DB)
	{
		LoadConfiguration(GetUserID());
	}

	#
        @s = split("\&", $tmp);

        # Section always defaults to none
        # (always show front page if no section= specified).
        $so{'section'} = "";
	# No redirection as default.
	$so{'redirect'} = "";

        #
        for($i=0,$change=0; $i<($#s+1); $i++)
        {
                #
                if($s[$i] =~ /\=/)
                {
                        #
                        $change = 1;

                        #
                        @s2 = split("\=", $s[$i]);

                        #
                        $so{$s2[0]} = $s2[1];
			$so{$s2[0]} =~ s/!FCE2E37B!/\=/gi;
			$so{$s2[0]} =~ s/!FF325136!/\&/gi;
                }
        }

        #
        if($change && !$DONT_AFFECT_DB) { SaveProfile(GetUserID()); }

        #
	return $ENV{'REQUEST_METHOD'};
}

#
sub IsRunning
{
	my (@lst,$i,$i2,$i3,$i4);

	#
	@lst = LoadList("ps aux|grep $_[0]|grep -v pico|grep -v lynx|grep -v links|");

	#
	return $#lst;
}

#
sub CreationDate1
{
        my ($aika);

        #
        $aika = 0;

        #
        if( -e $_[0] )
        {
                $aika = (stat($_[0]))[9];
        }
        return $aika;
}

# Tells file age in seconds.
sub FileAge
{
        my ($aik,$taik);

        #
        $taik = time;
        $aik = CreationDate1("$_[0]");
        return $taik-$aik;
}

#
sub Track
{
        # Specify that only users get logged.
                #
                open($f, ">>logs/redir.log") ||
                        die "<a href=\"$_[0]\">Error while redirecting. Click here manually ...</a>";
                $t = time;
                $str = "$t & $ENV{'REMOTE_ADDR'} & $ENV{'REMOTE_HOST'} & $_[0]\n";
                print $f $str;
                close($f);
}

true;

