# Altse menu system (derivered from Vunet Information Systsem).
# Updated: 8/2013
sub inc_menu
{
	my ($i,$i2,@lst,@lst2,$str,$str2);

	#
	$ENV{'MENUSEC'} = $_[0];
	$ENV{'MENUFPSEC'} = $_[1];
	$str = MainMenu();

	#
	return $str;
}

#
sub MainMenu
{
	my ($str,$str2,$str3,$str4,@lst,@lst2,$con,@items,
		$i,$i2,$i3,$i4);
	my @secs = (
	"kuuba", "venezuela", "vietnam",
		);

	#
#	vis_log();

	#
	for($i=0; $i<($#secs+1); $i++)
	{
		if($secs[$i] eq $so{'rs'})
		{
			$ENV{'MENUSEC'} = $secs[$i];
		}
	}

	#
	if($ENV{'MENUSEC'} eq "")
	{
		$ENV{'MENUSEC'} = "etusivu";
	}

	#$str = $ENV{'REQUEST_URI'};
	#$ENV{'MENUSEC'} = $_[0];
	#$ENV{'MENUFPSEC'} = $_[1];
	if($ENV{'MENUFPSEC'} eq "")
	{
#		$ENV{'MENUFPSEC'} = "finnish";
	}

	#
	if(($ENV{'MENUFPSEC'} eq "finnish" && $so{'section'} ne "progressive" && $so{'section'} ne "bush"))
	{
		@items = @ITEMS_FI;
	}
	else
	{
		@items = @ITEMS_EN;
	}

	#
	$con = "";

	#
	loop2: for($i=0,$tested=0,$t=time(); $i<($#items+1); $i++)
	{
		#
		$str = $items[$i];

		if( (time()-$t)>=4 ) { $con = $con . "time-out<BR>"; last loop2; }
		#
		if($str=~/^-/)
		{
			$con = $con . MajorItemBox("$str", $items[$i+2]);
			$tested = 0;
			$i3 = $i;
		}
		else
		{
			if($tested==0)
			{
				loop: for($i2=$i; $i2<($#items+1); $i2++)
				{
					if($items[$i2]=~/^-/ && $i3!=$i2)
					{
						$i = $i2-1;
						goto past;
					}
					@sp = split(/\:/, $items[$i2+0]);
					if($sp[1] eq $ENV{'MENUSEC'} && $sp[1] ne "") { last loop; }
					$i2++;
				}
			}
			$tested = 1;

			@sp = split(/\:/, $items[$i+0]);
			if($sp[1] eq $ENV{'MENUSEC'} && $sp[1] ne "")
			{
				$con = $con . SelectedItemBox($sp[0], $items[$i+1]);
			}
			else
			{
				$con = $con . ItemBox($sp[0], $items[$i+1]);
			}
			$i++;
		}
past:
	}

	#
	$con = ($con . "
<TABLE width=100% height=8 bgcolor=#800000>
<TR>
<TD>
</TD>
</TR>
</TABLE>
");

	#
	return $con;
}

#
@ITEMS_EN = (
"- Front page",
"Front Page:etusivu",
"/",
"Altse Finance:finance",
"/finance/",
"Uutiset:uutiset",
"/finance/?sec=finnish",
"Altse Directory:directory",
"/d/?q=World",
"RSS-feeds:rss_feeeds",
"/rss/",
);

#
@ITEMS_FI = (
"- P��jutut",
"Etusivu:etusivu",
"/finnish/",
#"Keskustelu:keskustelu",
#"/keskustelu/",
"P�iv�n suosituimmat:suosituimmat",
"/top/",
"Top 100 artikkelit:topafi",
"/top100/",
"RSS-feedit:browserfeeds",
"/browserfeeds.pl",
"Uudet suositellut:suositellut",
"/suositellut/",
"S��tiedot:saa",
"/saa.pl?q=Jyv�skyl�",
"��nestys:vote",
"/pollmain.pl",
"Online chat:onlinechat",
"/onlinechat.pl",
"USA - suuri utopia:yhdysvallat",
"/usa_utopia.pl",
"Poimitut:picks",
"/picks.pl",
#"MP3-kone:mp3machinefi",
#"/cgi/mp3machine.pl?l=fi",
#"Kuvapankki:imgbank",
#"/cgi/imgbank.pl",
#"Videot:videoz2",
#"/cgi/videos.pl",

"- Uutiset",
"Kotimaa:kotimaa",
"/finnish/kotimaa",
"Ulkomaat:ulkomaat",
"/finnish/ulkomaat",
"Politiikka:politiikka",
"/finnish/politiikka",
"Konfliktit:konfliktit",
"/finnish/konfliktit",
"Tiede/Terveys/IT:tiede",
"/finnish/tiede",
"Ty�paikat:tyopaikat",
"/finnish/tyopaikat",
"Psykologia:psykologia",
"/psykologia/",
"Seksuaalisuus:seksi",
"/seksi/",
"Kulttuuri:kulttuuri",
"/nw.pl?rs=kulttuuri&q=&maxts=20&section=kulttuuri&FP_SECTION=finnish",
"Videot:parhaatvideot",
"/nw.pl?rs=parhaatvideot&q=video&maxts=2000&section=kulttuuri&FP_SECTION=finnish",

"- Sijoittaminen",
"Talous:talous",
"/finnish/talous",
"Bisnessivut:biznez",
"/kultakaivos/",
"Kulta:kulta",
"/kulta/",
"Hopea:hopea",
"/hopea/",
"Pronssi:pronssi",
"/pronssi/",
"Jim Rogers:jimrogers",
"/jim_rogers/",

"- Maittain",
"Venaja:venaja",
"/venaja/",
"Kiina:kiina",
"/kiina/",
"Intia:intia",
"/intia/",
"SCO:sco",
"/sco/",
"CSTO:csto",
"/csto/",
"NATO:nato",
"/nato/",
"Korea:korea",
"/korea/",
"Ossetia:ossetia",
"/ossetia/",
"Pakistan:pakistan",
"/pakistan/",
"Myanmar:myanmar",
"/myanmar/",
"Hong Kong:hongkong",
"/hongkong/",
"Thaimaa:thaimaa",
"/thaimaa/",
"Singapore:singapore",
"/singapore/",
"Jemen:jemen",
"/jemen/",
"Libya:libya",
"/libya/",
"Iran:iran",
"/iran/",
"Irak:irak",
"/irak/",
"Syyria:syyria",
"/syyria/",
"Egypti:egypti",
"/egypti/",
"Laos:laos",
"/laos/",
"Vietnam:vietnam",
"/vietnam/",
"Venezuela:venezuela",
"/venezuela/",
"Kuuba:kuuba",
"/kuuba/",
"Serbia:serbia",
"/serbia/",

"- Viihde",
"Kummalliset:kummalliset",
"/kummalliset/",
"Videot:videoz",
"/finnish/kulttuuri",

"- Yhteiskunta",
"Jutut:yhteiskunta",
"/cgi/nw.pl?FP_SECTION=finnish&section=yhteiskunta",
"Tiedotteet:tiedotteet",
"/cgi/nw.pl?FP_SECTION=finnish&section=tiedotteet",
"Luonto:luonto",
"/cgi/nw.pl?FP_SECTION=finnish&section=luonto",
"Kolumnit:kolumnit",
"/cgi/nw.pl?FP_SECTION=finnish&section=kolumnit",
"Ajatelmat:ajatelmat",
"/cgi/nw.pl?FP_SECTION=finnish&section=ajatelmat",

"- Hallinto",
"Hallintokeskus:hallintokeskus",
"/cgi/admin/center.pl",
"Mainokset:postituslista",
"/cgi/admin/ads.pl",
"Postituslista:postituslista",
"/cgi/admin/mailinglist.pl",
"Julkaise artikkeli:julkaise",
"/cgi/publisharticle.pl",
);

#
sub MajorItemBox
{
	my ($str,$str2,$str3,$str4,@lst,@lst2,$con,@items);

	#
	$str = ("
<TABLE width=210 class=MajorItemBox>
<TR>
<TD>
	<A HREF=\"$_[1]\" class=bright>
	<H2 CLASS=head2_selected>
	$_[0]
	</H2>
	</A>
</TD>
</TR>
</TABLE>

		");

	#
	return $str;
}

#
sub SelectedItemBox
{
	my ($str,$str2,$str3,$str4,@lst,@lst2,$con,@items);

	#
	$str = ("
<TABLE width=210 class=SelectedItemBox>
<TR>
<TD width=60>
	<A HREF=\"$_[1]\" class=dark>
	<H2 CLASS=head2_selected>
	$_[0]
	</H2>
	</A>
</TD>
</TR>
</TABLE>

		");

	#
	return $str;
}

#
sub ItemBox
{
	my ($str,$str2,$str3,$str4,@lst,@lst2,$con,@items);

	#
	$str = ("
<TABLE width=210 class=ItemBox>
<TR>
<TD>
	<A HREF=\"$_[1]\" class=bright>
	<H2 CLASS=head2>
	$_[0]
	</H2>
	</A>
</TD>
</TR>
</TABLE>

		");

	#
	return $str;
}

1;
