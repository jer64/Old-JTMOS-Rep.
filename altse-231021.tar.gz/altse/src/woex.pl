#!/usr/bin/perl
######################################################################
#
# Vunet Search Engine
# WLI -Word List Extractor.
#
######################################################################
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use String::CRC::Cksum qw(cksum);

#
main();

##############################################################################
#
sub ViewWords
{
	my ($i,$i2,$str);

	##########################################################
	# Split into words.
	#
	@WORDS = split(" ", $_[0]);

	#
	for($i=0; $i<($#WORDS+1); $i++)
	{
		# Words can begin with an alpha or a number.
		$WORDS[$i] =~ s/^[^a-zA-Z������0-9]*//g;
		print "$WORDS[$i] ";
	}
}

##############################################################################
#
sub NiceString
{
	my ($body);

	#
	$body = $_[0];
	$body =~ s/\[[0-9]*\]//g;
	$body =~ s/[^0-9a-zA-Z������\ ]/ /g;
	return $body;
}

##############################################################################
#
sub WoexThis
{
	my ($i,$i2,$str,$str2,@sp,$a1,$a2,$body,$head,@prv,$l);

	################################################
	#

	# Load source text file.
	@src = LoadList($_[0]);

	##########################################################
	#
	# Make the whole article a single string.
	#
	$l = $#src+1;
	loop: for($i=0,$body=""; $i<$l; $i++)
	{
		if($src[$i] eq "References" &&
			$src[$i+1] eq "" &&
			$src[$i+2] ne "")
		{
			last loop;
		}
		$body = "$body $src[$i] ";
	}

	# Article body.
	$body = NiceString($body);

	#
	ViewWords($body);
}

##############################################################################
#
sub main
{
	my ($fn,$str,$str2,$fn);


	#
	if( (!($ARGV[0] =~ /^\s$/) && -e $ARGV[0]) || $ARGV[0]=~/^http:\/\// )
	{
		#
		$fn = $ARGV[0];
		if( !($fn=~/^http:\/\//) )
		{
			$fn =~ s/([^a-z���0-9\_\-\.\/ ])/\\$1/gi;
		}
		# Prepare command to call.
		$str =  "lynx -force_html -dump \"$fn\"|";
		$str2 = "prv.pl \"$fn\"|";
		# Process the content from pipe.
		WoexThis($str, $str2);
	}
}

