/////////////////////////////////////////////////////////////////////////////
//
// htmlproc.c - HTML processor.
// (C) 2005-2006 by Jari Tuominen (jari@vunet.org).
// Converts a HTML file into indexing friendly format.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <curses.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"
#include "htmlproc.h"

/////////////////////////////////////////////////////////////////////////////
//
// Get specific meta tag.
//
void GetMetaTag(BYTE *h, char *tag, char *target)
{
	int i,i2,l,found,l1,l2,l3;
	BYTE *p;
	static BYTE ftag[8192],content[8192];
	static BYTE match1[8192],
			match2[8192],
			match3[8192];

	//
	strcpy(target, "");

	//
	l = strlen((char*)h);

	//
	sprintf((char*)match1, "<meta name=\"%s\"",	tag);
	l1 = strlen((char*)match1);

	//
	for(i=0,found=0; i<l; i++)
	{
		//
		p = h+i;
		if(
			!strncasecmp((char*)p,(char*)match1,l1)
			)
		{
			for(i2=0; i2<8000 && p[i2]!='>' && p[i2]!=0; i2++)
			{
				ftag[i2] = p[i2];
			}
			ftag[i2++]='>';
			ftag[i2++]=0;
			found = TRUE;
			break;
		}
	}

	//
	if(found)
	{
		//
		strcpy((char*)content, "");
		//
		l = strlen((char*)ftag);
		for(i=0,i2=0; i<l; i++)
		{
			if(ftag[i]=='"') { i2++; }
			if(i2==3) { i++; break; }
		}
		if(i2==3)
		{
			for(i2=0; i<l && i2<8000; i++)
			{
				if(ftag[i]=='"') break;
				content[i2++] = ftag[i];
			}
			content[i2++]=0;
		}

		//
		strcpy((char*)target, (char*)content);
	/*	fprintf(stderr, "%s = \"%s\"\n",
			tag,
			content);*/
	}

	//
}


