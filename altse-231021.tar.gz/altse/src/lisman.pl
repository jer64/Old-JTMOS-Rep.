#!/usr/bin/perl
##########################################################################
#
# lisman.pl -- Text List Manipulation Tool.
#
##########################################################################
#
use POSIX;
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =		"$NWPUB_CGIBASE/sdb";	# search database root directory
$CID =		"$SDB/cid";		# central index
$LISTS =	"$SDB/cid/lists";	# list files directory
$DADI =		"$SDB/cid/data";	# data files
$DICT =		"$SDB/cid/dict";	# big index with dictionaries

#
main();

############################################################################
#
sub Probe
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn,$c);

	#
	if( !(-e $_[0]) ) { return 0; } # not found

	#
	@lst = LoadList($_[0]);

	#
	for($i=0,$i2=0; $i<($#lst+1); $i++)
	{
		#
		if($lst[$i] eq $_[1]) { return 1; } # found
	}

	# Not found.
	return 0;
}

############################################################################
#
# lisman.pl probe 
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn,$c);

	#
	$c = $ARGV[1];

	#
	if($c eq "probe")
	{
		# [list] [entry]
		exit( Probe($ARGV[0], $ARGV[2]) ); 
	}

	#
	print STDERR "Unknown command '$c'.\n";
}

