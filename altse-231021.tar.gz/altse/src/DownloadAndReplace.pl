#!/usr/bin/perl
# newsfeedbuilder.pl
# Downloads item at selected location.
# Features a failsafe where old file is not replaced if
# the new file is simply a truncated file -look like.
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use Cwd 'chdir';

#
AltseOpenConfig();

#
$LOPT =  "-useragent=HAPPYCRAWLER\@ONPARAS.COM-Lynx -connect_timeout=40";
$LOPT2 = "2>/dev/null";

#
if($ARGV[0] eq "" || $ARGV[1] eq "") {
        print STDERR "Usage: DownloadAndReplace.pl [URL] [local output file]\n";
        print STDERR "Description:\n";
	print STDERR "          Downloads item at selected location.\n";
	print STDERR "          Features a failsafe where old file is not replaced if\n";
	print STDERR "          the new file is simply a truncated file -look like.\n";
        print STDERR "Options:\n";
        print STDERR "          DownloadAndReplace.pl [URL] [destination file]\n";
        exit;
}

#
main();

#
sub main
{
	my (@lst,$i,$i2,$f);

	# Get URL target content.
	@lst = LoadList("wget -O - \"$ARGV[0]\" $LOPT2|");

	# Only accept files with at least ten lines.
	if($#lst>=9) {
		if( open($f, ">$ARGV[1]") ) {
			for($i=0; $i<($#lst+1); $i++) {
				print $f $lst[$i] . "\n";
			}
			close($f);
		}
	}

	#
}

#


