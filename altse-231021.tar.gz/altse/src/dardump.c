//--------------------------------------------------------------------------------------------
//
// dardump.c
// (C) 2010-2016 Jari Tuominen.
//
// TODO: add pageids_XX/base.txt support !!
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "dardump.h"
#include "htmlproc.h"
#include "wlisearch.h"

//
#define SUPER_DEBUGGING			1

// Can be used for checking the file later.
char dardump_global_page_dump_fn[16384];
//
int DARDUMP_VERBOSE = 0;
#define DBPATH		"/home/vai/db"
#define MAX_PAGE_SIZE			16384
#define MAX_LINK_DESCRIPTION_LEN	16384
// * Dardump debugging goes to stderr.
int dardump_debugging = 0;

//--------------------------------------------------------------------------------------------
//
// buf will be stored following information:
// NR	Description	Example
// 0	host		"www.yle.fi\n"
// 1	path		"/\n"
// 2	title		"News..... \n"
// 3	preview		".............. ........... ............ .............\n"
// 4	nfo		?
//
// Return value:
//	Zero on success
//	Non-zero on failure
int DarDump(int sid,  BYTE *buf,int l_buf, int index_to_use)
{
	FILE *f;
	static char str[WLI_BLS],bigfn[8192],dbifn[8192];
	char *test_ptr;
	DWORD offs,l,i,i2,i3,i4,i5,i6,d1;
	int fd;
	// ..
	static char *filelist = NULL;
	static int l_filelist = 0;
	static char fn[5120];
	// ..
	static int curpathnum = -1;
	static int curfilenum = -1;

	//
	static char dbpath_www[16384],
		meta_description[1024*1024],
		meta_keywords[1024*1024],
		wli_keyword_str[1024*1024];
	int pgnum,ch1;
	char strpath[16384];
	char *cutpl;
	float fa,fb;

	// Check if this is user terminal.
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: Attempting to call getenv(...)\n",
				__FILE__, __FUNCTION__, __LINE__);
	}
	if( getenv("COLUMNS")!=NULL ) {
		dardump_debugging = 1;
	}
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: Attempting to call getenv(...): success\n",
				__FILE__, __FUNCTION__, __LINE__);
	}

	// Check for base.txt.
	strcpy(dbifn, "pageids2fn");
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: dbifn set to \"%s\"\n",
				__FILE__, __FUNCTION__, __LINE__,
				dbifn);
	}
	if(index_to_use>0) {
		if(dardump_debugging) {
			fprintf(stderr, "%s/%s/line %d: attempting to sprintf(str,...) and strcat(dbifn, str);\n",
					__FILE__, __FUNCTION__, __LINE__);
		}
		sprintf(str, "\_%d", index_to_use);
		strcat(dbifn, str);
		if(dardump_debugging) {
			fprintf(stderr, "%s/%s/line %d: dbifn after strcat=\"%s\" (str=\"%s\"\n",
					__FILE__, __FUNCTION__, __LINE__,
					str,dbifn);
		}
	}
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: index_to_use = %d\n",
				__FILE__, __FUNCTION__, __LINE__,
				index_to_use);
		fprintf(stderr, "%s/%s/line %d: dbifn = %s\n",
				__FILE__, __FUNCTION__, __LINE__,
				dbifn);
	}
	sprintf(fn, "%s/%s/base.txt",
		DBPATH, dbifn);
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: fn = %s\n",
				__FILE__, __FUNCTION__, __LINE__,
				fn);
	}
	f = fopen(fn, "rb");
	if(f != NULL) {
		fscanf(f, "%s", &dbpath_www);
		fclose(f);
	} else {
		sprintf(dbpath_www, "%s/www", DBPATH);
	}
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: got dbpath_www = %s\n",
				__FILE__, __FUNCTION__, __LINE__,
				dbpath_www);
	}


	// FIRST CONVERT PAGE ID TO FILE NAME
	// 2000 entries per page id file, 200 different files per directory
	int pathnum = sid/(2000*200);
	int filenum = sid/2000; // % 200
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: pathnum = %d, filenum = %d\n",
				__FILE__, __FUNCTION__, __LINE__,
				pathnum, filenum);
	}

	//        my $PPF = 2000;
	//        my $SUB = 200;
	//        my $nn = 0;
	//        $sect = int($nn / $PPF) % $PPF; # N paths per file
	//        $n1 = int($sect/$SUB)   % $SUB; # N files per directory
	//        $n2 = int($n1/$SUB)     % $SUB; # N subdirectories at most per directory
	//        $n3 = int($n2/$SUB)     % $SUB; # N subdirectories at most per subdirectories
	//        $n4 = int($n3/$SUB)     % $SUB; # N subdirectories at most per subdirectories

	// Performance Fix
	// This *comparison makes a sort of cache in memory of current file list,
	// which avoids the possible scenario where the list has to be loaded
	// each time again and again.		* pathnum, filenum
	if(pathnum != curpathnum && filenum != curfilenum) {
		if(filelist!=NULL) {
			SafeFree(filelist);
			filelist = NULL;
		}
		strcpy(dbifn, "pageids2fn");
		if(index_to_use>0) {
			sprintf(str, "\_%d", index_to_use);
			strcat(dbifn, str);
		}
       		sprintf(fn, "%s/%s/0/0/0/%d/%d.dat",  DBPATH, dbifn,  pathnum, filenum);
		if(dardump_debugging) {
			fprintf(stderr, "%s/%s/line %d: fn = %s\n",
					__FILE__, __FUNCTION__, __LINE__,
					fn);
		}
		f = fopen(fn, "rb");
		if(f==NULL) {
			if(DARDUMP_VERBOSE || dardump_debugging)
					fprintf(stderr, "%s (error): File not found: %s\n",
					__FUNCTION__, fn);
			return 2;
		}
		fseek(f,0,SEEK_END);
		l_filelist = ftell(f);
		fseek(f,0,SEEK_SET);
		filelist = imalloc(l_filelist);
		fread(filelist,l_filelist,1,f);
		fclose(f);
	}
	if(filelist!=NULL) {
		GetLine(filelist,l_filelist,sid % 2000,fn);
	}
	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: got file name = %s\n",
				__FILE__, __FUNCTION__, __LINE__,
				fn);
	}

	// fn now contains (dump) file name of specified PAGE ID
	// f.e. ./1.b/1.bp.blogspot.com/1.dump.gz
	// which is convertible to an absolute path of
	// /home/vai/db/www/X

	// 
	if(DARDUMP_VERBOSE)
		fprintf(stderr, "%s: pageid2fn conversion result: id %d = \"%s\"\n", __FUNCTION__, sid, fn);
//	sleep(1);

	// CLEAR IMPORTANT
	if(DARDUMP_VERBOSE)
		fprintf(stderr, "%s: buf=0x%1.8x (%d bytes)\n", __FUNCTION__, buf,l_buf);
	memset(buf,0,l_buf);


	FILE *zf;
	char *dump=NULL,*html=NULL;
	int dump_len=0,html_len=0;

	// LOAD (TEXT) DUMP
	// Load ".dump.gz" file using zlib zopen.
	sprintf(bigfn, "%s/%s", dbpath_www, fn);
	char prepared_cmd[16384];


	sprintf(prepared_cmd, "zcat %s", bigfn);

//	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: attempting popen(\"%s\", \"%s\");\n",
				__FILE__, __FUNCTION__, __LINE__,
				prepared_cmd, "r");
//	}


	zf = popen(prepared_cmd, "r");
	if(zf==NULL) {
		if(DARDUMP_VERBOSE || dardump_debugging)
			fprintf(stderr, "%s (error): File not found: %s\n",	__FUNCTION__, fn);
		return 1;
	}

	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: popen opened a file handle (0x%x)\n",
				__FILE__, __FUNCTION__, __LINE__,
				zf);
	}

        int LIM = 1024*1024;
	dump = imalloc(LIM);
	for(i=0; i<l_buf && i<(LIM-1); i++) {
		ch1 = fgetc(zf);
		if(ch1>=0) {
			dump[i] = ch1;
		} else {
			break;
		}
	}
	dump[i] = 0; i++;	// string termination with zero.
	dump_len = i;
//	if(DARDUMP_VERBOSE || dardump_debugging)
		fprintf(stderr, "%s/line %d: %d byte(s) load from \"%s\".\n",  __FUNCTION__,__LINE__, i, prepared_cmd);
	fclose(zf);

	// We only accept text files, if not one then return 11.
	for(i4=0,i2=0; i4<dump_len; i4++)
	{
		if(isalnum(dump[i4]) || dump[i4]==' ') { i2++; }
	}
	// CAA
	fa = i2; fb = dump_len; fa = fa / fb; fa=fa*100;
	// We accept equal or greater to 60% ASCII text percentuality.
	if(fa<30) {
		fprintf(stderr, "%s/%s/line %d: Skipping: not a text file (%1f%% text percentuality).\nText amount in %d bytes = %d.\n",
				__FILE__, __FUNCTION__, __LINE__,
				fa,
				dump_len, i2);
		return 11;
	}
	fprintf(stderr, "%s/%s/line %d: Valid: text file (%1f%% text percentuality).\n",
				__FILE__, __FUNCTION__, __LINE__,
				fa);

	// LOAD HTML - for "title", see "DATA DELIVERY" -table below
	// Load ".html.gz" file using zlib zopen.
	sprintf(bigfn, "%s/%s", dbpath_www, fn);
	char *rep = strstr(bigfn, ".dump.gz");
	if(rep!=NULL) { strncpy(rep, ".html.gz", 8); }
		else { return 3; }
	// Use zlib
	//defined above: char prepared_cmd[16384];
	sprintf(prepared_cmd, "zcat %s", bigfn);

	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: attempting popen(\"%s\", \"%s\");\n",
				__FILE__, __FUNCTION__, __LINE__,
				prepared_cmd, "r");
	}

	zf = popen(prepared_cmd, "r");
	if(zf==NULL) {
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "%s/line %d: File not found: %s\n",	__FUNCTION__,__LINE__, fn);
		return 1;
	}

	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: popen opened a file handle (0x%x)\n",
				__FILE__, __FUNCTION__, __LINE__,
				zf);
	}

	// Load at most 1 Mb of text from (compressed) page text dump.
        LIM = 1024*1024;
	html = imalloc(LIM);
	for(i=0; i<(LIM-1); i++) {
		int ch1 = fgetc(zf);
		if(ch1>=0) {
			html[i] = ch1;
		} else {
			break;
		}
	}
	html[i] = 0; i++;	// string termination with zero.
	html_len = i;
	if(DARDUMP_VERBOSE || dardump_debugging)
		fprintf(stderr, "%s/line %d: %d byte(s) load from \"%s\".\n",  __FUNCTION__, __LINE__, i, bigfn);
	fclose(zf);

	//
	strcpy(meta_description, "");
	strcpy(meta_keywords, "");
	GetMetaTag(html, "description", meta_description);
	GetMetaTag(html, "keywords",    meta_keywords);

	if(dardump_debugging) {
		fprintf(stderr, "%s/%s/line %d: meta_description=\"%s\", meta_keywords=\"%s\"\n",
				__FILE__, __FUNCTION__, __LINE__,
				meta_description,meta_keywords);
	}

	// DATA DELIVERY
	// buf will be stored following information:
	// 0	host		From already.txt (seperate using string manipulation)
	// 1	path		From already.txt
	// 2	title		From html.gz
	// 3	preview		From dump.gz
	// 4	nfo		
	//

	// Variables.
	int cutbeg = -1,cutend = -1;
	static char host[65536*16],path[65536*16],title[65536*16],preview[65536*16],nfo[65536*16];
	// 1. GET TITLE FROM THE HTML CONTENTS
	static char *titbeg = "<title>";
	static char *titend = "</title>";
	static char *titbegcaps = "<TITLE>";
	static char *titendcaps = "</TITLE>";

	//
	strcpy(host, "");
	strcpy(path, "");
	strcpy(title, "");
	strcpy(preview, "");
	strcpy(nfo, "");

	//
	int matchcnt,phase;
	char found_title = 0;
	// Find title contents - scans for "<title>" and "</title>".
	for(i=0,matchcnt=0,phase=0; i<html_len; i++) {
		if(phase==0)
		{
			//if(DARDUMP_VERBOSE) fprintf(stderr, "'%c' <-> '%c'\n", html[i], titbeg[matchcnt]);
			if(html[i]==titbeg[matchcnt] || html[i]==titbegcaps[matchcnt]) {
				matchcnt++;
				if(matchcnt==strlen(titbeg)) {
					cutbeg = i+1;
					//if(DARDUMP_VERBOSE) 
					//fprintf(stderr, "<PRE>Found \"<title>\".</PRE>\n");
					phase++;
					matchcnt=0;
				}
			} else { matchcnt=0; }
		}

		if(phase==1)
		{
			//if(DARDUMP_VERBOSE) fprintf(stderr, "'%c' <-> '%c'\n", html[i], titend[matchcnt]);
			if(html[i]==titend[matchcnt] || html[i]==titendcaps[matchcnt]) {
				matchcnt++;
				if(matchcnt==strlen(titend)) {
					cutend = i-(strlen(titend)-1);
					//if(DARDUMP_VERBOSE) 
					//fprintf(stderr, "<PRE>Found \"</title>\".</PRE>\n");
					phase++;
					matchcnt=0;
					found_title = 1;
					break;
				}
			} else { matchcnt=0; }
		}
	}
	if(!found_title) {
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "%s line %d: HTML code does not contain a title (html_len=%d)\n", __FUNCTION__, __LINE__, html_len);
	} else {
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "%s line %d: title cut %d - %d (html_len=%d)\n", __FUNCTION__, __LINE__, cutbeg, cutend, html_len);

		// Store in title string - title contents within cutbeg - cutend.
		for(i=cutbeg,i2=0; i<cutend && i2<512; i++,i2++) {
			title[i2] = html[i];
		}
		title[i2] = 0;
		//fprintf(stderr, "<BLINK>TITLE: \"%s\"</BLINK>", title);
	}

	// 2. BUILD PREVIEW TEXT
	int preview_len = 100,lastchar=-1,isdes;
	char *desired = " qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM0123456789.-()[]?!{}äöÄÖåÅ";
	for(i=0,i3=0,isdes=0; i<strlen(dump) && i3<preview_len; i++) {

		isdes = 0;
		for(i2=0; i2<strlen(desired); i2++) {
			if(dump[i]==desired[i2] && 
				!(dump[i]==' ' && lastchar==' ') &&
				!(dump[i]==' ' &&
				!(i3==0 && dump[i]==' ') ) ) {
				preview[i3++] = dump[i];
				lastchar = dump[i];
				isdes = 1;
				break;
			}
		}

		//
		if(!isdes && i3) {
			if(lastchar!=' ') {
				preview[i3++] = ' ';
				lastchar = ' ';
			}
		}
	}
	preview[i3] = 0;

	// 3. BUILD HOST AND PATH STRINGS

	// A) Host from fn's string's beginning (path).
	char *postr = fn;
	if( postr[0]=='.' && postr[1]=='/' ) {
		postr += 2;
	}
	for(i=0; i<strlen(postr); i++) { if(postr[i-1]=='/'){break;} }
	for(i2=0; *postr!=0; i++,i2++,postr++) {
		if(*postr=='/'){break;}
	}
	*postr++;
	for(i2=0; *postr!=0; i++,i2++,postr++) {
		if(*postr=='/'){break;}
		host[i2]=*postr;
	}
	host[i2]=0;

	// B) Get WEB address path from already.txt using sid.

	// create path to the directory
	char dpath[256];
	strcpy(dpath,bigfn);
	for(i=strlen(dpath)-1; i!=0; i--) {
		if(dpath[i]=='/') { break; }
	}
	i++;
	dpath[i] = 0;

	// VERBOSE...
	if(DARDUMP_VERBOSE)
		fprintf(stderr, "%s line %d: dpath=\"%s\"\n",  __FUNCTION__, __LINE__, dpath);


	static char *alfilelist=NULL;
	static int l_alfilelist;
	static char alfn[1024];

	if(alfilelist!=NULL) {
		fprintf(stderr, "%s line %d: Freeing alfilelist\n", __FUNCTION__, __LINE__);
		SafeFree(alfilelist);
		alfilelist = NULL;
		fprintf(stderr, "%s line %d: done\n", __FUNCTION__, __LINE__);
	}
	
	fprintf(stderr, "%s line %d: opening up already.txt at dpath directory\n", __FUNCTION__, __LINE__);
      	sprintf(alfn, "%s/already.txt", dpath);
	f = fopen(alfn, "rb");
	if(f==NULL) {
		if(DARDUMP_VERBOSE)
				fprintf(stderr, "%s (error): File not found: %s\n",
				__FUNCTION__, alfn);
		return 2;
	}
	fseek(f,0,SEEK_END);
	l_alfilelist = ftell(f);
	fseek(f,0,SEEK_SET);
	alfilelist = imalloc(l_alfilelist);
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: reading\n", __FUNCTION__, __LINE__);
	fread(alfilelist,l_alfilelist,1,f);
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: done.\n", __FUNCTION__, __LINE__);
	fclose(f);

	// ...) Path from already.txt -path list using fn's end "N.dump.gz".
	char tmp1[2048];
	strcpy(tmp1, fn);
	char *pagenum=tmp1;
	char num[256];
	int le = strlen(pagenum);
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 1.\n", __FUNCTION__, __LINE__);
	for(pagenum+=le,i2=0; *pagenum!='/' && i2<le; pagenum--,i2++) {
	} pagenum++;
	for(i=0; pagenum[i]!=0 && pagenum[i]!='.'; i++) {
		if(pagenum[i]=='.') { break; }
	}
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 2.\n", __FUNCTION__, __LINE__);
	pagenum[i] = 0;
	sscanf(pagenum, "%d", &pgnum);
//	fprintf(stderr, "%s line %d: pagenum=%s (from \"%s\")\n",
//		__FUNCTION__, __LINE__, pagenum,fn);
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 3.\n", __FUNCTION__, __LINE__);
	GetLine(alfilelist,l_alfilelist,pgnum,strpath);
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 4.\n", __FUNCTION__, __LINE__);
	cutpl = strstr(strpath,"//"); cutpl+=2;
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 5.\n", __FUNCTION__, __LINE__);
	if(cutpl==NULL) { return 10; }
	if(SUPER_DEBUGGING) fprintf(stderr, "cutpl=%x\n", cutpl);
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 6.\n", __FUNCTION__, __LINE__);
	for(; *cutpl!='/' && *cutpl!=0; cutpl++) { }
	if(SUPER_DEBUGGING) fprintf(stderr, "cutpl=%x\n", cutpl);
	if(SUPER_DEBUGGING) fprintf(stderr, "path=%x\n", path);
//	fprintf(stderr, "%s line %d: cutpl=\"%s\"\n", __FUNCTION__, __LINE__, cutpl);
	strcpy(path, cutpl);

	// Produce NFO text - information about page.
	// - page ID (aka GID)
	// - HTML file size
	int fsz;
	FILE *f1;
	f1 = fopen(bigfn, "rb");
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 7.\n", __FUNCTION__, __LINE__);
	fsz = 0;
	if(f1!=NULL) {
		fseek(f1, 0, SEEK_END);
		fsz = ftell(f1);
		fclose(f1);
	}
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 8.\n", __FUNCTION__, __LINE__);
	sprintf(nfo, "%d, %dK", sid, (fsz/1024)+1);


	// FROM SIXTH LINE OF DARDUMP BEGINS MULTIMEDIA ENTRIES OF A PAGE IN FOUR ROW INTERVALS.
	char **im_urls,*au_urls,ch;
	int ma,ma2,ma3,ma4,ma5,ma6,ma7,ma8,mmstage,stage1beg,stage2beg;
	char *str_image =	"image";
	char *str_img =		"<img ";
	char *str_IMG =		"<IMG ";
	char *str_src =		"src=\"";
	char *str_SRC =		"SRC=\"";
	char *str_urlend =	"\"";
	char *str_URLEND =	"\"";
	char *str_imgtagend =	">";
	char *str_IMGTAGEND =	">";

	char *str_audio =	"audio";
	char *str_link =	"link";
	char *str_ahref_a =	"<a ";
	char *str_AHREF_A =	"<A ";
	char *str_ahref_b =	"href=\"";
	char *str_AHREF_B =	"href=\"";
	char *str_ahref_end =	"\"";
	char *str_AHREF_END =	"\"";
	char *str_ahreftagend =	">";
	char *str_AHREFTAGEND =	">";
	int n_max_im_urls = 25000,urlbeg,urlend,ii,ii2,ii3,ii4, wait_past_tag,
		wi,mmwrite,max_mmwrite_len=1024*512,
		go_back_here,go_back_here_2,
		last_char = -1;
	char *mm_content = NULL, *tmpdes = NULL,
		*raw_link_description,
		*clean_link_description;
	// In four lines ("\n" / rows) intervals.
	// 0    TYPE            f.e.    image
	// 1    URL             f.e.    http://www.mycookings.com/pie.jpg
	// 2    KEYWORDS        f.e.    my favorite apple pie
	// 3    EXTRA           f.e.    ...
	mm_content = imalloc(max_mmwrite_len); // upto X Kb of image URLs
	im_urls = imalloc(sizeof(void*)*n_max_im_urls);
	int t,t2;

	//
	raw_link_description = imalloc(MAX_LINK_DESCRIPTION_LEN);
	clean_link_description = imalloc(MAX_LINK_DESCRIPTION_LEN);

	mmwrite = 0;

	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 9.\n", __FUNCTION__, __LINE__);
img_roll_again:
	t = time(NULL);
	for(i=0,mmstage=1,ma=0,ma2=0,ma3=0,ma4=0,ma5=0,ma6=0,ma7=0,ma8=0; i<html_len && mmwrite<max_mmwrite_len; i++)
	{
		// Look for "<IMG".
		if(mmstage==1)	{
			// > ends IMG statement, roll back if one encountered.
			if( html[i]==str_img[ma] || html[i]==str_IMG[ma] ) {
					ma++;
				if(ma==strlen(str_img)) {
					// Found "<IMG".
					mmstage=2; // find "SRC=\""
					ma = 0;
					stage1beg = i;
				}
			} else {
				ma=0;
			}
		}

		// Look for "SRC=\"".
		if(mmstage==2)	{
			// > ends IMG statement, roll back if one encountered.
			if( html[i]=='>' ) { mmstage = 1; ma=0; ma=0; continue; }
			// Looking for "SRC=\"".
			if( html[i]==str_src[ma] || html[i]==str_SRC[ma] ) {
				ma++;
				if(ma==strlen(str_src)) {
					// found "SRC=\""
					mmstage = 3; // get image URL
					ma = 0;
					urlbeg = i+1;
					//stagebeg = i;
					continue;
				}
			}
		}

		// Get link URL.
		if(mmstage==3)	{
			if( html[i]==str_urlend[ma] || html[i]==str_URLEND[ma] ) {
				ma++;

				// Limit image URL max. length to 512 bytes.
				if(ma>511) {
					mmstage = 1; 
					ma = 0;
					continue;
				}

				// Looking for "\"".
				if(ma==strlen(str_urlend)) {
					// Found "\"", end of URL.
					urlend = i;

					//fprintf(stderr, "FOUND IMAGE URL (%d-%d): ", urlbeg, urlend);

					// 0    TYPE            f.e.    image
					// 1    URL             f.e.    http://www.mycookings.com/pie.jpg
					// 2    KEYWORDS        f.e.    my favorite apple pie
					// 3    EXTRA           f.e.    ...
					// Store "image" -type identifier.
					for(ii=0; ii<strlen(str_image); ii++,mmwrite++) {
						mm_content[mmwrite] = str_image[ii];
						//fprintf(stderr, "%c", html[ii]);
					}
					mm_content[mmwrite++] = '\n';
					// Store URL on mm_content.
					for(ii=urlbeg; ii<urlend; ii++,mmwrite++) {
						mm_content[mmwrite] = html[ii];
						//fprintf(stderr, "%c", html[ii]);
					}
					mm_content[mmwrite++] = '\n';
					//fprintf(stderr, "\n");

					mmstage = 4; // find end of IMG-tag (">").
					ma = 0;
					continue;
				}
			}
		}

		// Look for end of IMG-tag.
		if(mmstage==4)	{
			if( html[i]==str_imgtagend[ma] || html[i]==str_IMGTAGEND[ma] ) {
				ma++;
				// Looking for ">".
				if(ma==strlen(str_imgtagend)) {
					// Found ">", end of URL.
					mmstage = 1; // Find another image.
					ma = 0; ma2 = 0;
					go_back_here = i;

					// Get IMG description, if any.
					strcpy(clean_link_description, "");
					for(ii2=i+1,ii3=0,wait_past_tag=0,last_char=-1; ii2<html_len && ii3<150; ii2++) {
						if(last_char==' ' && html[ii2]==' ') { continue; }
						if(html[ii2]==' ' && !ii3) { continue; }

						// break on another image
						if( html[ii2]=='<' &&
							(html[ii2+1]=='i' || html[ii2+1]=='I') &&
							(html[ii2+2]=='m' || html[ii2+2]=='M') &&
							(html[ii2+3]=='g' || html[ii2+3]=='G') )  {
							break;
						}
						// Skip tags.
						if(html[ii2]=='<' && !wait_past_tag) { wait_past_tag=1; continue; }
						if(html[ii2]=='>' && wait_past_tag)  { wait_past_tag=0; continue; }
						// Tag or text?
						if(!wait_past_tag) {
							// Skip control codes.
							if(iscntrl(html[ii2]) || html[ii2]==0) { continue; }
							//
							clean_link_description[ii3++] = html[ii2];
							last_char = html[ii2];
						}
					}
					clean_link_description[ii3] = 0;

					// copy to mm_content
					for(ii2=0; ii2<ii3; ii2++) {
						mm_content[mmwrite++] = toascii(clean_link_description[ii2]);
					}


					//i--;
					mm_content[mmwrite++] = '\n';
					mm_content[mmwrite++] = '\n';
					continue;
				}
			}
		}

		// Build image description from near-by body text.
		if(mmstage==5) {
			tmpdes = malloc(1024*4);
			ma = i-120;
			if(ma<0) { ma=0; }
			Html2Text(html+ma,html_len,tmpdes,1024*4, 200);
			for(ma=0; ma<200 && tmpdes[ma]!=0; ma++) {
				mm_content[mmwrite++] = tmpdes[ma];
			}
			SafeFree(tmpdes);



			// Got keywords.
			mm_content[mmwrite++] = '\n';
			mm_content[mmwrite++] = '\n';
			//
			mmstage = 1; // Find another image.
			ma = 0;
			i = go_back_here;
			continue;
		}

		// OBSOLETE -- Look for image description text (keywords) after image, if any.
		if(mmstage==10)	{
			if( (isblank(html[i]) && isblank(html[i+1])) ||
				(isblank(html[i]) && ma==0) ) {
				continue;
			}
			ma++;
			if( html[i]!='<' && ma2<100 ) {
				// Looking for ">".
				ch = html[i];
				if(ch=='\n' || iscntrl(ch)) { ch=' '; }
				mm_content[mmwrite++] = ch;
				ma2++;
			} else {
				// Got tag? Let's skip it, if so.
			/*	if(html[i]=='<') {
					mmstage=6;
					//go_back_here_2 = i;
					continue;
				}*/
				// Got enough words?
				if(ma2>150) {
					// Got keywords.
					mm_content[mmwrite++] = '\n';
					mm_content[mmwrite++] = '\n';

					//
					mmstage = 1; // Find another image.
					ma = 0;
					i = go_back_here;
					continue;
				}
			}
		}

		// Skip tags stage.
		if(mmstage==6)	{
			if(html[i]=='>') {
				mmstage=5;
				//i = go_back_here_2;
				continue;
			}
		}
	}

// Look for MP3s, and other audio files.
aud_roll_again:
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 10.\n", __FUNCTION__, __LINE__);
	t = time(NULL);
	for(i=0,mmstage=1,ma=0,ma2=0,ma3=0,ma4=0,ma5=0,ma6=0,ma7=0,ma8=0; i<html_len && mmwrite<max_mmwrite_len; i++)
	{
		// Look for "<A ".
		if(mmstage==1)	{
			// Look for "<a ".
			if( html[i]==str_ahref_a[ma] || html[i]==str_AHREF_A[ma] ) {
					ma++;
				if(ma==strlen(str_ahref_a)) {
					// Found "<A ".
					mmstage=2; // find "HREF=\""
					ma = 0;
					stage1beg = i;
				}
			} else {
				ma=0;
			}
		}

		// Look for "HREF=\"".
		if(mmstage==2)	{
			// > ends '<A HREF'- statement, roll back if one encountered.
			if( html[i]=='>' ) { mmstage = 1; ma=0; ma=0; continue; }
			// Looking for "SRC=\"".
			if( html[i]==str_ahref_b[ma] || html[i]==str_AHREF_B[ma] ) {
				ma++;
				if(ma==strlen(str_ahref_b)) {
					// found "HREF=\""
					mmstage = 3; // get audio URL
					ma = 0;
					urlbeg = i+1;
					//stagebeg = i;
					continue;
				}
			}
		}

		// Get link URL.
		if(mmstage==3)	{
			if( html[i]==str_ahref_end[ma] || html[i]==str_AHREF_END[ma] ) {
				ma++;

				// Limit link length max. to 512 bytes.
				if(ma>511) {
					mmstage = 1; // find end of A HREF-tag (">").
					ma = 0;
					continue;
				}

				// Looking for "\"".
				if(ma==strlen(str_ahref_end)) {
					// Found "\"", end of URL.
					urlend = i;

					//fprintf(stderr, "FOUND IMAGE URL (%d-%d): ", urlbeg, urlend);

					// 0    TYPE            f.e.    link
					// 1    URL             f.e.    http://www.mycookings.com/
					// 2    KEYWORDS        f.e.    [text from the page inside the ref.]
					// 3    EXTRA           f.e.    ...
					// Store "image" -type identifier.
					for(ii=0; ii<strlen(str_link); ii++,mmwrite++) {
						mm_content[mmwrite] = str_link[ii];
						//fprintf(stderr, "%c", html[ii]);
					}
					mm_content[mmwrite++] = '\n';
					// Store URL on mm_content.
					for(ii=urlbeg; ii<urlend; ii++,mmwrite++) {
						mm_content[mmwrite] = html[ii];
						//fprintf(stderr, "%c", html[ii]);
					}
					mm_content[mmwrite++] = '\n';
					//fprintf(stderr, "\n");

					mmstage = 4; // find end of AHREF-tag (">").
					ma = 0;
					continue;
				}
			}
		}

		// Look for end of A HREF-tag.
		if(mmstage==4)	{
			if( html[i]==str_ahreftagend[ma] || html[i]==str_AHREFTAGEND[ma] ) {
				ma++;
				// Looking for ">".
				if(ma==strlen(str_ahreftagend)) {
					// Found ">", end of URL.
					mmstage = 1; // Find another link.
					ma = 0; ma2 = 0;
					go_back_here = i;

					// Get link description, if any.
					strcpy(clean_link_description, "");
					for(ii2=i+1,ii3=0,wait_past_tag=0,last_char=-1; ii2<html_len && ii3<150; ii2++) {
						if(last_char==' ' && html[ii2]==' ') { continue; }
						if(html[ii2]==' ' && !ii3) { continue; }

						// break on another link ..or.. end of link tag.
						if( html[ii2]=='<' &&
							(html[ii2+1]=='/') &&
							(html[ii2+2]=='a' || html[ii2+2]=='A') )  {
							break;
						}
						if( html[ii2]=='<' &&
							(html[ii2+1]=='a' || html[ii2+1]=='A') )  {
							break;
						}
						// Skip tags.
						if(html[ii2]=='<' && !wait_past_tag) { wait_past_tag=1; continue; }
						if(html[ii2]=='>' && wait_past_tag)  { wait_past_tag=0; continue; }
						// Tag or text?
						if(!wait_past_tag) {
							// Skip control codes.
							if(iscntrl(html[ii2]) || html[ii2]==0) { continue; }
							//
							clean_link_description[ii3++] = html[ii2];
							last_char = html[ii2];
						}
					}
					clean_link_description[ii3] = 0;

					// copy to mm_content
					for(ii2=0; ii2<ii3; ii2++) {
						mm_content[mmwrite++] = toascii(clean_link_description[ii2]);
					}
					//i--;
					mm_content[mmwrite++] = '\n';
					mm_content[mmwrite++] = '\n';
					continue;
				}
			}
		}

	}

	//
	t2 = time(NULL);
	//fprintf(stderr, "t/t2 %d/%d\n", t,t2);

	// End of multimedia content.
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 11.\n", __FUNCTION__, __LINE__);
	mm_content[mmwrite]=0;



	// ** REPORT **
	if(DARDUMP_VERBOSE)
		fprintf(stderr, "%s/line %d result: ",
		__FUNCTION__,__LINE__);

	// Notifications on empty entries.
	//
	if(
		!strcmp(host,"")
		)
	{
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Empty Host] ");
	} else {
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Host: \"%s\"] ", host);
	}

	//
	if(
		!strcmp(path,"")
		)
	{
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Empty Path] ");
	}

	//
	if(
		!strcmp(title,"")
		)
	{
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Empty Title] ");
	} else {
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Page Title: \"%s\"] ", title);
 	}

	//
	if(
		!strcmp(preview,"")
		)
	{
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Empty Preview] ");
	} else {
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Preview: %s] ", preview);
	}

	//
	if(
		!strcmp(nfo,"")
		)
	{
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[Empty NFO] ");
	} else {
		if(DARDUMP_VERBOSE)
			fprintf(stderr, "[NFO: %s] ", nfo);
	}
	if(DARDUMP_VERBOSE)
		fprintf(stderr, "\n");

	// Store all on the buffer.
	int lenny = strlen(host)+strlen(path)+strlen(title)+strlen(preview)+strlen(nfo)+strlen(mm_content)+10;
	if(lenny < (l_buf-4)) {
		if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 12.\n", __FUNCTION__, __LINE__);
		RemoveControlCodes(host);
		RemoveControlCodes(path);
		RemoveControlCodes(title);
		RemoveControlCodes(preview);
		RemoveControlCodes(nfo);
		RemoveControlCodes(meta_description);
		RemoveControlCodes(meta_keywords);
		if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 12B.\n", __FUNCTION__, __LINE__);
		if( !strlen(meta_description) ) {
			// Search one long quotation (40*4) chars.
			WLISEARCH_find_one_long_quotation = 1;
			sscanf(title, "%s", &wli_keyword_str); // use first word in the title for searching (WliSearch)
			//=F=
			test_ptr = WliSearch(sid, wli_keyword_str, index_to_use);
			if(test_ptr!=NULL)
			{
				strcpy(meta_description, test_ptr);
			}
			else
			{
				strcpy(meta_description, "");
			}
			//strcpy(meta_description, preview);
		}
		if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 13.\n", __FUNCTION__, __LINE__);
		//RemoveControlCodes(mm_content);
		sprintf(buf, "[BASIC PAGE INFO]\nhost=%s\npath=%s\ntitle=%s\nmeta_description=a%s\nnfo=%s\nbigfn=%s\npreview=%s\nmeta_keywords=%s\n\n[MULTIMEDIA AND OTHER CONTENT]\n%s\n",
			host,
			path,
			title,
			meta_description,
			nfo,
			bigfn,
			preview,
			meta_keywords,

			mm_content);
	} else {
		// Oops
		sprintf(buf, "\n\n\n\n%s line %d: TEXT CONTENT TOO LARGE FOR buf/l_buf (%d), content length=%d\n",
			__FUNCTION__, __LINE__, l_buf,lenny);
	}

	//
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 14.\n", __FUNCTION__, __LINE__);
	SafeFree(html);
	SafeFree(dump);
	SafeFree(mm_content);
	SafeFree(raw_link_description);
	SafeFree(clean_link_description);
	if(SUPER_DEBUGGING) fprintf(stderr, "%s line %d: guard 15.\n", __FUNCTION__, __LINE__);

	//
	return 0;
}


//
Html2Text(char *html, int l_html,
	char *buf,int l_buf,
	int wlen)
{
	int i,i2,i3,i4,i5,tag,lastch,ch;

	// Writes output without <TAGs></TAGs>
	for(i=0,tag=0,lastch; i<l_html && i2<l_buf && i2<wlen; i++)	{
		if(tag==0) {
			ch = html[i];
			if(ch=='<') {
				tag=1;
				continue;
			}
			if( iscntrl(ch) ) { ch=' '; }
			if( !(html[i]==' ' && lastch==' ') )
				buf[i2++] = html[i];
			lastch = html[i];
		}
		if(tag==1) {
			if(html[i]=='>') {
				tag=0;
				buf[i2++] = ' ';
				continue;
			}
		}
	}
	buf[i2]=0;

	//
}

