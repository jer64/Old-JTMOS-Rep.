// is_main.c - command line interface functionality.
// (C) 2011-2016 Jari Tuominen (jari.t.tuominen@gmail.com).
#include <stdio.h>
#include "selib.h"
#include "inde.h"
#include "inde_loadwords.h"
#include "inde_saveresults.h"

/////////////////////////////////////////////////////////////////////////////
//
int main(int argc, char **argv)
{
	int i,pages_loaded;
	INDE *in;

	// SEE beginning of inde.c for settings
	////inde_debug = TRUE;
	inde_start_time = time(NULL);

	//
	in = &inde;

	//
        AltseLoadConfig();
	// Output path.
	sprintf(GLOP, "%s/altse/cid/dict",
		database_path);
	//
	is_LoadConfig();

	////////////////////////////////////////////////////////////////////////////////
	//
	if(argc<2)
	{
		//
		fprintf(stderr, "inde.c version 2.0 (7/2011)\n");
		fprintf(stderr, "Usage: inde [page numbers] [options]\n");
		fprintf(stderr, "Example 1: inde 0 1 2 3 4 5 6 7 8 9 10  indexes these pages\n");
		fprintf(stderr, "Example 2: inde 0 1 2 3 -p0,6           use priority leels from 0 to 6\n");
		fprintf(stderr, "Example 3: inde 0 1 2 3 -o /tmp         saves index files to /tmp\n");
		fprintf(stderr, "Example 4: inde 0 1 2 3 -i 0             outputs to index 0 (default)\n");
		fprintf(stderr, "Example 5: inde 0 1 2 3 -i 4             outputs to index 4\n");
		fprintf(stderr, "- Define prisec's (ranks) which to index:\n");
		fprintf(stderr, "Example 6: inde -p0,0 OR -p0,6 OR -p1,1 etc.: from 0 to 0, from 0 to 6\n");
		fprintf(stderr, "Options:\n");
		fprintf(stderr, "-o [path]          output to this path\n");
		fprintf(stderr, "-a preview [keyword]        only accept this\n");
		fprintf(stderr, "-a title [keyword]          only accept this\n");
		fprintf(stderr, "-a path [keyword]           only accept this\n");
		fprintf(stderr, "-a host [keyword]           only accept this\n");
		fprintf(stderr, "-a keywords [keyword]       only accept this\n");
		fprintf(stderr, "-a description [keyword]    only accept this\n");
		fprintf(stderr, "-o [path]          output to this path\n");
		fprintf(stderr, "-o [path]          output to this path\n");
		fprintf(stderr, "-o [path]          output to this path\n");
		fprintf(stderr, "-i [output index]  use this output index\n");
		fprintf(stderr, "-pX,Y              use prirization (optimization) using levels X to Y\n");
		fprintf(stderr, "-v                 turn on verbose mode (debugging)\n");
		fprintf(stderr, "-vv                turn on super verbose mode (debugging)\n");
		fprintf(stderr, "\n");
		fprintf(stderr, "Note: inde defaults to index number 0, if -i is not defined.\n");
		return 0;
	}

	////////////////////////////////////////////////////////////////////////////////
	//
	// Fetch options.
	//
	for(i=1; i<argc; i++)
	{
		// -o. OR -o/tmp
		if( !strncmp(argv[i],"-o", 2) )
		{
			strcpy(GLOP, argv[i]+2);
		}

		// inclusive preview [keyword]
		if( !strncmp(argv[i],"-a preview", 10) )
		{
			strcpy(inclusive_preview, argv[i]+11);
		}
		// inclusive title [keyword]
		if( !strncmp(argv[i],"-a title", 8) )
		{
			strcpy(inclusive_title, argv[i]+9);
		}
		// inclusive path [keyword]
		if( !strncmp(argv[i],"-a path", 7) )
		{
			strcpy(inclusive_path, argv[i]+8);
		}
		// inclusive host [keyword]
		if( !strncmp(argv[i],"-a host", 7) )
		{
			strcpy(inclusive_host, argv[i]+8);
		}
		// inclusive keywords [keyword]
		if( !strncmp(argv[i],"-a keywords", 11) )
		{
			strcpy(inclusive_keywords, argv[i]+12);
		}
		// inclusive description [keyword]
		if( !strncmp(argv[i],"-a description", 14) )
		{
			strcpy(inclusive_description, argv[i]+15);
		}

		// Define prisec's (ranks) which to index.
		// -p0,0 OR -p0,6 OR -p1,1 etc.
		if( !strncmp(argv[i],"-p", 2) )
		{
			sscanf(argv[i]+2,"%d,%d",&min_prisec,&max_prisec);
			OPTIMIZE_FOR_SEARCH_SPEED = 1;
		}

		// Define which output index to be used.
		// -i 1 (default is 0).
		if( !strncmp(argv[i],"-i", 2) )
		{
			sscanf(argv[i]+3,"%d",&ProductionIndexNr);
		}

		// Debug -v
		if( !strncmp(argv[i],"-v", 2) )
		{
			inde_verbose = 1;
		}

		// Debug -vv
		if( !strncmp(argv[i],"-vv", 3) )
		{
			inde_verbose = 1;
			inde_debug = 1;
			inde_debug_verbose = 1;
		}
	}

	////////////////////////////////////////////////////////////////////////////////
	//
	InitInde(in);

	////////////////////////////////////////////////////////////////////////////////
	//
	// Count words.
	//
	inde.n_files = argc;
	if(inde_verbose) {
		fprintf(stderr, "%s/%s: Loading words from pages ...",
			__FILE__, __FUNCTION__);
	}
	for(i=1,pages_loaded=0; i<argc; i++)
	{
		//
		if(inde_verbose) {
			fprintf(stderr, "%s - %d/%d       \r",
				argv[i],
				in->n_ent,
				in->max_ent);
		}
		// Process pages, ignore option strings.
		if(strncmp(argv[i],"-",1)) {
			LoadWords(argv[i], in);
			pages_loaded++;
		} else {
			break;
		}
	}
	if(inde_verbose) {
		fprintf(stderr, "%s/%s: Page words loaded.",
			__FILE__, __FUNCTION__);
	}
	if(!pages_loaded) {
		fprintf(stderr, "No pages defined, exiting . .\n");
		return 0;
	}

	////////////////////////////////////////////////////////////////////////////////
	//
	// Display results.
	//
	if(inde_verbose) {
		fprintf(stderr, "\nSorting entries ...\n");
	}
	SortResults(in);
	if(inde_verbose) {
		fprintf(stderr, "Saving entries ...\n");
	}
	SaveResults(in);

	// Return OK.
	return 0;
}
