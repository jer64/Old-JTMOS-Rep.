#!/usr/bin/perl
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$testper = 10;

#
main();

#
sub main
{
	#
	@lst = LoadList("/usr/share/dict/words");

	#	
	for($i=0,$st=time; (time-$st)<$testper; $i++)
	{
		$ri = sprintf("%d", rand($#lst));
		$str = $lst[$ri];
		$str =~ s/[^a-zA-Z0-9]+/ /g;
		printf "%d/$testper: $str              \r", $testper-(time-$st);
		system("is $str 1> /dev/null");
	}
	printf("\nPerformance = %d searches per second\n", $i/$testper);

	#
}

#
