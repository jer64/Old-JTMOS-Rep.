// altse.c
// see selib.c for more settings
// (C) 2004-2011 Jari Tuominen (jari.t.tuominen@gmail.com).
#include <stdio.h>
#include "selib.h"
#include "altse.h"

//
char database_path[8192];
char WLI_BIGFN[8192];
char dictloc[8192]; // used by is.c
char IS_CFG_FILE[8192];

//
int ALTSE_N_RANKS=		2;
int SCORE_FOR_PAIRS=		10000000;
int SCORE_FOR_RANK=		1000000;
//
int OPTIMIZE_FOR_SEARCH_SPEED=	0;

// NOTE: these values are read [in most cases]
// from the central configuration file.

// is - internet search configuration
// **********************************
// How far we are ready to go in a dictionary, in bytes.
// (this specifies how much time IS will spend looking on a single dictionary)
DWORD MAX_DIVING_DEPTH=		(1024*1024*200);
// Max. amount of RAM to spend for results.
DWORD RESULT_SPACE_BYTES=	(1024*1024*100);

// Max. amount of locations to store per entry.
int MAX_LOCS=			10;
int MAX_RANK=			100;

// Keep this low to prevent long, time taking, queries.
int N_MAX_SEARCH_WORDS=		4;
// Max. number of hosts to remember per search.
int N_MAX_HOSTS=		200000;
//
int N_MIN_EXPECT_ENTRIES=	10;
//
int N_CHARS_MATTER=		1;

// Index used by is.c.
int ActiveIndexNr = -1;
// Index used by inde.c, dicwipe.
int ProductionIndexNr = -1;

//
char inclusive_preview[512];
char inclusive_title[512];
char inclusive_path[512];
char inclusive_host[512];
char inclusive_keywords[512];
char inclusive_description[512];

//
static char *vars[]={
	"ALTSE_N_RANKS",	&ALTSE_N_RANKS,
	"ACTIVE_INDEX_NR",	&ActiveIndexNr,
	"PRODUCTION_INDEX_NR",	&ProductionIndexNr,
	"N_CHARS_MATTER",	&N_CHARS_MATTER,
	"SCORE_FOR_PAIRS",	&SCORE_FOR_PAIRS,
	"SCORE_FOR_RANK",	&SCORE_FOR_RANK,
	"MAX_DIVING_DEPTH",	&MAX_DIVING_DEPTH,
	"RESULT_SPACE_BYTES",	&RESULT_SPACE_BYTES,
	"MAX_LOCS",		&MAX_LOCS,
	"MAX_RANK",		&MAX_RANK,
	"N_MAX_SEARCH_WORDS",	&N_MAX_SEARCH_WORDS,
	"N_MAX_HOSTS",		&N_MAX_HOSTS,
	"N_MIN_EXPECT_ENTRIES",	&N_MIN_EXPECT_ENTRIES,
	"OPTIMIZE_FOR_SEARCH_SPEED",	&OPTIMIZE_FOR_SEARCH_SPEED,
	"*",			"*"
};

//
void AltseLoadConfig(void)
{
	FILE *f;
	char fn[8192];

        //------------ LOAD CONFIGURATION -----------------
        //
        f = fopen(ETC_ALTSE_CONF, "rb");
        if(f==NULL) {
		sprintf( fn, "%s/.altserc", getenv("HOME") );
	        f = fopen(fn, "rb");
	        if(f==NULL) {
			printf(stderr, "Can't find %s !\n", ETC_ALTSE_CONF);
			exit(1);
		}
	}
        fscanf(f, "%s", database_path);
	if( !strcmp(database_path, "") ) {
		fprintf(stderr, "Error: database_path undefined, check /etc/altse.conf\n");
		exit(-2);
	}
	sprintf(WLI_BIGFN, "%s/cid/data/words", database_path);
	sprintf(dictloc, "%s/cid/dict", database_path);	
	sprintf(IS_CFG_FILE, "%s/altse/cfg/is.cfg", database_path);	
        fclose(f);

	//
	is_LoadConfig();
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// Set configuration variable.
//
void is_SetVar(char *key, char *val)
{
	int i,i2,dv;

	//
	for(i=0; strcmp(vars[i], "*"); i+=2)
	{
		//
		if(!strcmp(vars[i], key))
		{
			sscanf(val, "%d", vars[i+1]);
		}

		//
	}

	//
}

//////////////////////////////////////////////////////////////////////////////////////////
//
void is_LoadConfig(void)
{
        FILE *f;
	static char key[256],val[256],str[256];
	int i,i2,i3,i4,l;

	//
	strcpy(inclusive_preview, "");
	strcpy(inclusive_title, ""),
	strcpy(inclusive_path, "");
	strcpy(inclusive_host, "");
	strcpy(inclusive_keywords, "");
	strcpy(inclusive_description, "");

        //
/*	fprintf(stderr, "Loading configuration from %s.\n",
		IS_CFG_FILE);*/
        f = fopen(IS_CFG_FILE, "rt");
	if(f==NULL) { fprintf(stderr, "%s: can't read configuration file: %s\n", __FUNCTION__, IS_CFG_FILE); exit(1); }

        //
        while(!feof(f))
        {
                //
		strcpy(key, "");
		strcpy(val, "");
		fgets(str, 250 ,f);

		l = strlen(str);

		for(i=0,i2=0; i<250 && i<l; i++)
		{
			if(str[i]=='=') { break; }
			key[i2++] = str[i];
		}
		key[i2]=0; i++;

		for(i2=0; i<250 && i<l; i++)
		{
			val[i2++] = str[i];
		}
		val[i2]=0;

		//
		if( !strcmp(key, "") ) { break; }

		//
		//fprintf(stderr, "%s=%s\n", key,val);
		//
		is_SetVar(key,val);
        }

        //
        fclose(f);

	//
	if(ActiveIndexNr==-1 || ProductionIndexNr==-1)
	{
		printf("FATAL ERROR!\n");
		printf("ACTIVE_INDEX_NR or PRODUCTION_INDEX_NR not found\n");
		abort();
	}
}
