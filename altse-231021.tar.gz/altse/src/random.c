#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	int random_number,n_max;

	if(argc<2) {
		fprintf(stderr, "Usage: random [max. number]\n");
		return 0;
	}

	sscanf(argv[1], "%d", &n_max);
	srand(time(NULL));
	random_number = rand() % n_max;
	printf("%d", random_number);
	return 0;
}
