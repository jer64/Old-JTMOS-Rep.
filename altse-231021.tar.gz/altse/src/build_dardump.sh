#!/bin/bash
TARGET_PATH="../bin"
BUILDOPT=" -g3 -w -m32 -O2"
echo "Building dardump and friends ..."
gcc-9 $BUILDOPT -o $TARGET_PATH/dardump dardump.c dardumpMain.c wlisearch.c selib.c altse.c htmlproc.c -w
gcc-9 $BUILDOPT -o $TARGET_PATH/wlidump wlidump.c wlidumpMain.c selib.c altse.c htmlproc.c -w
gcc-9 $BUILDOPT -o $TARGET_PATH/htmldump htmldump.c htmldumpMain.c selib.c altse.c htmlproc.c -w #-lz

