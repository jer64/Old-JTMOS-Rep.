#!/usr/bin/perl
# cleanwww.pl - Clean up www-cache using already.txt -index files.
# Removes duplicate pages.
# pageids2fn: Page IDs to file name -conversion database.
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use Cwd 'chdir';

#
AltseOpenConfig();

# pageids2fn: Page IDs to file name -conversion database.
$PAGEIDSPATH = "pageids2fn";

#
main();

#
sub main
{
	my ($i,$i2,@lst,$str,$str2,$url,$f,$path,%ald,
		$n1,$n2,$n3,$n4,$n5,$n6,$n7,$n8,$n9,$n10,
		$hexx,$fn,$fn2);

	my $filterer;

	##
	$filterer = "";
	if($ARGV[0] ne "") {
		$filterer = $ARGV[0];
	}

	#
	print STDERR "cleanwww.pl running ...\n";

	#
	@lst = LoadList("$DB/www/list.txt");

	#
	chdir("$DB");
	#
	mkdir($PAGEIDSPATH);

	#
	my $PPF = 2000;
	my $SUB = 200;
	my $nn = 0;
	loop: for($i=0,$lt=0,$t=0,$nn=0; $i<($#lst+1); $i++) {
		$sect = int($nn / $PPF)	% $PPF; # N paths per file
		$n1 = int($sect/$SUB)	% $SUB;	# N files per directory
		$n2 = int($n1/$SUB)	% $SUB;	# N subdirectories at most per directory
		$n3 = int($n2/$SUB)	% $SUB;	# N subdirectories at most per subdirectories
		$n4 = int($n3/$SUB)	% $SUB;	# N subdirectories at most per subdirectories
		$path = sprintf $PAGEIDSPATH . "/%d/%d/%d/%d",
			$n4,$n3,$n2,$n1;
		$fn = sprintf "$path/%d.dat",
			$sect;
		system("mkdir -p \"$path\"");

		$t = time();
		if($t != $lt) {
			$lt = $t;
			print STDERR "$i / $#lst ($nn pages, \"$lst[$i]\", $lpid/$#already)       \r";
		}

		open($f, ">$fn");
		for($i2=0; $i2<$PPF && $i<($#lst+1); $i++) {

			# ./wor/wordpress.tv/2853.dump.gz
			my $alfn1 = $lst[$i];
			$alfn1 =~ s/^(.+)\/([^\/]+)$/$1/;
			$alfn1 =~ s/\.\///;
			my $alfn = "$DB/www/$alfn1/already.txt";
			if(!defined($allo{$alfn})) {
				$allo{$alfn}++;
				if(!-e $alfn) {
					print STDERR "PAGE CACHE INDEX FILE FILE NOT FOUND: $alfn\n";
					# Remove with rm -rf any directory without any files. Clean up space.
				} else {
					@already = LoadList($alfn);

					# lpid = local page ID
					my $lpid = $lst[$i];
					$lpid =~ s/^.+\/([0-9]+).+$/$1/;
					my $url = $already[$lpid];
					print STDERR "Checking page cache index: $alfn ... ";
					## Write new index (write empty \n lines on duplicates).
					my ($i5,$newindex_str,$need_to_write,%getrid);
					$need_to_write = 0;
					$newindex_str = "";
					for($i5=0; $i5<($#already+1); $i5++) {
						$getrid{$already[$i5]}++;
						if($getrid{$already[$i5]}>1) {
							# change: remove duplicate with empty line
							$need_to_write++;
							$newindex_str .= "\n";
						} else {
							# same old: build old data as it was
							$newindex_str .= "$already[$i5]\n";
						}
					}
					if($need_to_write) {
						print STDERR "Dirty index.\n> Index cleaned up - writing updated index (already.txt) ... ";
						my $alf;
						open($alf, ">$alfn") || die "Sigh.. Can't write $alfn ...\n";
						print $alf "$newindex_str";
						close($alf);
						print STDERR "Done.\n";
					} else {
						print STDERR "Clean.\n";
					}
				}
			} else {
			}
		}
		close($f);
	}

	open($f, ">".$PAGEIDSPATH."/id.cnt");
	print $f "$nn\n";
	close($f);

	#
	my $ff;
	open($ff, ">$DB/cid/gid.txt") || die "Can't write \"$DB/gid.txt\"\n";
	print $ff $nn;
	close($ff);

	print STDERR "\nFinished.\n";

	#
}

#

