#!/bin/bash
#
alias gcc="gcc-9"
BUILDOPT=" -O4 -w -m32"
TARGET_PATH="../bin"
#
echo "Building is"
gcc-9 $BUILDOPT -o $TARGET_PATH/is is.c is_dicsinglefind.c is_main.c is_searchindexes.c is_processresults.c \
iscfg.c wlidump.c htmlproc.c dardump.c wlisearch.c selib.c altse.c  -lpthread #-lz
gcc-9 $BUILDOPT -o $TARGET_PATH/ispub -DDICTLOC=\"/db/sdb/cid/pubdict\" is.c is_dicsinglefind.c is_main.c is_searchindexes.c is_processresults.c iscfg.c wlidump.c htmlproc.c dardump.c wlisearch.c selib.c altse.c  -lpthread #-lz
gcc-9 $BUILDOPT -o $TARGET_PATH/isv is.c is_dicsinglefind.c is_searchindexes.c is_processresults.c \
	isView.c iscfg.c wlidump.c dardump.c htmlproc.c wlisearch.c selib.c altse.c  -lpthread #-lz
