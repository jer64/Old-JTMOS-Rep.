//
#ifndef __INCLUDED_INDE_LOADWORDS_H__
#define __INCLUDED_INDE_LOADWORDS_H__

//
int LoadWords(char *str_sid,
        INDE *in);

#endif

