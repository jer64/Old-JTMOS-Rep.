#!/bin/bash
/usr/share/awstats/tools/awstats_buildstaticpages.pl -config=istrump.life -update -awstatsprog=/usr/lib/cgi-bin/awstats.pl -dir=/home/vai/altse/html/www/cache/aw/


