#!/bin/bash
echo "./tssdes 69e8ffff 108b14"
./tssdes 69e8ffff 108b14
