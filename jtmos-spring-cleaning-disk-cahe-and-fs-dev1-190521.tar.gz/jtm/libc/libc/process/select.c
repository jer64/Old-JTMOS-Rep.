//
#include <stdio.h>
#include "select.h"

// A dummy function. (TODO: Later this function should work.)
int select(int n, fd_set *readfds, fd_set *writefds,
	fd_set *exceptfds, struct timeval *timeout)
{
	return -EBADF;
}

//


