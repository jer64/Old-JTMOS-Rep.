#ifndef __INCLUDED_XXIDENTIFICATION_H__
#define __INCLUDED_XXIDENTIFICATION_H__

extern char *XXidentificationString;

#endif


