//
#ifndef __INCLUDED_MEMCMP_H__
#define __INCLUDED_MEMCMP_H__

//
int
memcmp (s1, s2, len)
     const __ptr_t s1;
     const __ptr_t s2;
     size_t len;
//int memcmp(const void *dstpp, const void *srcpp, int len);

#endif




