//
#ifndef __INCLUDED_INIT_H__
#define __INCLUDED_INIT_H__

//
void init_libc(void);
extern int main(int argc,char **);

#endif
