#ifndef __INCLUDED_JTMLIBC_LONGJMP_H__
#define __INCLUDED_JTMLIBC_LONGJMP_H__

#include "process.h"
void longjmp(jmp_buf env, int val);

#endif

