#ifndef __INCLUDED_GUIDESKTOPDRAW_H__
#define __INCLUDED_GUIDESKTOPDRAW_H__

int guiDesktopDraw(VMODE *v, int x1,int y1, int x2,int y2);
int guiDesktopDraw8(VMODE *v, int x1,int y1, int x2,int y2);

#endif

