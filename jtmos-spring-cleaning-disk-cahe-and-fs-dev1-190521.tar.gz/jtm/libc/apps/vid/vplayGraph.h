//
#ifndef __INCLUDED_VPLAYGRAPH_H__
#define __INCLUDED_VPLAYGRAPH_H__

//
void setpalette(unsigned char _color,
     unsigned char _rrr,unsigned char _ggg,unsigned char _bbb);
void greyscale256(void);
void openGraphics(void);
void closeGraphics(void);
void vf(char *__videoframe);
void setvmode(unsigned _mode);

#endif




