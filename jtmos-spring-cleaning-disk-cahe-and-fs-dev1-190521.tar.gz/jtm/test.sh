#!/bin/bash
echo > $(date +%d%m%y)
