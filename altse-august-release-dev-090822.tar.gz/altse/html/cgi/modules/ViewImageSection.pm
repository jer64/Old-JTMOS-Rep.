# Usage: ViewImageSection("7");
sub ViewImageSection
{
	        #
		my $page_gid = join("\n", LoadList("gid $_[0]|"));
		$ViewImageURL_nr = 0;
		print $page_gid;
		for(my $page=0; $page<$page_gid; $page++) {
		        @lst = LoadList("dardump $page $_[0]|");
		        #
		        for($i=0; $i<($#lst+1); $i++)
		        {
		                #
				if($lst[$i+0] ne "image") {
					goto skip;
				}
	
		                #
		                ViewImageURL($lst[$i+0]);
skip:
			}

	#
}

# Usage: ViewImageURL [URL]
# Example: ViewImageURL [http://www.imageserver.com/image.jpg]
sub ViewImageURL
{
	if( (($ViewImageURL_nr++) & 15)==0 ) {
		print("<TABLE width=800><TR height=64>");
	}
	print("
	<TD width=64>
	<A HREF=\"$_[0]\" alt=\"porn, pornoa\" title=\"Click here !\">
	<IMG SRC=\"$_[0]\" alt=\"porn, pornoa\" title=\"Click here !\"
		width=64 height=64>
	</A>
	</TD>
		");
	}
	if( (($ViewImageURL_nr) & 15)==15 ) {
		print("</TR></TABLE>");
	}

	#
	$ViewImageURL_nr++;

	#
}

TRUE;
