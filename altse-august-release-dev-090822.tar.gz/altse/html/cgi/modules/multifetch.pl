#!/usr/bin/perl
# MULTI FETCH
# Fetches multiple results, instead of max. paired search normally.
##############################################################################
#
if($ENV{'HOME'} eq "" || $ENV{'HOME'} =~ /^\/root$/) {
        $ENV{'HOME'} = "/home/vai";
} else
{
}
#print "ENV/HOME = \"$ENV{'HOME'}\".\n";
require "$ENV{'HOME'}/altse/html/cgi/modules/AltseOpenConfig.pm";
require "$ENV{'HOME'}/altse/html/cgi/modules/LoadList.pm";
#
AltseOpenConfig();

#
main();

#
sub main
{
        my ($i,$i2,$i3,$i4);

        #
        for($i=0; $i<($#ARGV+1); $i++)
        {
                if(
                        ($ARGV[$i] eq "www" ||
                        $ARGV[$i] eq "com" ||
                        $ARGV[$i] eq "org" ||
                        $ARGV[$i] eq "info" ||
                        $ARGV[$i] eq "net")
                ) { goto dont_search_this_one; }
        
                @results = LoadList("$ENV{'HOME'}/altse/bin/is $ARGV[$i] -mp 21 -q|");

                #if($i>=1)
                #{
                        for($i2=0; $i2<($#results+1); $i2++)
                        {
                                my ($key,@sp);
                                @sp = split(/ /, $results[$i2]);
                                $key = $sp[1]; # key = page number
                                $al{$key} += $sp[0]; # add up the score
                                #print $sp[0]."\n";
                        }
                #}

                #
dont_search_this_one:
        }

        #
        my (@ent);
        
        #
        foreach $key (keys %al)
        {
                push(@ent, (sprintf "%1.8d %d", $al{$key},$key));
        }
        
        #
        @ent = reverse sort @ent;
        
        #
        for($i=0; $i<($#ent+1); $i++)
        {
                print $ent[$i] . "\n";
        }
        
        #
        
        #
        
}

#
