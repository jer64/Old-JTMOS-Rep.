#
sub JsArray
{
	my $str = $_[0];
	$str = FixForJS($str);	
        return ("$str");
}

#
sub FixForJS
{
	my $str;
	$str = $_[0];
        $str =~ s/\n/\\\n/g;
        $str =~ s/[\t\r\s]/ /g;
        $str =~ s/\\/ /g;
        $str =~ s/  / /g;
        $str =~ s/\"/\\\"/g;
	return $str;
}

1;
