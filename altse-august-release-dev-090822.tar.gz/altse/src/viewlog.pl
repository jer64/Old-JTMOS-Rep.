#!/usr/bin/perl
###################################################################################
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
main();

###################################################################################
#
sub IgnoreHost
{
	#
	if( $_[0] =~ /winxp$/ ) { return 1; }
	if( $_[0] =~ /looksmart\.com$/ ) { return 1; }
	if( $_[0] =~ /googlebot\.com$/ ) { return 1; }
	if( $_[0] =~ /\.ask\.com$/ ) { return 1; }
	if( $_[0] =~ /\.kanetti\.fi$/ ) { return 1; }
	if( $_[0] =~ /192\.168\.0\.[0-9]/ ) { return 1; }
	if( $_[0] =~ /vunet\.org/ ) { return 1; }
	if( $_[0] =~ /67\.43\.164\.85/ ) { return 1; }
	if( $_[0] =~ /193\.64\.244\.185/ ) { return 1; }

	#
	return 0;
}

###################################################################################
#
sub main
{
	my (@lst,@sp,$i,$i2,$i3,$i4,
		$host,$date,$fetch);

	#
	@lst = LoadList("/var/log/apache/access_log");

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		@sp = split(" ", $lst[$i]);

		#
		$host = $sp[0];
		$date = $lst[$i];
		$date =~ s/^[^\[]*\[(.*)\].*$/$1/;
		$fetch = $lst[$i];
		$fetch =~ s/^[^\"]*\"(.*)\".*$/$1/;

		#
		if( !IgnoreHost($host) )
		{
			#
			print "[$date] $host $fetch\n";
		}
	}

	#
}
