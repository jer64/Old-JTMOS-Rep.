/////////////////////////////////////////////////////////////////////////////
//
// inde_loadwords.c - index builder - primary functionality.
// (C) 2005-2011 by Jari Tuominen (jari@vunet.org).
// Builds index files (DIC) out of word lists (WLI).
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "inde_loadwords.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"

/////////////////////////////////////////////////////////////////////////////
//
int LoadWords(char *str_sid,
	INDE *in)
{
	FILE *f;
	DWORD i,i2,i3,i4,gid,rank,l,pgp,sid,x,l_tmp;
	int decimal_i,er;
	static char str[4096];
	static char fn_dar[2560],fn_wli[2560];
	static BYTE *tmp;
	static char host[50000],path[50000],path2[50000],title[50000],preview[50000],nfo[50000],
		description[81920],
		keywords[81920],
		author[81920],
		pagebeg[81920],pageend[81920];
	int page_date,line_nr;
	DWORD hsum,dots;
	static char **wl;
	int n_wl;
	BYTE *html;
	ENT *e;
	// Creation date for the dardump's file.
	struct stat sb;
	int file_age;

	//
	if(in==NULL) {
		fprintf(stderr, "%s/%s/line %d [error]: Does not work because: in == NULL\n",
				__FILE__, __FUNCTION__, __LINE__);
		exit(2);
	}

	//
	fprintf(stderr, "%s, time spent %d: loading words (page %s)        \r",
		__FILE__, time(NULL)-inde_start_time, str_sid);

	// Allocate pointers.
	if(inde_debug) {
		fprintf(stderr, "%s/%s: Allocating pointers\n",
			__FILE__, __FUNCTION__);
	}
	if(wl==NULL) { wl = imalloc(sizeof(void*) * MAX_WL); }
	if(wl==NULL) {
		fprintf(stderr, "%s/%s/line %d [error]: imalloc returned NULL, presumably due to out of memory? *OUT OF MEMORY*\n",
				__FILE__, __FUNCTION__, __LINE__);
		exit(1);
	}

	//
	sscanf(str_sid, "%d", &sid);
	if(inde_debug) {
		fprintf(stderr, "%s/%s/line %d [debug]: page ID (var.: sid) = %d\n",
				__FILE__, __FUNCTION__, __LINE__,
				sid);
	}

	//
	gid = sid;

	//---------------------------------------------------------------------
	//
	//
	if(inde_debug) {
		fprintf(stderr, "%s/%s: running dardump(%d, %1.8x, %d, %d);\n",
			__FILE__, __FUNCTION__,
			sid,tmp,MAX_WWW_PAGE_SZ,
			ProductionIndexNr);
	}
	if(inde_debug) {
		fprintf(stderr, "%s/%s/%d line: attempting to call imalloc\n",
			__FILE__, __FUNCTION__, __LINE__);
	}
	tmp = imalloc(MAX_WWW_PAGE_SZ);
	if(tmp==NULL) {
		fprintf(stderr, "%s/%s/line %d [error]: Does not work: tmp = imalloc(MAX_WWW_PAGE_SZ);\n",
				__FILE__, __FUNCTION__, __LINE__);
		exit(-4);
	}
	if(inde_debug) {
		fprintf(stderr, "%s/%s/%d line: calling imalloc succeeded\n",
			__FILE__, __FUNCTION__, __LINE__);
	}

	er = DarDump(sid, tmp, MAX_WWW_PAGE_SZ, ProductionIndexNr);

	// Process error.
	if(er) {
		return;
	}

	if(inde_debug) {
		fprintf(stderr, "%s/%s/%d line: stat dardump_global_page_dump_fn, &gb\n",
			__FILE__, __FUNCTION__, __LINE__);
	}
	if(stat(dardump_global_page_dump_fn, &sb)!=-1) {
		int file_age = time(NULL) - ((unsigned int)&sb.st_mtime);
	} else {
		file_age = -1;
	}
	if(inde_debug) {
		fprintf(stderr, "%s/%s/%d line: file_age = %d\n",
			__FILE__, __FUNCTION__, __LINE__,
			file_age);
	}

	//
	if(inde_debug) {
		fprintf(stderr, "%s/%s: GetLine - of host,path,title,preview,nfo\n",
			__FILE__, __FUNCTION__);
	}
	strcpy(host, "");
	strcpy(path, "");
	strcpy(title, "");
	strcpy(preview, "");
	strcpy(nfo, "");
	// Get host, path, title, preview nfo (dardump).
	for(line_nr=0; line_nr<100; line_nr++) {
		GetLine(tmp,4900, line_nr, (BYTE*)str);
		if( !strcmp(str, "[BASIC PAGE INFO]") ) {
			line_nr++;
			break;
		}
	}
	GetLine(tmp,4900, line_nr, (BYTE*)host);	line_nr++;
	GetLine(tmp,4900, line_nr, (BYTE*)path);	line_nr++;
	GetLine(tmp,4900, line_nr, (BYTE*)title);	line_nr++;
	GetLine(tmp,4900, line_nr, (BYTE*)preview);	line_nr++;
	GetLine(tmp,4900, line_nr, (BYTE*)nfo);		line_nr++;
	line_nr++; // skip absolute local path variable, "/home/db/..."
	//

	// generate checksum of host name
	hsum = smart_csum((BYTE*)host, strlen(host));
	FixString1(host);
	FixString1(path);
	FixString1(title);
	FixString1(preview);
	if( strcmp(inclusive_host, "") &&
		!strstr(host, inclusive_host) ) {
		return 2;
	}
	if( strcmp(inclusive_path, "") &&
		!strstr(path, inclusive_path) ) {
		return 2;
	}
	if( strcmp(inclusive_title, "") &&
		!strstr(title, inclusive_title) ) {
		return 2;
	}
	if( strcmp(inclusive_preview, "") &&
		!strstr(preview, inclusive_preview) ) {
		return 2;
	}

	//
	l = strlen(host);
	for(i=0,dots=0; i<l; i++) { if(host[i]=='.') { dots++; } }

	//
	pgp = 0;

	// Skip empty hosts.
	if( !strcmp(host, "") ) {
		fprintf(stderr, "%s line %d: host is EMPTY\n",
			__FUNCTION__, __LINE__);
		SafeFree(tmp);
		return 1;
	}

	//
	if( !strcmp(path, "") || !strcmp(path,"/") )
	{
		//
		pgp |= WORD_TYPE_HIGH_PROFILE;

		//
		if( (dots<=2 && !strncmp(host,"www.",4)) )
		{
			pgp |= WORD_TYPE_PORTAL;
		}
	}

	//
	strcpy(description, "");
	strcpy(keywords, "");
	strcpy(author, "");

	int html_len = 1024*512;
	// Get some important meta tags...
	if(inde_debug) {
		fprintf(stderr, "%s/%s: running HtmlDump ...\n",
			__FILE__, __FUNCTION__);
	}
	html = imalloc(html_len);
	HtmlDump(sid, html,html_len, ProductionIndexNr);
	if(html!=NULL)
	{
		//
		LowerCaseString(html);
		//
		GetMetaTag(html, "description", description);
		GetMetaTag(html, "keywords", 	keywords);
		//
		FixString1(description);
		FixString1(keywords);
		if( strcmp(inclusive_description, "") &&
			!strstr(description, inclusive_description) ) {
			return 2;
		}
		if( strcmp(inclusive_keywords, "") &&
			!strstr(keywords, inclusive_keywords) ) {
			return 2;
		}
		
		//
		SafeFree(html);
	}

	// Calculate rank from A) host, B) path, C) description, D) keywords, E) file age.
	in->rank = 1000-GetRank(host,path,description,keywords,file_age);
	if(in->rank<0) {
		in->rank = 0;
	}

	//
	if(inde_verbose) {
		fprintf(stderr, "(%d) %s\n", in->rank, host);
	}

	// Ignore robots.txt.
	if( !strcmp(path, "robots.txt") )
	{
		return 0;
	}

	//---------------------------------------------------------------------
	//
	if(inde_debug) {
		fprintf(stderr, "%s/%s: Running WliDump ...\n",
			__FILE__, __FUNCTION__);
	}

	// MULTIMEDIA CONTENT.
	// Get host, path, title, preview nfo (dardump).
	for(; line_nr<200000; line_nr++) {
		GetLine(tmp,4900, line_nr, (BYTE*)str);
		if( !strcmp(str, "[MULTIMEDIA AND OTHER CONTENT]") ) {
			line_nr++;
			break;
		}
	}

	// FROM SIXTH LINE OF DARDUMP BEGINS MULTIMEDIA ENTRIES OF A PAGE IN FOUR ROW INTERVALS.
	// Parse multimedia entries.
	// In four lines ("\n" / rows) intervals.
	// 0	TYPE		f.e.	image
	// 1	URL		f.e.	http://www.mycookings.com/pie.jpg
	// 2	KEYWORDS	f.e.	my favorite apple pie
	// 3	EXTRA		f.e.	...
	char mm_type[2048];
	char mm_url[2048];
	char mm_keywords[16384];
	char mm_extra[8192];
	for(i=line_nr; ; i+=4) {
		GetLine(tmp,2048, i+0, (BYTE*)mm_type);
		FixString1(mm_type);
		GetLine(tmp,2048, i+1, (BYTE*)mm_url);
		FixString1(mm_url);
		GetLine(tmp,16384, i+2, (BYTE*)mm_keywords);
		FixString1(mm_keywords);
		GetLine(tmp,8192, i+3, (BYTE*)mm_extra);
		FixString1(mm_extra);
		if(!strcmp(mm_type,"")) {
			if(inde_verbose) {
				fprintf(stderr, "%s/%s/line %d: end of mm_type's at i=%d\n",
					__FUNCTION__, __FILE__, __LINE__, i);
			}
			break;
		}

		if(!strcmp(mm_type,"image")) {
			SpecialWords(in, mm_url,	gid, pgp|WORD_TYPE_IMAURL,	hsum); //, url);
			SpecialWords(in, mm_keywords,	gid, pgp|WORD_TYPE_IMAURL,	hsum); //, url);
		}
		if(!strcmp(mm_type,"video")) {
			SpecialWords(in, mm_url,	gid, pgp|WORD_TYPE_VIDURL,	hsum); //, url);
			SpecialWords(in, mm_keywords,	gid, pgp|WORD_TYPE_VIDURL,	hsum); //, url);
		}
		if(!strcmp(mm_type,"audio")) {
			SpecialWords(in, mm_url,	gid, pgp|WORD_TYPE_AUDURL,	hsum); //, url);
			SpecialWords(in, mm_keywords,	gid, pgp|WORD_TYPE_AUDURL,	hsum); //, url);
		}
	}

	WliDump(sid, tmp,MAX_WWW_PAGE_SZ, ProductionIndexNr);
	FixString1((char*)tmp); // xox
	l_tmp = strlen(tmp);

	//fprintf(stderr, "\"%s\"", tmp);

	//
/*	if( strlen(tmp)<16 || strlen(title)<3 ) // || strstr(tmp, "REFRESH(") )
	{
		// Drop this page, it has no proper content.
		//if(inde_verbose)
			fprintf(stderr, "%s line %d: Page %d ignored, no proper content detected.\n", __FUNCTION__, __LINE__, sid);
		return 0;
	}*/

	// Produce pagebeg and pageend preview.
	strncpy(pagebeg, tmp, 100);
	decimal_i = l_tmp-100;
	if(decimal_i<0) {
		strcpy(pageend, "");
	} else {
		strncpy(pageend, tmp+decimal_i, 100);
	}
	FixString1(pagebeg);
	FixString1(pageend);

	//---------------------------------------------------------------------
	//
	if(inde_debug) {
		fprintf(stderr, "%s/%s: adding highly relevant words to the db\n",
			__FILE__, __FUNCTION__);
	}

	if(inde_verbose) {
		fprintf(stderr, "%s/%s: title length = %d\n",
			__FILE__, __FUNCTION__,	strlen(title) );
		fprintf(stderr, "%s/%s: path length = %d\n",
			__FILE__, __FUNCTION__,	strlen(path) );
		fprintf(stderr, "%s/%s: host length = %d\n",
			__FILE__, __FUNCTION__,	strlen(host) );
		fprintf(stderr, "%s/%s: preview length = %d\n",
			__FILE__, __FUNCTION__,	strlen(preview) );
		fprintf(stderr, "%s/%s: description length = %d\n",
			__FILE__, __FUNCTION__,	strlen(description) );
		fprintf(stderr, "%s/%s: keywords length = %d\n",
			__FILE__, __FUNCTION__,	strlen(keywords) );
		fprintf(stderr, "%s/%s: pagebeg length = %d\n",
			__FILE__, __FUNCTION__,	strlen(pagebeg) );
		fprintf(stderr, "%s/%s: pageend length = %d\n",
			__FILE__, __FUNCTION__,	strlen(pageend) );
	}

	SpecialWords(in, title,		gid, pgp|WORD_TYPE_TITLE,		hsum); //, url);
	SpecialWords(in, path,		gid, pgp|WORD_TYPE_URL,			hsum); //, url);
	SpecialWords(in, host,		gid, pgp|WORD_TYPE_HOST,		hsum); //, url);
	SpecialWords(in, preview,	gid, pgp|WORD_TYPE_PREVIEW,		hsum); //, url);
	SpecialWords(in, description,	gid, pgp|WORD_TYPE_META_DESCRIPTION,	hsum); //, url);
	SpecialWords(in, keywords,	gid, pgp|WORD_TYPE_META_KEYWORDS,	hsum); //, url);
	SpecialWords(in, pagebeg,	gid, pgp|WORD_TYPE_PAGEBEG,		hsum); //, url);
	SpecialWords(in, pageend,	gid, pgp|WORD_TYPE_PAGEEND,		hsum); //, url);

	// Scan word list file for words.
	if(inde_debug) {
		fprintf(stderr, "%s/%s: scanning word list for usable words\n",
			__FILE__, __FUNCTION__);
	}
/*	// Skip the blob.
	for(i=0,n_wl=0; i<MAX_WWW_PAGE_SZ && n_wl<=MAX_WL; )
	{
		// Skip spaces.
		for(; !isKeyChar(tmp[i]) && i<MAX_WWW_PAGE_SZ; i++) { }
		for(x=0; isKeyChar(tmp[i]) && i<MAX_WWW_PAGE_SZ && x<(KEYWORD_MAX_L-2); i++) { str[x++]=tmp[i]; }
		//
		str[x++]=0;

		//
		if( (strlen(str)>=KEYWORD_MIN_L && strlen(str)<(KEYWORD_MAX_L-2)) )
		{
			//
			wl[n_wl] = imalloc(25600);
			strcpy(wl[n_wl], str);
			n_wl++;
		}
	}
	if(n_wl>=MAX_WL) {
		fprintf(stderr, "%s/%s/line %d [error]: Does not work because: Out of pointer space, increase MAX_WL in inde.h?\n",
			__FILE__, __FUNCTION__, __LINE__);
		exit(-5);
	}

	//
	strcpy(str,"");
	wl[n_wl+0] = str;
	wl[n_wl+1] = str;
	wl[n_wl+2] = str;

	//
	if(inde_debug) {
		fprintf(stderr, "%s/%s: Adding found usable words to the database\n",
			__FILE__, __FUNCTION__);
	}
	for(i=0; i<n_wl; i++)
	{
		//
		CountWord(wl[i+0],wl[i+1],wl[i+2],wl[i+3],
			i,gid, in, pgp|WORD_TYPE_REGULAR, hsum);
	}*/

	//
	if(inde_debug) {
		fprintf(stderr, "%s/%s: Freeing pointers of wl array (word list)\n",
			__FILE__, __FUNCTION__);
	}
	for(i=0; i<n_wl; i++)
	{
		//
		SafeFree(wl[i]);
	}

	if(inde_debug) {
		fprintf(stderr, "%s/%s: Freeing tmp\n",
			__FILE__, __FUNCTION__);
	}
	//
	SafeFree(tmp);

	if(inde_debug) {
		fprintf(stderr, "%s/%s: Returning back to the caller.\n",
			__FILE__, __FUNCTION__);
	}

	//
	return 0;
}
