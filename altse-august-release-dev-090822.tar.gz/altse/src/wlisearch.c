//--------------------------------------------------------------------------------------------
//
// wlisearch.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "wlisearch.h"

//
static int avoid[1000];
static int n_avoid=0;
int WLISEARCH_find_one_long_quotation = 0;

//
int IsJunk(int ch)
{
	char *junk="|_ \n";
	int i,l;

	//
	l = strlen(junk);
	for(i=0; i<l; i++)
	{
		if(ch==junk[i]) { return 1; }
	}

	//
	return 0;
}

//
int NeedToAvoid(int id, int explen)
{
	int i,i2;

	//
	for(i2=0; i2<n_avoid; i2++)
	{
		if(id>=(avoid[i2]) && id<(avoid[i2]+explen)) { return 1; }
	}

	//
	return 0;
}

// explen = Expected length.
int WliFindBuf(BYTE *buf,int l_buf, BYTE *ke,
        BYTE *re,int l_re,
        int explen)
{
        int i;

        //
        i=0;
        do
        {
                //
                WliFindBuf1(buf,l_buf,ke, re,l_re, explen);

                //
                i++;
                if(i>=10)
		{
			printf("Bad content.\n");
			return 0;
		}
        }while( strstr(re, "file://") || strstr(re, "localhost/") );

        //
        return 1;
}

// explen = Expected length.
int WliFindBuf1(BYTE *buf,int l_buf, BYTE *ke,
	BYTE *re,int l_re,
	int explen)
{
	int i,i2,i3,i4,mi,rmi,l,found,fof,rfof,x,splitted;
	static BYTE key[1024],str[8192];
	static BYTE tbuf[16384];

	//
	memcpy(tbuf,buf,l_buf);

	//
	strcpy(re, "");

	//
	strcpy(key, ke);
	LowerCaseString(tbuf);
	LowerCaseString(key);

	//
	l = strlen(key);
	for(i=0,mi=0,found=0,rmi=1,fof=0,rfof=0; i<l_buf; i++)
	{
		//
		if(tbuf[i]==key[mi])
		{
			if( NeedToAvoid(i,explen) ) { goto avoid_this; }
			if(mi==0) { fof = i; }
			mi++;
		}
		else
		{
avoid_this:
			mi = 0;
		}

		// rmi = length of so far the nearest hit to key, rfof = offset to the location
		if( mi>rmi ) { rmi=mi; rfof=fof; }
		// All chars of key matches? (l=key length)
		if( mi==l ) { rfof=fof; found=1; break; }
	}

	//
	if( !NeedToAvoid(rfof-16,explen) )
	{
		//
		strcat(re, "... ");
		//sprintf(str, "%d ", rfof-16);
		//strcat(re, str);
		for(i=rfof-16,i2=0,splitted=0; i2<explen && i<l_buf; i++,i2++)
		{
			//
			for(x=0; IsJunk(buf[i]) && i<l_buf; i++,x++) { }
			if(x>0 && x<5)
			{
				strcat(re, " ");
			}
			if(x>=5 && strlen(re)>2)
			{
				strcat(re, " ... ");
			}

			//
			if(i2>=(explen>>1) && !splitted && buf[i]==' ') { splitted=TRUE; strcat(re, "<br>"); }

			//
			if(i>=0)
			{
				l = strlen(re);
				re[l+0] = buf[i];
				re[l+1] = 0;
			}
		}
		avoid[n_avoid++] = rfof-16;
		strcat(re, " ...");
		return i2;
	}

	//
	return 0;
}

//--------------------------------------------------------------------------------------------
//
BYTE *WliSearch(DWORD wli_id, char *key, int which_index)
{
	static char str[8192],tmp[8192];
	static char *word[100];
	BYTE *re;
	int l_re;
	FILE *f;
	BYTE *buf;
	int i,i2,i3,i4,wordCount;

	//
	for(i=0; i<100; i++)
	{
		GetString(key,strlen(key), i, str);
		if(!strcmp(str,"")) { break; }
		word[i] = malloc(1024);
		strcpy(word[i], str);
	}
	wordCount = i;

	//
	sprintf(str, "%s/altse/bin/wlidump %d %d", // page / index nr.
		database_path,
		wli_id,
		which_index);
	f = popen(str, "r");
	if(f==NULL) { fprintf(stderr, "can't execute %s\n", str); return 1; }

	//
	re = malloc(16384);
	buf = malloc(65536);
	memset(buf, 0, 65536);
	fread(buf, 1,16384, f);
	RemoveControlCodes(buf);

	//
	pclose(f);

	//
	l_re = 16384;

	//
	strcpy(re,"");
	if( wordCount>1 )
	{
		if( WliFindBuf(buf,16384, key, tmp,8000, 70) )
		{
			strcat(re, tmp);
			strcat(re, "<br>");
		}
		for(i=0; i<wordCount && i<2; i++)
		{
			if( strlen(word[i])<2 ) { continue; }
			if( WliFindBuf(buf,16384, word[i], tmp,8000, 70) )
			{
				strcat(re,tmp);
				strcat(re, "<br>");
			}
		}
	}
	else
	{
		if(!WLISEARCH_find_one_long_quotation) {
			if( WliFindBuf(buf,16384, word[0], tmp,8000, 70) )
			{
				strcat(re,tmp);
				strcat(re, "<br>");
			}
			if( WliFindBuf(buf,16384, word[0], tmp,8000, 70) )
			{
				strcat(re,tmp);
				strcat(re, "<br>");
			}
			if( WliFindBuf(buf,16384, word[0], tmp,8000, 70) )
			{
				strcat(re,tmp);
				strcat(re, "<br>");
			}
		} else {
			if( WliFindBuf(buf,16384, word[0], tmp,8000, 70*3) )
			{
				strcat(re,tmp);
				strcat(re, "<br>");
			}
		}

		//
	}

	//
	free(buf);

	//
	return re;
}

