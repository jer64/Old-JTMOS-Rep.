#!/usr/bin/perl
##############################################################################
#
# BIM.pl [indexnr]
#
# Builds a searchable index out of the wwwimage's directory.
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
AltseOpenConfig();

#
main();

##############################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,@lst3,@lst4,$str,$str2);

        #
        $indexnr = -1;
        for($i=0; $i<($#ARGV+1); $i++) {
                if($ARGV[$i] eq "-i") {
                        $indexnr = int($ARGV[$i+1]);
                }
        }

        if($indexnr==-1) {
                print STDERR "Usage: BIM.pl [-i INDEXNR]\n";
                print STDERR "Example: BIM.pl -i 0\n";
                print STDERR "Also, you have to specify index number always\n";
                exit;
        }

        if($indexnr!=0) {
                $indexstr = "_$indexnr";
        }


	#
	print STDERR "Processing file names ...\n";
	# www images path
	my $wi_path = "$DB/wwwimages$indexstr";
	# load list of images
	@lst3 = LoadList("$wi_path/already.txt");

	# Create local path file list. Pick paths.
	@lst = ();
	for($i=0,$i2=0; $i<($#lst3); $i+=2) {
		$lst[$i2++] = "$lst3[$i+1] | $lst3[$i+0]";
	}

	# Reparse list.
	for($i=0,$i2=0; $i<($#lst+1); $i++) {
		if(
		$lst[$i]=~/jpg/i ||
		$lst[$i]=~/jpeg/i ||
		$lst[$i]=~/gif/i ||
		$lst[$i]=~/png/i ) {
			my $fn = $lst3[$i*2+1];
			my $sz = -s $fn;
			if($sz>0) {
				$lst2[$i2++] = sprintf "%1.8d %s", $sz, $lst[$i];
			}
		}
	}
	#
	@lst2 = reverse sort @lst2;

	#
	print STDERR "Writing index file ...\n";
	open($f, ">$wi_path/senseful.lst");
	for($i=0; $i<($#lst2+1); $i++) {
		print $f $lst2[$i] . "\n";
	}
	close($f);

	#
	print STDERR "Quick index created for image search index number $indexnr.\n";
	print STDERR "$#lst2 images.\n";

	#
}
