//----------------------------------------------------------------------------
// rank.c - Pagerank precalculator.
//----------------------------------------------------------------------------
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"
#include "gethtmlpage.h"

//
#define MAX_URL_LEN_CHARS	512
#define N_MAX_ALD	100000

//
#define N_MAX_LIST	100000

//
static DWORD time_code;
static char *list[N_MAX_LIST];
static int n_list;

//
int isEndOfUrl(int ch)
{
	//
	if(ch==' ' || ch=='\"' || ch=='\'' ||
		ch=='\n' || ch=='\r' || ch=='\t' || ch==0)
	{
		return TRUE;
	}

	//
	return FALSE;
}

//
int xchars(char *s, int ch)
{
	int i,i2,l,c;

	//
	l = strlen(s);
	for(i=0,c=0; i<l; i++)
	{
		if(s[i]==ch) { c++; }
	}

	//
	return c;
}

//
void GetOnlyHost(char *s)
{
	int i,l;

	// Require http://.
	if( strncmp(s,"http://",7) ) { return; }

	// Get past http://
	strcpy(s,s+7);

	//
	l = strlen(s);
	for(i=0; i<l; i++)
	{
		if(s[i]=='/') break;
	}
	s[i]=0;
}

//
void AddToList(char *s)
{
	int i;

	//
	for(i=0; i<n_list; i++)
	{
		if(!strcmp(list[i],s)) { return; } // already in list?
	}

	//
	i = n_list;
	if(list[i]==NULL) list[i] = malloc(MAX_URL_LEN_CHARS);
	strcpy(list[i], s);
	n_list++;
}

//
void GetLinks(char *host, char *path)
{
	BYTE *h;
	int i,i2,i3,i4,l;
	static char str[8192];

	//
	n_list = 0;

	//
	if(!strcmp(path,"/"))
	{
		strcpy(path,"");
	}

	//
	h = GetHtmlPage(host, path);
	if(h==NULL)
	{
		//fprintf(stderr, "Not in database: host=%s, path=%s\n",
		//	host,path);
		return;
	}

	//
	l = strlen(h);

	// Extract links.

	//
	for(i=0; i<l; i++)
	{
		//
		if( !strncmp(h+i,"http://",7) )
		{
			//
			for(i2=0; i2<150; i2++)
			{
				if( isEndOfUrl(h[i]) )
					break;
				str[i2] = h[i++];
			}
			str[i2]=0;

			//
			if( strlen(str)>9 && strlen(str)<26 &&
				strncmp(str+7,host,strlen(host)) )
			//	(xchars(str,'/')==2 || (xchars(str,'/')==3 && str[strlen(str)-1]=='/')) )
			{
				GetOnlyHost(str);
				AddToList(str);
			}
		}
	}

	//
	free(h);

	//
	return;
}

//--------------------------------------------------------------------------------
//
void InitList(void)
{
	static int once=0;

	//
	if(!once)
	{
		memset(list,0,sizeof(list));
		once++;
	}
	n_list=0;
}

//--------------------------------------------------------------------------------
//
int RewardHost(char *host, char *who)
{
	char *ho,tho[10];
	DWORD i,i2,i3,i4,tc,score;
	static char fn[8192],dir[8192];
	FILE *f;

	//
	ho = host;
	if(!strncmp(ho,"www.",4)) ho+=4;

	//
	memset(tho, 0, 10);
	strncpy(tho,ho,3);
	sprintf(dir, "%s/www/%c%c%c/%s",
		database_path,
		tho[0],tho[1],tho[2],
		host);

	//
	f = fopen(dir, "rb");
	if( f==NULL ) { return 1; }
	fclose(f);

	//
	sprintf(fn, "%s/rank.txt",
		dir);
	f = fopen(fn, "rt");
	score=0;
	if(f!=NULL)
	{
		//
		fscanf(f, "%d", &tc);
		if(tc==time_code)
		{
			fscanf(f, "%d", &score);
		}
		fclose(f);
	}

	//
	score++;

	//
	f = fopen(fn, "wt");
	if(f!=NULL)
	{
		fprintf(f, "%d\n%d\n",
			time_code,
			score);
		fclose(f);
	}

	//
	fprintf(stderr, "%s promotes %s to rank [%d]\n", who, host, score);

	//
	return 0;
}

//--------------------------------------------------------------------------------
//
void RankAllPages(int which_index)
{
	static BYTE tmp[65536],host[8192],path[8192],str[8192],str2[8192];
	int i,i2,i3,i4,id,n_id;
	FILE *f;
	static char *ald[N_MAX_ALD];
	static int do_once = TRUE, line_nr;
	int n_ald,already;

	//
	time_code = time(NULL);

	//
	sprintf(tmp, "%s/cid/gid.txt", database_path);
	f = fopen(tmp, "rb");
	if(f==NULL)
	{
		return;
	}
	//
	fscanf(f, "%d", &n_id);
	//
	fclose(f);

	//
	if(do_once)
	{
		do_once = FALSE;
		for(i=0; i<N_MAX_ALD; i++) { ald[i] = NULL; }
	}

	//
	for(id=0,n_ald=0; id<n_id; id++)
	{
		//
		fprintf(stderr, "%d/%d (%d)      \r", id,n_id, n_ald);
		DarDump(id, tmp,65536, which_index);

	        // Get host, path, title, preview nfo (dardump).
	        for(line_nr=0; line_nr<100; line_nr++) {
			GetLine(tmp,4900, line_nr, (BYTE*)str);
	                if( !strcmp(str, "[BASIC PAGE INFO]") ) {
	                        line_nr++;
	                        break;
	                }
	        }


		GetLine(tmp,512, line_nr, (BYTE*)host); line_nr++;
		GetLine(tmp,512, line_nr, (BYTE*)path); line_nr++;
		if( !strcmp(host, "") ) { continue; }
		GetLinks(host,path);

		//
		for(i=0; i<n_list; i++)
		{
			if(strlen(list[i])>5)
			{
				sprintf(str, "%s_%s", host,list[i]);
				for(i2=0,already=FALSE; i2<n_ald; i2++)
				{
					if(!strcmp(ald[i2],str))
					{
						already = TRUE;
					}
				}
				if(!already)
				{
					if( !RewardHost(list[i], host) && n_ald<N_MAX_ALD )
					{
						if(ald[n_ald]==NULL)
							ald[n_ald] = malloc(100);
						sprintf(ald[n_ald], "%s_%s", host,list[i]);
						n_ald++;
					//	fprintf(stdout, "%d\n", n_ald);
					}
				}

				//
			}
		}
	}
}

//--------------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
	int which_index;

	//
	if(argc<2) {
		printf("Usage: rank [which index to do rank for]");
		return 0;
	}

	//
        AltseLoadConfig();

	//
	sscanf(argv[1], "%d", &which_index);

	//
	InitList();

	//
	RankAllPages(which_index);

	//
	return 0;
}

//
