#!/usr/bin/perl
require "tools.pl";
use String::CRC::Cksum qw(cksum);
#
AltseOpenConfig();

#
main();

#
sub main
{
	my ($i,$i2,@lst,@filelist,@istext,$nontext,$str,$str2,@sp,%words,$collen);

	#
	#print STDERR "Building a list of candidates to analyze ...\n";
	#@filelist = LoadList("find $ENV{'HOME'}/db/www -type f -size +1000k|");
	print "Loading list of pages ...\n";
	@filelist = LoadList("$DB/www/list.txt");

	#
	print STDERR "Collecting words ...\n";
	$collen = 10000;
	for($i=0,$nontext=0; $i<($#filelist+1) && $i<$collen; $i++) {
		@lst = LoadList("zcat $DB/www/".$filelist[$i]."|");
		$str = join(" ", @lst);
		$str =~ tr/[A-ZÄÖÅ]/[a-zäöå]/;
		$str =~ s/[^a-zäöå0-9]/ /gi;
		$str =~ s/\s+/ /g;
		$str =~ s/^\s+/ /g;
		$str =~ s/\s+$/ /g;
		@sp = split(/ /, $str);
		for($i2=0; $i2<($#sp+1); $i2++) {
			$words{$sp[$i2]}++;
		}
		print STDERR sprintf "%d \%   \r", ($i/($collen+1))*100;
	}

	#
	print STDERR "\nFinished, $i file(s) analyzed.\n";

	# Build up an array from the hashtable.
	$i=0;
	@lst = ();
	foreach $str (sort(keys %words)) {
		$lst[$i++] = sprintf "%1.8d $str", $words{$str};
	}
	print $#lst+1 . " word(s)\n";
	@lst = sort @lst; @lst = reverse @lst;
	for($i=0; $i<($#lst+1); $i++) {
		print $lst[$i] . "\n";
	}

	#
}
