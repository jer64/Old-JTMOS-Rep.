#ifndef __INCLUDED_SEARCHINDEXES_H__
#define __INCLUDED_SEARCHINDEXES_H__

//
int SearchIndexes(IS *is);

#endif
