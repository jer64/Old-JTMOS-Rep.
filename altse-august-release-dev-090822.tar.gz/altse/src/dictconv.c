//-------------------------------------------------------------------------------
//
// dictconv.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"

//
#define BLS	(1024*16)

//-------------------------------------------------------------------------------
//
int Convert(char *source,char *output)
{
	FILE *f,*f2;
	DWORD sz1,sz2,i,i2;

	//
	f = fopen(source, "rb");
	if(f==NULL) { fprintf(stderr, "can't open %s\n", source); return 0; }

	//
	fseek(f,0,SEEK_END);
	sz1 = ftell(f);
	fseek(f,0,SEEK_SET);
	sz2 = (( (sz1+64)/BLS )+1)*BLS;


	//
	f2 = fopen(output, "wb");
	if(f2==NULL) { fprintf(stderr, "can't write %s\n", output); return 0; }

	// WRITE HEADER
	fputc( (sz1)&255,     f2);
	fputc( (sz1>>8)&255,  f2);
	fputc( (sz1>>16)&255, f2);
	fputc( (sz1>>24)&255, f2);
	for(i=0; i<60; i++) { fputc(0, f2); }

	// COPY DICTIONARY DATA
	for(i=0; i<sz2; i++)
	{
		if(i<sz1)
		{
			// Copy.
			fputc(fgetc(f), f2);
		}
		else
		{
			// Write zeroes at the end.
			fputc(0, f2);
		}
	}

	//
	fclose(f2);
	//
	fprintf(stderr, "Alignment: %d bytes -> %d bytes\n", sz1,sz2);

	//
	fclose(f);
}

//-------------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
	//
	if(argc<3)
	{
		//
		return 0;
	}

	//
	Convert(argv[1], argv[2]);

	//
	return 0;
}
