#ifndef __INCLUDED_SQSH_H__
#define __INCLUDED_SQSH_H__

// ---- PREFERENCES --------------------------------
// Max. words
#define SQSH_MAX_WORDS          200
//
#define SCRIPT_MAX_LINES        500

// ---- FUNCTION PROTOTYPES ------------------------
int loadscript(const char *fname);

#endif
