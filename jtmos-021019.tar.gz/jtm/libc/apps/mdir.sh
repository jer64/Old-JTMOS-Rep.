#!/bin/bash
gcc -w -O2 -o mdir mdir.c


