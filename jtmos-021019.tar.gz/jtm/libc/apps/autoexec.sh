hda:clear
echo "JTMOS autoexec.sh - Starting services ..."
echo "Welcome to JTMOS operating system."
echo "Launching user interface"
hda:sqsh.bin
