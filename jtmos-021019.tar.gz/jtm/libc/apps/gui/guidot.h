#ifndef __INCLUDED_GUIDOT_H__
#define __INCLUDED_GUIDOT_H__

#include "graos.h"

int gui_dotSetBPP1(VMODE *v, int x,int y, int state);
int gui_dotRemoveBPP1(VMODE *v, int x,int y);
int gui_dotSet(VMODE *v, int x,int y);
int gui_dotRemove(VMODE *v, int x,int y);
int gui_dotGetBPP1(VMODE *v, int x,int y);
int gui_dotGet(VMODE *v, int x,int y);
int gui_dotPut(VMODE *v, int x,int y, int va);
void DrawDot(VMODE *v, int x,int y, char state);
int gui_dotPutBPP8(VMODE *v, int x,int y, int va);
int gui_dotGetBPP8(VMODE *v, int x,int y);

#endif

