// =====================================================
// guiStart.c
// =====================================================
#include <stdio.h>
#include "guiEnd.h"

//
void guiEnd(VMODE *v)
{
	//
	exitAllApplications(v);

	// Restore default video mode
	setmode(3);

	// Close debug stream
	CloseDebugStream();
}

