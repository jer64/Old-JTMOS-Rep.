// clear.c - Clear the terminal screen
#include <stdio.h>
#include <jtmos/filefind.h>

int main(int argc, char **argv)
{
	clrscr();
	return 0;
}
