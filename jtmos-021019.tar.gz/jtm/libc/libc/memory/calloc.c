#include "basdef.h"
#include "string.h"
#include "malloc.h"
#include "calloc.h"

void *calloc(int n, int s)
{
	return malloc(n*s);
}
