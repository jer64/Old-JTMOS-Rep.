// ==================================================
// JTMOS LIBC ENVIRONMENT VARIABLE HANDLING FUNCTIONS
//
// NOT WORKING YET - TODO !!!!!!!!!
// ==================================================
#include "basdef.h"
#include "process.h"
#include "env.h"

// lala=blabla
int putenv(const char *fmt)
{
	return 0;
}

// lala blabla TRUE/FALSE
int setenv(const char *name, const char *value, int overwrite)
{
	return 0;
}

void unsetenv(const char *name)
{
	return;
}

char *getenv(const char *name)
{
        return NULL;
}

