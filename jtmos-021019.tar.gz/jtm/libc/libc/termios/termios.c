// Dummies here
#include "basdef.h"
#include "termios.h"

int tcgetattr(int fd, struct termios *termios_p)
{
	return 0;
}

