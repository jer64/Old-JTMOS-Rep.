#ifndef __INCLUDED_ATEXIT_H__
#define __INCLUDED_ATEXIT_H__

//
int atexit(void (*function)(void));

#endif
