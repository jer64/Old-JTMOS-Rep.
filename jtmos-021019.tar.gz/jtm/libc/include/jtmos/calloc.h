#ifndef __INCLUDED_CALLOC_H__
#define __INCLUDED_CALLOC_H__

void *calloc(int n, int s);

#endif

