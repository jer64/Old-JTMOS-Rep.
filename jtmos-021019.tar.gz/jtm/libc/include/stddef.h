//
#ifndef __INCLUDED_STDDEF_H__
#define __INCLUDED_STDDEF_H__

//
#define size_t unsigned long int

//
#endif

//

