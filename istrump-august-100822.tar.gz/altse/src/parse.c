//
#include <stdio.h>
#include "selib.h"

//
int main(int argc, char **argv)
{
	FILE *f;
	int ch;
	BYTE *buf;
	int l_buf,i,i2,l,found;

	//
	l_buf = 1024*1024*5;
	buf = malloc(l_buf);

	//
	if(argc<2)
	{
		f = stdin;
	}
	else
	{
		f = fopen(argv[1], "rb");
	}

	//
	for(i=0; !feof(f) && i<(l_buf-1); )
	{
		//
		ch = fgetc(f);

		//
		if(ch=='[')
		{
			while(!feof(f) && (ch=fgetc(f))!=']') { }
		}
		else
		{
			buf[i++] = ch;
		}
	}
	buf[i] = 0;
	l = i;
	//
	if(!(argc<2)) { fclose(f); }

	//
	for(i=l,found=0; i>0; i--)
	{
		//
		if( !strncmp(buf+i,"References\n\n",12) )
		{
			found = 1;
			break;
		}
	}
	if(found)buf[i]=0;

	//
	fprintf(stdout, "%s", buf);

	//
	return 0;
}

//
