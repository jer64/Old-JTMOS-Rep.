//
#include <stdio.h>
#include "selib.h"

//
int main(int argc, char **argv)
{
	FILE *f;
	int ch;

	//
	f = popen("lynx -dump http://192.168.0.3/?q=fish", "r");
	if(f==NULL) return 1;
	while( !feof(f) )
	{
		ch = fgetc(f);
		fprintf(stdout, "%c", ch);
		fflush(stdout);
	}
	pclose(f);

	//
	return 0;
}

//
