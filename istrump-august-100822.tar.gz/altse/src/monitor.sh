#!/bin/bash
watch tail -f /home/vai/db/download.log
