///////////////////////////////////////////////////////////////////////////
//
// mkdix.c - Make index for keyword index directory.
//
///////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "iscfg.h"

//
#define NONE		0xFFFFFFFF

///////////////////////////////////////////////////////////////////////////
//
void mkdix(int ch, char quiet, int word_level)
{
	DWORD *buf;
	static char fndix[8192],fndic[8192],fndir[8192],str[8192],
		key[8192],lkey[8192],skey[8192];
	int fd,fd2;
	DWORD sz,cnt,i,i2,i3,i4,offs1,offs2,start,click,st,end,first,goback;
	FILE *f;
	DWORD *dp;

        //
	// #define DICPA           "/xdbx/cid/dict/0"
	//
        sprintf(str, "%s/cid/dict/%d/%c-%d",
                database_path, ProductionIndexNr, ch, word_level);
        //
        sprintf(fndic, "%s.dic", str);
        sprintf(fndix, "%s.dix", str);
        sprintf(fndir, "%s.dir", str);

	//
	fd = open(fndir, O_RDONLY);
	if(fd<0) { return; }

	//
	sz = lseek(fd,0,SEEK_END);
	buf = malloc(sz);
	lseek(fd,0,SEEK_SET);
	read(fd,buf,sz);

	//
	close(fd);


	//
	cnt = sz>>2;

	//
	strcpy(key, "");
	strcpy(lkey, "");

	//
	f = fopen(fndix, "wb");
	if(f==NULL) { return; }

	//
	for(i=0,start=NONE,dp=buf,click=0; i<cnt; click++)
	{
		//
		for(strcpy(lkey,""),strcpy(key,""),start=i,first=1; i<cnt; )
		{
			for(; dp[i]!=0x12345678 && i<cnt; i++); goback=i;
			i++;
			memcpy(key,dp+i,8); key[8]=0;
			for(; dp[i]!=0xAAAAAAAA && i<cnt; i++); i++;

			//
			if(!quiet) fprintf(stdout, "'%s'\n", key);
			if( strcmp(key,lkey) && !first ) { i=goback; break; }

			//
			strcpy(lkey,key);
			first=0;
		}

		//
		end = i;

		//
		if(!quiet) fprintf(stdout, "-ENTRY-  %s: %.8X - %.8X\n", lkey, start<<2,end<<2);
		//bush6qk_
		fwrite(lkey, 8,1, f);
		fputd(start<<2, f);
		fputd(end<<2, f);
	}

	//
	fwrite(key, 8,1, f);
	fputd(start<<2, f);
	fputd(i<<2, f);

	//
	fclose(f);

	//
	free(buf);

	//
}

///////////////////////////////////////////////////////////////////////////
//
void mkall(void)
{
	char *lst="0123456789abcdefghijklmnopqrstuvwxyz���";
	int i,l;
	char str[256];

	//
	l = strlen(lst);
	//
	int r;

	int max_r = 21;
	if(!OPTIMIZE_FOR_SEARCH_SPEED) { max_r = 1; }

	for(r=0; r<max_r; r++) {
		for(i=0; i<l; i++)
		{
		//	sprintf(str, "defrag %c", lst[i]);
		//	system(str);
			fprintf(stderr, "%c", lst[i]);
			mkdix(lst[i], TRUE, r);
		}
	}
	fprintf(stderr, "\nDone.\n");
}

///////////////////////////////////////////////////////////////////////////
//
int main(int argc, char **argv)
{
	int i;

	//
	if(argc<2)
	{
		fprintf(stderr, "Usage: mkdix [char OR \"all\"] [-i index number] [-o optimize search speed mode]\n");
		fprintf(stderr, "mkdix creates third-level index to optimize search performance.\n");
		return 0;
	}

	//
	AltseLoadConfig();

        //
        for(i=1; i<argc; i++) {
                // define which index to use for searches,
                // f.e. -i 1 (default is 0)

                if( !strncmp(argv[i],"-i",2) ) {
                        //
                        sscanf(argv[i]+3, "%d", &ProductionIndexNr);
                }
                if( !strncmp(argv[i],"-o",2) ) {
                        //
                        OPTIMIZE_FOR_SEARCH_SPEED = 1;
                }
	}

	//
	if( !strcmp(argv[1],"all") )
	{
		mkall();
	}
	else
	{
		int i;
		int max_l=21;
		if(!OPTIMIZE_FOR_SEARCH_SPEED) { max_l=1; }
		for(i=0; i<max_l; i++) {
			mkdix(argv[1][0], FALSE, i);
		}
	}

	//
	return 0;
}

//
