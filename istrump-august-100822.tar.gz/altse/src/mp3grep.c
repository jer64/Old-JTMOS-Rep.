// emailgrep.c
#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>

//
#define TRUE				1
#define FALSE				0
#define MAX_FILE_SIZE_TO_PROCESS	(1024*1024*300)

//
int isValidEmailChar(int c)
{
	char *valid="-_.";
	int i,l;

	//
	if( isalpha(c) ) return TRUE;
	if( isdigit(c) ) return TRUE;

	//
	l = strlen(valid);
	for(i=0; i<l; i++) { if(valid[i]==c){return TRUE;} }

	//
	return FALSE;
}

//
int IsEmail(char *buf,int index,
	char *email,int l_max_email,
	int *sk)
{
	int i,i2,i3,i4,stage,stage_cnt,ch,vc,gotdots;

	//
	for(i=0,i2=0,stage=0,i3=0,vc=0,stage_cnt=0; i<(l_max_email); i++)
	{
		//
		ch = buf[i];

		// jari.tuominen
		if(stage==0)
		{
			//
			if( ch=='@' )
			{
				// Hey there needs to be some chars before @!
				if(i2<=0)
					return FALSE;
				// Move to next stage.
				stage++;
				stage_cnt=0;
				i3=0;
				goto store_only;
			}

			//
			if( !isValidEmailChar(ch) )
			{
				return FALSE;
			}

			//
			stage_cnt++;
		}

		// past @, at my.isp.com
		//            |  |   |  |
		//            |  |   |  \-- vc=3 and end
		//            |  |   \--- dots = 2
		//            |  \------- dots = 1
		//            \---------- dots = 0
		//
		if(stage==1)
		{
			// Expect first character after @ -character to be from alphabet or a number.
			if( !i3 && !(isalpha(ch) || isdigit(ch)) )
			{
				//printf("shit: %s, illegal char=%c, i3=%d\n", email, ch, i3);
				return FALSE;
			}

			// Check for dots.
			if(ch=='.')
			{
				// Reset counter of number of valid characters to zero.
				vc=0;
				// Increase number of dots encountered.
				gotdots++;
				goto store_only;
			}
			else
				// Valid chars counter after a dot.
				vc++;

			// End of email address?
			if( !isValidEmailChar(ch) )
			{
				if(gotdots && vc>=2 && vc<=3)
					break;
				else
				{
					return FALSE;
				}
			}

			//
			i3++;

			//
			stage_cnt++;
		}
store_only:
		email[i2++] = ch;
		email[i2] = 0;
	}
	email[i2]=0;

	//
/*	if( !(strstr(email, "@") && strstr(email, ".") && strlen(email)>3) )
	{
		return FALSE;
	}*/

	// Set amount of skip bytes.
	*sk = i2;

	// Sufficient proof found for a valid e-mail string.
	return TRUE;
}

// Example emails:
// jari.tuominen@sesca.com
// temp-123@3s1b51-3423ab.com
void EmailBufGrep(char *buf,int l)
{
	int i,i2,i3,i4,skip_bytes;
	gzFile *f;
	char email[256];

	//
	for(i=0; i<l; i++)
	{
		if( i<(l-10) )
		{
			if( i>1 && !isValidEmailChar(buf[i-1]) 
				&& isValidEmailChar(buf[i])
				&& IsEmail(buf+i, l-i, &email,250, &skip_bytes) )
			{
				printf("%s\n", email);
				i += skip_bytes-1;
			}
		}
	}

	//
}

//
void FilterEmailsOutFromFile(const char *fname)
{
	int i,i2,i3,i4,l;
	gzFile *f;
	char *buf;
	static char str[1024];
	char *fn_tmp="/tmp/_emailgrep.tmp";

	//
	sprintf(str, "zcat %s > %s", fname, fn_tmp);
	system(str);

	//
	f = fopen(fn_tmp, "rb");
	if(f==NULL)
	{
		fprintf(stderr, "%s: cannot open file %s\n",
			__FUNCTION__, fn_tmp);
	}
	fseek(f, 0, SEEK_END);
	l = ftell(f);
	fclose(f);

	//
/*	fprintf(stderr, "%s: file of %s size reported by ftell is %d bytes\n",
		__FUNCTION__,
		fn_tmp, l);*/

	//
	if(l >= MAX_FILE_SIZE_TO_PROCESS)
	{
		fprintf(stderr, "%s: file size (%d bytes) exceeds maximum\n", __FUNCTION__, l);
		return 1;
	}

	//
	f = fopen(fn_tmp, "rb");
	if(f==NULL) { fprintf(stderr, "%s: (2) cannot open file %s\n", __FUNCTION__, fn_tmp); }
	buf = malloc(l);
	fread(buf,l,1,f);
	fclose(f);

	//
	EmailBufGrep(buf,l);

	//
}

//
int main(int argc, char **argv)
{
	//
	if(argc<2)
	{
		printf("Usage: emailgrep [html file name]\n");
		return 0;
	}

	//
	FilterEmailsOutFromFile(argv[1]);
}
