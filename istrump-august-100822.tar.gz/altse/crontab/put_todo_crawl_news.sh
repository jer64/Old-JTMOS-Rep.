#!/bin/bash
cd /home/vai/altse/crontab
#
export HTTP_PROXY=
#
PATH=$PATH:/home/vai/altse/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
export PATH

# No more termination of crawl processes, may interrupt downloads elsewhere.
# First let's take care of the processes we should not be running ...
#echo "First let's take care of the processes we should not be running ..."
#
#
#killall -9 crawl

#
mkdir  /home/vai/db/www

# * LOCAL VAIHTOEHTOUUTISET & KULTAKAIVOS FRONT PAGE UPDATE
cd /home/vai/db/www

#echo "[Removing unnecessary files] Locating links.txt files and removing ..."
#find . -name 'links.txt'|xargs rm -f

# XVII. Waiting until Finnish news are crawled. Memory usage up to 1 Gb using ReiserFS (takes lots of cache here apparently.)
#WaitUntilCrawlsStop.pl
#

echo "[Crawling] Crawling Finnish websites ..."
# FINNISH NEWS
cd /home/vai/db/www
screen -d -m crawl http://finnish.ruvr.ru/  -f 
screen -d -m crawl http://www.rusgate.fi/  -f 
screen -d -m crawl http://yle.fi/uutiset/venajan_verkossa/  -f 
screen -d -m crawl http://maailma.net/uutiset/eurooppa/itaeurooppa/venaja  -f 
screen -d -m crawl http://www.finrusresearch.fi/  -f 
screen -d -m crawl http://www.tvnewsradio.com/tv/tv-kanavat-venaja.htm  -f 
screen -d -m crawl http://www.suomenmaa.fi/  -f 
screen -d -m crawl http://www.forssanlehti.fi/  -f 
screen -d -m crawl http://www.pietarsaarensanomat.fi/  -f 
screen -d -m crawl http://www.iijokiseutu.fi/  -f 
screen -d -m crawl http://www.kansanuutiset.fi/  -f 
screen -d -m crawl http://www.kansanaani.fi/  -f 
screen -d -m crawl http://www.kansantahto.fi/  -f 
screen -d -m crawl http://www.demari.fi/  -f 
screen -d -m crawl http://www.koillissanomat.fi/  -f 
screen -d -m crawl http://www.rantalakeus.fi/  -f 
screen -d -m crawl http://www.uusiaika-lehti.fi/  -f 
screen -d -m crawl http://www.kotiseudunsanomat.fi/  -f 
screen -d -m crawl http://www.sisis.fi/  -f 
screen -d -m crawl http://www.joutsanseutu.fi/  -f 
screen -d -m crawl http://www.loimaanlehti.fi/  -f 
screen -d -m crawl http://www.kainuunsanomat.fi/  -f 
screen -d -m crawl http://www.parikkalan-rautjarvensanomat.fi/‎  -f 
screen -d -m crawl http://www.kaleva.fi/  -f 
screen -d -m crawl http://www.kauppalehti.fi/  -f 
screen -d -m crawl http://www.lansi-savo.fi/  -f 
screen -d -m crawl http://www.uusimaa.fi/  -f 
screen -d -m crawl http://www.iltalehti.fi/  -f 
screen -d -m crawl http://www.iltasanomat.fi/  -f 
screen -d -m crawl http://www.ts.fi/  -f 
screen -d -m crawl http://www.tervareitti.fi/  -f 
screen -d -m crawl http://www.kotiseutu-uutiset.com/  -f 
screen -d -m crawl http://www.vaikka.fi/  -f 
screen -d -m crawl http://www.kymensanomat.fi/  -f 
screen -d -m crawl http://www.ita-savo.fi/  -f 
screen -d -m crawl http://www.shl.fi/  -f 
screen -d -m crawl http://www.viiskunta.fi/  -f 
screen -d -m crawl http://www.ilkka.fi/  -f 
screen -d -m crawl http://www.hameensanomat.fi/  -f 
screen -d -m crawl http://www.orivedensanomat.fi/  -f 
screen -d -m crawl http://www.satakunnanviikko.fi/  -f 
screen -d -m crawl http://www.maaseuduntulevaisuus.fi/  -f 
screen -d -m crawl http://www.taloussanomat.fi/  -f 
screen -d -m crawl http://www.warkaudenlehti.fi/  -f 
screen -d -m crawl http://www.satakunnankansa.fi/  -f 
screen -d -m crawl http://www.kuntsari.fi/  -f 
screen -d -m crawl http://www.keski-uusimaa.fi/  -f 
screen -d -m crawl http://www.loviisansanomat.fi/  -f 
screen -d -m crawl http://www.ksml.fi/  -f 
screen -d -m crawl http://www.sss.fi/  -f 
screen -d -m crawl http://www.kangasalansanomat.fi/  -f 
screen -d -m crawl http://www.pohjalainen.fi/  -f 
screen -d -m crawl "http://www.hs.fi/haku/?haku=Niinist%C3%B6"  -f 
#WaitUntilCrawlsStop.pl



# FINANCE NEWS
echo "[Crawling] Crawling finance ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.marketwatch.com/  -f 
screen -d -m crawl  http://www.foxbusiness.com/  -f 
screen -d -m crawl  http://www.singaporetimes.com/  -f 
screen -d -m crawl  http://www.europac.net/  -f 
screen -d -m crawl  http://www.cnbc.com/  -f 
screen -d -m crawl  http://www.themoscowtimes.com/  -f 
screen -d -m crawl  http://www.valuewalk.com/  -f 
screen -d -m crawl  http://www.seekingalpha.com/  -f 
screen -d -m crawl  http://finance.yahoo.com/  -f 
screen -d -m crawl  http://www.moneynews.com/  -f 
screen -d -m crawl  http://www.bloomberg.com/  -f 
screen -d -m crawl  http://www.telegraph.co.uk/finance/  -f 
screen -d -m crawl  http://money.cnn.com/  -f 
screen -d -m crawl  http://www.istockanalyst.com/  -f 
screen -d -m crawl  http://www.upi.com/Business_News/  -f 
screen -d -m crawl  http://www.businessinsider.com/  -f 
screen -d -m crawl  http://www.businessweek.com/  -f 
screen -d -m crawl  http://www.reuters.com/  -f 
screen -d -m crawl  http://www.etftrends.com/  -f 
screen -d -m crawl  http://www.bbc.co.uk/news/business/  -f 



# ENTERTAINMENT NEWS
echo "[Crawling] Crawling entertainment ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.eonline.com/  -f 
screen -d -m crawl  http://variety.com/  -f 
screen -d -m crawl  http://www.tmz.com/  -f 
screen -d -m crawl  http://www.imdb.com/  -f 
screen -d -m crawl  http://perezhilton.com/  -f 
screen -d -m crawl  http://www.rottentomatoes.com/  -f 
screen -d -m crawl  http://games.allmyfaves.com/  -f 
screen -d -m crawl  http://www.pogo.com/  -f 
screen -d -m crawl  http://www.rollingstone.com/music  -f 
screen -d -m crawl  http://www.lyricsnmusic.com/  -f 
screen -d -m crawl  http://serendip.me  -f 
screen -d -m crawl  http://www.time.com/time/  -f 
screen -d -m crawl  http://www.nationalgeographic.com/  -f 
screen -d -m crawl  http://9gag.com/  -f 
screen -d -m crawl  http://www.funnyordie.com/  -f 
screen -d -m crawl  http://www.youtube.com/  -f 
screen -d -m crawl  http://espn.go.com/  -f 
screen -d -m crawl  http://www.infinitylist.com/  -f 
screen -d -m crawl  "http://www.fandango.com/?CJAFFILIATE&CMPID=cj_2477067"  -f 
screen -d -m crawl  http://www.stubhub.com/  -f 
screen -d -m crawl  http://entertainment.allmyfaves.com/  -f 



# ENTERTAINMENT NEWS
echo "[Crawling] Crawling weather ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.weather.com/  -f 
screen -d -m crawl  http://www.wunderground.com/  -f 
screen -d -m crawl  http://www.accuweather.com/  -f 
screen -d -m crawl  http://www.intellicast.com/  -f 
screen -d -m crawl  http://www.wxusa.com/  -f 
screen -d -m crawl  http://weather.cnn.com/  -f 
screen -d -m crawl  http://www.weatherimages.org/  -f 
screen -d -m crawl  http://www.harmweather.com/  -f 
screen -d -m crawl  http://weather.unisys.com/  -f 
screen -d -m crawl  http://www.weatherforyou.com/  -f 
screen -d -m crawl  http://www.myforecast.com/  -f 
screen -d -m crawl  http://www.hwn.org/  -f 
screen -d -m crawl  http://www.noaa.gov/  -f 
screen -d -m crawl  http://www.usatoday.com/weather/  -f 
screen -d -m crawl  http://www.sailflow.com/  -f 
screen -d -m crawl  http://www.theweathernetwork.com/  -f 
screen -d -m crawl  http://wwghcc.msfc.nasa.gov/GOES/goeseastconus.html  -f 
screen -d -m crawl  http://www.marineweather.com/  -f 



# SPACE NEWS
echo "[Crawling] Crawling space news ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.space.com/  -f 
screen -d -m crawl  http://www.ufoseek.com/  -f 



# News from Russia
echo "[Crawling] Crawling 'news from Russia' ..."
cd /home/vai/db/www
screen -d -m crawl  http://sputniknews.com/russia/  -f 
screen -d -m crawl  http://www.themoscowtimes.com/  -f 
screen -d -m crawl  http://tass.ru/en  -f 
screen -d -m crawl  http://english.pravda.ru/  -f 
screen -d -m crawl  http://www.interfax.com/pressind.asp  -f 
screen -d -m crawl  http://www.youtube.com/user/sputniknews  -f 



# Science
echo "[Crawling] Crawling science ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.sciencenews.org/  -f 
screen -d -m crawl  http://www.sciencedaily.com/  -f 
screen -d -m crawl  http://www.bbc.co.uk/news/science_and_environment/  -f 
screen -d -m crawl  http://www.nytimes.com/pages/science/  -f 
screen -d -m crawl  http://esciencenews.com/  -f 
screen -d -m crawl  http://news.sciencemag.org/  -f 
screen -d -m crawl  http://student.societyforscience.org/sciencenews-students  -f 
screen -d -m crawl  http://www.huffingtonpost.com/science/  -f 
screen -d -m crawl  http://www.eurekalert.org/  -f 
screen -d -m crawl  http://www.abc.net.au/science/news/  -f 
screen -d -m crawl  "http://www.richarddawkins.net/news_articles?category=Science&gclid=CJjd3OfWjrsCFYNxOgodQHYAAQ"  -f 
screen -d -m crawl  http://science.nasa.gov/science-news/  -f 
screen -d -m crawl  http://www.sci-news.com/  -f 
screen -d -m crawl  http://phys.org/science-news/  -f 
screen -d -m crawl  http://news.yahoo.com/science/  -f 
screen -d -m crawl  http://www.independent.co.uk/news/science/sun-will-flip-upside-down-within-weeks-says-nasa-8942769.html  -f 
screen -d -m crawl  http://www.scientificamerican.com/  -f 
screen -d -m crawl  http://www.reuters.com/news/science  -f 
screen -d -m crawl  http://www.telegraph.co.uk/science/science-news/  -f 
screen -d -m crawl  http://twitter.com/ScienceNewsOrg  -f 
screen -d -m crawl  http://www.newscientist.com/section/science-news  -f 
screen -d -m crawl  http://www.npr.org/sections/science/  -f 
screen -d -m crawl  http://www.upi.com/Science_News/  -f 
screen -d -m crawl  http://www.scienceagogo.com/  -f 
screen -d -m crawl  http://www.science.org.au/nova/  -f 
screen -d -m crawl  http://www.nsf.gov/news/  -f 
screen -d -m crawl  http://www.theguardian.com/science  -f 
screen -d -m crawl  http://www.nbcnews.com/science  -f 
screen -d -m crawl  http://www.world-science.net/  -f 
screen -d -m crawl  http://www.insidescience.org/  -f 
screen -d -m crawl  http://www.latimes.com/science/  -f 
screen -d -m crawl  http://onlinelibrary.wiley.com/journal/10.1002/%28ISSN%291943-0930  -f 


