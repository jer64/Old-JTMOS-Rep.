#
sub NewsFeedsView
{
	#
        print ViewNewsFeed();
        
        #
        print("
	</TD>
        </TR>
        </TABLE>");

	#
}
      
TRUE;
