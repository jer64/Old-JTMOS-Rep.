## Altse Configuration File

#
$ALTSE_PROTOCOL =	"http://";
$ALTSE_HOST =		"IsTrump.life";

# see altse/cfg/is.cfg for configuration
$LANG = "$DB/altse/lang";
#$altse_SERVICE_NOTIFICATION = "(!) 100% reindexing in progress - DIRECTORY WORKS - TRY IT.";
#
$IMAGES_URL = "/";
$GALLERY_URL = "/altsegallery";
#
$CGICMD = "/";
# Keep this off!
$SEARCH_LOG = "$DB/slog.txt";

# This affects image search view
$images_per_page = 250;

## INTERFACE SETTINGS
#
$SEARCH_FRONT_PAGE_TABLE_WIDTH = 640;
$SUBMIT_TABLE_WIDTH = 640;

#
$IMP_MESSAGE = "<font size=1><i>Putinin ystavien internet-hakukone $ALTSE_HOST - Putin-Trump-Jinping - Reippaana Kohti Parempaa Maailmaa Venaja ja Kiina mukaan luettuna!</i></font><br>";
#
$PAGE_COMMERCIAL_TEXT_SHORT="$ALTSE_HOST: Kulta, dollari, Trump, Putin, TASS, Interfax, jne. -uutishaku. Suomeksi vaihtoehtouutisia jo vuodesta 2002.";
$PAGE_ENGINE_FOOTER=("
<DIV
    style=\"vertical-align: middle;\">
        <A HREF=\"$ALTSE_PROTOCOL$ALTSE_HOST\">$ALTSE_HOST</A>
</DIV>
<DIV
    style=\"text-transform: capitalize; color: #FFFFFF; border:4px solid #CCCCCC;background-color:#202020;
  cursor: hand;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  font-weight: bold;\">
Hae nyt maailman uutisia, politiikkaa taloudella maustettuna. Suomeksi uutisia jo vuodesta 2002.
</DIV
");
$PAGE_ENGINE_FOOTER2= ("
<DIV
    style=\"text-transform: none; color: #FFFFCC; border:4px solid #CCCC80;background-color:#804020;
  cursor: hand;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  font-weight: bold;\">
Kriittiset markkinauutiset, Trump, Putin ja kaverit löytyvat meiltä.
</DIV>
");
$PAGE_ENGINE_FOOTER3="Hakuja.";
$PAGE_KEYWORDS="Fedi, raha, kupla, kuplatalous, vapaa Venajä, Vladimir Putin, Xi Jinping, Donald J. Trump, Donald Trump, Republikaani, Republikaanit, Kulta, Talous, istrump.life, is, trump, life, valtavirta, ruohonjuuri, taso, kapitalismi, Peter Schiff, Jim Rogers, Marc Faber, Peter D. Schiff, James Beeland, Presidentti Joe Biden, Euro Pacific Capital, JTMOS, ALTSE, China, Korea, Taiwan, Yhdysvallat, Fed, Federal Reserve, keskuspankki, inflaatio, hyperinflaatio, stagflaatio, rupla, dollari, jeni, juani, juan, jen, dollar, konkurssi, pienyritykset, suuryritykset, porvari, maallikko, Bill Gates, coronavirus, koronavirus, cocci, bacteria, kokkibakteeri, Venezuela, terveydenhuolto, Suomi, Sanna Marin, vaikuttaminen, vaikutta, net, vaihtoehtouutiset, network, p4t1n.com, vaihtoehtouutiset.com, haku, internet-hakukone, Gazprom, oljy, rahatalous, naisten, oikeudet, siviilisaatio, Jumala, Jesus, Johannes, rukoukset, kuplatalous, sosialidemokratia, globalismi, globalisaatio, Manuel Macron, presidenttii, paaministeri, valtio, plato, platon, TASS, Interfax, AP, Reuters, talousuutiset, avaruus, Roskosmos, ISS, is.fi, il.fi, iltalehti, taloussanomat, Ilta-Sanomat, Helsingin Sanomat, Demokraatti, katsaus, uutiskatsaus, Vladimir Putin Fan CLub Suomi Finland, Vaihtoehtouutiset, tietokone, hakukanta, hakukone, Jari Tapio Tuominen, Jari Tuominen, jkl, jkl.fi, jyvaskyla.fi, jyvaskyla, keski-suomi, lansi-suomi, taloushakukone, budjetti, liittovaltio, hyvinvointi, yhteiskunta, yhteiskunnallinen";
$SEARCH_GO = "Hae";

#
$ADMIN_IP = "192.168.0.2";
# FEATURES
$Google_ads = 0;
$WEB_DIRECTORY = 0;
$PAGE_TITLE = "$ALTSE_HOST: Vaihtoehtouutisten internet-hakukone";
$ADVERTISE_ALTSE = 0;
$IGNORE_DUPLICATE_URLS = 0;
$IGNORE_DUPLICATE_HOSTS = 0;

# IMAGE SETTINGS
$LOGO1 =	"/images/NewAltseLogo.gif";
$LOGO2 =	"/images/NewAltseLogo2.gif";
$LOGO_FRONT =	"/images/NewAltse.gif";

$MOB_LOGO1 =		"/images/mobile_NewAltseLogo.png";
$MOB_LOGO2 =		"/images/mobile_NewAltseLogo2.png";
$MOB_LOGO_FRONT =	"/images/mobile_NewAltse.png";

$BIM = "/images/newaltse.jpg";
# LAYOUT
$CSS_URL="/images/altse.css";

# Result view settings.
$DEFAULT_RESULTS_PER_PAGE = 30;

#
$IS_PL = "is.pl";

# Image search.
$MAX_IMGS_PER_LINE = 5;
$MAX_IMGS_PER_PAGE = 2*$MAX_IMGS_PER_LINE;
$REQ_MIN_IMG_SIZE = 8192;
$IMG_SS = 175;

#
$FONTCC =  "dark";
$FONTCC2 = "dark";
$FONTCC3 = "dark";
$TVAR = "#FFFFFF";

#
$SITE_STATEMENT = "<P>Ilmainen hakukone pienyritttajille. A non-profit open source project based on BSD-license.</P>";
$COPYRIGHT = "(C) 2003-2022 Jari Tuominen (<A HREF=\"mailto:jari.t.tuominen\@gmail.com\">jari.t.tuominen [AT] gmail.com</A>). All rights reserved.";

#
$altse = "$NWPUB_CGIBASE/altse";    # search database root directory
$CID = "$altse/cid";              # central index
$DATA = "$altse/cid/data";
$LISTS = "$altse/cid/lists";          # list files directory
$TMP = "$DB/tmp";

1;
