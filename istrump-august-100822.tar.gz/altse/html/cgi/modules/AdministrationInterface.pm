#########################################################
#
# Administration user interface
#
sub AdministrationInterface
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$str2);

	#
	print ("
<TABLE WIDTH=800 cellspacing=0 cellpadding=4 bgcolor=#0000C0>
<TR>
<TD>
<FONT COLOR=#FFFFFF size=4>
");

	#
	print("
<TABLE WIDTH=100% cellspacing=0 cellpadding=4 bgcolor=#4040C0>
<TR>
<TD>
<FONT COLOR=#FFFFFF>
<H2>SEARCH ENGINE ADMINISTRATION</H2>
</FONT>
</TD>
</TR>
</TABLE>
		");

	#
	@lst = LoadList("ps aux|grep /usr/bin/perl|grep crawl|grep -v \"sh -c\"|");

	# vai 1626 1.6 2.0 50240 21220 pts/15 S+ 09:07 4:57
	# /usr/bin/perl /home/vai/altse/bin/crawl http://finnish.feedburner.es/ . fast
	for($i=0; $i<($#lst+1); $i++) {
		#print $lst[$i] . "<BR>\n";
		my @sp = split(" ", $lst[$i]);
		my $url = $lst[$i];
		$url =~ s/^.*\/usr\/bin\/perl\s\S*\s(\S*).*/$1/;

		#
		$ram1 = int($sp[4]/1024)+1;
		$ram2 = int($sp[5]/1024)+1;
		my $crpid = $sp[1];

		#
		print ("
<TABLE width=100% cellspacing=0 cellpadding=4
	BGCOLOR=\"#000000\">
<TR>

<TD>

<TABLE width=100% cellspacing=0 cellpadding=4
	BGCOLOR=\"#802020\">
<TR>

<TD width=50%>
Crawling <B>$url</B>
</TD>

<TD width=50%>
RAM usage: <B>$ram1</B> Mb virtual / <B>$ram2</B> Mb
</TD>

</TR>
</TABLE>

</TD>

</TR>
</TABLE>

");
	}

	#
	print ("
<FORM action=\"?\">
Start new crawl, URL: 
<INPUT TYPE=\"TEXT\" name=\"new_crawl\" value=\"\">
<INPUT TYPE=\"SUBMIT\" VALUE=\"START\">
</FORM>
");

	#
	print("
<PRE>
SYSTEM MEMORY OVERVIEW
Note: memory in megabytes
");
	system("free -m");
	#
	print("
</PRE>
");


	#
	print ("
</FONT>
</TD>
</TR>
</TABLE>
");
}

1;

