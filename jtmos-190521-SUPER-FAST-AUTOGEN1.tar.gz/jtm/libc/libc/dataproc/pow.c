//
#include <stdio.h>

// TODO
double pow(double x, double y)
{
	//
	return 0;
}
