#include <stdio.h>
main()
{
	printf("Test\b\b\b\b\n");
}
