#ifndef __INCLUDED_GUIBLIT_H__
#define __INCLUDED_GUIBLIT_H__

//
int guiReadArea(VMODE *v, int x1,int y1, int x2,int y2, BYTE *buf);
int guiWriteArea(VMODE *v, int x1,int y1, int x2,int y2, BYTE *buf);
int guiWriteArea1(VMODE *v, int x1,int y1, int x2,int y2, BYTE *buf);
void guiMark(VMODE *v,
        int _x1, int _x2, int y1, int y2);
int guiBlit(VMODE *v,
        int x1,int y1,int x2,int y2,
        BYTE *src,int swidth,int sheight);

#endif

