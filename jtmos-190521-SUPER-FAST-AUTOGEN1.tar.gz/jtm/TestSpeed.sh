#!/bin/bash
date > SpeedCompile
./compileall
date >> SpeedCompile

