#!/bin/bash
ncftpput 192.168.0.10 -P 21 ./ graos.img
