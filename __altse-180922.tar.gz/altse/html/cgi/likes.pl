#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
#require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
#require "./modules/SearchSubModule.pm";
#require "./modules/DirectorySubModule.pm";
require "./modules/OpenHTMLDocument.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

###############################################################################
#
# HTML, HEAD, BODY.
#
# ./modules/OpenHTMLDocument.pm
OpenHTMLDocument();


# Call the main function.
#SocialLikes();
print("
<meta http-equiv=\"refresh\" content=\"0; url=/?q=like\">

");

#############################################
# THE END OF THE HTML DOCUMENT.
#############################################

#
CloseHTMLDocument();


#####################################################################################################
# ISTRUMP.LIFE CGI CODE.
# (C) Jari Tapio Tuominen (jari.t.tuominen@gmail.com);
sub SocialLikes
{
	################
	#
	# LOAD UP THE ALTSE's SOCIAL LIKES.
	#
	if(-e "$DB/likes.txt")
	{
		@lst = reverse LoadList("$DB/likes.txt");
	}
	
	#
	print("
<TABLE style=\"width: 100%;\">
<TR>
<TD>
<A NAME=\"likes\">
	<CENTER><H1>Tykättyjä hakuja:</H2></CENTER>
	
	<DIV style=\"background: #FFFF40; font-size: 24; padding: 10; \">
	<A HREF=\"/?#recommended\" target=\"_blank\"
		style=\"background: #FFFF40; font-size: 24; padding: 10; \">
	<H2>Tykkää uutisia tästä.</H2></A>
	</DIV>
</A>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		
	}
	#
	print("
</TD>
</TR>
</TABLE>
	");

}

1;
