#!/bin/bash
cd /home/vai/altse/crontab
#
export HTTP_PROXY=
#
PATH=$PATH:/home/vai/altse/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
export PATH

# No more termination of crawl processes, may interrupt downloads elsewhere.
# First let's take care of the processes we should not be running ...
#echo "First let's take care of the processes we should not be running ..."
#killall crawl
#sleep 30
#killall -9 crawl

#
mkdir -p /home/vai/db/www

# * LOCAL VAIHTOEHTOUUTISET & KULTAKAIVOS FRONT PAGE UPDATE
cd /home/vai/db/www

#echo "[Removing unnecessary files] Locating links.txt files and removing ..."
#find . -name 'links.txt'|xargs rm -f

# XVII. Waiting until Finnish news are crawled. Memory usage up to 1 Gb using ReiserFS (takes lots of cache here apparently.)
#WaitUntilCrawlsStop.pl
#killall crawl

echo "[Crawling] Crawling Finnish websites ..."
# FINNISH NEWS
cd /home/vai/db/www
screen -d -m crawl http://finnish.ruvr.ru/ -p
screen -d -m crawl http://www.rusgate.fi/ -p
screen -d -m crawl http://yle.fi/uutiset/venajan_verkossa/ -p
screen -d -m crawl http://maailma.net/uutiset/eurooppa/itaeurooppa/venaja -p
screen -d -m crawl http://www.finrusresearch.fi/ -p
screen -d -m crawl http://www.tvnewsradio.com/tv/tv-kanavat-venaja.htm -p
screen -d -m crawl http://www.suomenmaa.fi/ -p
screen -d -m crawl http://www.forssanlehti.fi/ -p
screen -d -m crawl http://www.pietarsaarensanomat.fi/ -p
screen -d -m crawl http://www.iijokiseutu.fi/ -p
screen -d -m crawl http://www.kansanuutiset.fi/ -p
screen -d -m crawl http://www.kansanaani.fi/ -p
screen -d -m crawl http://www.kansantahto.fi/ -p
screen -d -m crawl http://www.demari.fi/ -p
screen -d -m crawl http://www.koillissanomat.fi/ -p
screen -d -m crawl http://www.rantalakeus.fi/ -p
screen -d -m crawl http://www.uusiaika-lehti.fi/ -p
screen -d -m crawl http://www.kotiseudunsanomat.fi/ -p
screen -d -m crawl http://www.sisis.fi/ -p
screen -d -m crawl http://www.joutsanseutu.fi/ -p
screen -d -m crawl http://www.loimaanlehti.fi/ -p
screen -d -m crawl http://www.kainuunsanomat.fi/ -p
screen -d -m crawl http://www.parikkalan-rautjarvensanomat.fi/‎ -p
screen -d -m crawl http://www.kaleva.fi/ -p
screen -d -m crawl http://www.kauppalehti.fi/ -p
screen -d -m crawl http://www.lansi-savo.fi/ -p
screen -d -m crawl http://www.uusimaa.fi/ -p
screen -d -m crawl http://www.iltalehti.fi/ -p
screen -d -m crawl http://www.iltasanomat.fi/ -p
screen -d -m crawl http://www.ts.fi/ -p
screen -d -m crawl http://www.tervareitti.fi/ -p
screen -d -m crawl http://www.kotiseutu-uutiset.com/ -p
screen -d -m crawl http://www.vaikka.fi/ -p
screen -d -m crawl http://www.kymensanomat.fi/ -p
screen -d -m crawl http://www.ita-savo.fi/ -p
screen -d -m crawl http://www.shl.fi/ -p
screen -d -m crawl http://www.viiskunta.fi/ -p
screen -d -m crawl http://www.ilkka.fi/ -p
screen -d -m crawl http://www.hameensanomat.fi/ -p
screen -d -m crawl http://www.orivedensanomat.fi/ -p
screen -d -m crawl http://www.satakunnanviikko.fi/ -p
screen -d -m crawl http://www.maaseuduntulevaisuus.fi/ -p
screen -d -m crawl http://www.taloussanomat.fi/ -p
screen -d -m crawl http://www.warkaudenlehti.fi/ -p
screen -d -m crawl http://www.satakunnankansa.fi/ -p
screen -d -m crawl http://www.kuntsari.fi/ -p
screen -d -m crawl http://www.keski-uusimaa.fi/ -p
screen -d -m crawl http://www.loviisansanomat.fi/ -p
screen -d -m crawl http://www.ksml.fi/ -p
screen -d -m crawl http://www.sss.fi/ -p
screen -d -m crawl http://www.kangasalansanomat.fi/ -p
screen -d -m crawl http://www.pohjalainen.fi/ -p
screen -d -m crawl "http://www.hs.fi/haku/?haku=Niinist%C3%B6" -p
#WaitUntilCrawlsStop.pl

#sleep 30
#killall crawl

# FINANCE NEWS
echo "[Crawling] Crawling finance ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.marketwatch.com/ -p
screen -d -m crawl  http://www.foxbusiness.com/ -p
screen -d -m crawl  http://www.singaporetimes.com/ -p
screen -d -m crawl  http://www.europac.net/ -p
screen -d -m crawl  http://www.cnbc.com/ -p
screen -d -m crawl  http://www.themoscowtimes.com/ -p
screen -d -m crawl  http://www.valuewalk.com/ -p
screen -d -m crawl  http://www.seekingalpha.com/ -p
screen -d -m crawl  http://finance.yahoo.com/ -p
screen -d -m crawl  http://www.moneynews.com/ -p
screen -d -m crawl  http://www.bloomberg.com/ -p
screen -d -m crawl  http://www.telegraph.co.uk/finance/ -p
screen -d -m crawl  http://money.cnn.com/ -p
screen -d -m crawl  http://www.istockanalyst.com/ -p
screen -d -m crawl  http://www.upi.com/Business_News/ -p
screen -d -m crawl  http://www.businessinsider.com/ -p
screen -d -m crawl  http://www.businessweek.com/ -p
screen -d -m crawl  http://www.reuters.com/ -p
screen -d -m crawl  http://www.etftrends.com/ -p
screen -d -m crawl  http://www.bbc.co.uk/news/business/ -p
#sleep 30
#killall crawl

# ENTERTAINMENT NEWS
echo "[Crawling] Crawling entertainment ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.eonline.com/ -p
screen -d -m crawl  http://variety.com/ -p
screen -d -m crawl  http://www.tmz.com/ -p
screen -d -m crawl  http://www.imdb.com/ -p
screen -d -m crawl  http://perezhilton.com/ -p
screen -d -m crawl  http://www.rottentomatoes.com/ -p
screen -d -m crawl  http://games.allmyfaves.com/ -p
screen -d -m crawl  http://www.pogo.com/ -p
screen -d -m crawl  http://www.rollingstone.com/music -p
screen -d -m crawl  http://www.lyricsnmusic.com/ -p
screen -d -m crawl  http://serendip.me -p
screen -d -m crawl  http://www.time.com/time/ -p
screen -d -m crawl  http://www.nationalgeographic.com/ -p
screen -d -m crawl  http://9gag.com/ -p
screen -d -m crawl  http://www.funnyordie.com/ -p
screen -d -m crawl  http://www.youtube.com/ -p
screen -d -m crawl  http://espn.go.com/ -p
screen -d -m crawl  http://www.infinitylist.com/ -p
screen -d -m crawl  "http://www.fandango.com/?CJAFFILIATE&CMPID=cj_2477067" -p
screen -d -m crawl  http://www.stubhub.com/ -p
screen -d -m crawl  http://entertainment.allmyfaves.com/ -p
#sleep 30
#killall crawl

# ENTERTAINMENT NEWS
echo "[Crawling] Crawling weather ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.weather.com/ -p
screen -d -m crawl  http://www.wunderground.com/ -p
screen -d -m crawl  http://www.accuweather.com/ -p
screen -d -m crawl  http://www.intellicast.com/ -p
screen -d -m crawl  http://www.wxusa.com/ -p
screen -d -m crawl  http://weather.cnn.com/ -p
screen -d -m crawl  http://www.weatherimages.org/ -p
screen -d -m crawl  http://www.harmweather.com/ -p
screen -d -m crawl  http://weather.unisys.com/ -p
screen -d -m crawl  http://www.weatherforyou.com/ -p
screen -d -m crawl  http://www.myforecast.com/ -p
screen -d -m crawl  http://www.hwn.org/ -p
screen -d -m crawl  http://www.noaa.gov/ -p
screen -d -m crawl  http://www.usatoday.com/weather/ -p
screen -d -m crawl  http://www.sailflow.com/ -p
screen -d -m crawl  http://www.theweathernetwork.com/ -p
screen -d -m crawl  http://wwghcc.msfc.nasa.gov/GOES/goeseastconus.html -p
screen -d -m crawl  http://www.marineweather.com/ -p
#sleep 30
#killall crawl

# SPACE NEWS
echo "[Crawling] Crawling space news ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.space.com/ -p
screen -d -m crawl  http://www.ufoseek.com/ -p
#sleep 30
#killall crawl

# News from Russia
echo "[Crawling] Crawling 'news from Russia' ..."
cd /home/vai/db/www
screen -d -m crawl  http://sputniknews.com/russia/ -p
screen -d -m crawl  http://www.themoscowtimes.com/ -p
screen -d -m crawl  http://tass.com -p
screen -d -m crawl  http://english.pravda.ru/ -p
screen -d -m crawl  http://www.interfax.com/pressind.asp -p
screen -d -m crawl  http://www.youtube.com/user/sputniknews -p
#sleep 30
#killall crawl

# Science
echo "[Crawling] Crawling science ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.sciencenews.org/ -p
screen -d -m crawl  http://www.sciencedaily.com/ -p
screen -d -m crawl  http://www.bbc.co.uk/news/science_and_environment/ -p
screen -d -m crawl  http://www.nytimes.com/pages/science/ -p
screen -d -m crawl  http://esciencenews.com/ -p
screen -d -m crawl  http://news.sciencemag.org/ -p
screen -d -m crawl  http://student.societyforscience.org/sciencenews-students -p
screen -d -m crawl  http://www.huffingtonpost.com/science/ -p
screen -d -m crawl  http://www.eurekalert.org/ -p
screen -d -m crawl  http://www.abc.net.au/science/news/ -p
screen -d -m crawl  "http://www.richarddawkins.net/news_articles?category=Science&gclid=CJjd3OfWjrsCFYNxOgodQHYAAQ" -p
screen -d -m crawl  http://science.nasa.gov/science-news/ -p
screen -d -m crawl  http://www.sci-news.com/ -p
screen -d -m crawl  http://phys.org/science-news/ -p
screen -d -m crawl  http://news.yahoo.com/science/ -p
screen -d -m crawl  http://www.independent.co.uk/news/science/sun-will-flip-upside-down-within-weeks-says-nasa-8942769.html -p
screen -d -m crawl  http://www.scientificamerican.com/ -p
screen -d -m crawl  http://www.reuters.com/news/science -p
screen -d -m crawl  http://www.telegraph.co.uk/science/science-news/ -p
screen -d -m crawl  http://twitter.com/ScienceNewsOrg -p
screen -d -m crawl  http://www.newscientist.com/section/science-news -p
screen -d -m crawl  http://www.npr.org/sections/science/ -p
screen -d -m crawl  http://www.upi.com/Science_News/ -p
screen -d -m crawl  http://www.scienceagogo.com/ -p
screen -d -m crawl  http://www.science.org.au/nova/ -p
screen -d -m crawl  http://www.nsf.gov/news/ -p
screen -d -m crawl  http://www.theguardian.com/science -p
screen -d -m crawl  http://www.nbcnews.com/science -p
screen -d -m crawl  http://www.world-science.net/ -p
screen -d -m crawl  http://www.insidescience.org/ -p
screen -d -m crawl  http://www.latimes.com/science/ -p
screen -d -m crawl  http://onlinelibrary.wiley.com/journal/10.1002/%28ISSN%291943-0930 -p
#sleep 30
#killall crawl

# FTP Search (FTP sites)
echo "[Crawling] Crawling FTP sites ..."
cd /home/vai/db/www
screen -d -m crawl  http://ftp.sunet.se/pub/ -p
screen -d -m crawl  http://ftp.funet.fi/pub/ -p
screen -d -m crawl  http://ftp.urc.ac.ru/pub/ -p
screen -d -m crawl  http://vvstepa.wheelnt.ru/FTP_root/ -p
screen -d -m crawl  http://ftp.mozilla.org/pub/ -p
screen -d -m crawl  http://download.videolan.org/pub/ -p
screen -d -m crawl  http://pirxnet.pl/ftp/ -p
#sleep 120

#
echo "[Crawling] DPRK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.korea-dpr.com/ -p
screen -d -m crawl http://www.kcna.co.jp/ -p
screen -d -m crawl http://www.kp.undp.org/content/dprk/en/home/ -p
screen -d -m crawl http://www.kp.undp.org/dprk/en/home.html -p
screen -d -m crawl http://www.koryogroup.com/ -p
screen -d -m crawl http://www.youtube.com/user/stimmekoreas -p
screen -d -m crawl http://www.youtube.com/user/soffkj4y -p
#sleep 30
#killall crawl

# MUSIC Search (Music sites)
echo "[Crawling] Music ..."
cd /home/vai/db/www
screen -d -m crawl http://www.youtube.com/watch?v=GLv7eC_HZ0M&list=PL4B7518B6434C9639 -p
screen -d -m crawl http://www.youtube.com/watch?v=nJ7wei17HI0&list=RD1bXtgIokvhI -p
#sleep 30
#killall crawl

# CHINA Search (China sites)
echo "[Crawling] News from China ..."
cd /home/vai/db/www
screen -d -m crawl https://english.news.cn/home.htm -p
#sleep 30
#killall crawl

# News from UK
echo "[Crawling] News from UK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.bbc.co.uk/news/ -p
screen -d -m crawl http://www.dailymail.co.uk/news/index.htm -p
screen -d -m crawl http://www.theguardian.com/uk-news -p
screen -d -m crawl http://www.telegraph.co.uk/news/uknews/ -p
screen -d -m crawl http://www.express.co.uk/news/uk -p
screen -d -m crawl http://www.independent.co.uk/ -p
screen -d -m crawl http://www.thesundaytimes.co.uk/sto/?CMP=INTstp2 -p
screen -d -m crawl http://metro.co.uk/news/ -p
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/ -p
screen -d -m crawl http://www.mirror.co.uk/news/uk-news/ -p
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/ -p
screen -d -m crawl http://www.huffingtonpost.co.uk/ -p
screen -d -m crawl http://news.sky.com/uk -p
screen -d -m crawl http://www.britishnewspaperarchive.co.uk/ -p
screen -d -m crawl http://topics.nytimes.com/top/news/international/countriesandterritories/unitedkingdom/ -p
screen -d -m crawl http://www.youtube.com/user/BritishForcesNews -p
#sleep 30
#killall crawl

# IT jobs Search (IT jobs sites)
echo "[Crawling] News from IT jobs ..."
cd /home/vai/db/www
screen -d -m crawl "http://jobsearch.monster.com/search/?q=Information-Technology-__26-Information-Systems" -p
screen -d -m crawl "http://www.careerbuilder.com/" -p
screen -d -m crawl "http://www.linkedin.com/job/q-information-technology-jobs" -p
screen -d -m crawl "http://www.eurojobs.com/en/candidate/job.html?search%5Bkeyword%5D=information+technology&search%5Bsector%5D=&search%5Bcountry%5D=" -p
screen -d -m crawl "http://www.workinfinland.com/" -p
screen -d -m crawl "http://jobs.telegraph.co.uk/searchjobs/?Keywords=information+technology&location=" -p
screen -d -m crawl "http://www.prospects.ac.uk/graduate_job_search_results.htm" -p
screen -d -m crawl "http://www.ic-software.com/c-jobs" -p
#sleep 30
#killall crawl

#
echo "[Crawling] Crawling some other websites ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.svu.fi/kilpailut/ -p
#sleep 30
#killall crawl

#
#WaitUntilCrawlsStop.pl
#killall crawl

#
#cd /home/vai/db/www
#find . -name 'links.txt'|xargs rm -f

#
#sleep 30
