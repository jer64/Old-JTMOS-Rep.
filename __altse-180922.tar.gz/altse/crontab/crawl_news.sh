#!/bin/bash
cd /home/vai/altse/crontab
#
export HTTP_PROXY=
#
PATH=$PATH:/home/vai/altse/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
export PATH

# No more termination of crawl processes, may interrupt downloads elsewhere.
# First let's take care of the processes we should not be running ...
#echo "First let's take care of the processes we should not be running ..."
#killall crawl
#sleep 30
#killall -9 crawl

#
mkdir -p /home/vai/db/www

# * LOCAL VAIHTOEHTOUUTISET & KULTAKAIVOS FRONT PAGE UPDATE
cd /home/vai/db/www

#echo "[Removing unnecessary files] Locating links.txt files and removing ..."
#find . -name 'links.txt'|xargs rm -f

# XVII. Waiting until Finnish news are crawled. Memory usage up to 1 Gb using ReiserFS (takes lots of cache here apparently.)
#WaitUntilCrawlsStop.pl
#killall crawl

echo "[Crawling] Crawling Finnish websites ..."
# FINNISH NEWS
cd /home/vai/db/www
screen -d -m crawl http://finnish.ruvr.ru/ -p -f --maxpages 10
screen -d -m crawl http://www.rusgate.fi/ -p -f --maxpages 10
screen -d -m crawl http://yle.fi/uutiset/venajan_verkossa/ -p -f --maxpages 10
screen -d -m crawl http://maailma.net/uutiset/eurooppa/itaeurooppa/venaja -p -f --maxpages 10
screen -d -m crawl http://www.finrusresearch.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.tvnewsradio.com/tv/tv-kanavat-venaja.htm -p -f --maxpages 10
screen -d -m crawl http://www.suomenmaa.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.forssanlehti.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.pietarsaarensanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.iijokiseutu.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kansanuutiset.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kansanaani.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kansantahto.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.demari.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.koillissanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.rantalakeus.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.uusiaika-lehti.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kotiseudunsanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.sisis.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.joutsanseutu.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.loimaanlehti.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kainuunsanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.parikkalan-rautjarvensanomat.fi/‎ -p -f --maxpages 10
screen -d -m crawl http://www.kaleva.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kauppalehti.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.lansi-savo.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.uusimaa.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.iltalehti.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.iltasanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.ts.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.tervareitti.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kotiseutu-uutiset.com/ -p -f --maxpages 10
screen -d -m crawl http://www.vaikka.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kymensanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.ita-savo.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.shl.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.viiskunta.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.ilkka.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.hameensanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.orivedensanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.satakunnanviikko.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.maaseuduntulevaisuus.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.taloussanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.warkaudenlehti.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.satakunnankansa.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kuntsari.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.keski-uusimaa.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.loviisansanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.ksml.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.sss.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.kangasalansanomat.fi/ -p -f --maxpages 10
screen -d -m crawl http://www.pohjalainen.fi/ -p -f --maxpages 10
screen -d -m crawl "http://www.hs.fi/haku/?haku=Niinist%C3%B6" -p -f --maxpages 10
#WaitUntilCrawlsStop.pl
sleep 30
killall crawl

# FINANCE NEWS
echo "[Crawling] Crawling finance ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.marketwatch.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.foxbusiness.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.singaporetimes.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.europac.net/ -p -f --maxpages 10
screen -d -m crawl  http://www.cnbc.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.themoscowtimes.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.valuewalk.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.seekingalpha.com/ -p -f --maxpages 10
screen -d -m crawl  http://finance.yahoo.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.moneynews.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.bloomberg.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.telegraph.co.uk/finance/ -p -f --maxpages 10
screen -d -m crawl  http://money.cnn.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.istockanalyst.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.upi.com/Business_News/ -p -f --maxpages 10
screen -d -m crawl  http://www.businessinsider.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.businessweek.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.reuters.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.etftrends.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.bbc.co.uk/news/business/ -p -f --maxpages 10
sleep 30
killall crawl

# ENTERTAINMENT NEWS
echo "[Crawling] Crawling entertainment ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.eonline.com/ -p -f --maxpages 10
screen -d -m crawl  http://variety.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.tmz.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.imdb.com/ -p -f --maxpages 10
screen -d -m crawl  http://perezhilton.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.rottentomatoes.com/ -p -f --maxpages 10
screen -d -m crawl  http://games.allmyfaves.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.pogo.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.rollingstone.com/music -p -f --maxpages 10
screen -d -m crawl  http://www.lyricsnmusic.com/ -p -f --maxpages 10
screen -d -m crawl  http://serendip.me -p -f --maxpages 10
screen -d -m crawl  http://www.time.com/time/ -p -f --maxpages 10
screen -d -m crawl  http://www.nationalgeographic.com/ -p -f --maxpages 10
screen -d -m crawl  http://9gag.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.funnyordie.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.youtube.com/ -p -f --maxpages 10
screen -d -m crawl  http://espn.go.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.infinitylist.com/ -p -f --maxpages 10
screen -d -m crawl  "http://www.fandango.com/?CJAFFILIATE&CMPID=cj_2477067" -p -f --maxpages 10
screen -d -m crawl  http://www.stubhub.com/ -p -f --maxpages 10
screen -d -m crawl  http://entertainment.allmyfaves.com/ -p -f --maxpages 10
sleep 30
killall crawl

# ENTERTAINMENT NEWS
echo "[Crawling] Crawling weather ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.weather.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.wunderground.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.accuweather.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.intellicast.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.wxusa.com/ -p -f --maxpages 10
screen -d -m crawl  http://weather.cnn.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.weatherimages.org/ -p -f --maxpages 10
screen -d -m crawl  http://www.harmweather.com/ -p -f --maxpages 10
screen -d -m crawl  http://weather.unisys.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.weatherforyou.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.myforecast.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.hwn.org/ -p -f --maxpages 10
screen -d -m crawl  http://www.noaa.gov/ -p -f --maxpages 10
screen -d -m crawl  http://www.usatoday.com/weather/ -p -f --maxpages 10
screen -d -m crawl  http://www.sailflow.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.theweathernetwork.com/ -p -f --maxpages 10
screen -d -m crawl  http://wwghcc.msfc.nasa.gov/GOES/goeseastconus.html -p -f --maxpages 10
screen -d -m crawl  http://www.marineweather.com/ -p -f --maxpages 10
sleep 30
killall crawl

# SPACE NEWS
echo "[Crawling] Crawling space news ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.space.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.ufoseek.com/ -p -f --maxpages 10
sleep 30
killall crawl

# News from Russia
echo "[Crawling] Crawling 'news from Russia' ..."
cd /home/vai/db/www
screen -d -m crawl  http://sputniknews.com/russia/ -p -f --maxpages 10
screen -d -m crawl  http://www.themoscowtimes.com/ -p -f --maxpages 10
screen -d -m crawl  http://tass.ru/en -p -f --maxpages 10
screen -d -m crawl  http://english.pravda.ru/ -p -f --maxpages 10
screen -d -m crawl  http://www.interfax.com/pressind.asp -p -f --maxpages 10
screen -d -m crawl  http://www.youtube.com/user/sputniknews -p -f --maxpages 10
sleep 30
killall crawl

# Science
echo "[Crawling] Crawling science ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.sciencenews.org/ -p -f --maxpages 10
screen -d -m crawl  http://www.sciencedaily.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.bbc.co.uk/news/science_and_environment/ -p -f --maxpages 10
screen -d -m crawl  http://www.nytimes.com/pages/science/ -p -f --maxpages 10
screen -d -m crawl  http://esciencenews.com/ -p -f --maxpages 10
screen -d -m crawl  http://news.sciencemag.org/ -p -f --maxpages 10
screen -d -m crawl  http://student.societyforscience.org/sciencenews-students -p -f --maxpages 10
screen -d -m crawl  http://www.huffingtonpost.com/science/ -p -f --maxpages 10
screen -d -m crawl  http://www.eurekalert.org/ -p -f --maxpages 10
screen -d -m crawl  http://www.abc.net.au/science/news/ -p -f --maxpages 10
screen -d -m crawl  "http://www.richarddawkins.net/news_articles?category=Science&gclid=CJjd3OfWjrsCFYNxOgodQHYAAQ" -p -f --maxpages 10
screen -d -m crawl  http://science.nasa.gov/science-news/ -p -f --maxpages 10
screen -d -m crawl  http://www.sci-news.com/ -p -f --maxpages 10
screen -d -m crawl  http://phys.org/science-news/ -p -f --maxpages 10
screen -d -m crawl  http://news.yahoo.com/science/ -p -f --maxpages 10
screen -d -m crawl  http://www.independent.co.uk/news/science/sun-will-flip-upside-down-within-weeks-says-nasa-8942769.html -p -f --maxpages 10
screen -d -m crawl  http://www.scientificamerican.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.reuters.com/news/science -p -f --maxpages 10
screen -d -m crawl  http://www.telegraph.co.uk/science/science-news/ -p -f --maxpages 10
screen -d -m crawl  http://twitter.com/ScienceNewsOrg -p -f --maxpages 10
screen -d -m crawl  http://www.newscientist.com/section/science-news -p -f --maxpages 10
screen -d -m crawl  http://www.npr.org/sections/science/ -p -f --maxpages 10
screen -d -m crawl  http://www.upi.com/Science_News/ -p -f --maxpages 10
screen -d -m crawl  http://www.scienceagogo.com/ -p -f --maxpages 10
screen -d -m crawl  http://www.science.org.au/nova/ -p -f --maxpages 10
screen -d -m crawl  http://www.nsf.gov/news/ -p -f --maxpages 10
screen -d -m crawl  http://www.theguardian.com/science -p -f --maxpages 10
screen -d -m crawl  http://www.nbcnews.com/science -p -f --maxpages 10
screen -d -m crawl  http://www.world-science.net/ -p -f --maxpages 10
screen -d -m crawl  http://www.insidescience.org/ -p -f --maxpages 10
screen -d -m crawl  http://www.latimes.com/science/ -p -f --maxpages 10
screen -d -m crawl  http://onlinelibrary.wiley.com/journal/10.1002/%28ISSN%291943-0930 -p -f --maxpages 10
sleep 30
killall crawl

# FTP Search (FTP sites)
echo "[Crawling] Crawling FTP sites ..."
cd /home/vai/db/www
screen -d -m crawl  http://ftp.sunet.se/pub/ -p -f --maxpages 10
screen -d -m crawl  http://ftp.funet.fi/pub/ -p -f --maxpages 10
screen -d -m crawl  http://ftp.urc.ac.ru/pub/ -p -f --maxpages 10
screen -d -m crawl  http://vvstepa.wheelnt.ru/FTP_root/ -p -f --maxpages 10
screen -d -m crawl  http://ftp.mozilla.org/pub/ -p -f --maxpages 10
screen -d -m crawl  http://download.videolan.org/pub/ -p -f --maxpages 10
screen -d -m crawl  http://pirxnet.pl/ftp/ -p -f --maxpages 10
sleep 120

#
echo "[Crawling] DPRK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.korea-dpr.com/ -p -f --maxpages 10
screen -d -m crawl http://www.kcna.co.jp/ -p -f --maxpages 10
screen -d -m crawl http://www.kp.undp.org/content/dprk/en/home/ -p -f --maxpages 10
screen -d -m crawl http://www.kp.undp.org/dprk/en/home.html -p -f --maxpages 10
screen -d -m crawl http://www.koryogroup.com/ -p -f --maxpages 10
screen -d -m crawl http://www.youtube.com/user/stimmekoreas -p -f --maxpages 10
screen -d -m crawl http://www.youtube.com/user/soffkj4y -p -f --maxpages 10
sleep 30
killall crawl

# MUSIC Search (Music sites)
echo "[Crawling] Music ..."
cd /home/vai/db/www
screen -d -m crawl http://www.youtube.com/watch?v=GLv7eC_HZ0M&list=PL4B7518B6434C9639 -p -f --maxpages 10
screen -d -m crawl http://www.youtube.com/watch?v=nJ7wei17HI0&list=RD1bXtgIokvhI -p -f --maxpages 10
sleep 30
killall crawl

# CHINA Search (China sites)
echo "[Crawling] News from China ..."
cd /home/vai/db/www
screen -d -m crawl http://www.shenzhen-standard.com/ -p -f --maxpages 10
screen -d -m crawl http://www.chinadaily.com.cn/china/ -p -f --maxpages 10
screen -d -m crawl http://www.china.org.cn/ -p -f --maxpages 10
screen -d -m crawl http://www.xinhuanet.com/english/china/ -p -f --maxpages 10
screen -d -m crawl http://www.sznews.com/english/ -p -f --maxpages 10
screen -d -m crawl http://europe.chinadaily.com.cn/ -p -f --maxpages 10
sleep 30
killall crawl

# News from UK
echo "[Crawling] News from UK ..."
cd /home/vai/db/www
screen -d -m crawl http://www.bbc.co.uk/news/ -p -f --maxpages 10
screen -d -m crawl http://www.dailymail.co.uk/news/index.htm -p -f --maxpages 10
screen -d -m crawl http://www.theguardian.com/uk-news -p -f --maxpages 10
screen -d -m crawl http://www.telegraph.co.uk/news/uknews/ -p -f --maxpages 10
screen -d -m crawl http://www.express.co.uk/news/uk -p -f --maxpages 10
screen -d -m crawl http://www.independent.co.uk/ -p -f --maxpages 10
screen -d -m crawl http://www.thesundaytimes.co.uk/sto/?CMP=INTstp2 -p -f --maxpages 10
screen -d -m crawl http://metro.co.uk/news/ -p -f --maxpages 10
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/ -p -f --maxpages 10
screen -d -m crawl http://www.mirror.co.uk/news/uk-news/ -p -f --maxpages 10
screen -d -m crawl http://www.thesun.co.uk/sol/homepage/ -p -f --maxpages 10
screen -d -m crawl http://www.huffingtonpost.co.uk/ -p -f --maxpages 10
screen -d -m crawl http://news.sky.com/uk -p -f --maxpages 10
screen -d -m crawl http://www.britishnewspaperarchive.co.uk/ -p -f --maxpages 10
screen -d -m crawl http://topics.nytimes.com/top/news/international/countriesandterritories/unitedkingdom/ -p -f --maxpages 10
screen -d -m crawl http://www.youtube.com/user/BritishForcesNews -p -f --maxpages 10
sleep 30
killall crawl

# IT jobs Search (IT jobs sites)
echo "[Crawling] News from IT jobs ..."
cd /home/vai/db/www
screen -d -m crawl "http://jobsearch.monster.com/search/?q=Information-Technology-__26-Information-Systems" -p -f --maxpages 10
screen -d -m crawl "http://www.careerbuilder.com/" -p -f --maxpages 10
screen -d -m crawl "http://www.linkedin.com/job/q-information-technology-jobs" -p -f --maxpages 10
screen -d -m crawl "http://www.eurojobs.com/en/candidate/job.html?search%5Bkeyword%5D=information+technology&search%5Bsector%5D=&search%5Bcountry%5D=" -p -f --maxpages 10
screen -d -m crawl "http://www.workinfinland.com/" -p -f --maxpages 10
screen -d -m crawl "http://jobs.telegraph.co.uk/searchjobs/?Keywords=information+technology&location=" -p -f --maxpages 10
screen -d -m crawl "http://www.prospects.ac.uk/graduate_job_search_results.htm" -p -f --maxpages 10
screen -d -m crawl "http://www.ic-software.com/c-jobs" -p -f --maxpages 10
sleep 30
killall crawl

#
echo "[Crawling] Crawling some other websites ..."
cd /home/vai/db/www
screen -d -m crawl  http://www.svu.fi/kilpailut/ -p -f --maxpages 10
sleep 30
killall crawl

#
#WaitUntilCrawlsStop.pl
#killall crawl

#
#cd /home/vai/db/www
#find . -name 'links.txt'|xargs rm -f

#
sleep 30
