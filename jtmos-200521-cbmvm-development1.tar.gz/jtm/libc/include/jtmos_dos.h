// Turbo C emulation
//
#include <stdio.h>

