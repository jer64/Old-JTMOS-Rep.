#ifndef __INCLUDED_FILEDIR_H__
#define __INCLUDED_FILEDIR_H__

int mkdir(const char *path, ...);
int rmdir(const char *path, ...);

#endif

