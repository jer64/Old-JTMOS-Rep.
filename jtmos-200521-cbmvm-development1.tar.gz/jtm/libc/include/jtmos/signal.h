#ifndef __INCLUDED_JTMLIBC_SIGNAL_H__
#define __INCLUDED_JTMLIBC_SIGNAL_H__

#include "jtmos_signal.h"

void *signal(int num, void *handler);
int raise(int sig);

#endif

