// Wrapper
#include <jtmos/stdarg.h>
