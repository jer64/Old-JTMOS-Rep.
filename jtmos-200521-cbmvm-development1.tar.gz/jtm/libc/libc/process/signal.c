// =======================================
// signal.c
// TODO TODO TODO ....
// =======================================
#include "basdef.h"
#include "signal.h"

// TODO
void *signal(int num, void *handler)
{
	return NULL;
}

/* NAME
         raise - send a signal to the current process

  SYNOPSIS
         #include <signal.h>
  
         int raise (int sig);

	TODO !!!!!!!!!!:
 */
int raise(int sig)
{
	return 0;
}

