#!/bin/bash
cd jtmos
ln -fs ../basics/*.h .
ln -fs ../date/*.h .
ln -fs ../process/*.h .
ln -fs ../console/*.h .
ln -fs ../process/*.h .
ln -fs ../dataproc/*.h .
ln -fs ../memory/*.h .
ln -fs ../io/*.h .
ln -fs ../termios/*.h .
ln -fs ../random/*.h .
ln -fs ../error/*.h .
ln -fs ../file/*.h .
ln -fs ../video/*.h .
ln -fs ../audio/*.h .
ln -fs ../turboc/*.h .
ln -fs ../mouse/*.h .
cd ..

