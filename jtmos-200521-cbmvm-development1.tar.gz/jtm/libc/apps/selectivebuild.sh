#!/bin/bash
echo "Building only selected applications(edit selectivebuild.sh for changes) ..."
./utilsdisk.sh
#make -f picture.mak
#make -f sqsh.mak
#make -f sqdsk.mak
#make -f install.mak
#make -f sqsh.mak
#make -f snake.mak
#make -f memconfig.mak
#make -f cp.mak
#make -f mv.mak

