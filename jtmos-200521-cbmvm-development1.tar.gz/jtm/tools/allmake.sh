#!/bin/bash
make graos
make disk
make disk2
make web
make tools
