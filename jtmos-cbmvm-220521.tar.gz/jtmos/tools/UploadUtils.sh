#!/bin/bash
#ncftpput 192.168.0.10 -u code -p code -P 21 ./ jtm32.img
#ncftpput 192.168.0.10 -t 1 -P 21 ./ utilsdisk.img
#
