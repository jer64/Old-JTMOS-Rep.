#ifndef __INCLUDED_DFILE_H__
#define __INCLUDED_DFILE_H__

//
#include <stdio.h>

//
int readfile(const char *fname, BYTE *buf, int len, int offset);
int writefile(const char *fname, BYTE *buf, int len, int offset);

#endif




