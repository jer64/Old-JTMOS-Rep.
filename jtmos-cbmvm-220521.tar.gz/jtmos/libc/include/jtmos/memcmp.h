//
#ifndef __INCLUDED_MEMCMP_H__
#define __INCLUDED_MEMCMP_H__

//
int memcmp(const void *dstpp, const void *srcpp, int len);

#endif




