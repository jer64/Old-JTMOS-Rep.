#ifndef __INCLUDED_JTMLIBC_STRPBRK_H__
#define __INCLUDED_JTMLIBC_STRPBRK_H__

char *strpbrk(const char *s, const char *accept);

#endif
