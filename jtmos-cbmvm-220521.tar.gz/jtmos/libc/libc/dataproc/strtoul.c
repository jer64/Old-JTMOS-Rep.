#include "basdef.h"
#include "console.h"
#include "string.h"

#define UNSIGNED        1

#include "strtol.c"

