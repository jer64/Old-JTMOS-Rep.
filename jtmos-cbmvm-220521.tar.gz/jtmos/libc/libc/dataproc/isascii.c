#include <stdio.h>
#include "isascii.h"

int isascii(int c)
{
	if(c<128)	return TRUE;
			else
			return FALSE;
}
