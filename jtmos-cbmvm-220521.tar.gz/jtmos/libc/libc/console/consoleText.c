// consoleText.c
#include <stdio.h>

//
/*int gettext(int left,int top,int right,int bottom,
		void *destin)
{
	//
}*/

//
int puttext(int left,int top,int right,int bottom,
		void *destin)
{
	//
}

int movetext(int left, int top,
	int right, int bottom,
	int destleft, int desttop)
{
	//
}

//



