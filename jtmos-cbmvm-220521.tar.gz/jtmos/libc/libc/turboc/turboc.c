// ====================================================
// Turbo C emulation unit
// (C) 2002-2003 by Jari Tuominen(jari@vunet.org)
// ====================================================
#include "basdef.h"
#include "console.h"
#include "syscallcodes.h"
#include "cpu.h"
#include "scall.h"

//

//

