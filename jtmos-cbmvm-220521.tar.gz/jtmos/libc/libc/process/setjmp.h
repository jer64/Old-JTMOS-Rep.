#ifndef __INCLUDED_JTMLIBC_SETJMP_H__
#define __INCLUDED_JTMLIBC_SETJMP_H__

#include "process.h"
int setjmp(jmp_buf env);

#endif

