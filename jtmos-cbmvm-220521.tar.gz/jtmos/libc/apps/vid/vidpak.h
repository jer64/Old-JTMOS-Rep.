#ifndef __INCLUDED_VIDPAK_H__
#define __INCLUDED_VIDPAK_H__

//
typedef unsigned char BYTE;
typedef unsigned short int WORD;
typedef unsigned long int DWORD;

#endif



