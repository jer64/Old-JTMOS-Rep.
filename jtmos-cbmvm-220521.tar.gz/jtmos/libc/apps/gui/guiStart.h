#ifndef __INCLUDED_GUISTART_H__
#define __INCLUDED_GUISTART_H__

extern VMODE vmode;

int guiStart(void);

#endif

