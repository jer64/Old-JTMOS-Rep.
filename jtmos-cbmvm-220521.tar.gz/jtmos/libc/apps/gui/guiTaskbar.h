#ifndef __INCLUDED_GUITASKBAR_H__
#define __INCLUDED_GUITASKBAR_H__

#include "graos.h"
void guiTaskbarCall(VMODE *v);

#endif
