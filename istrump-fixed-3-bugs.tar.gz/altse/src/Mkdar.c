/////////////////////////////////////////////////////////////////////////////
//
// Mkdar.c - convert HTML files to text.
// (C) 2005 by Jari Tuominen (jari@vunet.org).
//
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"

//
int main(int argc, char **argv)
{
	//

	//
	return 0;
}

//
