// grabtitle.c
#include <stdio.h>
#include "selib.h"

//
int main(int argc, char **argv)
{
	FILE *f;
	int ch;
	BYTE *buf,*tbuf;
	int l_buf,i,i2,l,found,x;
	static char str[256];

	//
	l_buf = 1024*1024*1;
	buf = malloc(l_buf);
	tbuf = malloc(l_buf);

	//
	if(argc<2)
	{
		f = stdin;
	}
	else
	{
		f = popen(argv[1], "r");
		if(f==NULL) { return; }
	}

	//
	for(i=0; !feof(f) && i<(l_buf-1); )
	{
		//
		ch = fgetc(f);

		//
		tbuf[i] = ch;
		buf[i++] = ch;
	}
	buf[i] = 0;
	l = i;
	//
	if(!(argc<2)) { pclose(f); }

	//
	LowerCaseString(buf);

	//
	for(i=0,found=0; i<l; i++)
	{
		//
		if( !strncmp(buf+i,"<title>",7) )
		{
			found = 1;
			break;
		}
	}
	//
	i+=7;

	//
	for(x=0; x<250; )
	{
		if( !strncmp(buf+i,"</title>",8) ) { break; }
		str[x++] = tbuf[i++];
	}
	str[x++] = 0;

	//
	OkWord(str);
	RemoveControlCodes(str);

	//
	fprintf(stdout, "%s", str);

	//
	return 0;
}

//
