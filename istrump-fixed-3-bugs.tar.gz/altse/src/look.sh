#!/bin/bash
find . -name 'multimedia.txt' -type f
