
///////////////////////////////////////////////////////////////////////////
//
// defragMain.c - KEYWORD INDEX defragmentation tool.
//
///////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
//#include <db.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "iscfg.h"

//
int main(int argc, char **argv)
{
	int i;

	//
	if(argc<2)
	{
		//
		fprintf(stderr, "KEYWORD INDEX DEFRAGMENTATION TOOL\n");
		fprintf(stderr, "Usage: defrag [which dictionary a-z OR all] [-i which index] [-l which index level 0-6 only for speed optimized mode] [-o enable search performance optimization mode]\n");
		return 0;
	}
	int run_on_rank = 0;

	//
	AltseLoadConfig();

        //
        for(i=1; i<argc; i++) {
                // define which index to use for searches,
                // f.e. -i 1 (default is 0)


                if( !strncmp(argv[i],"-o",2) ) {
                        //
			OPTIMIZE_FOR_SEARCH_SPEED = 1;
		}

                if( !strncmp(argv[i],"-i",2) ) {
                        //
                        sscanf(argv[i]+3, "%d", &ProductionIndexNr);
			fprintf(stderr, "%s/%s: using production index %d\n",
				__FUNCTION__,__FILE__, ProductionIndexNr);
                }


                if( !strncmp(argv[i],"-l",2) ) {
                        //
                        sscanf(argv[i]+4, "%d", &run_on_rank);
			fprintf(stderr, "%s/%s: defragmenting on index level %d\n",
				__FUNCTION__,__FILE__, ProductionIndexNr);
                }
        }

	//
	if(!strcmp(argv[1], "all"))
	{
		defragAll();
		return 0;
	}

	//
	Defragment(argv[1][0], run_on_rank);

	//
	return 0;
}

//


