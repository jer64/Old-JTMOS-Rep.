//--------------------------------------------------------------------------------------------
//
// wliconv.c
// (C) 2005 by Jari Tuominen (jari@vunet.org).
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"

//
int main(int argc, char **argv)
{
	DWORD i,i2,i3,i4,space,ch,non;
	FILE *f,*f2;

	//
	if(argc<2)
	{
		//
	//	fprintf(stderr, "Usage: wliconv [output file name]\n");
	//	fprintf(stderr, "Input = stdin\n");
	//	return 0;
	}

	//
	f = stdin;
	if(argc<2)
	{
		f2 = stdout;
	}
	else
	{
		f2 = fopen(argv[1], "wb");
	}
	for(i=0,space=0,non=0; !feof(f); i++)
	{
		ch = fgetc(f);
		if( !isok(ch) )
		{
			if(!space && non>0)
			{
				fputc(' ', f2);
				space++;
			}
		}
		else
		{
			fputc(ch, f2); non++;
			space = 0;
		}
	}
	fclose(f);
	if(!(argc<2))	fclose(f2);

	//
	return 0;
}


