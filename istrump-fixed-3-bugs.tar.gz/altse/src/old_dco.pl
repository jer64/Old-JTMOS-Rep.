#!/usr/bin/perl
##########################################################################
#
# Dictionary archiver.
# Builds single files out of individual dictionaries.
#
##########################################################################
#
use POSIX;
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =          "/db/sdb";   # search database root directory
$CID =          "$SDB/cid";             # central index
$LISTS =        "$SDB/cid/lists";       # list files directory
$DADI =         "$SDB/cid/data";        # data files
$DICT =         "$SDB/cid/dict";        # big index with dictionaries

#
main();

############################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,$str,$f,$fn,$fn2,$dir,@sp);

	# Read list of directories.
	open($f, "find $DICT -name '*.dic' -type f|") || die "Can't read directory...\n";

	#
	for($i=0; !eof($f); $i++)
	{
		#   1   2   3   4  5  6
		# /db/sdb/cid/dict/0/30/31-36-34.dic
		$fn = <$f>; chomp $fn;
		$fn2 = $fn;
		$fn2 =~ s/\/dict\//\/dic\//;
		@sp = split(/\//, $fn);

		#
		$dir = "/db/sdb/cid/dic/$sp[5]";
		mkdir($dir);
		$dir = "/db/sdb/cid/dic/$sp[5]/$sp[6]";
		mkdir($dir);
		#
		system("dictconv $fn $fn2");
	}

	#
	close($f);
}
