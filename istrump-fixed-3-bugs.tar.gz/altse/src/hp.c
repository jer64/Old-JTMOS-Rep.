/////////////////////////////////////////////////////////////////////////////////////
//
// hp.c HTML to text converter.
// (C) 2005 by Jari Tuominen (jari@vunet.org).
//
/////////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "selib.h"

//
FILE *opf;

//
typedef struct
{
	//
	BYTE *buf;
	DWORD l_buf;

	//
	int x;
}HTML;
HTML html;

/////////////////////////////////////////////////////////////////////////////////////
//
int isSpace(int ch)
{
	//
	if(ch==0x09 || ch==' ')
		return TRUE;

	//
	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////////////
//
int HandleTag(char *s1, char *s2)
{
	static int body=FALSE,script=FALSE,remark=FALSE;
	static char tmp[8192];
	int i,i2,i3,i4,l,last,lc,first;

	//
	if( !strncasecmp(s1, "script",6) )
	{
		//
		script = TRUE;
		return 0;
	}

	//
	if( !strncasecmp(s1, "/script",7) )
	{
		//
		script = FALSE;
		return 0;
	}

	//
	if( !strncasecmp(s1, "body",4) )
	{
		//
		body = TRUE;
		return 0;
	}

	//
	if( !strncasecmp(s1, "img src=",8) )
	{
		//
		for(i=8; s1[i]!=0 && s1[i]!='\'' && s1[i]!='\"'; i++) { }
		if(s1[i]!=0) i++;

		//
		for(i2=0; s1[i]!=0 && s1[i]!='\'' && s1[i]!='\"'; i++)
		{
			if(s1[i]=='\n') continue;
			tmp[i2++] = s1[i];
		}
		tmp[i2]=0;
		//
		if(strlen(tmp)>2)
			fprintf(opf, "%s\n", tmp);

		//
		return 0;
	}

	//
	if( !strncasecmp(s1, "/body",5) )
	{
		//
		body = FALSE;
		return 0;
	}

	// TEXT PRINT OUT.
	if(body && !script)
	{
		//
		l = strlen(s2);
		for(i=0,i2=0,first=1; i<l; i++)
		{
			//
			if(s2[i]==' ' && s2[i+1]==' ') { continue; }
			if(s2[i]=='\n') { continue; }
			//
			if( isSpace(s2[i]) && first) { continue; }

			//
			tmp[i2++] = s2[i];
			first = 0;
		}
		tmp[i2]=0;

		//
		while( strlen(tmp) && isSpace(tmp[strlen(tmp)-1]) )
		{
			tmp[strlen(tmp)-1]=0;
		}

		//
		if( strcmp(tmp,"") )
		{
			// TEXT PRINT OUT...
		/*	fprintf(stdout, "\"\" %.2ux,%.2ux :  %s \"\"\n",
				tmp[0],tmp[1],
				tmp);*/
//			fprintf(stdout, "%s ", tmp);
		}
		return 0;
	}

	//
//	fprintf(stderr, "\nUNHANDLED \"%s\", \"%s\"\n",
//		s1,s2);
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////
//
int ParseHTML(HTML *h, char *_fn)
{
	FILE *f;
	DWORD i,i2,i3,i4,sz,offs1,offs2,l_buf,oi,l;
	static char str[8192],str2[8192],str3[8192],str4[8192],
		cmd[8192],quotes,fn[8192],ofn[8192],*p,
		popen_cmd[8192];
	BYTE *buf;

	//------------------------------------------------------------------------
	//
	// Allocate & read.
	//

	//
	strcpy(fn, _fn);
	if( strncmp(fn+(strlen(fn)-3),".gz",3) )
	{
		strcat(fn, ".gz");
	}

	//
	strcpy(ofn, fn);
	if( (p = strstr(ofn, ".html.gz"))!=NULL )
	{
		strncpy(p, ".imglink", 8);
	}
	else
		return;
	opf = fopen(ofn, "wt");

	//
	sprintf(popen_cmd, "zcat %s", fn);
	f = popen(popen_cmd, "rb");
	if(f==NULL) {
		fprintf(stderr, "%s/%s/line %d: File not found (%s).\n", __FILE__,__FUNCTION__,__LINE__, fn);
		return 1;
	}
	//
	l_buf = 1024*512;
	buf = malloc(l_buf);
	//
	for(i=0; !feof(f) && i<l_buf; i++)
	{
		buf[i] = fgetc(f);
	}
	sz = i;
	//
	fclose(f);

	//------------------------------------------------------------------------
	//
	// Parse.
	//

	//
	for(i=0; i<sz; i++)
	{
                // Find '<'
                for(quotes=0; i<sz; i++)
		{
			if(buf[i]=='\"') { quotes ^= 1; continue; }
			if(quotes) continue;

			if(buf[i]=='<') break;
		}
		i++;
                for(i2=0,quotes=0; i<sz && i2<8100; i++)
		{
//			if(buf[i]=='\"') { quotes ^= 1; continue; }
//			if(quotes) continue;

			str[i2++]=buf[i];

			if(buf[i]=='>')break;
		}
                str[i2]=0;

                //
                offs1 = i+1;
                // Find '>'
                for(quotes=0; i<sz; i++)
		{
			if(buf[i]=='\"') { quotes ^= 1; continue; }
			if(quotes) continue;

			if(buf[i]=='<') break;
		}
                offs2 = i;

                //
                for(i=offs1,i2=0,quotes=0; i<offs2 && i2<8100; i++)
                {
			if(buf[i]=='\"') { quotes ^= 1; continue; }
			if(quotes) continue;

                        str2[i2++] = buf[i];
                }
                str2[i2]=0;

                //
                i = offs1;

		// SKIP REMARKS......

		//
		if( !strncasecmp(str, "!--",3) )
		{
			//
			if(
				str[strlen(str)-1]=='>' &&
				str[strlen(str)-2]=='-' &&
				str[strlen(str)-3]=='-'
				)
				// Single line remark.
				continue;

	                //
	                for(i=offs1; i<sz; i++)
	                {
				//
				//fprintf(stderr, "%c", buf[i]);
				if( !strncasecmp(buf+i, "-->",3)  )
				{
					i += 3;
					goto past;
				}
			}

			//
			continue;
		}

		// ........

                //
		HandleTag(str,str2);
past:
	}

	//
	fclose(opf);

	//------------------------------------------------------------------------
	//
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////
//
int main(int argc, char **argv)
{
	int i;

	//
	if(argc<2)
	{
		//
		fprintf(stderr, "Usage: hp [HTML file]\n");
		return 0;
	}

	//
	for(i=1; i<argc; i++)
	{
		//
		fprintf(stdout, "%s\n", argv[i]);
		//
		ParseHTML(&html, argv[i]);
	}

	//
	return 0;
}

//

