#!/usr/bin/perl
#
# DownloadImages.pl -i [which index]
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";
require "$ENV{'HOME'}/sdb/html/cgi/modules/GetPageImages.pm";

#
AltseOpenConfig();

#
$AMOUNT_OF_PROCESSES_FOR_DOWNLOADING = 20;

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2);

        #
        $indexnr = -1;
        for($i=0; $i<($#ARGV+1); $i++) {
                if($ARGV[$i] eq "-i") {
                        $indexnr = int($ARGV[$i+1]);
                }
        }
	if($indexnr==-1) {
		print STDERR "Usage: DownloadImages.pl [-i INDEXNR]\n";
		print STDERR "Example: DownloadImages.pl -i 0\n";
		print STDERR "You have to specify index number always\n";
		exit;
	}

	#
	my $www_dir_path = "$DB/wwwimages";
	if($indexnr>0) {
		$www_dir_path .= "_$indexnr";
	}
	system("rm -vf \"$www_dir_path/already.txt\"");

	#
	my @tmp = LoadList("gid $indexnr -q|");
	$gid = $tmp[0];

	# How many images to have a single image processer process handle?
	my $PER = $gid/$AMOUNT_OF_PROCESSES_FOR_DOWNLOADING;

	#
	printf STDERR "Launching %d image downloader processes (index $indexnr/$gid pages) ...\n",
		($gid/$PER)+1;
	sleep(5);

	#
	for($i=0; $i<($gid+1); $i+=$PER) {
			my $lasti = $i+$PER;
			if($lasti>$gid) { $lasti = $gid; }
			system("screen -d -m dlim.pl $i ".int($lasti)." -i ".int($indexnr)."");
	}
	print "Done, background processes running ...";

	#
}
