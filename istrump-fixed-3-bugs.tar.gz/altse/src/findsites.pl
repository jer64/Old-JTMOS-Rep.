#!/usr/bin/perl
# buildpageids2fn.pl - Builds a page ID-connected list of all pages stored on the WWW-cache (db/www).
# pageids2fn: Page IDs to file name -conversion database.
require "$ENV{'HOME'}/sdb/bin/tools.pl";
use Cwd 'chdir';

#
AltseOpenConfig();

# pageids2fn: Page IDs to file name -conversion database.
$PAGEIDSPATH = "pageids2fn";

#
main();

#
sub main
{
	my ($i,$i2,@lst,$str,$str2,$url,$f,$path,%ald,
		$n1,$n2,$n3,$n4,$n5,$n6,$n7,$n8,$n9,$n10,
		$hexx,$fn,$fn2);

	my $filterer;

	##
	$filterer = "";
	if($ARGV[0] ne "") {
		$filterer = $ARGV[0];
	}

	#
	print STDERR "buildpageids2fn.pl running ...\n";

	#
	@lst = LoadList("$DB/www/list.txt");

	#
	chdir("$DB");
	#
	mkdir($PAGEIDSPATH);

	#
	my $PPF = 2000;
	my $SUB = 200;
	my $nn = 0;
	loop: for($i=0,$nn=0; $i<($#lst+1); $i++) {
		$sect = int($nn / $PPF)	% $PPF; # N paths per file
		$n1 = int($sect/$SUB)	% $SUB;	# N files per directory
		$n2 = int($n1/$SUB)	% $SUB;	# N subdirectories at most per directory
		$n3 = int($n2/$SUB)	% $SUB;	# N subdirectories at most per subdirectories
		$n4 = int($n3/$SUB)	% $SUB;	# N subdirectories at most per subdirectories
		$path = sprintf $PAGEIDSPATH . "/%d/%d/%d/%d",
			$n4,$n3,$n2,$n1;
		$fn = sprintf "$path/%d.dat",
			$sect;
		system("mkdir -p \"$path\"");

		print STDERR "$i / $#lst ($nn pages)    \r";

		open($f, ">$fn");
		for($i2=0; $i2<$PPF && $i<($#lst+1); $i2++,$i++) {
			if($filterer eq "")	{
				print $f "$lst[$i]\n";
				$nn++;
			} else {
				if($lst[$i] =~ /$filterer/) {
					print $f "$lst[$i]\n";
					$nn++;
				}
			}
		}
		close($f);
	}

	open($f, ">".$PAGEIDSPATH."/id.cnt");
	print $f "$nn\n";
	close($f);

	#
	my $ff;
	open($ff, ">$DB/cid/gid.txt") || die "Can't write \"$DB/gid.txt\"\n";
	print $ff $nn;
	close($ff);

	print STDERR "\nID to file name conversion for $nn WWW-pages generated.\n";

	#
}

#

