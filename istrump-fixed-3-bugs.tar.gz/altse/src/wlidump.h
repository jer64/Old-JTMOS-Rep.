//
#ifndef __INCLUDED_WLIDUMP_H__
#define __INCLUDED_WLIDUMP_H__

//
#define BIGFN   "/db/cid/data/words"
#define BLS     16384

//--------------------------------------------------------------------------------------------
//
int WliDump(int sid,  BYTE *buf,int l_buf, int index_to_use);

#endif

