#include <stdio.h>
#include <zlib.h>

int main(int argc, char **argv)
{
	FILE *f;
	int len,i,i2,spaces,zeroes,nonasc,ch;
	static char str[2048];

	//
	if(argc<2) { return -1; }
	sprintf(str, "zcat %s", argv[1]);
	f = popen(str, "r");
	for(i=0,len=0,zeroes=0,nonasc=0,spaces=0; ; i++,len++) {
		ch = fgetc(f);
		if(ch==EOF) { break; }
		if(ch==32 || ch=='\n') { spaces++; }
		if(ch>127) { nonasc++; }
		if(ch==0)  { zeroes++; }
	}
	if(zeroes > ((len/4)+2) ||
		nonasc > ((len/2)+2) ||
		spaces < (len/200))
	{
		printf("NONTEXT\n");
		return 1;
	}
	else
	{
		printf("TEXTFILE\n");
		return 0;
	}
	fclose(f);
	return 0;
}
