#!/bin/bash
# News
mkdix all -i 0
mkdix all -i 1
mkdix all -i 2
mkdix all -i 3
mkdix all -i 4
mkdix all -i 5
mkdix all -i 6
mkdix all -i 7
# FTP search
mkdix all -i 100
