#!/bin/bash
echo "======================================================="
echo "Installing tons of apt packages needed to run Altse ..."
echo "======================================================="
apt-get -y install perl
apt-get -y install libdbi-perl
apt-get -y install squid
apt-get -y install gcc
apt-get -y install make
apt-get -y install gcc-dev
apt-get -y install g++
apt-get -y install libzip-dev
apt-get -y install libz-dev
apt-get -y install ncurses-dev
apt-get -y install libxml-rss*
apt-get -y install libjcode*
apt-get -y install libjcode-perl
apt-get -y install wget
apt-get -y install lynx
apt-get -y install zcat

echo ""

echo "Copying Apache2 configuration file for Apache 2.x ..."
cp /home/vai/sdb/apache2/altse /etc/apache2/sites-available/
echo "Enabling 'altse' -virtual Apache server ..."
ln -s /etc/apache2/sites-available/altse /etc/apache2/sites-enabled/altse
ln -s /etc/apache2/mods-available/rewrite.load /etc/apache2/mods-enabled/
echo "Configuring altse.conf ..."
echo "/home/vai/db" > /etc/altse.conf
rm /etc/apache2/sites-enabled/000-default
#
ln -s /home/vai/sdb /home/vai/db/sdb
#
mkdir /home/vai/db/directory
mkdir /home/vai/db/www
chown vai /home/vai/db
chown vai /home/vai/directory
/sbin/apache2ctl restart
