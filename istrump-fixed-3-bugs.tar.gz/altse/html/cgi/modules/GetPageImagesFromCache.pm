################################################################
#
# Get images from a single page.
#
# Parameters: [page ID] [ignore PNG&GIF images]
#
# Note: PNG and GIF images are often thumbnails
# or small images on the crawled site.
#
sub GetPageImagesFromCache
{
	my ($i,$i2,$str,$str2,@lst,@lst2,@images);

	#
	my $pageid = $_[0];
	my $pagedivided = int($_[0]/100);
	my $skips;
	loop: for($i=0; ; $i++) {
		my $probe_for_jpg = "wwwimages/$pagedivided/220x175/$pageid\_$i.jpg";
		my $probe_for_png = "wwwimages/$pagedivided/220x175/$pageid\_$i.png";
		my $probe_for_gif = "wwwimages/$pagedivided/220x175/$pageid\_$i.gif";
		my $localfn = "$DB/$probe_for_jpg";
		#print "Looking for $localfn<BR>";
		if( -e $localfn ) {
			push(@images, $probe_for_jpg);
			#print "Found $localfn ($probe_for_jpg)<BR>";
			$skips = 0;
		} else {
			# End of images?
			$skips++;
			if($skips>3) { last loop; }
			#if($i>199) { last loop; }
		}
		my $localfn = "$DB/$probe_for_png";
		if( -e $localfn && !$_[1] ) {
			push(@images, $probe_for_png);
			#print "Found $localfn ($probe_for_png)<BR>";
		} else {
			# End of images.
			#last loop;
		}
		my $localfn = "$DB/$probe_for_gif";
		if( -e $localfn && !$_[1] ) {
			push(@images, $probe_for_gif);
			#print "Found $localfn ($probe_for_gif)<BR>";
		} else {
			# End of images.
			#last loop;
		}
	}

#	print "$#images<BR>";

	#
	return @images;
}

1;
