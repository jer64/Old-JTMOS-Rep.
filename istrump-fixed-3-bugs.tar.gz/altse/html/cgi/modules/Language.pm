###########################################################################################
#
sub DetectLanguage
{
        my ($i,$i2,$i3,$i4,$tmp,$tmp2,$str,$str2,@l,$co,@s,@s2,$change,$r,@sp);

	#
	$r = $ENV{'REMOTE_HOST'};
	if($r=~/\.cn$/)
	{
		return "cn";
	}
	if($r=~/\.nl$/)
	{
		return "nl";
	}
	if($r=~/\.se$/)
	{
		return "se";
	}
	if($r=~/\.fi$/)
	{
		return "fi";
	}

	#
	@sp = split(/[\,\;]/, $ENV{'HTTP_ACCEPT_LANGUAGE'});
	for($i=0; $i<($#sp+1); $i++)
	{
		if($sp[$i] eq "nl") { return "nl"; }
		if($sp[$i] eq "cn") { return "cn"; }
		if($sp[$i] eq "fi") { return "fi"; }
		if($sp[$i] eq "se") { return "se"; }
		if($sp[$i] eq "en") { return "en"; }
	}

	return "en";
}

1;