#
sub CookieTools
{
	print("
<SCRIPT LANGUAGE=\"JavaScript\">
<!--

// name - name of the cookie
// value - value of the cookie
// [expires] - expiration date of the cookie (defaults to end of current session)
// [path] - path for which the cookie is valid (defaults to path of calling document)
// [domain] - domain for which the cookie is valid (defaults to domain of calling document)
// [secure] - Boolean value indicating if the cookie transmission requires a secure transmission
// * an argument defaults when it is assigned null as a placeholder
// * a null placeholder is not required for trailing omitted arguments
function setCookie(name, value, expires, path, domain, secure) {
  var curCookie = name + \"=\" + escape(value) +
      ((expires) ? \"; expires=\" + expires : \"\") +
      ((path) ? \"; path=\" + path : \"\") +
      ((domain) ? \"; domain=\" + domain : \"\") +
      ((secure) ? \"; secure\" : \"\");
  document.cookie = curCookie;
}

// name - name of the desired cookie
// * return string containing value of specified cookie or null if cookie does not exist
function getCookie(name) {
  var dc = document.cookie;
  var prefix = name + \"=\";
  var begin = dc.indexOf(\"; \" + prefix);
  if (begin == -1) {
    begin = dc.indexOf(prefix);
    if (begin != 0) return null;
  } else
    begin += 2;
  var end = document.cookie.indexOf(\";\", begin);
  if (end == -1)
    end = dc.length;
  return unescape(dc.substring(begin + prefix.length, end));
}

// name - name of the cookie
// [path] - path of the cookie (must be same as path used to create cookie)
// [domain] - domain of the cookie (must be same as domain used to create cookie)
// * path and domain default if assigned null or omitted if no explicit argument proceeds
function deleteCookie(name, path, domain) {
  if (getCookie(name)) {
    document.cookie = name + \"=\" + 
    ((path) ? \"; path=\" + path : \"\") +
    ((domain) ? \"; domain=\" + domain : \"\") +
    \"; expires=Thu, 01-Jan-70 00:00:01 GMT\";
  }
}

// date - any instance of the Date object
// * hand all instances of the Date object to this function for \"repairs\"
function fixDate(date) {
  var base = new Date(0);
  var skew = base.getTime();
  if (skew > 0)
    date.setTime(date.getTime() - skew);
}

// -->
</SCRIPT>

	");
}

#
sub AddAdmin
{
        my ($rad,$i);

        #
        system "touch $ENV{'DOCUMENT_ROOT'}/articles/cfg/notracking.txt";
        @igl = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/notracking.txt");

        #
        $rad = $ENV{'REMOTE_ADDR'};
        for($i=0; $i<($#igl+1); $i++)
        {
                if($igl[$i] eq $rad)
                {
                ####    print "IS ON LIST $rad";
                        # His IP is already on the list.
                        return 1;
                }
        }

        # His IP is not yet on the list, let's add it.
        system "echo \"$ENV{'REMOTE_ADDR'}\" >> $ENV{'DOCUMENT_ROOT'}/articles/cfg/notracking.txt";

        #
        return 0;
}

#
sub AddPerkele
{
        my ($rad,$i);

        #
        system "touch $ENV{'DOCUMENT_ROOT'}/articles/cfg/perkele.txt";
        @igl = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/perkele.txt");

        #
        $rad = $ENV{'REMOTE_ADDR'};
        for($i=0; $i<($#igl+1); $i++)
        {
                if($igl[$i] eq $rad)
                {
                ####    print "IS ON LIST $rad";
                        # His IP is already on the list.
                        return 1;
                }
        }

        # His IP is not yet on the list, let's add it.
        system "echo \"$ENV{'REMOTE_ADDR'}\" >> $ENV{'DOCUMENT_ROOT'}/articles/cfg/perkele.txt";

        #
        return 0;
}

#
sub JSTools
{
        #
print("
<SCRIPT LANGUAGE=\"JavaScript\">
<!--

// name - name of the cookie
// value - value of the cookie
// [expires] - expiration date of the cookie (defaults to end of current session)
// [path] - path for which the cookie is valid (defaults to path of calling document)
// [domain] - domain for which the cookie is valid (defaults to domain of calling document)
// [secure] - Boolean value indicating if the cookie transmission requires a secure transmission
// * an argument defaults when it is assigned null as a placeholder
// * a null placeholder is not required for trailing omitted arguments
function setCookie(name, value, expires, path, domain, secure) {
  var curCookie = name + \"=\" + escape(value) +
      ((expires) ? \"; expires=\" + expires.toGMTString() : \"\") +
      ((path) ? \"; path=\" + path : \"\") +
      ((domain) ? \"; domain=\" + domain : \"\") +
      ((secure) ? \"; secure\" : \"\");
  document.cookie = curCookie;
}

// name - name of the desired cookie
// * return string containing value of specified cookie or null if cookie does not exist
function getCookie(name) {
  var dc = document.cookie;
  var prefix = name + \"=\";
  var begin = dc.indexOf(\"; \" + prefix);
  if (begin == -1) {
    begin = dc.indexOf(prefix);
    if (begin != 0) return null;
  } else
    begin += 2;
  var end = document.cookie.indexOf(\";\", begin);
  if (end == -1)
    end = dc.length;
  return unescape(dc.substring(begin + prefix.length, end));
}

// name - name of the cookie
// [path] - path of the cookie (must be same as path used to create cookie)
// [domain] - domain of the cookie (must be same as domain used to create cookie)
// * path and domain default if assigned null or omitted if no explicit argument proceeds
function deleteCookie(name, path, domain) {
  if (getCookie(name)) {
    document.cookie = name + \"=\" +
    ((path) ? \"; path=\" + path : \"\") +
    ((domain) ? \"; domain=\" + domain : \"\") +
    \"; expires=Thu, 01-Jan-70 00:00:01 GMT\";
  }
}

// date - any instance of the Date object
// * hand all instances of the Date object to this function for \"repairs\"
function fixDate(date) {
  var base = new Date(0);
  var skew = base.getTime();
  if (skew > 0)
    date.setTime(date.getTime() - skew);
}

// -->
</SCRIPT>
        ");

        #
}

#
sub GetCookies
{
	my (@cookies,$_cl);

	#
	$_cl = $ENV{'HTTP_COOKIE'};
	#
	@cookies = split /;/, $_cl;

	#
	return @cookies;
}

#
sub GetCookie1
{
	my ($i,@cookies);

	#
	@cookies = GetCookies();

        #
        for($i=0; $i<($#cookies+1); $i++)
        {
                #
                if($cookies[$i] =~ /$_[0]\=/)
                {
                        return $cookies[$i];
                }
        }

        #
        return "";
}

#
sub GetCookie
{
	my ($tmp);

	#
	$tmp = GetCookie1($_[0]);
	$tmp =~ s/$_[0]\=//g;
	return $tmp;
}

#
sub GetUserID
{
	my ($usrid);

	#
	$usrid = GetCookie("userid");

	#
	$usrid =~ s/\D//g;
	return $usrid;
}

#
%so =   (
	);

# Save user profile.
sub SaveProfile
{
	my ($key);

        #
        $so{'lastaccessdate'} = time;

        #
#        open(f, ">$VAI_PROF_DIR$_[0]\.profile") || die "error while creating user profile, please contact vaihtoehtouutiset\@sci.fi";
        #
#        foreach $key (keys %so)
#        {
#            print f "$key=$so{$key}\n";
#        }
#        close(f);
}

#
sub NoTracking
{
	#
	if($ENV{'REMOTE_HOST'} =~ /gov.cn/i) {
		return "1";
	}

	#
	if(GetCookie("vunetadmin") eq "true") { return "1"; }

	#
	if($ENV{'REMOTE_HOST'} =~ /cache/i || $ENV{'REMOTE_HOST'} =~ /proxy/i) #### || $so{'cookie_nick'} eq "")
	{
		return "0";
	}

	#
	if($ENV{'NO_TRACKING'} ne "") { return $ENV{'NO_TRACKING'}; }

	#
	if(_NoTracking() )
	{
		$ENV{'NO_TRACKING'} = "1";
	}
	else
	{
		$ENV{'NO_TRACKING'} = "0";
	}
	return $ENV{'NO_TRACKING'};
}

#
sub _NoTracking
{
        my ($str);
        my ($i,@igl);

	#
	for($i=0; $i<($#MASTER_IPS+1); $i++)
	{
		if( $ENV{'REMOTE_ADDR'} eq $MASTER_IPS[$i] )
		{
			return 1;
		}
	}

	#
#	if( $ENV{'REMOTE_ADDR'} eq $MASTER_IP )
#	{
#		return 1;
#	}
#
        #
        @igl = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/notracking.txt");

        #
        for($i=0; $i<($#igl+1); $i++)
        {
                if($igl[$i] eq $ENV{'REMOTE_ADDR'})
                {
                        # This userid is being ignored.
                        return 1;
                }
        }
	return 0;
}

# TGL.
sub _NoPerkele
{
        my ($str);
        my ($i,@igl);

	#
	for($i=0; $i<($#PERKELE_IPS+1); $i++)
	{
		if( $ENV{'REMOTE_ADDR'} eq $PERKELE_IPS[$i] )
		{
			return 1;
		}
	}

	#
#	if( $ENV{'REMOTE_ADDR'} eq $PERKELE_IP )
#	{
#		return 1;
#	}
#
        #
        @igl = LoadList("$ENV{'DOCUMENT_ROOT'}/articles/cfg/perkele.txt");

        #
        for($i=0; $i<($#igl+1); $i++)
        {
                if($igl[$i] eq $ENV{'REMOTE_ADDR'})
                {
                        # This userid is being ignored.
                        return 1;
                }
        }
	return 0;
}

# Load user profile.
sub LoadProfile
{
        my ($i,$str,$str2,$str3,$str4,@tmp);

        #
        open(f, "$VAI_PROF_DIR$_[0]\.profile") || return 0;
        close(f);
        @opt = LoadList("$VAI_PROF_DIR$_[0]\.profile");

	#
	%so = "";

        #
        for($i=0; $i<($#opt+1); $i++)
        {
                $str = $opt[$i];
		VarSet($str);
        }
        return 1;
}

# Load configuration.
sub LoadConfiguration
{
	my ($u);

	#
	$u = GetUserID();
	if( !LoadProfile($u) )
	{
		#
		SaveProfile($u);
	}

	#
	$ENV{'CFG_LOADED'} = "TRUE";
}

1;
