##################################################################################################################
#
# Displays text results.
#
# Returns $con variable which stands for "content" (HTML content).
#
# (C) 2005-2016 Jari Tuominen (jari.t.tuominen@gmail.com).
#
##################################################################################################################
sub ViewTextResults
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$fna,$score,@sp,$id,$ST,
		$str,$str2,$con);

	# Text view.
	####$so{'start'};
	$ST = $so{'start'};


	#
	@COT = (
		"F0F0F0",
		"E0E0E0"
		);
		
		goto GOT_ON_FRONTPAGE_PM;

               my @queries = LoadList("cfg/Menu.txt");
 
                $con .= ("
<!--- EXAMPLES OF SEARCH KEYWORDS TO BE SHOWN TO THE USER --->
<TABLE ALIGN=\"LEFT\"
        cellpadding=\"4\" cellspacing=\"0\"
        width=175>
<TR>
<TD>
                ");
                $current_blog = $so{'q'};
                for($i=0; $i<($#queries+1); $i++)
                {
                        my $st;
                        my @sp = split(/\=/, $queries[$i]);
                        ## (@)Text search or images
                        if( $sp[1]=~/^\@/ ) {
                                $st = "text";
                                #$sp[1] = s/^\@//;
                        }
                        else
                        {
                                $st = "image";
                        }
                        if( ($so{'q'}=~/^$sp[1]$/i) )
                        {
                                $con .= ("
<A HREF=\"/?q=$sp[1]&st=$st&cmd=go\" class=\"goldlink2\">
$sp[0]</A><BR><BR>
                                ");
                        }
                        else
                        {
                                $con .= ("
<A HREF=\"/?q=$sp[1]&st=$st&cmd=go\" class=\"goldlink\">
$sp[0]</A><BR><BR>
                                ");
                        }
                }
                
                $con .= ("
                </TD>
                </TR>
                </TABLE>
                ");
GOT_ON_FRONTPAGE_PM:

	#
	if($ORGQ =~ /site:/)
	{
$str = $so{'q'};
$str =~ s/site:\S*//;
$con .= ("
test

<table cellpadding=2 cellspacing=0 width=800>
<tr>

<td width=30% bgcolor=#E0E0FF>
<div align=center>
<a href=\"/?cmd=go&q=$str&indexnr=$so{'indexnr'}\" class=dark>> $so{'W_SEARCH_ALL_WEB_SITES'}</a><br>
</div>
</td>

<td width=30% bgcolor=#E0E0F8>
<div align=center>
<font color=black>
<b>$keyword</b>
</font>
</div>
</td>

<td width=30% bgcolor=#E0E0F0>
<div align=center>
<font color=#000000>$site</font>
</div>
</td>

</tr>
</table>
                        ");
	}

	# Show feed table.
	my @index_names = LoadList("$DB/altse/html/cgi/indexnames.txt");
	my ($ii);
	my $section_friendly_name;
	for($ii=0; $ii<($#index_names); $ii+=2) {
		if($index_names[$ii] eq $so{'indexnr'}) {
			$section_friendly_name = $index_names[$ii+1];
		}
	}
	$section_friendly_name =~ tr/[A-Z���]/[a-z���]/;
	$section_friendly_name =~ tr/[a-z���]/[a-zaoo]/;
	$section_friendly_name =~ s/[^a-z���0-9]/ /g;
	$section_friendly_name =~ s/^\s+//g; 
	$section_friendly_name =~ s/\s+$//g; 
	$con .= ("<DIV style=\"width: 100%;
padding: 12px 20px;
margin: 8px 0;
box-sizing: border-box;

font-size: 24;

box-sizing: content-box;
display: flex;
float: none;
line-height: normal;
position: static;
z-index: auto;
background: 0xC0C0C0;
text-transform:capitalize;\">$section_friendly_name</DIV>");
	if($section_friendly_name ne "") {
		$con .= ("
<!----

<TABLE ALIGN=RIGHT CELLSPACING=0 CELLPADDING=4 width=200
	style=\"position: absolute; left: 720;\">
<TR>
<TD>
<STRONG><P>FEEDS FOR YOU - UPDATED HOURLY</P></STRONG>
<SCRIPT LANGUAGE=\"JavaScript\" src=\"jsfeed/?q=$section_friendly_name\">
</SCRIPT>
</TD>
</TR>
</TABLE>

----->
			");
	}

	#
	my ($poll,$ii,$ii2);
	loop: for($i=0,$i2=0,$imgs=0,$poll=0; $i<($#results+1) && $poll<100000; $i++,$poll++)
	{
		#
		@sp = split(" ", $results[$i]);
#		$con .=  $results[0];

		# Get cached images for search (useful with porn).
		# Parameters: [page ID] [ignore PNG&GIF images]
		#
		# Note: PNG and GIF images are often thumbnails
		# or small images on the crawled site.
		#
		my ($index_i,$image_candidate);
		my (@pageimg) = GetPageImagesFromCache($sp[1], 0);
		loop: for($index_i=0; $index_i<($#pageimg+1); $index_i++) {
			$image_candidate = $pageimg[$index_i];
			my $imgsize = -s $image_candidate;
			if($imgsize>14999) { last loop; }
		}


		#
		if($i2>=$SHOW || $sp[1] eq "") { last loop; }


		## Call itemview
		#
		my (@tl) = LoadList("$DB/altse/bin/itemview \"$sp[1]\" \"$so{'indexnr'}\" \"$keyword\" 2>/dev/null|"); ## 0 = index 0
		#
		$tl[0] =~ s/^host\=//;


		#
		my (@dar) = LoadList("$DB/altse/bin/dardump \"$sp[1]\" \"$so{'indexnr'}\" 2>/dev/null|");
		LoadVars("$DB/altse/bin/dardump \"$sp[1]\" \"$so{'indexnr'}\" 2>/dev/null|");
		#print "<H1>HMMM1 $so{'title'}</H1>\n";
		#print @dar;

		###
		# SKIP CRAP
		#
		if(!($tl[1]=~/^\//) )
		{
			$tl[1] = "/$tl[1]";
		}

		#
		if($so{'start'} > $i)
		{
			goto skip;
		}

		# Ignore duplicate URLs.
		$url =  "$so{'host'}$so{'path'}";
		if($IGNORE_DUPLICATE_URLS) {
			$goturl{$url}++;
			if($goturl{$url}>2) { 
				goto skip;
			}
		}

		# Ignore duplicate HOSTs.
		$host = "$so{'host'}";
		if($IGNORE_DUPLICATE_HOSTS) {
			#$con .=  "<li>" . $host . "</li><br>\n";
			$gothost{$host}++;
			# if($so{'site'} ne "")
			# Failsafe. Max. entries per host to show for a search.
			if($gothost{$host} > 2 && $so{'site'} eq "") { 
				goto skip;
			}
		}


		## LOOK FOR LINKS TO BE EMBEDDED IN THE SEARCH RESULT ITEMS
		#
		if($this_show_link_shown{$tl[0]} ne "") {
			#goto skip_links_build;
		}
		$this_show_link_shown{$tl[0]}++;

		# Find basic info.
		loop2: for($ii=0; $ii<($#dar+1); $ii++) {
			if($dar[$ii] eq "[BASIC PAGE INFO]") {
				$ii++;
				last loop2;
			}
		}

		#
		my $age = time() - CreationDate1($dar[$ii+5]);

                my $nice_age;
                if($age >= 86400) {
                        my $days = int($age/86400);
                        if($days==1) {
                                $nice_age = $days . " day ago";
                        } else {
                                $nice_age = $days . " days ago";
                        }
                } else {
                        my $hour = int($age/3600);
                        if($hour<=1) {
                                $nice_age = "an hour ago";
                        } else {
                                $nice_age = $hour . " hours ago";
                        }
                }
#                $age_html = "<strong><font size=1 color=\"#404040\">" . $nice_age . "</font></strong>";
		$age_html = "";
		
		#
		# > TODO! - Like - Tykkaa
		# -------------------------
		$con .= ("
<TABLE width='85' height='64' align='left'>
<TR>
<TD>
<A HREF=\"/?cmd=like&url=$url&redir=http://$ALTSE_HOST&pageid=$sp[1]&indexnr=$so{'indexnr'}\">
<IMG SRC='https://www.pngitem.com/pimgs/m/35-356815_red-thumbs-up-clipart-thumbs-up-icon-red.png'
	valign='left'
	title='Tasta uutisesta tykättiin!' alt='Tasta uutisesta tykättiin!'
	width='85' height='64'>
	<H3>Tykkaa</H3>
</TD>
</TR>
</TABLE>
		");
		

		#
		my ($ii, $item_links_html);

		loop2: for($ii=0; $ii<($#dar+1); $ii++) {
			if($dar[$ii] eq "[MULTIMEDIA AND OTHER CONTENT]") {
				$ii++;
				last loop2;
			}
		}

		# $ii = in the multimedia, etc. info location
		my (@good_links,%got_link);
		for(; $ii<($#dar); $ii+=4) {
			if($dar[$ii] eq "link") {
				$dar[$ii+2] =~ s/^\s+//g;
				$dar[$ii+2] =~ s/\s+$//g;
				my $short_name = $dar[$ii+2];
				$short_name =~ s/^([^a-zA-ZäöåÄÖÅ0-9]+)//g;
				$short_name =~ s/^([a-zA-ZäöåÄÖÅ0-9]+\s{1})\s.*$/$1/;
				$short_name =~ s/^(.{100}).*$/$1.../;
				if(length($short_name) > 2 &&
				!($short_name =~ /[a-z]+\[[a+z]+\]/i) &&
				!($short_name =~ /google_ads/i) &&
					$short_name =~ /^[^#\<\>\;\=]+$/) {
					if($got_link{$short_name} eq "") {
						push(@good_links, $dar[$ii+1] . " | " . $short_name);
						$got_link{$short_name}++;
					}
				}
			}
		}

		# -> LINK1 - LINK2 - LINK3 - LINK4
		if($#good_links >= 0) {
			$item_links_html = ("<TABLE cellspacing=0 cellpadding=2><TR>".
				"<TD>");
			my $nr_count = $#good_links+1;
			for($ii=0; $ii<($#good_links+1) && $ii<10; $ii++) {
				#if($ii>0) {
				#	$item_links_html .= "<TD width=1>-</TD>";
				#}
				my @sp = split(/ \| /, $good_links[$ii]);
				my $go_to_url = "/?q=$sp[1] $tl[0]&st=text";
				$item_links_html .=
				("
                                        <DIV style='display: inline;
                                            float: right;
                                            width: 225px;
                                            border: 3px solid #FFF;
                                            padding: 10px;'>
                                            
<A HREF=\"$go_to_url\" class=dark><FONT STYLE=\"font-size: 18px;\">$sp[1]</FONT></DIV>");
			}
			$item_links_html .= ("</TD></TR></TABLE>")
		}
skip_links_build:


		## PROCESS ITEMVIEW DATA HERE:
		#
		$CO = "FFFFFF"; # $COT[($i2%2)];

		#
		if( $Google_ads!=0 && ($i2&15)==5 )
		{
			#
			@lst = LoadList("$DB/google.txt");
			for($i4=0; $i4<($#lst+1); $i4++)
			{
				$con .= "$lst[$i4]\n";
			}
		}

		#
		#
		$goturl{$url}++;
		$durl = $url;
		$durl =~ s/^(.{150}).*(.{150})$/$1 \.\.\. $2/;
		$durl =~ s/(\S{50})(\S{50})/$1 $2/g;
		$cap = $so{'title'}; if($cap eq "") { $cap = "UNTITLED"; }
		#print "<H1>HMMM2 $so{'title'}</H1>\n";
		$cap = FixScands($cap);
		#$cap =~ s/[^a-z���A-Z���0-9 ]/ /g;
		if( !($cap =~ /\&h/i) ) {
			$cap =~ s/^(.{125}).*/$1\.\.\./; # max. cap. length is 80 chars
		}
		$prv = $tl[3];
		$prv = FixScands($prv);
		$dat = $so{'nfo'};
		$prv =~ s/[\.\s]{2}/./g;
		$prv =~ s/[\.]{4}/./g;
		$prv =~ s/^[^a-z���A-Z���0-9]*//;
		if( !($dat=~/[0-9]*K/) ) { 
			#$dat="[no information available]";
			#$dat="";
		}
		$dat2 = $dat;
		$dat2 =~ s/^([0-9]*)\,.*$/$1/;

		#
		$cap =~ s/<[^>]*>//g;
		# HIGHLIGHT (EMPHASIZE) WORDS
		$cap = EmphasizeKeywords($cap,1);
		$durl = EmphasizeKeywords($durl,0);

### Thumbnails for search entries

#<!--<a href=\"http://www.alexa.com/data/details/main?q=$url&url=http://$url\" class=news1>
#<img src=\"http://thumbnails.alexa.com/image_server.cgi?size=small&url=http://$url\" align=right border=1
#	vspace=4 hspace=4>
#</a>-->
##<a href=\"/?b=$dat2\" class=news2><b>$cap</b></a><br>
		#
		$spe = $tl[3];
		$spe =~ s/^www\.//;
		$spe =~ s/^(.{75}).*(.{75})$/$1..$2/;
		#
		$prv =~ s/<[^>]*>//g;
		# HIGHLIGHT (EMPHASIZE) WORDS
		$prv = EmphasizeKeywords($prv,0);
		#
		if(!$EMBEDDED_SEARCH) {
		$entry_info = ("
 - $dat<BR>$age_html -
                                        <DIV style=\"display: inline;
                                            float: right;
                                            width: 400;
                                            border: 3px solid #FFF;
                                            padding: 10px;\">
<a href=\"$CGICMD?cmd=vcache&id=$dat2&q=$so{'q'}&indexnr=$so{'indexnr'}\"><STRONG>$so{'W_VIEW_CACHE'}</STRONG></a> -
<a href=\"$CGICMD?cmd=go&q=$keyword $tl[0]&indexnr=$so{'indexnr'}\"><STRONG>$so{'W_SEARCH_SPECIFIC'}</STRONG> $spe</a>
					</DIV>
");
		}
		#
		my $img_keys = $so{'q'};# . " " . $cap;
		$img_keys =~ tr/[A-Z���]/[a-z���]/;
		$img_keys =~ s/[^a-z���0-9]/ /g;
		$img_keys =~ s/\s+/ /g; 
#		my $image_javascript = ("
#<SCRIPT LANGUAGE=\"JavaScript\" src=\"/jsimage/?q=$img_keys\"> <!-- jsimage.pl -->
#</SCRIPT>
#		");
		
		# http://$url
		$open_up_url = 		"http://$url";
		$cache_open_up_url = 	"/?cmd=vcache&id=$sp[1]&noajax=TRUE";
		
		
		$con .= ("

<!--- ALTSE SEARCH RESULT ENTRY --->

<A HREF=\"$cache_open_up_url\" target=\"_blank\">Välimuistissa</A> - <A HREF=\"$open_up_url\" class=\"newsresult\" title=\"$url\" target=\"_blank\"><b>$cap</b></A>
<BR>

<table width=\"100%\"><tr>
<td width=30><font class=\"newsresult2\"><font color=black>$image_javascript</font></font></td>

<td width=100%>
	<TABLE align=\"right\" vspace=\"8\" hspace=\"8\">
	<TR>
	<TD>
	<IMG SRC=\"$image_candidate\" ALT=\"$image_candidate\">
	</TD>
	</TR>
	</TABLE>
	<font class=\"newsresult3\">$prv</font></td>
</tr></table>

<!-- TEXT BEFORE URL AND OTHER INFORMATION ON AN ENTRY -->    <!-- -->

<FONT color=\"#000000\" size=3>
");

	$con .= ("
$durl
</FONT>

	");

$con .= ("
$entry_info
		");
		# Add links table.
		if($item_links_html eq "") {
			$con .= ("<BR>");
		} else {
			$con .= ("$item_links_html");
		}
		$con .= ("</FONT>");
		#
		if( !($so{'q'}=~/site:/) )
		{
$con .= ("

<br>
			");
		}
		#
		$i2++;
		#
		$con .= ("
				$imgview
					");
skip:
	}

	#
	if(!$i2) {
		my $suggested_fn = "cfg/$so{'indexnr'}_recommended.txt";
		my $suggested_html;
		$suggested_html = ProduceSuggestedSearchesHTML();
		$con .= "$suggested_html";
	}

	#
#	$con .=  "shown $i2 / $SHOW --- $i/$#tl";
	$con .= ("
</DIV>

</DIV>
	");

	#
	return $con;
}

################################################################
#
sub EmphasizeKeywords
{
	my ($str,$q,$i,$i2,$rep1,$rep2);

	#
	$str = $_[0];

	#
	if($_[1]==1)
	{
		$rep1 = "<font color=#FF0000>";
		$rep2 = "<\/font>";
	}
	else
	{
		$rep1 = "<b>";
		$rep2 = "<\/b>";
	}

	#
	for($i=0; $i<($#W+1); $i++)
	{
		#
		$q = $W[$i];
		if($q =~ /OR/ || $q =~ /AND/) {
			goto skip;
		}
		if($q=~/\*/)
		{
			$q =~ s/\*/\\S*/;
			$q =~ s/^(.{4}).*$/$1\\S*/;
		}
		#print "$q ";

		#
		$W[$i] =~ s/\s*//g;
		#
		$str =~ s/($q)/$rep1$1$rep2/gi;
	#	$str =~ s/([\s\.,\/_:])($q)$/$1$rep1$2$rep2/gi;
	#	$str =~ s/^($q)([\s\.\/_:])/$rep1$1$rep2$2/gi;
	#	$str =~ s/([\s\.\/_,:])($q)([\s\.\/_,:])/$1$rep1$2$rep2$3/gi;
skip:
	}

	#
	return $str;
}

################################################################
#
sub EmphasizeKeywordsYellow
{
	my ($str,$q,$i,$i2,$rep1,$rep2);

	#
	$str = $_[0];

	#
	if($_[1]==1)
	{
		$rep1 = "<font color=YELLOW size=4 stlye=\"background:black;\">";
		$rep2 = "<\/font>";
	}
	else
	{
		$rep1 = "<font color=YELLOW style=\"background:black;\" size=4><b>";
		$rep2 = "<\/b></font>";
	}

	#
	for($i=0; $i<($#W+1); $i++)
	{
		#
		$q = $W[$i];
		if($q=~/\*/)
		{
			$q =~ s/\*/\\S*/;
			$q =~ s/^(.{4}).*$/$1\\S*/;
		}
		#print "$q ";

		#
		$W[$i] =~ s/\s*//g;
		#
		$str =~ s/($q)/$rep1$1$rep2/gi;
	#	$str =~ s/([\s\.,\/_:])($q)$/$1$rep1$2$rep2/gi;
	#	$str =~ s/^($q)([\s\.\/_:])/$rep1$1$rep2$2/gi;
	#	$str =~ s/([\s\.\/_,:])($q)([\s\.\/_,:])/$1$rep1$2$rep2$3/gi;
	}
	
	#
	return $str;
}


1;
