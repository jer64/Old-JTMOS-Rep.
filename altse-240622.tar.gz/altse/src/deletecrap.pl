#!/usr/bin/perl
require "tools.pl";
use String::CRC::Cksum qw(cksum);
#
AltseOpenConfig();

#
main();

#
sub main
{
	my ($i,$i2,@lst,@istext,$nontext);

	#
	print STDERR "Building a list of candidates to analyze ...\n";
	@lst = LoadList("find $ENV{'HOME'}/db/www -type f -size +99k|");

	#
	print STDERR "Searching for non-text files ...\n";
	for($i=0,$nontext=0; $i<($#lst+1); $i++) {
		@istext = LoadList("istext $lst[$i]|");
		if($istext[0] eq "NONTEXT") {
			print STDERR "\nDumping non-text file: $lst[$i]\n";
			unlink($lst[$i]);
			system("touch $lst[$i]");
			$nontext++;
		}
		print STDERR ".";
	}

	#
	print STDERR "\nFinished, $i file(s) analyzed, $nontext file(s) dumped.\n";

	#
}
