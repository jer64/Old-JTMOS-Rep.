//--------------------------------------------------------------------------------------------
//
// dardump.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "dardump.h"

#define max_content_len		1024*512

//--------------------------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
        int i,which_index;
        static char str_buf[(max_content_len)];

        //
        if(argc<3)
        {
                //
                fprintf(stderr, "dardump [DARID] [which index]\n");
                return 0;
        }

        //
        AltseLoadConfig();

	//
        i = 0;
        sscanf(argv[1], "%d", &i);
        sscanf(argv[2], "%d", &which_index);

        //
        DarDump(i, str_buf, max_content_len-10, which_index); // last par. : 0=use index 0 (default)
        printf("%s", str_buf);

        //
        return 0;
}

