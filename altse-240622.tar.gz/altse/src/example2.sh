#!/bin/bash
echo "SCORE  GID  LOCATIONS  RANK  HOST"
is sosialismi text www.skp.fi
