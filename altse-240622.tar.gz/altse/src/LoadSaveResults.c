///////////.........
// WORD_TYPE_AUDIO
// WORD_TYPE_VIDEO
// WORD_TYPE_IMAGE

//
#define MAX_WL		100000

//
char inde_debug=FALSE;
INDE inde;
char GLOP[256]; // global path
DWORD persec;


/////////////////////////////////////////////////////////////////////////////
//
// /home/vai/altse/cid/data/1/006/69/66982.dar 
//
int GetRank(char *host, char *path)
{
	static char str[8192],fn[8192];
	static char country[8192],domain[8192];
	int rank,i,i2,l,s,c;
	char *ho;
	FILE *f;

	//------------------------------------------------------------------------
	//
	// Primary rank evaluation.
	//
	//
	rank = 0;

	//
	ho = host;
	if(!strncmp(ho,"www.",4)) ho+=4;

	//
	sprintf(fn, "%s/www/%c%c/%s/rank.txt",
		database_path,
		ho[0],ho[1],
		host);
	f = fopen(fn, "rt");
	if(f!=NULL)
	{
		// Get precalculated host base rank.
		fscanf(f, "%d %d",
			&i,
			&rank);
		fclose(f);
	}

	//------------------------------------------------------------------------
	//
	// Secondary rank evaluation.
	//

	//
	l = strlen(host);
	for(i=l; i>0; i--)
	{
		if(host[i]=='.') { i++; break; }
	}
	strcpy(country, host+i);
	for(i-=2,c=0; i>0; i--,c++)
	{
		if(host[i]=='.') { i++; break; }
	}
	strncpy(domain,host+i, c);
	domain[c] = 0;

	//--------------------------------------------------------------
	//
	// Start rank calculation.
	//
	//
	if( strstr(host, "vunet.org") ) { rank+=4; }

	//
	if( 	strcmp(domain, "co") &&
		strcmp(domain, "edu") &&
		strcmp(domain, "gov") &&
		strcmp(domain, "int") &&
		strcmp(domain, "org") &&
		strcmp(domain, "net") &&
		strcmp(domain, "com") )
	{
		rank += 2;
		if(strlen(domain)==2)
		{
			rank += 1;
		}
		else
		if(strlen(domain)==3)
		{
			rank += 1;
		}
		else
		if(strlen(domain)==4)
		{
			rank += 1;
		}
		else
		{
			//rank += (strlen(domain)/5)-1;
		}
	}


	l = strlen(path);
	//
	for(i=0; i<l; i++)
	{
		if(path[i]=='/') { rank--; }
	}

	//
	l = strlen(host);
	//
	for(i=0; i<l; i++)
	{
		if(host[i]=='.') { rank--; }
	}
	// Forgive single dot.
	rank -= 1;

	// Shorter is more favorable.
	rank -= strlen(host)/10;
	rank -= strlen(path)/10;

	//
	if(	strstr(path, "index.") ||
		strstr(path, "default.")	)
	{
		rank += 2;
	}

	//
	if(	!strcmp(path, "")	)
	{
		rank += 4;
	}

	//---------------------------------------------------
	//
	// Divide result.
	//
	//rank /= 2;

	//
	if(rank<0) { rank=0; }

	//
	return rank;
}


/////////////////////////////////////////////////////////////////////////////
//
void DisplayResults(INDE *in)
{
	int i;
	ENT *e;

	//
	for(i=0; i<in->n_ent; i++)
	{
		//
		e = in->ent[i];

		//
		printf("%s %x %d %d\n",
			(char*)e->tiny, e->csum_w1, e->loc, e->gid);
	}

	//	
}

/////////////////////////////////////////////////////////////////////////////
//
DWORD val2(DWORD ch)
{
	if(ch=='�' || ch=='�' || ch=='�') { ch-='�'; ch+='z'+1; }
	return ch-'0';
}

/////////////////////////////////////////////////////////////////////////////
//
DWORD val(char *s)
{
	int i;

	//
	return (val2(s[3])<<0) | (val2(s[2])<<8) | (val2(s[1])<<16) | (val2(s[0])<<24);
}

/////////////////////////////////////////////////////////////////////////////
//
int compare_ents(DWORD *a1, DWORD *a2)
{
	ENT *e1,*e2;

	//
	e1 = *a1;
	e2 = *a2;

	//
	return strcmp(e1->tiny, e2->tiny);
}

/////////////////////////////////////////////////////////////////////////////
//
void SortResults(INDE *in)
{
	int i,i2;
	ENT *e;

	//
	fprintf(stderr, ">> begin sort\n");
	qsort(in->ent, in->n_ent, 4, compare_ents);
	fprintf(stderr, "<< end sort\n");

	//
//	sleep(10000);
}

/////////////////////////////////////////////////////////////////////////////
//
void SortOnce(INDE *in, int lim)
{
	register int i;
	register ENT *e,*e1,*e2;

	//
	for(i=0; i<(lim-1); i++)
	{
		//
		e1 = in->ent[i+0];
		e2 = in->ent[i+1];

		//
		if(e1->tiny[0] > e2->tiny[0])
		{
			in->ent[i+0] = e2;
			in->ent[i+1] = e1;
		}
	}

	//
}



/////////////////////////////////////////////////////////////////////////////
//
int LoadWords(char *str_sid,
	INDE *in)
{
	FILE *f;
	DWORD i,i2,i3,i4,gid,rank,l,pgp,sid,x;
	static char str[4096];
	static char fn_dar[256],fn_wli[256];
	static BYTE tmp[65536];
	static char host[5000],path[5000],path2[5000],title[5000],preview[5000],nfo[5000],
		description[8192],
		keywords[8192],
		author[8192];
	DWORD hsum,dots;
	static char *wl[MAX_WL];
	int n_wl;
	BYTE *html;
	ENT *e;

	//
	f = stdin;

	// PARSE HTML
	//
	strcpy(description, "");
	strcpy(keywords, "");
	strcpy(author, "");
	// Get some important meta tags...
	html = malloc(1024*128);
	for(i=0; i<(1024*128) || !feof(f); i++)
	{
		html[i] = fgetc(f);
	}
	if(html!=NULL)
	{
		//
		GoodWord(html);
		//
		GetMetaTag(html, "description", description);
		GetMetaTag(html, "keywords", 	keywords);
		//
		FixString1(description);
		FixString1(keywords);
		//
		free(html);
	}

	// Calculate rank.
	in->rank = GetRank(host,path);

	//
	fprintf(stderr, "(%d) %s\n", in->rank, host);

	// Ignore robots.txt.
	if( !strcmp(path, "robots.txt") )
	{
		return 0;
	}

	// Scan word list file for words.
	for(i=0,n_wl=0; i<16384 && n_wl<(MAX_WL-100); )
	{
		// Skip spaces.
		for(; !isKeyChar(tmp[i]) && i<16384; i++) { }
		for(x=0; isKeyChar(tmp[i]) && i<16384 && x<(KEYWORD_MAX_L-2); i++) { str[x++]=tmp[i]; }
		//
		str[x++]=0;

		//
		if( (strlen(str)>=KEYWORD_MIN_L && strlen(str)<(KEYWORD_MAX_L-2)) )
		{
			//
			wl[n_wl] = malloc(256);
			strcpy(wl[n_wl], str);
			n_wl++;
		}
	}

	//
	strcpy(str,"");
	wl[n_wl+0] = str;
	wl[n_wl+1] = str;
	wl[n_wl+2] = str;

	//
	for(i=0; i<n_wl; i++)
	{
		//
		CountWord(wl[i+0],wl[i+1],wl[i+2],wl[i+3],
			i,gid, in, pgp|WORD_TYPE_REGULAR, hsum);
	}

	//
	for(i=0; i<n_wl; i++)
	{
		//
		free(wl[i]);
	}

	//
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
//
void SaveResults(INDE *in)
{
	int fd;
	DWORD i,x,t,lt,li,y,n_ranks,type,r,rr;
	ENT *e;
	static BYTE *chr, *lchr[100];
	static BYTE buf[8192];
	DWORD wib; // last DWORD written at the DIR stream
	BYTE *p;

	//
	n_ranks = 10;

	//
	inde_fs_init(in, n_ranks);

	//
	for(r=0; r<n_ranks; r++)
	{
		lchr[r] = malloc(1024);
		if(lchr[r]==NULL) { fprintf(stderr, "Error: malloc returned NULL (5)\n"); abort(); }
		strcpy((char*)lchr[r],"");
	}
	
	//
	fprintf(stderr, "%s: Now saving results.\n",
		__FUNCTION__);
	for(i=0,li=0,persec=0,x=0,lt=t,r=0,t=time(NULL),rr=0; i<in->n_ent; i++) // t=time(NULL);
	{
		//
		if(inde_debug) fprintf(stderr, "1\n");
		e = in->ent[i];

		//
		r = e->rank;
		////////////////if( r<0 || r>9 ) { continue; }
		//
		chr = e->tiny;

                //
                if( ((x++)&31)==0 )
                {
                        t = time(NULL);
                        if(t!=lt)
                        {
                                //
                                persec = i-li;

                                //
                                li = i;
                                lt = t;
                        }
                }

		//
		if(inde_debug) fprintf(stderr, "2 - e=%x chr=%x, in=%x, lchr[rr]=%x, matter=%d, r=%d\n",
			e, chr, in, lchr[rr], N_CHARS_MATTER, r);
		if(strncmp((char*)chr,(char*)lchr[rr], N_CHARS_MATTER))
		{
			//
			fprintf(stderr, "[%d/%d (%d),%d files,%s] writing at %d /s\n",
					i, in->n_ent, in->max_ent, in->n_files, chr,
					persec);
		}

		//
		if(inde_debug) fprintf(stderr, "3\n");
		if(strncmp((char*)chr,(char*)lchr[rr], N_CHARS_MATTER))
		{
			//
			type = (e->type&255);

			//
			wib = 0xFFFFFFFF;
			if(inde_debug) fprintf(stderr, "3B\n");
			OpenDic(in, chr, i, 0); // r

			//
			p = buf;
		}

		//
		if(inde_debug) fprintf(stderr, "4\n");
		WriteDic(in,rr, e->csum_w1);
		WriteDic(in,rr, e->csum_w2);
		WriteDic(in,rr, e->csum_w3);
		WriteDic(in,rr, e->csum_w4);
		WriteDic(in,rr, e->gid);
		WriteDic(in,rr, e->host);
		WriteDic(in,rr, e->loc);
		WriteDic(in,rr, e->type);
		WriteDic(in,rr, e->rank);

		//
		if(inde_debug) fprintf(stderr, "5\n");
		if(e->csum_w1!=wib)
		{
			WriteDir(in,rr, e->csum_w1);
			wib = e->csum_w1;
		}

		//
		if(inde_debug) fprintf(stderr, "6\n");
		strcpy((char*)lchr[rr], (char*)chr);

		//
		if(inde_debug) printf("%s %x %d %d\n",
			e->tiny, e->csum_w1, e->loc, e->gid);
	}

	//
	fprintf(stderr, "\n%s: completed, i=%d\n",
		__FUNCTION__, i);

	//
	inde_fs_end(in, n_ranks);

	//	
}

/////////////////////////////////////////////////////////////////////////////
//
int main(int argc, char **argv)
{
	static int i;
	static INDE *in;

	//
	inde_debug = FALSE;

	//
	in = &inde;

	//
        AltseLoadConfig();
	// Output path.
	sprintf(GLOP, "%s/altse/cid/dict",
		database_path);
	//
	is_LoadConfig();

	////////////////////////////////////////////////////////////////////////////////
	//
	if(argc<2)
	{
		//
		fprintf(stderr, "inde.c version 1.0 (21.06.2005)\n");
		fprintf(stderr, "Usage: inde [WLI files]\n");
		return 0;
	}

	////////////////////////////////////////////////////////////////////////////////
	//
	InitInde(in);

	////////////////////////////////////////////////////////////////////////////////
	//
	// Fetch options.
	//
	for(i=1; i<argc; i++)
	{
		if( !strncmp(argv[i],"-o", 2) )
		{
			strcpy(GLOP, argv[i]+2);
		}
	}

	////////////////////////////////////////////////////////////////////////////////
	//
	// Count words.
	//
	inde.n_files = argc;
	for(i=1; i<argc; i++)
	{
		//
		fprintf(stderr, "%s - %d/%d - ",
			argv[i],
			in->n_ent,
			in->max_ent);
		LoadWords(argv[i], in);
	}

	////////////////////////////////////////////////////////////////////////////////
	//
	// Display results.
	//
	fprintf(stderr, "\nSorting entries ...\n");
	SortResults(in);
	fprintf(stderr, "Saving entries ...\n");
	SaveResults(in);

	//
	return 0;
}

