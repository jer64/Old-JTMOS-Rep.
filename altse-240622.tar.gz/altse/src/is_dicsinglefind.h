
#ifndef __INCLUDED_DICSINGLEFIND_H__
#define __INCLUDED_DICSINGLEFIND_H__

//
int DicSingleFind(IS *is, char *dicfn, char *key, DWORD csum);
HOSTHASH look_host,look_host2;

#endif
