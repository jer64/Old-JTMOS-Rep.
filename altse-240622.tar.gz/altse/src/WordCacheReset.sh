#!/bin/bash
echo "Resetting word cache (text converted pages cache) ..."
cd ~/sdb/cid
rm -rfv data/*
echo "0" > gid.txt
