#!/usr/bin/perl
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
sub main
{
	my ($i,$i2,@lst,$str,$str2,@sp);

	#
	@lst = LoadList("zcat $ARGV[0]|");

	#
	$str = join(" ", @lst);

	#
	$str =~ s/[^a-zA-Z0-9]/ /g;
	$str =~ tr/[A-Z]/[a-z]/;
	$str =~ s/\s+/ /g;

	#
	@sp = split(/ /, $str);

	#
	for($i=0; $i<($#sp+1); $i++) {
		#
		$words{$sp[$i]}++;
	}

	#
	$i=0;
	foreach $key (sort(keys %words)) {
		$lst[$i++] = sprintf "%1.8d %s", $words{$key},$key;
	}
	@lst = sort @lst;
	@lst = reverse @lst;

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		print $lst[$i] . "\n";
	}
}

#
if($ARGV[0] ne "") {
	main();
}
