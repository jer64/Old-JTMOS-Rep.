#!/usr/bin/perl
#############################################################################
# Search engine image gallery.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2013 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "./modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "./modules/settings.pm";
require "./modules/ViewCache.pm";
require "./modules/GetPageImages.pm";
require "./modules/GetPageImagesFromCache.pm";
require "./modules/ViewTextResults.pm";
require "./modules/ViewImageResults.pm";
require "./modules/QueryDB.pm";
require "./modules/Logging.pm";
require "./modules/Frontpage.pm";
require "./modules/InterfaceOpenDP.pm";
require "./modules/CacheResults.pm";

#
print "Content-type: text/html\n\n";
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush STDOUT buffer after each command
select(STDOUT);
$| = 1;

# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();
#print $so{'q'};

#
$CSS_URL = "$IMAGES_URL/altse.css";

#
if($so{'indexnr'} eq "") { $so{'indexnr'} = 0; }

#
main();

#
sub HtmlHeader
{
	### HARDCODED USER INTERFACE
        #
                print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"http://images.vunet.org/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$CSS_URL\" title=\"Cool\">
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<script language=\"Javascript\" type=\"text/javascript\">
function clickHandle1(e,url)
{
	window.location.href = url;
}
</script>
<title>
$PAGE_TITLE - $CURRENT_GALLERY_NAME (image gallery)
</title>
</head>

<BODY $xtra bgcolor=$TVAR
	topmargin=0 leftmargin=0
	marginheight=0 marginwidth=0>


<TABLE width=100% height=1 cellpadding=0 cellspacing=0
	bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<table width=100% bgcolor=$TVAR cellpadding=0 cellspacing=0>
<tr>
<td>

			");
}

#
sub HtmlHeaderEnd
{
	#
	print("
</td>
</tr>
</table>

</body>
		");
}

# /wwwimages/pic1.png
# /wwwimages_1/pic2.png
sub ImageUrl
{
	my $str = $_[0];
	$str =~ s/^[0-9]+\s//;
	$str =~ s/$DB//;
	return $str
}

#
sub SearchEngineGallery
{
	my ($i,$i2,$str,$str2,@lst,@lst2);

	#
	print("
<TABLE width=100% CELLPADDING=4 CELLSPACING=0>
<TR>
<TD>
	");

	#
	@kuvaukset = LoadList("indexnames.txt");
	#
	my $www_path = "$DB/wwwimages";
	if( int($so{'indexnr'}) > 0 ) {
		$www_path .= "_$so{'indexnr'}";
	}
	#
	@lst = LoadList("$www_path/senseful.lst");
	#
	#@lst2 = LoadList("$www_path/already.txt");

	#
	my $INDEX_CHOOSER_HTML = "<SELECT name=indexnr>\n";
	my $DEFAULT = "";
	for($i=0; $i<($#kuvaukset); $i+=2) {
		if($so{'indexnr'}==$kuvaukset[$i+0]) { $DEFAULT = "selected"; } else { $DEFAULT = ""; }
		$INDEX_CHOOSER_HTML .= "<OPTION $DEFAULT value=\"$kuvaukset[$i+0]\">$kuvaukset[$i+1]</OPTION>\n";
	}
	$INDEX_CHOOSER_HTML .= "</SELECT>\n";

	#
	$SEARCH_FORM_HTML = ("
<FORM ACTION=\"?\">
Search: 
<INPUT TYPE=TEXT NAME=q value=\"$so{'q'}\">
Choose source: 
$INDEX_CHOOSER_HTML 
<INPUT TYPE=SUBMIT value=\"Go\">
</FORM>
<LI>$#lst images in the database.</LI>
	");

	#
	my $IMAGES_PER_ROW =	5;
	my $IMAGES_PER_PAGE =	20*5;

	#
	my $startti = 0;
	if(int($so{'i'}) > 0) {
		$startti = $so{'i'};
	}

	my $qexec = $so{'q'};
	$qexec =~ s/[^a-z���0-9\ ]/ /i;
	$qexec =~ s/\s+/\.\*/i;

	for($i=$startti,$i2=0; $i<($#lst) && $i2<($IMAGES_PER_PAGE); $i++) {
		@sp = split(/\s\|\s/, $lst[$i]);
		my $localfn = $sp[0];
		$localfn =~ s/^[0-9]+\s//;;
		#$localfn =~ s/^(.+\/)([^\/]+)$/$1\/96x96\/$2/;

		my $URL = $sp[1];

		if($already{$URL}) { goto skip; } else {
			$already{$URL}++;
		}

		if($so{'q'} ne "") {
			if( !($URL =~ /$qexec/i) ) {
				goto skip;
			}
		}

		#print $localfn . "<BR>";
		if( !(-e $localfn) ) { goto skip; }

		if(($i2%$IMAGES_PER_ROW)==0) {
			$IMAGES_HTML .= ("
<TABLE width=100% cellspacing=0 cellpadding=4
	bgcolor=\"#000000\">
<TR>
				");
		}

		my $url = ImageUrl($sp[0]);
		my $th_url = $url;
		$th_url =~ s/^(.+\/)([^\/]+)$/$1$2/;
		$th_url =~ s/(\.[a-z]+)$/.jpg/;
		$th_url =~ s/^\/*/..\//;

		my $img_url = $sp[1];
		$img_host = $img_url;
		#$img_host = s/^http:\/\/([^\/]+).*$/$1/;

		$IMAGES_HTML .= "<TD><A HREF=\"$img_url\"><IMG SRC=\"$th_url\" alt=\"$CURRENT_GALLERY_NAME - $th_url\" title=\"$CURRENT_GALLERY_NAME from $img_host\"></A></TD>";
		if(($i2%$IMAGES_PER_ROW)==($IMAGES_PER_ROW-1)) {
			$IMAGES_HTML .= "</TR></TABLE>";
		}
		$i2++;
skip:
	}
	if(($i2%$IMAGES_PER_ROW)!=0) {
		$IMAGES_HTML .= "</TR></TABLE>";
	}
	$next_i = $i;

	#
	if(1)
	{
		#
		if( ($i2 > $#results && $so{'start'} != 0) || $#results<$SHOW ) { $DIS="disabled"; }
			else { $DIS=""; }

		#
		if($DIS eq "") {
			my ($pagenr,$images_per_page,$view_count);

			$PAGE_SELECTOR_HTML = "";

			$images_per_page = $i2;
			$number1 = $so{'i'} / $images_per_page + 1;
			$pagenr = 1;
			for($number1=0,$view_count=0; $number1<10 && $view_count<$IMAGE_COUNT;
						$pagenr+=1,
						$number1+=$images_per_page,
						$view_count+=$images_per_page) {
				$PAGE_SELECTOR_HTML .= ("<td width=12>");
				if($DIS eq "" || $LAST_PAGE ne "")
				{
					$PAGE_SELECTOR_HTML .= ("
					<center><a href=\"$CGICMD?q=$so{'q'}&indexnr=$so{'indexnr'}&start=$i2&st=$so{'st'}&cmd=go\">$pagenr</a></center>
						");
				}
				$PAGE_SELECTOR_HTML .= ("</td>");
				$DIS = "";
			}
		}

		#
		$DIS = "";
	}

	#
	$NEXT_PAGE_HTML = ("
<DIV ALIGN=CENTER>

<TABLE width=200 cellspacing=0 cellpadding=4>
<TR>
<TD>

<TD>
<A HREF=\"?i=0&indexnr=$so{'indexnr'}&q=$so{'q'}\">
<IMG SRC=\"$IMAGES_URL/icons1/previous.gif\" border=0><BR>
Back to beginning </a>
</TD>

$PAGE_SELECTOR_HTML

<TD>
<A HREF=\"?i=$next_i&indexnr=$so{'indexnr'}&q=$so{'q'}\">
<IMG SRC=\"$IMAGES_URL/icons1/next.gif\" border=0><BR>
Next page </a>
</TD>

</TR>
</TABLE>
<BR>
<FONT SIZE=2><A HREF=\"/\" class=darkul>Altse Project</A> (C) 2005-2011 by Jari Tuominen (jari.t.tuominen[AT]gmail.com)</FONT>

</DIV>
		");

	#
	print("
<P>
<BR>
<DIV ALIGN=CENTER>
<H2><FONT COLOR=BLUE>
<A HREF=\"/\" class=blue>
Altse - Image Search
</A></FONT> - <FONT COLOR=RED>
$CURRENT_GALLERY_NAME
$kuvaukset[$so{'indexnr'}*2+1]
</FONT></H2>
</DIV>
</P>

<DIV ALIGN=CENTER>
$NEXT_PAGE_HTML
$SEARCH_FORM_HTML
</DIV>

$IMAGES_HTML

<DIV ALIGN=CENTER>
$NEXT_PAGE_HTML
</DIV>
");

	#
	print("
</TD>
</TR>
</TABLE>
	");
}

#
sub DisplayResults
{
	my ($i,$i2,@lst);

	#
	@lst = LoadList("$DB/wwwimages/already.txt");

	#
	for($i=0; $i<($#lst+1) && $i<2000; $i++) {
		$lst[$i] =~ s/^\///g;
		print "<IMG SRC=\"$lst[$i]\"><BR>";
	}

	#
}

#
sub main
{
	#
	@kuvaukset = LoadList("indexnames.txt");
	#
	for($i=0; $i<($#kuvaukset); $i+=2) {
		if($so{'indexnr'}==$kuvaukset[$i+0]) { $CURRENT_GALLERY_NAME = "$kuvaukset[$i+1]"; }
	}

	#
        HtmlHeader();


	print("
<TABLE WIDTH=1100 CELLSPACING=0 CELLPADDING=2 BGCOLOR=#000000>
<TR>
<TD>

<TABLE width=100% height=96 cellspacing=0 cellpadding=0
	background=\"$IMAGES_URL/NewAltseLogo.gif\"
	class=\"image_search_logo_area\"
	onClick=\"Javascript:clickHandle1(this, '../');\">
<TR>
<TD>
</TD>
</TR>
</TABLE>

<TABLE WIDTH=1100 CELLSPACING=0 CELLPADDING=2 bgcolor=#FFFFFF>
<TR>
<TD>
		");
	SearchEngineGallery();
	print("
</TD>
</TR>
</TABLE>
</TD>
</TR>
</TABLE>
		");
        HtmlHeaderEnd();
}
