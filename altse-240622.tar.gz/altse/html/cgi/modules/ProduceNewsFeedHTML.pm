# ProduceNewsFeedHTML.pm
sub ProduceNewsFeedHTML
{
	my ($i,$i2,$i3,$i4,$con);

	#
	my $nam = $_[0];
	$nam =~ s/[^0-9a-z]//g;
	my $fn = "cache/rss/$nam\.txt";
	@lst = reverse LoadList($fn);
	#$con .= $fn;

	#
	for($i=0; $i<($#lst+1) && $i<7; $i++) {
		my @sp = split(/ \| /, $lst[$i]);
		$con .= ("
			<TABLE WIDTH=375
				CELLSPACING=0
				CELLPADDING=0
				bgcolor=#FFFF00>
			<TR>
			<TD>
			<TABLE WIDTH=100%
				CELLSPACING=0
				CELLPADDING=4>
			<TR>
			<TD>
			<B>$sp[1]</B><BR>
			$sp[2]<BR>
			<A HREF=\"$sp[3]\">$sp[3]</A><BR>
			</TD>
			</TR>
			</TABLE>
			</TD>
			</TR>
			</TABLE>
			<HR COLOR=GREEN>
			");
	}
	if($#lst<=1) {
		$con .= ProduceSuggestedSearchesHTML();
	}

	#
	return $con;
}

TRUE;
