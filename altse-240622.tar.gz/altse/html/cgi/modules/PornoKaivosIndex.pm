#
$so{'q'} = "porn";
$so{'cmd'} = "go";

