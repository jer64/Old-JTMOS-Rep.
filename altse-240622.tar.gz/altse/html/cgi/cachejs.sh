#!/bin/bash
lynx -dump "http://www.altse.vunet.org/js/?q=" > ../www/Top.js
lynx -dump "http://www.altse.vunet.org/js/?q=World" > ../www/World.js
lynx -dump "http://www.altse.vunet.org/js/?q=World/Suomi" > ../www/Suomi.js
