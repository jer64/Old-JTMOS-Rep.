#!/usr/bin/perl
# beta_newsfeeds.pl

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();

#
$DONT_AFFECT_DB = 1;
ArgLineParse();
#
$so{'js'} = "true";
# source section correction
$so{'sec'} =~ s/[^a-z]//g;
if($so{'sec'} eq "") {
	$so{'sec'} = "finance";
}
#
if($so{'js'} ne "") {
	if( int($so{'c'}) > 0) {
		$MAX_VIEW_COUNT = $so{'c'};
	} else {
		$MAX_VIEW_COUNT = 10;
	}
	print "Content-type: text/JavaScript\n\n";
} else {
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$HOSTI = "http://www.vaihtoehtouutiset.info";
#
$ENV{'CURSEC'} = "picks";

#
if($so{'js'} eq "") {
}
main();

#
if($so{'js'} eq "") {
}

###########################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$niceurl,$age,$content);

	if($so{'js'} eq "") {
	#
	}

	#
	my $fn1 = "$SDB/html/cgi/cache/rss/$so{'sec'}.txt";
	if(-e $fn1) {
		@lst = LoadList($fn1);
	}
	for($i=0; $i<($#lst+1) && $i<$MAX_VIEW_COUNT; $i++) {
		@sp = split(/ \| /, $lst[$i]);
		#print $lst[$i] . "<BR>\n";
		my $age = $sp[0];
		my $title = $sp[1];
		my $description = $sp[2];
		my $niceurl = $sp[3];
		my $url = $sp[3];
		$niceurl =~ s/^http:\/\/([^\/]+).*$/$1/;

		my $nice_age;
		if($age >= 86400) {
			my $days = int($age/86400);
			if($days==1) {
				$nice_age = $days . " day ago";
			} else {
				$nice_age = $days . " days ago";
			}
		} else {
			my $hour = int($age/3600);
			if($hour<=1) {
				$nice_age = "an hour ago";
			} else {
				$nice_age = $hour . " hours ago";
			}
		}
		$age_html = "<font size=1 color=\"#808080\">  - " . $nice_age . "</font>";

		if($title =~ /^\s*$/) { goto skip; }

		if( !($title=~/&h.*\&/) ) {
			#$title =~		s/[^a-z0-9\.\,\-\[\]\(\)\!\?]\'\�\`/ /gi;
		}
		if( !($description=~/&h.*\&/) ) {
			#$description =~		s/[^a-z0-9\.\,\-\[\]\(\)\!\?]\'\�\`/ /gi;
		}
		if($alreadytitle{$title} ne "") {
			goto skip;
		} else {
			$alreadytitle{$title}++;
		}

		if($so{'small'} eq "true") {
			$so{'cap_font_size'} = 2;
		} else {
			$so{'cap_font_size'} = 3;
		}

		$source_name_html = ("
<font size=1 color=\"#808080\"> - $niceurl</font>");

		$content .= ("
<TABLE width=100% cellpadding=0 cellspacing=0 bgcolor=\"#FFFFFF\">
<TR valign=top>
<TD>
<A HREF=\"$url\" class=darkul><B><LI>
<FONT SIZE=$so{'cap_font_size'}>
$title</B></A> $source_name_html $age_html
</FONT>
</LI></B></A>
</TD>
</TR>
</TABLE>
			");
		if( length($description)>5 && $so{'js'} eq ""  ) {
		$content .= ("
			");
		}

		#
skip:
	}

	#
	if($so{'js'} eq "") {
	#
	print("
$content
		");
	}

	#
	if($so{'js'} ne "") {
	        $content =~ s/[\t\n\r\s]/ /g;
	        $content =~ s/\"/\\\"/g;
	        print(" document.write(\"$content\"); \n");
	}

	#
}
