#!/bin/bash
cd /home/vai/sdb/crontab
#
PATH=$PATH:/home/vai/sdb/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
export PATH

# Do daily updates of search indexes.
#wi -i 101 -o -c
#wi -i 103 -o -c
