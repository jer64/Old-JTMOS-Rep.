#!/bin/bash
#cd /home/vai/sdb/crontab
#
#PATH=$PATH:/home/vai/sdb/bin:/home/vai/cgi-bin:/home/vai/cgi-bin/admin
#export PATH

#
#mkdir -p /home/vai/db/frontpages
#mkdir -p /home/vai/db/frontpages2

#
#~/sdb/crontab/crawl_news.sh


#

