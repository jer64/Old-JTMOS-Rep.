// dixdump.c
#include <stdio.h>
#include "selib.h"

//-----------------------------------------------------------------------------
//
void DixDump(char *fn)
{
	DWORD offs1,offs2;
	char key[8192];
	FILE *f;

	//
	f = fopen(fn, "rb");
	if(f==NULL) { return; }

	//
	while(!feof(f))
	{
		//
		fread(key, 8,1, f);
		fread(&offs1, 4,1, f);
		fread(&offs2, 4,1, f);

		//
		fprintf(stdout, "%8s: %.8X - %.8X\n",
			key,
			offs1,offs2);
	}

	//
	fclose(f);
}

//-----------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
	//
	if(argc<2)
	{
		//
		fprintf(stderr, "Usage: dixdump [dix-file]\n");
		return 0;
	}

	//
	DixDump(argv[1]);

	//
	return 0;
}
