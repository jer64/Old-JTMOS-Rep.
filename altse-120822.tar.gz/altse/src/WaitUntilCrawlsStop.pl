#!/usr/bin/perl
#
# WaitUntilCrawlsStop.pl
#
#
if($ENV{'HOME'} eq "") {
        $ENV{'HOME'} = "/home/vai";
}
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
AltseOpenConfig();

#
my $bt = time;
# Wait at most an hour for crawls to stop.
loop: for(; (time-$bt)<(60*60*1);) {
	my $nr = join("\n", LoadList("nrcrawl|"));
	if($nr <= 2) { sleep(30); last loop; }
	sleep(30);
}
