#!/usr/bin/perl
###############################################################################
# sid.pl - Index Searcher Interface.
###############################################################################

#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =          "/home/vai/sdb";        # search database root directory
$CID =          "$SDB/cid";             # central index
$LISTS =        "$SDB/cid/lists";       # list files directory
$DADI =         "$SDB/cid/data";        # data files
$DICT =         "$SDB/cid/dict";        # big index with dictionaries
# This is solely for reducing the amount of time queries take.
$MAX_RESULTS_PER_SITE =		10000;
#
$SID_RESULT_CACHE_IS_ON =	1;

#
main();

##################################################
#
sub GenPreview
{
	my ($i,$i2,$str,$f,$long,@sp,$bg);

	#
	open($f, $_[0]) || return();
	$str = <$f>;
	@sp = split(/ /, $str);
	close($f);

	#
	$bg = $_[1]-2;
	if($bg<0) { $bg=0; }
	for($i=$bg,$str=""; $i<($#sp+1) && $i<($bg+100); $i++)
	{
		$str = "$str $sp[$i]";
	}

	#
	if($str eq "") { $str = "NO PREVIEW"; }

	if($bg>0) { $str="...$str"; }
	$str =~ s/^(.{200}).*$/$1/;
	return "$str ...";
}

##################################################
#
# Parameters: SCORE, GID, LOCS, LEVEL.
# (old: 000000000122 & www.pellervo.fi/index.html & 0 & www.pellervo.fi & 28 & 1,2,3,)
#
sub ViewRes
{
	my ($str,$str2,$i,$i2,$i3,$i4,@lst,
		$fndar,$fnwli,
		$fn,$fn2,@sp,$host,$url,$path,
		$good,$l,
		$id1,$id2,$id3,$id4);

	#
	@wof = split(",", $_[2]);

	#
	$str = sprintf "%.8d", $_[1];
	#
	$id2 = $str;
	$id2 =~ s/^[0-9]{4}([0-9]{2}).*$/$1/;
	#
	$id1 = $str;
	$id1 =~ s/^[0-9]{1}([0-9]{3}).*$/$1/;

	#
	$fndar = "$DADI/$_[3]/$id1/$id2/$_[1].dar";
	$fnwli = "$DADI/$_[3]/$id1/$id2/$_[1].wli";
	if( !(-e $fndar) ) {
#		print "Not found $fndar.\n";
		return 0;
	}

	######################################################
	#
	# Load & display DAR file.
	#

	#
	@lst = LoadList($fndar);

	#
	if($lst[2] eq "") { return 0; }
#	if($lst[1] eq "") { $lst[1]="Kuvaus puuttuu!"; }

	# PRINT STUFF FROM DAR.
	loop: for($i=0; $i<3; $i++)
	{
		if($lst[$i] eq "") { last loop; }
		print "$lst[$i]\n";
	}

	# 
	###############################

	#
	loop: for($i=0,$good=$wof[0],$l=-1,$i2=0,$i3=0; $i<($#wof+1); $i++)
	{
		#
		if( $l!=-1 && abs($l-$wof[$i])<=1 )
		{
			# Increase amount of word combinations.
			$i2++;
			# Got a new record?
			if($i2>$i3) { $i3=$i2; $good = $wof[$i-$i2]; }
		}
		else
		{
			# Reset back to zero combinations.
			$i2=0;
		}
		$l = $wof[$i];
	}

	# PICTURE MODE.
	if($so{'st'}==3)
	{
		#
		loop: for($i=0; $i<($#lst+1); $i++) { if($lst[$i]=~/^\[IMAGE_LINKS\=/) { last loop; } } 
		$i++; $zi=$i;

		#
		@jpg = ();
		@png = ();
		@gif = ();
		%ald = ();
		loop2: for($i=$zi; $i<($#lst+1); $i++)
		{
			if($lst[$i] eq "") { last loop2; }
			if( $ald{$lst[$i]}<=0 ) 
			{
				$ald{$lst[$i]}++;
				if($lst[$i]=~/\.jpg$/) { $jpg[$#jpg+1]=$lst[$i]; }
				if($lst[$i]=~/\.gif$/) { $gif[$#gif+1]=$lst[$i]; }
				if($lst[$i]=~/\.png$/) { $png[$#png+1]=$lst[$i]; }
			}
		}

		#
		@both = (@jpg, @png, @gif);

		#
		for($i=0; $i<($#both+1) && $i<5; $i++)
		{
			if($both[$i] ne "")
			{
	print(" <a href=\"$both[$i]\">$both[$i]</a><br> ");
			}
		}
		print "\n";
	}

	# MUSIC MODE.
	if($so{'st'} eq "1" || $so{'st'} eq "2")
	{
		#
		if($so{'st'} eq "1") { for($i=0; $i<($#lst+1) && !($lst[$i]=~/^\[AUDIO_LINKS/); $i++) { } }
		if($so{'st'} eq "2") { for($i=0; $i<($#lst+1) && !($lst[$i]=~/^\[VIDEO_LINKS/); $i++) { } }
		$i++; $zi=$i;

		#
		@maud = ();
		@aud = ();
		@ald = ("");
		$qm = $so{'q'};
		$qm =~ s/[^a-z0-9]/.*/g;
		loop2: for($i=$zi; $i<($#lst+1); $i++)
		{
			if($lst[$i] eq "") { last loop2; }
			if( $ald{$lst[$i]}<=5 ) 
			{
				$ald{$lst[$i]}++;
				if($lst[$i]=~/$qm/i)
				{
					# Direct match.
					$maud[$#maud+1]=$lst[$i];
				}
				else
				{
					# Non-direct match.
					$aud[$#aud+1]=$lst[$i];
				}
			}
		}

		#
		@both = (@maud,@aud);

		#
		$ast = "";
		for($i=0; $i<($#both+1) && $i<10; $i++)
		{
			if($both[$i] ne "")
			{
				#
				if($so{'st'} eq "1")
				{
					$IMG = "<img src=\"http://images.vunet.org/speaker3.gif\" border=0 align=center>";
				}
				if($so{'st'} eq "2")
				{
					$IMG = "<img src=\"http://images.vunet.org/iccam.gif\" border=0 align=center>";
				}
				$str = $both[$i];
				$str =~ s/^.*\/(.*)$/$1/;
				$str =~ s/\%[0-9]*/ /g;
				$str =~ s/[^a-z������\.\-\_0-9 ]/ /gi;
				$str2 = (" <a href=\"$both[$i]\">$IMG $str</a> ");
				$ast = "$ast<table cellpadding=0 cellspacing=0 width=100%><tr><td>$str2</td></tr></table>";
			}
		}

		#
$ast = "<table width=100% cellpadding=0 cellspacing=0 bgcolor=#F0F0FF><tr><td>$ast</td></tr></table>";

		#
		print "$ast\n";
	}

	# TEXT MODE.
	if($so{'st'}==0)
	{
		# Preview.
		if(-e $fnwli)
		{
			# Generate preview matching search keywords.
			$prv = GenPreview($fnwli, $good);
			print "$prv\n";
		}
		else
		{
			# Use default pregenerated preview.
			print "Deprecated: $lst[3]\n";
		}
	}

	#
	$str = sprintf "$lst[4] <font size=1>- ($fndar) - score %d</font>\n", $_[0];

	#
	print "$str\n";

	#
	return 1;
}

##################################################
#
# ResView [page number]
#
sub ResView
{
	my ($str,$str2,$i,$i2,$i3,$i4,@lst,$RESULTS,
		$fn,$fn2,@sp);

	#
	$RESULTS = $so{'RC'};

	#
	%hosts = ();

	#
	print "$#res\n\n";

	#
	for($i=0,$i2=0; $i<($#res+1) && $i2<($_[0]+$RESULTS); $i++)
	{
		#
		@sp = split(/ /, $res[$i]);

		#
		if($#sp<1 || $sp[0] eq "") { goto past; }

		#
		if($i2>=$_[0])
		{
			# Parameters: SCORE, GID, LOCS
			# (old: 000000000122 & www.pellervo.fi/index.html & 0 & www.pellervo.fi & 28 & 1,2,3,)
			if( ViewRes($sp[0], $sp[1], $sp[2], $sp[3]) )
			{
				# Start -counter.
				$i2++;
			}
		}
		else
		{
			$i2++;
		}
past:
	}

	#
}

##################################################
#
sub SaveCache
{
	my ($str,$fn,$f,$i);

	#
	$fn = "$SDB/tmp/cache_$_[0]";
	open($f, ">$fn") || die "can't write cache on file $fn";
	for($i=0; $i<($#res+1); $i++)
	{
		print $f "$res[$i]\n";
	}
	close($f);
}

##################################################
#
sub ProbeCache
{
	my ($str);

	#
	$fn = "$SDB/tmp/cache_$_[0]";

	#
	if(-e $fn)
	{
		@res = LoadList($fn);
		return 1;
	}

	#
	return 0;
}

##################################################
#
sub main
{
	my ($str,$fn);
	my @ty = (
		"text",
		"audio",
		"video",
		"image"
			);

	#
	$DONT_AFFECT_DB = 1;
	ArgLineParse();

	#############################################################
	#
	if($so{'st'} eq "")
	{
		$so{'st'} = 0;
	}

	#
	if( $so{'RC'} > 200 || $so{'RC'} < 10 )
	{
		$so{'RC'} = 20;
	}

	#
	if($so{'q'} ne "")
	{
		#
		print "Content-type: text\n";
		print "\n";
	#	open(STDERR,'<&STDOUT');  $| = 1;
		#
		$str = "$so{'q'}";
		$str =~ s/[^a-z���0-9\_\-\.\ ]/ /gi;
		$str =~ tr/[A-Z���]/[a-z���]/;
		$fn = "$str\_$so{'st'}";
		if($SID_RESULT_CACHE_IS_ON && ProbeCache($fn))
		{
		}	
		else
		{
			if($so{'st'} ne "0") { $xtra=",unl"; } else { $xtra=""; }
			@res = LoadList("/db/sdb/bin/is \"$str\" \"$ty[$so{'st'}]$xtra\"|");
			SaveCache($fn);
		}
		$so{'pg'} = sprintf "%d", $so{'pg'};
		ResView($so{'pg'});
		return();
	}

	#
	print "Content-type: text/html\n\n";
	# Send error messages to the user, not system log
	open(STDERR,'<&STDOUT');  $| = 1;

	#
	if($so{'q'} eq "")
	{
		#
		print("
			<form action=/search/>
			Search string:
			<input type=text name=q value=\"$so{'q'}\">
			<input type=submit>
			</form>
			");
	}
}


