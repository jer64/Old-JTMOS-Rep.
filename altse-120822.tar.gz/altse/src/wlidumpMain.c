//--------------------------------------------------------------------------------------------
//
// wlidumpMain.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "wlidump.h"

//--------------------------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
        BYTE buf[WLI_BLS];
	int i,which_index;

        //
        if(argc<3)
        {
                //
                fprintf(stderr, "wlidump [ID] [which index]\n");
                return 0;
        }

	//
	AltseLoadConfig();

        //
        i = 0;
        sscanf(argv[1], "%d", &i);
        sscanf(argv[2], "%d", &which_index);

        //
        WliDump(i, buf, WLI_BLS, which_index);
	printf("%s", buf);

        //
        return 0;
}

