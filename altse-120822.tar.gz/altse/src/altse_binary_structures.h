#ifndef __ALTSE_BINARY_STRUCTURES_H__
#define __ALTSE_BINARY_STRUCTURES_H__

//////////////////////////////////////////////////////////////////////////////////////////
//
// Real [.DIC] file element structure.
//
typedef struct
{
        //
        DWORD csum_w1;
        DWORD csum_w2;
        DWORD csum_w3;
        DWORD csum_w4;
        DWORD gid;
        HOSTHASH host;
        DWORD loc;
        DWORD type;
	DWORD rank; // TODO, in addition, also a page date valuation must be implemented in this rank value.
}DEN; // THE BINARY STRUCTURE ACTUALLY IMPLEMENTED

//
#define REAL_EN_SZ              (sizeof(DEN))

/////////////////////////////////////////////////////////////////////////////
//
typedef struct
{
        DWORD csum_w1;
        DWORD csum_w2;
        DWORD csum_w3;
        DWORD csum_w4;
        DWORD gid; // global identifier, identifies which file this is about...
	HOSTHASH host; // host identifier (csum), path identifier (csum)
        DWORD loc; // location of the word on the word list
	DWORD type; // what type of word this is
	DWORD rank;
        BYTE tiny[10];
}ENT;

//////////////////////////////////////////////////////////////////////////////////////////
// BASIC BINARY LEVEL DATA STRUCTURE USED BY inde.c, defrag.c and is.c + others.
typedef struct
{
        //
        DWORD csum_w1;
        DWORD csum_w2;
        DWORD csum_w3;
        DWORD csum_w4;
        DWORD gid;
        HOSTHASH host;
	//HOSTHASH url;
        DWORD loc;		// loc - 1) location of word, 2) in case of multimedia,
				// f.e. image, this indicates image ID
        DWORD type;
        DWORD rnk;

        // (non-structure member)
	DWORD pairs;
}EN;

// Indexer "inde"'s main data structure.
typedef struct
{
        //
        ENT **ent;
        DWORD n_ent;
        DWORD max_ent;
        BYTE *buf;
        DWORD l_buf;
        DWORD n_files;
	DWORD rank;

	//
	DWORD *imp;
	DWORD n_imp;
}INDE;

//
typedef struct
{
        char key[8];
        DWORD offs1,offs2;
}DIXE;

#endif
