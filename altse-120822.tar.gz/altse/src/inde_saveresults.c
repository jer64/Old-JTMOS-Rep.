/////////////////////////////////////////////////////////////////////////////
//
// inde_saveresults.c - index builder - primary functionality.
// (C) 2005-2011 by Jari Tuominen (jari.t.tuominen@gmail.com).
// Builds index files (DIC/DIR) out of word lists (WLI).
// "mkdix" program can be used to build
// third level index to speed up the search.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "inde.h"
#include "inde_fs.h"
#include "inde_saveresults.h"
#include "iscfg.h"
#include "dardump.h"
#include "wlidump.h"

/////////////////////////////////////////////////////////////////////////////
//
void SaveResults(INDE *in)
{
	int fd;
	DWORD i,x,t,lt,li,y,n_ranks,type,r,prisec;
	ENT *e;
	static BYTE *chr, *lchr[100];
	static BYTE buf[8192],fname[8192];
	DWORD wib; // last DWORD written at the DIR stream
	BYTE *p;

	//
	fprintf(stderr, "\n");

	//
	n_ranks = 100;

	//
	inde_fs_init(in, n_ranks);

	//
	for(r=0; r<n_ranks; r++)
	{
		lchr[r] = imalloc(1024);
		if(lchr[r]==NULL) { fprintf(stderr, "Error: imalloc returned NULL (5)\n"); abort(); } // errmsg
		strcpy((char*)lchr[r],"");
	}

	//
	if(inde_verbose) {
		fprintf(stderr, "%s: Now saving results.\n",
			__FUNCTION__);
	}

	int prisec_walk;

        if(min_prisec==0 && max_prisec==0) {
                if(OPTIMIZE_FOR_SEARCH_SPEED) {
                        min_prisec = 0;
                        max_prisec = 21;
                } else {
                        min_prisec = 0;
                        max_prisec = 1;
                }
        }

	// Go through all ranks (prisec's) and write its dictionaries.
	for(prisec_walk=min_prisec; prisec_walk < max_prisec; prisec_walk++)
	{
        	//
       	 	fprintf(stderr, "%s, time spent %d: saving (word level=%d)        \r",
	                __FILE__, time(NULL)-inde_start_time,
			prisec_walk);

		// Current rank dictionary writing.
		for(i=0,li=0,persec=0,x=0,lt=t,r=0,t=time(NULL),prisec=0; i<in->n_ent; i++) // t=time(NULL);
		{
			//
			prisec = 0;

			//
			if(inde_debug_verbose) fprintf(stderr, "1\n");
			e = in->ent[i];

			//
			r = e->rank;
			////////////////if( r<0 || r>9 ) { continue; }
			//
			chr = e->tiny;
			// ************ PROBLEM :  DOES e structure have string at all?
			//strncpy(fname, 

	                //
			if( ((x++)&31)==0 )
               		{
                        	t = time(NULL);
                        	if(t!=lt)
                        	{
                               		//
                                	persec = i-li;

                                	//
                                	li = i;
                                	lt = t;
                        	}
               		}

// INDIVIDUAL WORD PROPERTY
//#define WORD_TYPE_REGULAR               1
//#define WORD_TYPE_TITLE                 2
//#define WORD_TYPE_HOST                  3
//#define WORD_TYPE_URL                   4
//#define WORD_TYPE_META                  5
//
//...FOR MULTIMEDIA SEARCH
//#define WORD_TYPE_AUDURL                6
//#define WORD_TYPE_VIDURL                7
//#define WORD_TYPE_IMAURL                8
//
//...
//#define WORD_TYPE_PREVIEW               9
//#define WORD_TYPE_META_DESCRIPTION      10
//#define WORD_TYPE_META_KEYWORDS         11
//#define WORD_TYPE_META_AUTHOR           12
//#define WORD_TYPE_PAGEBEG               13
//#define WORD_TYPE_PAGEEND               14

			// CATEGORIZE RANK ACCORDING TO DATA TYPE.
			if(!OPTIMIZE_FOR_SEARCH_SPEED) {
				prisec = 0;
			} else {
				// default to garbage (ordinary class)
				prisec = 20;

				// Check types, and change to different class if matches.
				if(e->type==WORD_TYPE_HOST)	{
					prisec = 0;
				}
				if(e->type==WORD_TYPE_URL)	{
					prisec = 1;
				}
				if(e->type==WORD_TYPE_TITLE)	{
					prisec = 2;
				}
				if(e->type==WORD_TYPE_PAGEBEG)	{
					prisec = 3;
				}
				if(e->type==WORD_TYPE_PAGEEND)	{
					prisec = 4;
				}
				if(e->type==WORD_TYPE_PREVIEW)	{
					prisec = 5;
				}
				if(e->type==WORD_TYPE_META_DESCRIPTION)	{
					prisec = 6;
				}
				if(e->type==WORD_TYPE_META_KEYWORDS) {
					prisec = 7;
				}
				if(e->type==WORD_TYPE_META_AUTHOR) {
					prisec = 8;
				}
				if(
				e->type==WORD_TYPE_AUDURL ||
				e->type==WORD_TYPE_IMAURL ||
				e->type==WORD_TYPE_VIDURL
				) {
					prisec = 9;
				}
				// rest goes to the garbage class (TODO,
				// add more word levels)
			}

			//
			if(inde_debug) fprintf(stderr, "2 - e=%x chr=%x, in=%x, lchr[rr]=%x, matter=%d, r=%d\n",
				e, chr, in, lchr[prisec], N_CHARS_MATTER, r);
			if( strncmp((char*)chr,(char*)lchr[prisec], N_CHARS_MATTER) )
			{
				//
				if(inde_debug_verbose) {
					fprintf(stderr, "[%d/%d (%d),%d files,%s] writing at %d /s\n",
							i, in->n_ent, in->max_ent, in->n_files, chr,
							persec);
				}
			}

			if(prisec==prisec_walk) {
				//
				if(inde_debug_verbose) fprintf(stderr, "3\n");
				if( strncmp((char*)chr,(char*)lchr[prisec], N_CHARS_MATTER) )
				{
					//
					type = (e->type&255);

					// last word csum
					wib = 0xFFFFFFFF;

					if(inde_debug) fprintf(stderr, "3B\n");	
					OpenDic(in, chr, i, prisec_walk); // last arg=rank

					//
					p = buf;
				}

				//
				if(inde_debug_verbose) fprintf(stderr, "4\n");

				// in r type
				WriteDic(in,prisec, e->csum_w1);	// 00
				WriteDic(in,prisec, e->csum_w2);	// 04
				WriteDic(in,prisec, e->csum_w3);	// 08
				WriteDic(in,prisec, e->csum_w4);	// 0C
				WriteDic(in,prisec, e->gid);		// 10
				WriteDic(in,prisec, e->host);		// 14
				WriteDic(in,prisec, e->loc);		// 18
				WriteDic(in,prisec, e->type);		// 1C
				WriteDic(in,prisec, e->rank);		// 20
									// TOTAL = 0x24 bytes
			}

			//
			if(inde_debug_verbose) fprintf(stderr, "5\n");
			if(e->csum_w1!=wib && prisec==prisec_walk)
			{
				WriteDir(in,prisec, e->csum_w1);
				wib = e->csum_w1;
			}

			//
			if(inde_debug_verbose) fprintf(stderr, "6\n");
			strcpy((char*)lchr[prisec], (char*)chr);

			//
			if(inde_debug) printf("%s %x %d %d\n",
				e->tiny, e->csum_w1, e->loc, e->gid);
		}

		//
		CloseDic(in, prisec_walk, TRUE);

		//
	}
	// prisec_walk loop (goes through all ranks and writes its own dictionaries in priority order)

	//
	if(inde_verbose) {
		fprintf(stderr, "\n%s: completed, i=%d\n",
			__FUNCTION__, i);
	}

	//
	inde_fs_end(in, n_ranks);

	//
	fprintf(stderr, "\n");

	//
}
