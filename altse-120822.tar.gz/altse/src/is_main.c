//////////////////////////////////////////////////////////////////////////////////////////
//
// is_main.c - Altse Internet Search.
// (C) 2005-2011 by Jari Tuominen (jari.t.tuominen@gmail.com).
//
// Usage: is "keyword1 keyword2 keyword3 keyword4" [options]
// Use quotes, use only alphabets and numbers for keywords.
//
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
//#include <db.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "is_processresults.h"
#include "iscfg.h"

//////////////////////////////////////////////////////////////////////////////////////////
//
int main(int argc, char **argv)
{
        int ret;
        IS *is;

        //
        work_began_at = GetTickCount();

        //
	AltseLoadConfig();
        is_LoadConfig();

        /////////////////////////////////////////////////////////////////////////////////////
        //
        if(argc<2)
        {
                fprintf(stderr, "Internet Search\n");
		fprintf(stderr, "Usage: is [search keyword] -h [host] -t [search type] -f\n");
		fprintf(stderr, "NOTE: put search keyword(s) always first in \"keyword1 keyword2\" -format.\n");
		fprintf(stderr, "-i =  define which index to use (default is 0)\n");
		fprintf(stderr, "-q =  search quick (less verbose)\n");
		fprintf(stderr, "-qq =  search as quickly as possible (much less verbose)\n");
		fprintf(stderr, "-mp = max. priority level to search (1=only URL/titles, 6=all)\n");
		fprintf(stderr, "-h =  define host (like f.e. www.linux.com)\n");
		fprintf(stderr, "-t =  define type (txt, aud, vid or img)\n");
		fprintf(stderr, "-f =  force to bring as much results as possible\n");
                fprintf(stderr, "Examples:\n");
                fprintf(stderr, "is \"world\" -t txt -h www.yle.fi\n");
                fprintf(stderr, "is \"apple\" -t img -h www.playboy.com\n");
                fprintf(stderr, "is \"culture\" -t vid -h www.archive.org\n");
                fprintf(stderr, "is \"monkey\" -t aud -h www.mp3.com\n");
                fprintf(stderr, "is \"www\" -f\n");
                fprintf(stderr, "is \"beer juice cola drink\" -f -q -mp 5 -or        - Finds matches with any of these keywords (no pairs).\n");

                return 0;
        }

        //
        is = InitIS(argc, argv);

        //
        SearchIndexes(is);

        //
        ProcessResults(is);

        //
        SortResults(is);

        //
        DisplayResults(is);

        //
        fclose(flog);

        //
        return 0;
}

