#!/usr/bin/perl
##########################################################################
#
# dicex.pl -- Dictionary extraction tool.
#
# Extracts a single dictionary into seperate files
# so that it is faster to access.
#
##########################################################################
#
use POSIX;
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =		"/home/vai/sdb";	# search database root directory
$CID =		"$SDB/cid";		# central index
$LISTS =	"$SDB/cid/lists";	# list files directory
$DADI =		"$SDB/cid/data";	# data files
$DICT =		"$SDB/cid/dict";	# big index with dictionaries

#
main();

############################################################################
#
sub ExtractDic
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn,$c,
		$site,$word,$lword,
		@glst,@sp,$key,$x,$y,$z,
		$chr1,$chr2,$chr3,$lchr,$chr,
		$cid1,$cid2,$cid3,
		$f,$f2);

	#
	@lst = LoadList($_[0]);

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		loop: for(; $i<($#lst+1); $i++) { if($lst[$i] ne "") { last loop; } }

		#
		$site = $lst[$i+0];
		$str = $lst[$i+1];
		@glst = split(/\|/, $str);
		$i+=2;

		#
		@words = ();
		@scores = ();
		@nids = ();

		#
		loop2: for($lword="",$i2=0; $i<($#lst+1); $i++)
		{
			#
			if($lst[$i] eq "") { last loop2; }

			#
			@sp = split(" ", $lst[$i]);
			#
			$word = $sp[0];
			if($word eq "*") { $word=$lword; }

			# Store in seperate arrays.
			$words[$i2] = $word;
			$scores[$i2] = $sp[1];
			$nids[$i2] = $sp[2];
			$i2++;

			#
			$lword = $word;
		}

		#
		for($i2=0; $i2<($#words+1); $i2++)
		{
			#
			$str = $words[$i2];

			# Search for keywords in this group.
			@sw = ();
			loopz: for($lchr="",$x=0,$y=0; $i2<($words+1); $i2++,$x++)
			{
				#
				if($x>0 && $chr ne $lchr) { last loopz; }

				#
				$key = $words[$i2];

				#
				$chr1 = $key;
				$chr1 =~ s/^(\S).*$/$1/;
				$chr2 = $key;
				$chr2 =~ s/^\S(\S).*$/$1/;
				$chr3 = $key;
				$chr3 =~ s/^\S\S(\S).*$/$1/;
	
				# Convert the first three chars into numbers.
				$cid1 = ord($chr1);
				$cid2 = ord($chr2);
				$cid3 = ord($chr3);

				#
				$chr = $key; $chr =~ s/^(\S\S\S).*$/$1/;

				#
				$sw[$y++] = key;

				#
				$lchr = $chr;
			}

			#
			if($y)
			{
				$str2 = $str;
				$str2 =~ s/^(\S).*$/$1/;
				$str2 = ord($str2);
				mkdir("$str2");
			#	open
				for($x=0; $x<$y; $x++)
				{
				}
			}
		}

		#
	}

	#
}

############################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,@lst,@lst2,$fn,$c);

	#
	if($ARGV[0] ne "")
	{
		ExtractDic($ARGV[0]);
	}
}

