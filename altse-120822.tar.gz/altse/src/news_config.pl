#!/usr/bin/perl
################################################################
# Your home computer's IP (for master access in some cases).
$MASTER_IP=             "82.103.200.47";
#
@MASTER_IPS=(
	#	"82.103.200.47",
	#	"82.103.201.139"
		);
#
$NWPUB_WWWBASE =        "/home/vai/public_html";
$NWPUB_CGIBASE =        "/home/vai/cgi-bin";
$ENV{'NWPUB_WWWBASE'} = $NWPUB_WWWBASE;
$ENV{'NWPUB_CGIBASE'} = $NWPUB_CGIBASE;
#
$VAI_PROF_DIR = "$NWPUB_CGIBASE/user/";
$IMGBASE = "http://images.vunet.org";
$NEBASE = "http://vunet.org/~vai/uutiset";
$NEBASECGI = "http://vunet.org/~vai/cgi-bin";
#
$BGBAK1 = "http://images.vunet.org/bakki5.gif";
$BGBAK2 = "http://images.vunet.org/bakki6.gif";
$TABCOL = "40E0FF";
