#!/usr/bin/perl
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
main();

#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,$f,$s1,$s2,$s3,$s4);

	#
	open($f, "/db/bigidb.txt");

	#
	for($i=0; !eof($f); $i+=4)
	{
		#
		$s1 = <$f>; chomp($s1);
		$s2 = <$f>; chomp($s2);
		$s3 = <$f>; chomp($s3);
		$s4 = <$f>; chomp($s4);

		#
		if($s3 > 19999)
		{
			printf "%.8d %s\n", $s3, $s1;
		}
	}

	#
	close($f);

	#
}
