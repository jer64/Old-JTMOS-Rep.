#!/usr/bin/perl
# news.pl

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "./modules/settings.pm";
require "./modules/AltseOpenConfig.pm";
require "./modules/AltseMenuSystem.pm";
require "./modules/ViewNewsFeed.pm";
#
AltseOpenConfig();

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
if($so{'js'} ne "") {
	$MAX_VIEW_COUNT = 10;
	print "Content-type: text/JavaScript\n\n";
} else {
	$MAX_VIEW_COUNT = 500;
	print "Content-type: text/html\n\n";
}
# source section correction
$so{'sec'} =~ s/[^a-z]//g;
if($so{'sec'} eq "") {
        $ENV{'CURSEC'} = "finance";
	$so{'sec'} = "finance";
}
if($so{'sec'} eq "finnish") {
        $ENV{'CURSEC'} = "uutiset";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

#
$HOSTI = "http://istrump.life";

###############################################################################
#
print("
<TABLE width=100% cellspacing=0 cellpadding=0 align=left valign=top>
<TR valign=top>
<TD width=210>
");
#
print inc_menu($ENV{'CURSEC'}, "");

#
print("
</TD>
<TD width=100%>

");

#
main();

#
print("
</TD>

</TR>
</TABLE>
");

#
if($so{'js'} eq "") {
}

###########################################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,$str,$str2,$niceurl,$age,$content);

	if($so{'js'} eq "") {
                print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
<link REL=\"SHORTCUT ICON\" HREF=\"$IMAGES_URL/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"images/altse.css\" title=\"Cool\">
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=iso-8859-1\" />
<title>
ALTSE - FINANCE - $ENV{'CURSEC'}
</title>
</head>

<BODY topmargin=0 leftmargin=0
        marginheight=0 marginwidth=0>
	");


	print("
                        <DIV ALIGN=LEFT>
                        <TABLE width=1150 height=109 cellpadding=0 cellspacing=0
                                background=\"$IMAGES_URL/new_altse_2.gif\"
				onClick=\"this.href='/';\">
                        <tr valign=top>
                        <td>
<DIV ALIGN=CENTER>
<FONT SIZE=6 CLASS=\"Style: Capitalize\">$ENV{'CURSEC'}</FONT>
</DIV>

                        </td>
                        </tr>
                        </table>
                        </DIV>

<TABLE width=750 cellpadding=16 cellspacing=0 class=main_frontpage_article_window>
<TR valign=top>
<TD>

<P>
<TABLE width=150>
<TR>
<TD WIDTH=50>
<A HREF=\"?sec=\">Home</A>
</TD>
<TD WIDTH=50>
<A HREF=\"?sec=english\">English</A>
</TD>
<TD WIDTH=50>
<A HREF=\"?sec=finnish\">Finnish</A>
</TD>
</TR>
</TABLE>
</P>

<FORM ACTION=\"/$CGICMD\">
Search news:
<INPUT TYPE=\"TEXT\" NAME=\"q\" VALUE=\"\">
<INPUT TYPE=\"HIDDEN\" NAME=\"indexnr\" VALUE=\"$which_index\">
<INPUT TYPE=\"HIDDEN\" NAME=\"cmd\" VALUE=\"go\">
<INPUT TYPE=\"SUBMIT\" value=\"search\">
</FORM>

		");
	}

	#
        print ViewNewsFeed();
        
        #
        print("
        </TD>
        </TR>
        </TABLE>");
	
	#
	if($so{'js'} ne "") {
	        $content =~ s/[\t\n\r\s]/ /g;
	        $content =~ s/\"/\\\"/g;
	        print(" document.write(\"$content\"); \n");
	} else {
		print("
</BODY>
</HEAD>
");
	}

	#
}
