#!/usr/bin/perl
#############################################################################
# Image search prototype pre-alpha.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2011 by Jari Tuominen (jari.t.tuominen@gmail.com).
#############################################################################

#
use POSIX;

# CHANGE THIS IF YOU ARE NOT RUNNING AS USER "vai" !
require "modules/AltseOpenConfig.pm";
#
AltseOpenConfig();
require "modules/settings.pm";
require "modules/ViewCache.pm";
require "modules/GetPageImages.pm";
require "modules/GetPageImagesFromCache.pm";
require "modules/ViewTextResults.pm";
require "modules/ViewImageResults.pm";
require "modules/QueryDB.pm";
require "modules/Logging.pm";
require "modules/Frontpage.pm";
require "modules/InterfaceOpenDP.pm";
require "modules/CacheResults.pm";

#
if( !$ENV{'newswire_conset'} )
{
        print "Content-type: text/html\n\n";
}
# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush STDOUT buffer after each command
select(STDOUT);
$| = 1;

# Search arguments line for options.
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
main();

#
sub HtmlHeader
{
	### HARDCODED USER INTERFACE
        #
                print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"http://images.vunet.org/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"$CSS_URL\" title=\"Cool\">
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
<title>
$PAGE_TITLE
</title>
</head>

<BODY $xtra bgcolor=$TVAR
	topmargin=0 leftmargin=0
	marginheight=0 marginwidth=0>


<TABLE width=100% height=1 cellpadding=0 cellspacing=0
	bgcolor=#000000>
<TR>
<TD>
</TD>
</TR>
</TABLE>

<table width=100% bgcolor=$TVAR cellpadding=0 cellspacing=0>
<tr>
<td>

			");
}

#
sub HtmlHeaderEnd
{
	#
	print("
</td>
</tr>
</table>

</body>
		");
}

#
sub ImageSearchProto
{
	#
	print("
<TABLE CELLPADDING=4 CELLSPACING=0>
<TR>
<TD>
	<FORM ACTION=\"?\">
	Search for image: 
	<INPUT type=text name=\"q\" value=\"$so{'q'}\">
	<INPUT type=submit value=\"SEARCH\">
	</FORM>
</TD>
</TR>
</TABLE>
	");
}

#
sub DisplayResults
{
	my ($i,$i2,@lst,$pagenr);

	#
	$so{'indenr'} = 0;
#	@lst = LoadList("$DB/wwwimages/already.txt");
	@lst = ();
	print "<PRE>@lst</PRE>";

	#
	for($pagenr=0; $pagenr<10; $pagenr++) {
		@lst = GetPageImages($pagenr); # pagenr
		for($i=0; $i<($#lst+1) && $i<2000; $i++)
		{
			if($lst[$i] =~ /\.jpg$/i)
			{
				print "<IMG SRC=\"$lst[$i]\"><BR>";
			}
		}
	}

	#
}

#
sub main
{
	#
        HtmlHeader();
	ImageSearchProto();
	if($so{'q'} ne "") {
		DisplayResults();
	}
        HtmlHeaderEnd();
}
