#!/usr/bin/perl
#############################################################################
# index.pl - ALTSE text search CGI -frontend for the Internet Search.
# ALTSE - ALTERNATIVE SEARCH ENGINE.
# (C) 2003-2022 by Jari Tuominen (jari.t.tuominen@gmail.com).
# Calls is -executable (instant search, see is.c).
#############################################################################

#
use POSIX;
use POSIX qw(strftime);

#
require "./modules/AltseOpenConfig.pm";
require "./modules/freesms.pm";
#require "modules/ViewNewsFeed.pm"; is useful
#
AltseOpenConfig();
require "./modules/SearchSubModule.pm";
require "./modules/DirectorySubModule.pm";
#
print "Content-type: text/html\n\n";

#
$DONT_AFFECT_DB = 1;
ArgLineParse();

#
#<meta http-equiv=\"refresh\" content=\"0; url=/cache/VladimirPutin.html\">
# http://www.altse.online/cache/VladimirPutin.html
	
#	system("./gallery.pl");
#	return;
#

#
#print "Attention";

# Can now choose index to use for searching.
if($so{'indexnr'} eq "") {
	$so{'indexnr'} = 0;
}

# Send error messages to the user, not system log
open(STDERR,'<&STDOUT');  $| = 1;

# Flush
# This should flush stdout.
my $ofh = select(STDOUT);$| = 1;select $ofh;

###############################################################################
#
my @menu_items = (
	"0", # 0
	"1", # 1
	"2", # 2
	"3", # 3
	"4", # 4
	"5", # 5
	"6", # 6
	"7", # 7
	"8", # 8
	"9", # 9
);

my @menu_labels = (
	"", # 0
	"", # 1
	"", # 2
	"", # 3
	"", # 4
	"", # 5
	"", # 6
	"", # 7
	"", # 8
	"", # 9
);

my @menu_urls = (
	"", # 0
	"", # 1
	"", # 2
	"", # 3
	"", # 4
	"", # 5
	"", # 6
	"", # 7
	"", # 8
	"", # 9
);

#################################################################
#
print("
<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">
<html>

<head>
  <link REL=\"SHORTCUT ICON\" HREF=\"/images/icon_altse.png\">
  <link rel=\"STYLESHEET\" type=\"text/css\" href=\"/altse.css\" title=\"Cool\">

  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />
<!--- iso-8859-1 --->

<meta name=\"google-site-verification\" content=\"IL1bs0eDAEFwROhwR_foI2w6lCw7Y5YJ9reoyWmAvCM\" />

  <meta name=\"revisit-after\" content=\"1 days\">
  ");
  if($so{'q'} eq "")
  {
	  print("
  <meta name=\"description\" content=\"$PAGE_COMMERCIAL_TEXT_SHORT\">
  ");
  }
  else
  {
	  print("
  <meta name=\"description\" content=\"$PAGE_COMMERCIAL_TEXT_SHORT: $so{'q'}\">
  ");
  }
  print("
  <meta name=\"keywords\" content=\"$so{'q'}, $PAGE_KEYWORDS}\">
  <meta name=\"author\" content=\"Jari Tapio Tuominen\">

  <meta name=\"google-site-verification\" content=\"jyAYuR14wFvkF0LjVP6W63jh6y-lIX3Qa2FNoahjEkE\" />

<title>
");
if($so{'q'} eq "")
{
        print "$PAGE_TITLE";
}
else
{
        print "$so{'q'} - $PAGE_TITLE - ".int($so{'start'})."";
}
print("
</title>
</head>



<script async src=\"https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4178289363390566\"
     crossorigin=\"anonymous\"></script>

<BODY $xtra bgcolor=$TVAR
        topmargin=0 leftmargin=0
        marginheight=0 marginwidth=0>

");

past:

#
if($so{'frontpage'} eq "" && $so{'cmd'} eq "") {
	# Introduction and search engine form.
	print("



<BR>
<TABLE width=\"350\" align='center'>
<TR>
<TD>

<DIV align='center' style=\"color: #000000; font-size: 24;\">$PAGE_ENGINE_FOOTER</DIV>

<IMG SRC=\"$LOGO_FRONT\">

$PAGE_ENGINE_FOOTER2

<DIV align='center'>
<FORM ACTION=\"/?\" name=\"FORM1\” id=\"FORM1\">

<INPUT TYPE=\"TEXT\" VALUE=\"$so{'q'}\" NAME=\"q\" SIZE=\"20\" id=\"q\" maxlength=\"100\"
	style=\"width: 100%;
padding: 12px 20px; margin: 8px 0;
box-sizing: border-box; font-size: 24; box-sizing: content-box;
display: flex; float: none; line-height: normal; position: static; z-index: auto; \">
<INPUT TYPE=\"HIDDEN\" VALUE=\"$so{'indexnr'}\" NAME=\"indexnr\">
<INPUT TYPE=\"HIDDEN\" VALUE=\"go\" NAME=\"cmd\">
<INPUT TYPE=\"SUBMIT\" VALUE=\"$SEARCH_GO\"
style=\"width: 100;
padding: 12px 20px; margin: 8px 0;
box-sizing: border-box; font-size: 24; box-sizing: content-box;
display: flex; float: none; line-height: normal; position: static; z-index: auto;\">
</DIV>

</TD>
</TR>
</TABLE>

                <script language=\"javascript\">
                        document.getElementById('q').focus();
                </script>

");
	################
	#
	my (@lst) = LoadList("/home/vai/altse/html/cgi/cfg/recommended_searches.txt");
	#print $#lst;
	my ($i,@sp,$str);
	#
	print("
<BR>
<A NAME=\"recommended\"></A><TABLE width=\"550\" align=\"center\">
<TR>
<TD>
	");
	#
	print("
	<CENTER><H1>Hakuja, tykkää uutisista tästä:</H2></CENTER>
	");
	#
	print("
	<TABLE>
	<TR>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		if(($i%4)==3)
		{
			print("</TR><TR>");
		}
		
		print("
		<TD>
		<H2>
		<A HREF=\"/?cmd=go&indexnr=0&q=$lst[$i]\">
		$lst[$i]
		</A>
		</H2>
		</TD>
		");
	}
	print("
</TR>
</TABLE>

<BR>
<BR>
	");

	################
	#
	# LOAD UP THE ALTSE's SOCIAL LIKES.
	#
	if(-e "$DB/likes.txt")
	{
		@lst = reverse LoadList("$DB/likes.txt");
	}
	
	#
	print("
<A NAME=\"likes\">
	<CENTER><H1>Tykättyjä hakuja:</H2></CENTER>
	
	<DIV style=\"background: #FFFF40; font-size: 24; padding: 10; \">
	<A HREF=\"#recommended\">Tykkää uutisia tästä.</A>
	</DIV>
</A>
	");
	for($i=0; $i<($#lst+1); $i++)
	{
		#
		@sp = split(/\|/, $lst[$i]);
		#
		my $str="$sp[0]/$sp[1]";
		if($dup{$str})
		{
			goto skip11;
		}
		$dup{$str}++;
		# > Load Preview From The Altse WWW Cache.
		my @dar = LoadList("$DB/altse/bin/dardump \"$sp[0]\" \"$sp[1]\" 2>/dev/null|");
		LoadVars("$DB/altse/bin/dardump \"$sp[0]\" \"$sp[1]\" 2>/dev/null|");
		#
		print("
		<H1>
		<IMG SRC='https://www.pngitem.com/pimgs/m/35-356815_red-thumbs-up-clipart-thumbs-up-icon-red.png'
	valign='left'
	title='Tykkää tästa uutisesta!' alt='Tykkää tasta uutisesta'
	width='20' height='13'>

		<A HREF=\"http://$so{'host'}$so{'path'}\" target=\"_blank\">
		$so{'title'}
		</A>
		</H1>
		");
skip11:
	}
	#
	print("
</TD>
</TR>
</TABLE>
	");

	#
	print("

</FORM>
<SCRIPT LANGUAGE=\"JAVASCRIPT\">
document.getElementById('q').requestFocus();
</SCRIPT>
");

print("
</TD>
</TR>
</TABLE>
");


	# Links to partner websites.
	my $style_for_div = ("style=\"background: #C04040; font-size: 18px; a.color: #000000; color: #000000; padding: 10px;
	height: 35; \"
	");
	my $style_for_div_cap = ("style=\"background: #E04040; font-size: 28px; a.color: #000000; color: #000000; padding: 10px;
        height: 35; \"  
        ");
	my $table_width = 800;
	my $td_width = 800;
	my $a_style=" style=\" COLOR: yellow; TEXT-DECORATION: underline; font-weight: normal; \" target=\"_blank\" ";


	#
	print("
	<P>
	<TABLE width=\"640\" align=\"center\" cellpadding=\"4\" cellspacing=\"0\">
	<TR>
	<TD>
	
	<P><FONT style=\"font-size: 24px; \">Viimeksi ladattuja sivuja:</FONT></P>
	");
	
	# db/download.log
	my @dlog = reverse LoadList("tail -n 10000 $DB/download.log|");
	my ($i);
	#
	for($i=0,my $ic=0; $i<($#dlog+1) && $ic<25; $i++)
	{
		my @sp = split(/ /, $dlog[$i]);
		
		if( $sp[1] eq "downloaded" && int($sp[0])>=0 )
		{
			my $timeint1 = int($sp[0]);
			my $url1 = $sp[2];
			#my $timestr1 = strftime("%a %b %e %H:%M:%S %Y", $timeint1);
			   
			my	$urlbeginning = $url1;
				$urlbeginning =~ s/^(.{25}).*$/$1/;
			my $compacturl = $url1;
				$compacturl =~ s/^(.{25}).*$/$1/;
			my $compacturllong = $url1;
				$compacturllong =~ s/^(.{50}).*$/$1/;
			if(!$gotlogged{$urlbeginning})
			{
				$gotlogged{$urlbeginning}++;
				
				my $dumpfn = $sp[4];
				$dumpfn =~ s/\.html/\.dump/;
				@dumplist = LoadList("zcat $DB/www/$dumpfn|");
				my $compactstr = join(" - ", @dumplist);
				my $cutstr = $compactstr;
				   $cutstr =~ s/^({30}.).*$/$1 .../;
				
				print "<LI><A HREF=\"$url1\" target=\"_blank\">$compacturllong ...</A></LI>\n";
				$ic++;
			}
		}	
	}
	
	#
	print("
	</TD>
	</TR>
	</TABLE>
	</P>
	<BR>
	");
	#1660273676 downloaded http://www.varastoduunarit.com/forum/index.php?PHPSESSID=suvrn63dou42s1jslfs847pf12&topic=288.0 as var/www.varastoduunarit.com/24624.html.gz

	
	# LINKIT: Uutissyötteitä.
	$F1 = ("<FONT STYLE=\"font-size: 14px; color: #FFFFFF;\">");
	$F2 = ("</FONT>");
	
	#
	print("

<TABLE width=\"$table_width\" cellpadding=\"0\" cellspacing=\"0\" valign=\"top\" align=\"center\">

<TR valign=\"top\">
<TD width=\"$td_width\" style=\”padding: 0;\">
 <DIV $style_for_div_cap>
 <FONT style=\"color: #E8E8E8;\">Uutissyötteitä</FONT>
 </DIV>
</TD>
</TR>

<TR valign=\"top\">
<TD width=\"$td_width\" style=\”padding: 0;\">
 <DIV $style_for_div>
 <A HREF=\"http://istrump.life\" $a_style>IsTrump.Life</A>$F1 - Vaihtoehtouutisten internet-hakukone. $F2
 </DIV>
</TD>
</TR>

<TR>
<TD width=\"$td_width\" style=\”padding: 0;\">
 <DIV $style_for_div>
 <A HREF=\"http://www.vaihtoehtouutiset.com\" $a_style>Vaihtoehtouutiset.com</A>$F1 - Vaihtoehtouutiset (Vunet). $F2
 </DIV>
</TD>
</TR>

<TR>
<TD width=\"$td_width\" style=\”padding: 0;\">
 <DIV $style_for_div>
 <A HREF=\"http://www.p4t1n.com\" $a_style>P4t1n.com</A>$F1 - Putin- ja bisnesuutiset. $F2
 </DIV>
</TD>
</TR>

<TR>
<TD width=\"$td_width\" style=\”padding: 0;\">
 <DIV $style_for_div>
 <A HREF=\"https://www.facebook.com/sipila.heikki/\" $a_style>Heikki Sipilä FaceBook</A> - $F1 Bloggaaja, toimittaja. Ajankohtaisia uutisia päivittäin. $F2
 </DIV>
</TD>
</TR>

<TR>
<TD width=\"$td_width\" style=\"padding: 0;\">
 <DIV $style_for_div>
 <A HREF=\"https://www.facebook.com/hannu.rainesto\" $a_style>Hannu Rainesto FaceBook</A>$F1 - Bloggaaja, ajattelija, ja entinen yrittäjä. $F2
 </DIV>
</TD>
</TR>

<TR>
<TD width=\"$td_width\" style=\”padding: 0;\">
 <DIV $style_for_div>
 <A HREF=\"https://www.facebook.com/jari.t.tuominen\" $a_style>Jari Tuominen Facebook</A>$F1 - Bloggaaja, toimittaja, ohjelmistoteollisuuden guru. $F2
 </DIV>
</TD>
</TR>

<TR>
<TD width=\"$td_width\" style=\"padding: 0;\">
 <DIV $style_for_div>
 <A HREF=\"https://www.youtube.com/vunet\" $a_style>youtube.com/vunet</A>$F1 - Vunet - TV - Musiikkia ja tanssia slaavilaisteemalla. $F2
 </DIV>
</TD>
</TR>


</TABLE>
	");


}

#
if($so{'cmd'} eq "like")
{
	#
	my ($f);
	#
	open($f, ">>$DB/likes.txt");
	print $f "$so{'pageid'}|$so{'indexnr'}|$so{'url'}\n";
	close($f);
	#
	print("
<meta http-equiv=\"refresh\" content=\"0; url=/#likes\">
 ");
 	goto endi;
 	#
}

#
#my $ON_TOP_MENU_HTML = ("
#<TABLE width=100% cellspacing=0 cellpadding=0 bgcolor=#000000
#	height=32>
#<TR valign=top>
#");
#my $width_for_td = 100/($#menu_items+1);
##for($i=0; $i<$#menu_items; $i++) {
##	print("
##<TD width=$width_for_td\% bgcolor=#000000>
#<A HREF=\"$menu_urls[$i]\">$menu_labels[$i]</A>
#</TD>
#		");
#}
#print("
#</TR>
#</TABLE>
#");
#

#
print("
$ON_TOP_MENU_HTML
");


#################################################################
#
if($so{'frontpage'} eq "") {
#	$so{'frontpage'} = "news";
}


#
print("


</TD>

</TR>
</TABLE>

</body>
");

#
if($so{'noajax'} eq "" && $so{'q'} ne "")
{
my $redirect_to = "/?cmd=go&q=$so{'q'}&st=$so{'st'}&indexnr=0&start=$so{'start'}&noajax=TRUE";
my $job = $so{'q'};
print("
<BR><BR>
<DIV ALIGN=\"CENTER\" id=\"ajax2\">
<FONT FACE=\"IMPACT\" size=6 color=\"#C00000\">$ALTSE_HOST - $job - Vaihtoehtouutisten hakukone</FONT><BR>
<A HREF=\"$redirect_to\">
<IMG SRC=\"/images/ajaxloader2.gif\" alt=\"Odota hetki ...\">
</A>
<BR>
<A HREF=\"$redirect_to\">
<!---
$redirect_to
--->
</A>
<BR>
</DIV>
<meta http-equiv=\"refresh\" content=\"0; url=$redirect_to\">
");
	goto endi;
}

#
if($so{'q'} =~ /\//) {
	$so{'sec'} = $so{'q'};
}
if($so{'frontpage'} eq "news" || $so{'cmd'} eq "go" || $so{'cmd'} eq "vcache" 
|| $so{'cmd'} eq "preview" || $so{'cmd'} eq "previewimage"  ) {
	# Show main menu.
	MainSearchIndexModule();
} else {
	if($so{'sec'} eq "directory" || $so{'sec'} =~ /\//) {
		DirectorySubModule();
	} else {
		# Show specific section.
		if($so{'sec'} eq "directory" || $so{'sec'} =~ /\//) {
			DirectorySubModule();
		} else {
			#NewsFeedsView();
		}
	}
}

print("
<CENTER>
<TABLE width='550'>
<TR>
<TD>
<HR>
<CENTER>
<H3>
$COPYRIGHT
</H3>
</CENTER>
</TD>
</TR>
</TABLE>
</CENTER>
");

endi:
