// Obsolete - syssh_applications.h.
