//
#ifndef __INCLUDED_VMWARE_H__
#define __INCLUDED_VMWARE_H__

//
int vmware;
int InitVmwareDriver(void);

#endif


