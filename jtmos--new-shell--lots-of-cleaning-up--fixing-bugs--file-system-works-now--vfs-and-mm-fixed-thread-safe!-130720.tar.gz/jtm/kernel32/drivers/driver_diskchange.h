#ifndef __INCLUDED_DISKCHANGE_H__
#define __INCLUDED_DISKCHANGE_H__

//
void diskchangednr(int WHICH_DNR);
void driver_api_diskchange(int WHICH_DNR);
void diskchange(int dnr);
void DiskChange(int dnr);

#endif

