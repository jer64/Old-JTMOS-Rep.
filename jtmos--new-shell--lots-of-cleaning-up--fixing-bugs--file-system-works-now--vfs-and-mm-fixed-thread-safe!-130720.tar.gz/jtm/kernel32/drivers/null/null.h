#ifndef __INCLUDED_NULL_H__
#define __INCLUDED_NULL_H__

// Something here:
int null_init(void);

#endif
