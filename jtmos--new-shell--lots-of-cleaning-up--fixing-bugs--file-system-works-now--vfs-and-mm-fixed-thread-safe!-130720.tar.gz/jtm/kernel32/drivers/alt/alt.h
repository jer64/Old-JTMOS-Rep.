// device driver
#ifndef __INCLUDED_ALTDEV_H__
#define __INCLUDED_ALTDEV_H__

// Something here:
int altdev_init(void);

#endif
