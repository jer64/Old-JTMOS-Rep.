#ifndef __INCLUDED_DEVAPI_INIT_H__
#define __INCLUDED_DEVAPI_INIT_H__

//
void driver_init(void);

#endif
