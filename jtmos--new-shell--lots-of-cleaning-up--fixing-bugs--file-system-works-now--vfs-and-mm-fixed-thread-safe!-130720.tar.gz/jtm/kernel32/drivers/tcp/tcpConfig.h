//
#ifndef __INCLUDED_TCPCONFIG_H__
#define __INCLUDED_TCPCONFIG_H__

//
#define TCP_CFG_FNAME	"tcp.cfg"

//
void tcpReadConfiguration(void);

#endif




