//--------------------------------------------------------------------------
// tcpConfig.c
//--------------------------------------------------------------------------
#include <stdio.h>
#include "ts.h"
#include "tcp.h"
#include "tcpConfig.h"

// IP address.
int ipad0=10,ipad1=0,ipad2=0,ipad3=5;
// Mask
int ipma0=255,ipma1=255,ipma2=255,ipma3=0;

// Read & parse tcp configuration
void tcpReadConfiguration(void)
{
	//

}



