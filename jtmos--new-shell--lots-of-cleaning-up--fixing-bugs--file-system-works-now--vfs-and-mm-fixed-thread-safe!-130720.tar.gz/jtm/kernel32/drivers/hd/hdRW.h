#ifndef __INCLUDED_HDRW_H__
#define __INCLUDED_HDRW_H__

#include "hd.h"
int hdRW(HD *h, BYTE *buf, int rw);

#endif



