//
#ifndef __INCLUDED_HDSERVICE_H__
#define __INCLUDED_HDSERVICE_H__

//
void hdServiceInit(void);
void hdDriverMain(void);
void hdDriverInit(void);

#endif





