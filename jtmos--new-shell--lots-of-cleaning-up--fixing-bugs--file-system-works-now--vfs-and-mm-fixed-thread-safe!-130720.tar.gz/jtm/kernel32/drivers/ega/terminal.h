#ifndef __INCLUDED_TERMINAL_H__
#define __INCLUDED_TERMINAL_H__

#define ID_VIRTUAL_TERMINAL_1           0
#define ID_VIRTUAL_TERMINAL_2           1
#define ID_VIRTUAL_TERMINAL_3           2
#define ID_VIRTUAL_TERMINAL_4           3
#define ID_VIRTUAL_TERMINAL_5           4
#define ID_VIRTUAL_TERMINAL_6           5
#define ID_VIRTUAL_TERMINAL_7           6
#define ID_VIRTUAL_TERMINAL_8           7
#define ID_VIRTUAL_TERMINAL_9           8

#endif
