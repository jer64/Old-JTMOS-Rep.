#ifndef __INCLUDED_STRTOK_H__
#define __INCLUDED_STRTOK_H__
char *
strtok (char *s, const char *delim);

#endif
