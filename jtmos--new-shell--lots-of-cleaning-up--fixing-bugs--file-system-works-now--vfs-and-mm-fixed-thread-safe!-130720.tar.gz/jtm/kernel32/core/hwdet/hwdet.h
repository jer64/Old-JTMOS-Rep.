#ifndef __INCLUDED_HWDET_H__
#define __INCLUDED_HWDET_H__

//
#include "basdef.h"

//
extern DWORD hwdetCounter;

//
void hwdetProgram(void);
void hwdet(void);

#endif

