#ifndef __INCLUDED_SPEED_H__
#define __INCLUDED_SPEED_H__

//
extern DWORD determine_cpu_speed(void);

#endif
