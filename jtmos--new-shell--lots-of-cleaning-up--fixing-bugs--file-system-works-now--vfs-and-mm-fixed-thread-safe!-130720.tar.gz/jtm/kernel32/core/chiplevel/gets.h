//
#ifndef __INCLUDED_GETS_H__
#define __INCLUDED_GETS_H__

//
char *gets(char *s);

#endif
