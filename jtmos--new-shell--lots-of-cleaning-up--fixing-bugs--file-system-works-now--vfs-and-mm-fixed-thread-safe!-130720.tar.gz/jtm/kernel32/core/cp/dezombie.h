#ifndef __INCLUDED_DEZOMBIETHREAD_H__
#define __INCLUDED_DEZOMBIETHREAD_H__

// 
#include "basdef.h"

// 
extern void     DezombieThreadProgram(void);
extern void     DezombieProgram(void);
extern void     init_DezombieThread(void);

#endif
