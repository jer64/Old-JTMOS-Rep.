#ifndef __INCLUDED_EXEIDENT_H__
#define __INCLUDED_EXEIDENT_H__

//
int isExeBinary(BYTE *buf, int l);
extern int exeIdentAnythingGoes;
int getExeMemReq(BYTE *buf, int l);

#endif


