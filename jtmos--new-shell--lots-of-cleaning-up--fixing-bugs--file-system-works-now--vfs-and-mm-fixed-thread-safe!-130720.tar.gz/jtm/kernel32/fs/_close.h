#ifndef __INCLUDED_CLOSE_H__
#define __INCLUDED_CLOSE_H__

#include "scs.h"
int msdos_close(SYSCALLPAR);

#endif

