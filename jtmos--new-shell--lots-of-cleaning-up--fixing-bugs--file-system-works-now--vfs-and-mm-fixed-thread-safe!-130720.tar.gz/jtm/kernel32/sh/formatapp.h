#ifndef __INCLUDED_FORMATAPP_H__
#define __INCLUDED_FORMATAPP_H__

//
int format_app(int argc, char **argv);

#endif
