//
#include <stdio.h>
#include "sh.h"
#include "lsapp.h"
#include "formatapp.h"
#include "chdirapp.h"

//
static char *ptr_string_table_cmds = {
    "cd",	chdir_app,NULL,NULL,
    "chdir",	chdir_app,NULL,NULL,
    "ls",	ls_app,NULL,NULL,
    "dir",	ls_app,NULL,NULL,
    "mkfs",	format_app,NULL,NULL,
    "format",	format_app,NULL,NULL,
    NULL, NULL, NULL, NULL
};

// Returns argc.
int getargumentlist(char *ptr_string_table_cmdstr, char **argv)
{
    int i,argc;
    char *ptr,*src;

    argv = malloc(1024*64);
    memset(argv, 0, 1024*64);
    
    ptr = ptr_string_table_cmdstr;

    src = strtok(ptr, " ");
    if(src==NULL)
    {
        argc = 0;
    }
    else
    {
        for(i=0,argc=0; i<5000; i++,argc++)
        {
            argv[i] = src;
            if(src==NULL) { break; } // Break on No more tokens available.
            src = strtok(NULL, " ");
        }
    }

    // Return the argument ount.
    return argc;
}

//
int run_shell(void)
{
    char *ptr_long_string, *ptr_str_fn_executable,
        *ptr_str_user_input, *ptr_string_head,
        *ptr_head;
    void (*ptr_call)(int,char **);
    int i,i2;
    int argc;
    char **argv;

    // RESERVE MEMORY    
    // 64K should be enough for a command line prompt string of a maintance shell.
    ptr_long_string = malloc(1024*64);
    if(ptr_long_string==NULL)
    {
        printf("Error: \"ptr_long_string\" memory allocation failed, malloc returned NULL.\n");
        return 1;
    }

    ptr_str_fn_executable = malloc(1024*64);
    if(ptr_str_fn_executable==NULL)
    {
        printf("Error: \"ptr_str_fn_executable\" memory allocation failed, malloc returned NULL.\n");
        return 1;
    }

    // HELLO TEXT TO THE USER.
    printf("Built-In System Maintenance Debug Shell 1.0 / 7/2020\n");

    // ACTUAL SHELL MAIN LOOP.
    while(1)
    {
        // Indicator.
        printf("#");
        // Tell about happening, inputting a string.
        printf("%s: Inputting string.\n", __FUNCTION__);
        gets(ptr_long_string);
        ptr_str_user_input = ptr_long_string;
        //
        for(i=0; ; i+=4)
        {
            if(ptr_string_table_cmds[i+0]==NULL) {
                // It seems to be the last parameter on cmds table.
                //
                printf("strtok on \"ptr_string_head\", to get the executable file name.\n");
                ptr_str_fn_executable = strtok(ptr_string_head, " ");
                // END OF LIST AND NO RECOGNIZED INTERNAL COMMAND.
                // Did not recognize this as an internal command.
                if(ptr_str_fn_executable!=NULL)
                {
                    printf("%s: Launching external application '%s': %s\n",
                        __FUNCTION__, ptr_long_string, ptr_str_fn_executable);
                    system(ptr_long_string);
                }
                else
                {
                    printf("Error: empty executable file parameter.\n");
                }
                break;
            }
            else
            {
                //
                printf("Doing strok to get the executable file name.\n");
                ptr_str_fn_executable = strtok(ptr_string_head, " ");

                printf("Checking whether command is the one in the string table array.\n");
                if(ptr_str_fn_executable!=NULL &&
                    !strcmp(ptr_string_table_cmds[i+0], ptr_str_fn_executable))
                {
                    // See We Got A Recognized internal command!
                    printf("Calling getargumentlist\n");
                    argc = getargumentlist(ptr_str_user_input, argv);
                    //
                    ptr_call = ptr_string_table_cmds[i+1];
                    printf("%s: Launching up internal application (ptr=0x%x): %s (app. has %d arguments, argv at 0x%x).\n",
                            __FUNCTION__,ptr_call,ptr_str_fn_executable,argc,argv);
                    ptr_call(argc,argv);
                    printf("Application finished.\n");
                    break;
                }
                else
                {
                    // Continue search loop below:
                }
            }
        }
    }
    // FREE SHELL MEMORY.
    free(ptr_long_string);
    free(ptr_str_fn_executable);
    //
    printf("Exiting Shell, Thank You For Visiting Us!\n");
    ExitThread(0);
}

//

