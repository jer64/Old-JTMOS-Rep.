/*** System Miscellaneous Routines ***/
#include "sysmisc.h"
halt()
{
 while(!0){}
}
