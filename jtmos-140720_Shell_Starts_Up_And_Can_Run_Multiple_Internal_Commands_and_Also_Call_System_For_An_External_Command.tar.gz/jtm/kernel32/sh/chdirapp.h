#ifndef __INCLUDED_CHDIRAPP_H__
#define __INCLUDED_CHDIRAPP_H__

//
int chdir_app(int argc, char **argv);

#endif
