#!/bin/bash
gcc -o mst mst.c
