//
#include <stdio.h>

//
FILE *freopen(const  char *path,
	const char *mode, FILE *stream)
{
	// Flush the stream
	fflush(stream);

	// Reopen the stream with different file
	return _fopen(path, mode, stream);
}



