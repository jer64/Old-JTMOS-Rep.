// TODO
#include <stdio.h>
#include <fcntl.h>

//
int stat(const char *pathname, struct stat *buf)
{
	return 0;
}

//
int fstat(int fd, struct stat *buf)
{
	return 0;
}

//
int lstat(const char *pathname, struct stat *buf)
{
	return 0;
}

