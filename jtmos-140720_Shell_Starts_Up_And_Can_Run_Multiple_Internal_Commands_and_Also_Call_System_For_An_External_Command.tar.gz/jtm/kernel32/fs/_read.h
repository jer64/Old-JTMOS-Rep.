#ifndef __INCLUDED_READ_H__
#define __INCLUDED_READ_H__

#include "scs.h"
int scall_read(SYSCALLPAR);

#endif

