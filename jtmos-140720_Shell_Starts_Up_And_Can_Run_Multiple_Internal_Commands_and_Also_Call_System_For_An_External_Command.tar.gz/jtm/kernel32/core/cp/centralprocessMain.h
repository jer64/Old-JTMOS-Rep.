//
#ifndef __INCLUDED_CENTRALPROCESSMAIN_H__
#define __INCLUDED_CENTRALPROCESSMAIN_H__

//
extern int reboot_now;
void centralprocess_run(void);
void centralprocess_init(void);

#endif

