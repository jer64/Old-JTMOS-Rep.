#ifndef __INCLUDED_STRTOK_H__
#define __INCLUDED_STRTOK_H__

//# define __strtok_r strtok_r
char *
__strtok_r (char *s, const char *delim, char **save_ptr);

#endif
