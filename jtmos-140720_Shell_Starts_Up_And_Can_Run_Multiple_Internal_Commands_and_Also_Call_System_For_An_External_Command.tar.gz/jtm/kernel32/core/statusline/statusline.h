//
#ifndef __INCLUDED_STATUSLINE_H__
#define __INCLUDED_STATUSLINE_H__

//
void start_statusline(void);
extern int statusline_terminate;

#endif

