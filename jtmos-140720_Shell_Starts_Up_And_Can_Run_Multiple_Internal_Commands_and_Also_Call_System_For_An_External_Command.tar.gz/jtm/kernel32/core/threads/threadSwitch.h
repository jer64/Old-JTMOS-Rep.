//
#ifndef __INCLUDED_THREADSWITCH_H__
#define __INCLUDED_THREADSWITCH_H__

//
void forceSwitch(void);
int vmware_sleep_enabled;

#endif
