//=====================================================================
// KERNEL INTERNAL - User Administration System
// (user magenement system)
//=====================================================================
#include "kernel32.h"
#include "useradmin.h"

//
void GetMachineName(char *s)
{
	//
	strcpy(s, DEFAULT_SYSTEM_NAME);
}

//
void GetCurrentUser(char *s)
{
	//
	strcpy(s, DEFAULT_USER_NAME);
}

//


