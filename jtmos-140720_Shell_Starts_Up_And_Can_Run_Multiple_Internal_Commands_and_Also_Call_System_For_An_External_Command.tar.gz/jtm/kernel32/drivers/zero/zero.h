#ifndef __INCLUDED_ZERO_H__

// Something here:
int zero_init(void);

#endif
