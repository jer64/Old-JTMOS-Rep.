#ifndef __INCLUDED_FLOPPY_H__
#define __INCLUDED_FLOPPY_H__

#include "fdc.h"
#include "fdc_dev.h"

#endif
