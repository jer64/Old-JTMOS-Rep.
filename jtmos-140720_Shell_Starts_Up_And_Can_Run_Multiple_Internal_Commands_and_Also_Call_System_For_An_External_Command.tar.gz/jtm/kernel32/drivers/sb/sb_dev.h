#ifndef __INCLUDED_SB_DEV_H__
#define __INCLUDED_SB_DEV_H__

int sb_register_device(void);
int sb_device_call(DEVICE_CALL_PARS);

#endif
