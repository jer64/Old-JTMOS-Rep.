//--------------------------------------------------------------------------------------------
//
// dict.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"

//--------------------------------------------------------------------------------------------
int DictDump(char *fn)
{
	FILE *f;
	int fd;
	DEN d;
	DWORD i,i2,i3,i4,sz;

	//
	fd = open(fn, O_RDONLY);
	if(fd<0)
	{
		fprintf(stderr, "File not found: %s\n", fn);
		return 1;
	}

	//
	sz = lseek(fd, 0, SEEK_END);
	lseek(fd, 0, SEEK_SET);
	//
	fprintf(stdout, "%s (%dK)\n", fn, (sz/1024)+1);

	//
	for(i=0; ; i++)
	{
		//
		if( (i%20)==0 ) 
		{
			fprintf(stdout, "\n    GID     HOST    CSUM     CSUM     CSUM     CSUM     LOC     TYPE\n");
		}

		//
		if( read(fd, &d, sizeof(DEN))<=0 )
		{
			break;
		}

		//
		fprintf(stdout, "%8x %8x %.8x,%.8x,%.8x,%.8x %8d %.8x\n",
			d.gid,
			d.host,
			d.csum_w1,
			d.csum_w2,
			d.csum_w3,
			d.csum_w4,
			d.loc,
			d.type);
	}

	//
	close(fd);

	//
	return 0;
}

//--------------------------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
	char fn[256],str[256];

	//
	if(argc<2)
	{
		//
		fprintf(stderr, "no arguments\n");
		return 0;
	}

	//
	AltseLoadConfig();

	//
	strcpy(fn, argv[1]);
	//
	if(fn[0]=='/')
	{
	}
	else
	{
		if( strlen(argv[1])<1 ) { return 1; }
		strcpy(str, argv[1]);
		sprintf(fn, "%s/cid/dict/0/%c-0.dic",
			database_path, str[0]);
	}

	//
	DictDump(fn);

	//
	return 0;
}
