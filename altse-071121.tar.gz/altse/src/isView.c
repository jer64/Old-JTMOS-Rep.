//////////////////////////////////////////////////////////////////////////////////////////
//
// Altse Internet Search.
// (C) 2005-2021 by Jari Tuominen (jari.t.tuominen@gmail.com).
//
// Usage: isView "word1 word2 word3 word4" audio
// Use quotes.
//
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "iscfg.h"
#include "wlidump.h"
#include "dardump.h"

// String length in ViewResult(...).
#define MAGIC_LENGTH	(64*1024)

//////////////////////////////////////////////////////////////////////////////////////////
//
void ViewResult(IS *is, ENTSCO *e, int entry_nr)
{
	static char dar[MAGIC_LENGTH],str[MAGIC_LENGTH],tmp[MAGIC_LENGTH],
	        host[MAGIC_LENGTH], path[MAGIC_LENGTH], title[MAGIC_LENGTH],
	        meta_description[MAGIC_LENGTH], nfo[MAGIC_LENGTH],url[MAGIC_LENGTH];
	char *content;
	int gid,line_nr,l;
	char *code_host="host=", *code_path="path=", *code_title="title=",
	        *code_meta_description="meta_description=";

	//
	gid = e->gid;

	//
	// int DarDump(int sid,  BYTE *buf,int l_buf, int index_to_use)
	fprintf(stderr, "PHASE X1\n");
	DarDump(gid, dar,16384, ActiveIndexNr);
	fprintf(stderr, "PHASE X2\n");
	content = WliSearch(gid, is->word[0]);

	//
	fprintf(stderr, "PHASE X3\n");
        // Get host, path, title, preview nfo (dardump).
        for(line_nr=0; line_nr<100; line_nr++) {
                GetLine(dar,4900, line_nr, (BYTE*)str);
                if( !strcmp(str, "[BASIC PAGE INFO]") ) {
                        line_nr++;
                        break;
                }
        }

	//
	fprintf(stderr, "PHASE X4\n");
	GetLine(dar,16384, line_nr, host); line_nr++; // host
	GetLine(dar,16384, line_nr, path); line_nr++; // path
	GetLine(dar,16384, line_nr, title); line_nr++; // title
	GetLine(dar,16384, line_nr, meta_description); line_nr++; // meta description
	//RemoveControlCodes(content);
	//printf("%s\n", content);
	GetLine(dar, 16384, line_nr, nfo);
	
	fprintf(stderr, "PHASE X5\n");
	//printf("D%d - score %d - %s\n", gid, e->score, str); // page gen. info (one-liner)
        l = strlen(meta_description);
        if(l > 150)
        {
                meta_description[148] = '.';
                meta_description[149] = '.';
                meta_description[150] = 0;
        }
	fprintf(stderr, "PHASE X6\n");
	html_print_section_number(entry_nr + 1);
	sprintf(url, "http://%s%s", host+strlen(code_host),path+strlen(code_path));
	html_print_title(title+strlen(code_title), url);
	html_print_description(meta_description+strlen(code_meta_description));
	html_print_new_line();
}

//
int html_print_section_number(int section_nr)
{
        //
        if(html_output_mode)
        {
                printf("<H1 style=\"background-color:yellow; font-color:red; padding:8xpx;\">%d</H1>\n", section_nr);
        }
        else
        {
                printf("[%.2d] ", section_nr);
        }
}

//
int html_print_title(const char *title, const char *url)
{
        //
        if(html_output_mode)
        {
                printf("<A HREF=\"$url\" style=\"font-color:black;\"><H2 style=\"text-transform:capitalize background-color:yellow; font-color:black; padding:4px;\">%s</H2></A>\n", title);
        }
        else
        {
                printf("%s (%s)\n", title, url);
        }
        
        //
}

//
int html_print_new_line(void)
{
        //
        if(html_output_mode)
        {
                printf("<BR>\n");
        }
        else
        {
                printf("\n");
        }
}

//
int html_print_description(const char *description)
{
        //
        if(html_output_mode)
        {
                printf("<H3 style=\"background-color: whitegrey; font-color:blue; padding:2px;\">%s</H3><H6></H6>");
        }
        else
        {
                printf("%s\n", description);
        }
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int ViewResults(IS *is, int only_important)
{
	int i,i2,i3,i4,l,skipped,shown;
	ENTSCO *e;

	//
//	printf("%d titles.\n\n", is->n_entsco);

	//
	for(i=0,skipped=0,shown=0; i<is->n_entsco && shown < web_search_max_results; i++)
	{
		//
		e = is->entsco[i];

                //
                if( (is->n_word>1 && !e->pairs) && only_important )
                {
                        skipped++;
                        continue;
                }

                //
                fprintf(stderr, "PHASE 1\n");
                if( HostQuery(is, e->host) >= max_results_per_host )
                {
                        skipped++;
                        continue;
                }

		//
                fprintf(stderr, "PHASE 2\n");
		ViewResult(is, e, shown);
		//
		shown++;
	}

	//
	return shown;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int main(int argc, char **argv)
{
        int ret;
        IS *is;

        //
        work_began_at = GetTickCount();

        //
        AltseLoadConfig();
        is_LoadConfig();

        /////////////////////////////////////////////////////////////////////////////////////
        //
        if(argc<2)
        {
                fprintf(stderr, "Internet Search\n");
                fprintf(stderr, "Usage: is [search keyword] [mode] [host]\n");
                fprintf(stderr, "Examples:\n");
                fprintf(stderr, "is \"world\" text www.yle.fi\n");
                fprintf(stderr, "is \"apple\" image www.playboy.com\n");
                fprintf(stderr, "is \"culture\" video www.archive.org\n");
                fprintf(stderr, "is \"monkey\" audio www.mp3.com\n");
                return 0;
        }

        //
        is = InitIS(argc, argv);

        //
        SearchIndexes(is);

        //
        ProcessResults(is);

        //
        SortResults(is);

        //
	if( !ViewResults(is, TRUE) ) {
		ViewResults(is, FALSE);
	}

        //
        fclose(flog);

        //
        return 0;
}

