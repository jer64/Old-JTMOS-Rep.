//////////////////////////////////////////////////////////////////////////////////////////
//
// is_searchindexes.c - Altse Internet Search.
// (C) 2005-2011 by Jari Tuominen (jari@vunet.org).
// See is_main.c for command line interface functionality.
//
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
//#include <db.h>
#include <pthread.h>
#include "selib.h"
#include "inde.h"
#include "is.h"
#include "is_processresults.h"
#include "is_searchindexes.h"
#include "iscfg.h"

// Max. time to spend searching indexes.
#define N_MAX_SECS_SEARCH_TAKES		60*2

//////////////////////////////////////////////////////////////////////////////////////////
//
// Searches through indexes for matches.
//
int SearchIndexes(IS *is)
{
	int i,i2,i3,i4,tr,st,t;

	////////////////////////////////////////////////////////////////////
	//
	RANK = 0;

	//
	st = time(NULL);

TryAgain:
	//
	WriteLog("[%d] %s/%s: beginning (is->n_word=%d [to search]) ...\n",
		GetIsTickCount(),
		__FUNCTION__, __FILE__,
		is->n_word);

	// Note: Make search stop on enough results.
	// So that we needn't go through too much data.
	// First searched is URL's A) host names and B) paths.
	int max_pr_to;
	if(OPTIMIZE_FOR_SEARCH_SPEED) {
		max_pr_to = 21;
	} else {
		max_pr_to = 1;
	}
	if(max_search_word_level) {
		max_pr_to = max_search_word_level;
	}
	is->resco = 0;
	for(i=0,tr=0; i<is->n_word; i+=4) // 4 word sums are stored in a single entry
	{
		//
		if(i>=4 && or_mode==0) {
			break;
		}

		// word_level = index word level in inde and defrag and mkdix
		for(is->word_level=0; is->word_level<max_pr_to; is->word_level++)
		{
			is->curword = i;
			if( 
			//(is->word_level<2 || is->word_resco[i] < N_MIN_EXPECT_ENTRIES) &&
				(time(NULL)-st)<N_MAX_SECS_SEARCH_TAKES )
			{
				WriteLog("[%d] %s: resco = %d, word_level=%d, %d < %d\n",
					GetIsTickCount(),
					__FUNCTION__,
					is->word_resco[i],
					is->word_level,
					is->word_resco[i], N_MIN_EXPECT_ENTRIES);
				SearchSingleIndex(is, is->word[i]);
				is->word_resco[i] += is->resco;
				tr += is->resco;
				if( strcmp(is->ascii_word[i],is->word[i]) )
				{
					SearchSingleIndex(is, is->ascii_word[i]);
					is->word_resco[i] += is->resco;
					tr += is->resco;
				}
				// Don't search long if short seek is fruitful (successful).
				//if(is->resco)break;
				if(quick_less_verbose==1 && is->resco>=10 &&
					is->word_level>=5)
					break;
				if(quick_less_verbose==2 && is->resco>=10 &&
					is->word_level>=1)
					break;
			}
			else return 1;

			fprintf(stderr, "%s: results=%d (word level=%d)\n",
				__FILE__, is->n_en, is->word_level);
		}
	}
	is->word_level=-1;
	if(tr) WriteLog("[%d]  -- RANK %d: %d MATCHES\n", GetIsTickCount(), RANK, tr);

	//
	WriteLog("[%d]: End of index search phase (n_en=%d).\n",
		GetIsTickCount(),
		is->n_en);

	//
	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
int SearchSingleIndex(IS *is, char *s)
{
	static BYTE key[8192],str[8192];
	static char dicfn[8192],fname[8192];
	FILE *f;
	BYTE *buf;
	int l_buf;
	DWORD sum,wild;

	//
	wild = 0;

	// Make search keyword at least 4 chars long.
	strcpy((char*)key, (char*)s);
	while( strlen((char*)key)<8 ) { strcat((char*)key, "_"); }
	str[8]=0;
	// Got wildcard search?
	if(strstr(key, "*")) { wild=1; }

	//
//	fprintf(stderr, "N_CHARS_MATTER = %d\n",
//		N_CHARS_MATTER);
	//
	//if(N_CHARS_MATTER==8)
	//{
		strcpy(str,key);
		strcpy(fname,key);
		fname[3]=0;
		sprintf((char*)dicfn, "%s/%d/%s-%d.dic",
			dictloc,
			ActiveIndexNr, // which index to use (f.e. 0=news / 1=business / 2=other stuff) 
			fname,
			is->word_level);
	/*	fprintf(stderr, "%s/%s: using dicfn=\"%s\"\n", 
			__FILE__, __FUNCTION__,
			dicfn);*/
	//}

	//
	if( fs(dicfn)>0 )
	{
		//
		if(debug) fprintf(stdout, "dictionary found: %s (%d bytes)\n",
			dicfn, fs(dicfn));

		//
		sum = smart_csum((BYTE*)s, strlen((char*)s));

		// wild = wildcard search
		if(wild)
		{
			// More verbose search.
			DicSingleFind(is, dicfn, key, 0);
		}
		else
		{
			// Normal search.
			DicSingleFind(is, dicfn, key, sum);
		}

		//
		return 0;
	}
	else
	{
		return 1;
	}
}
