//--------------------------------------------------------------------------------------------
//
// dardump.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"
#include "dardump.h"

#define DBPATH		"/home/vai/db"
#define MAX_PAGE_SIZE	16384

//--------------------------------------------------------------------------------------------
//
// buf will be stored following information:
// 0	host
// 1	path
// 2	title
// 3	preview
// 4	nfo
//
int HtmlDump(int sid,  BYTE *buf,int l_buf, int index_to_use)
{
	FILE *f;
	static char str[WLI_BLS],bigfn[8192],dbifn[8192];
	DWORD offs,l,i,i2,d1;
	int fd;
	// ..
	static char *filelist = NULL;
	static int l_filelist = 0,ch1;
	static char fn[512],popen_cmd[512];
	// ..
	static int curpathnum = -1;
	static int curfilenum = -1;
	FILE *zf;

        //
        static char dbpath_www[2048];

        // Check for base.txt.
        strcpy(dbifn, "pageids2fn");
        if(index_to_use>0) {
                sprintf(str, "\_%d", index_to_use);
                strcat(dbifn, str);
        }
        sprintf(fn, "%s/%s/base.txt",
                DBPATH, dbifn);
        f = fopen(fn, "rb");
        if(f != NULL) {
                fscanf(f, "%s", &dbpath_www);
                fclose(f);
        } else {
                sprintf(dbpath_www, "%s/www", DBPATH);
        }

	// FIRST CONVERT PAGE ID TO FILE NAME
	// 2000 entries per page id file, 200 different files per directory
	int pathnum = sid/(2000*200);
	int filenum = sid/2000;
	// Performance Fix
	// This *comparison makes a sort of cache in memory of current file list,
	// which avoids the possible scenario where the list has to be loaded
	// each time again and again.		* pathnum, filenum
	////fprintf(stderr, "%d %d %d\n", filelist, pathnum, filenum);
	if(pathnum != curpathnum && filenum != curfilenum) {
		if(filelist!=NULL) {
			free(filelist);
			filelist = NULL;
		}

                strcpy(dbifn, "pageids2fn");
                if(index_to_use>0) {
                        sprintf(str, "\_%d", index_to_use);
                        strcat(dbifn, str);
                }

       		sprintf(fn, "%s/%s/0/0/0/%d/%d.dat", DBPATH, dbifn, pathnum, filenum);

		f = fopen(fn, "rb");
		if(f==NULL) {
			fprintf(stderr, "%s/%s: Error. pageds2fn FN is invalid? File not found: %s\n",
				__FUNCTION__, __FILE__,
				fn);
			return -6;
		}
		fseek(f,0,SEEK_END);
		l_filelist = ftell(f);
		fseek(f,0,SEEK_SET);
		filelist = malloc(l_filelist);
		fread(filelist,l_filelist,1,f);
		fclose(f);
	}
	if(filelist!=NULL) {
		GetLine(filelist,l_filelist,sid % 2000,fn);
	}

	// fn now contains (dump) file name of specified PAGE ID
	// f.e. ./1.b/1.bp.blogspot.com/1.dump.gz
	// which is convertible to an absolute path of
	// /home/vai/db/www/X

	// 
	//if(HTMLPARSE_VERBOSE)
	//	fprintf(stderr, "%s line %d: pageid2fn conversion result: \"%s\"\n", __FUNCTION__, __LINE__, fn);
	//sleep(1);

	//
	memset(buf,0,l_buf);

	// Load ".dump.gz" file using zlib zopen.
       	sprintf(bigfn, "%s/%s", dbpath_www, fn);
       	char *rep = strstr(bigfn, ".dump.gz");
       	if(rep!=NULL) { strncpy(rep, ".html.gz", 8); }
       		else { return 3; }

	sprintf(popen_cmd, "zcat %s", bigfn);
	zf = popen(popen_cmd, "r");
        int LIM = 1024*1024;
	//char *temppi = malloc(LIM);
	for(i=0; i<l_buf && i<(LIM); i++) {
		ch1 = fgetc(zf);
		if(ch1>=0) {
			buf[i] = ch1;
		} else {
			break;
		}
	}
	//fprintf(stderr, "%s line %d: %d byte(s) load from \"%s\".\n",  __FUNCTION__, __LINE__, i, bigfn);
	fclose(zf);

	//
	return 0;
}


