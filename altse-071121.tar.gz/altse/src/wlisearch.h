#ifndef __INCLUDED_WLISEARCH_H__
#define __INCLUDED_WLISEARCH_H__

//
extern int WLISEARCH_find_one_long_quotation;
//
extern int IsJunk(int ch);
extern int NeedToAvoid(int id, int explen);
extern int WliFindBuf(BYTE *buf,int l_buf, BYTE *ke,
        BYTE *re,int l_re,
        int explen);
extern int WliFindBuf1(BYTE *buf,int l_buf, BYTE *ke,
	BYTE *re,int l_re,
	int explen);
extern BYTE *WliSearch(DWORD wli_id, char *key, int which_index);

#endif
