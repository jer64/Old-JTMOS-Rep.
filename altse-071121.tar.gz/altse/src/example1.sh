#!/bin/bash
echo "SCORE  GID  LOCATIONS  RANK  HOST"
is suomi text www.suomi.fi unl
