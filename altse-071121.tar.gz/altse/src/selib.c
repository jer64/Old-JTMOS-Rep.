//
#include <stdio.h>
#include <sys/time.h>
#include "selib.h"

// free(3) - Linux man page
// Name
// 
// malloc, free, calloc, realloc - allocate and free dynamic memory
// Synopsis
// 
// #include <stdlib.h>
// 
// void *malloc(size_t size);
// void free(void *ptr);
// void *calloc(size_t nmemb, size_t size);
// void *realloc(void *ptr, size_t size);
//
// Description
//
// The malloc() function allocates size bytes and returns a pointer to the allocated memory. The memory is not initialized. If size is 0, then malloc() returns either NULL, or a unique pointer value that can later be successfully passed to free(). 

//
void *SafeFree(void *_ptr)
{
	if(_ptr!=NULL) {
		free(_ptr);
		//*_ptr=(void*)NULL;
	}
	return NULL;
}

//
void to_ascii_string(char *str)
{
	int len,i;

	//
	len = strlen(str);
	for(i=0; i<strlen(str); i++) {
		str[i] = toascii(str[i]);
	}
}


//
void *imalloc(size_t size) {
	char *tmp;
	tmp = malloc(size);
	memset(tmp,0,size);
	return tmp;
}

/////////////////////////////////////////////////////////////////////////////
//
void fputd(DWORD d1, FILE *f)
{
        //
        fputc(d1&255, f);
        fputc(d1>>8&255, f);
        fputc(d1>>16&255, f);
        fputc(d1>>24&255, f);
}

//
DWORD n2i(char *fn)
{
        DWORD i;
        char *p;
        char str[512];

        //
        i=0;
        strcpy(str, fn);
        for(i=strlen(str)-1; i>0; i--)
        {
                if(str[i]=='.') { str[i]=0; }
                if(str[i]=='/') { break; }
        }
        p = str+i+1;
        sscanf(p, "%d", &i);
        return i;
}

//
void FixString1(char *s)
{
	//
	FixString(s);
	LowerCaseString(s);
	RepNonOk(s);
}

/////////////////////////////////////////////////////////////////////////////
//
// Removes any trailing \n or \r control characters from the string.
// Used in correlation with fgets -function.
//
void FixString(char *s)
{
	int i,l,c;

	//
	while(1)
	{
		l = strlen(s);
		if(l<1) { break; }
		c = s[l-1];
		if(c==0x0A || c==0x0D) { s[l-1]=0; } else { break; }
	}
}

/////////////////////////////////////////////////////////////////////////////
//
// Determine file size.
//
int fs(const char *fn)
{
        int sz;
        FILE *f;

        //
        f=fopen(fn, "rb");
        if(f==NULL) { return -1; }
        fseek(f,0,SEEK_END);
        sz=ftell(f);
        fclose(f);

        //
        return sz;
}


// Rotate DWORD number bits to right.
// Wont not destroy any bits of information.
DWORD bitrotate32(DWORD numero, int n_times)
{
	DWORD rotnum,i,num;

	//
	num = numero;

	//
	for(i=0; i<n_times; i++) {
		rotnum = num;
		rotnum <<= 1;
		if( (num&0x80000000)!=0 ) {
			// Xor bit 0.
			rotnum |= 1;
		}
		num = rotnum;
	}

	//
	return num;
}

/////////////////////////////////////////////////////////////////////////////
// Ideal for 16 character host name.
HOSTHASH smart_csum(BYTE *buf, int l_buf)
{
	HOSTHASH i,sum;

        //
        for(i=0,sum=0; i<l_buf; i++)
        {
		//sum <<= 1;
                sum += buf[i]+1;
		sum = bitrotate32(sum,2);
		//sum = sum<<2;
        }

        //
        return sum;
}

/////////////////////////////////////////////////////////////////////////////
//
/*DWORD csum(BYTE *buf, int l_buf)
{
	DWORD i,sum;

        //
        for(i=0,sum=0; i<l_buf; i++)
        {
                sum += buf[i]+1;
		//sum = sum<<2;
        }

        //
        return sum;
}*/

/////////////////////////////////////////////////////////////////////////////
//
void LowerCaseString(BYTE *s)
{
        DWORD i,i2,i3,i4,c,l,l2,x;
        BYTE *pat1="ABCDEFGHIJKLMNOPQRSTUVWXYZ���";
        BYTE *pat2="abcdefghijklmnopqrstuvwxyz���";

        //
        for(i=0; i<100; i++)
        {
                l = strlen(s);
                if(l>0)
                {
                        c = s[l-1];
                        if( c=='.' || c=='-' ) { s[l-1]=0; } else { break; }
                }
                else
                {
                        break;
                }
        }

        // Make lower case.
        l = strlen(s);
        l2 = strlen(pat1);
	int success;
        for(i=0; i<l; i++)
        {
		success = 0;
                for(x=0; x<l2; x++)
                {
                        if(pat1[x]==s[i]) { s[i]=pat2[x]; success=1; break; }
                }
		// try stdio option if no success
		// (BAD OPTION, may/will produce gibberish)
		//if(!success) { s[i]=tolower(s[i]); }
        }

        //
}

//
int isalnum1(BYTE ch)
{
        BYTE *ac="������";
        int i,l;

        //
        if( isalnum(ch) ) { return 1; }

        //
        l = strlen(ac);
        for(i=0; i<l; i++) { if(ac[i]==ch) { return 1; } }

        //
        return 0;
}

//
int isKeyChar(BYTE ch)
{
        BYTE *ac="������";
        int i,l;

        //
        if( isalnum(ch) ) { return 1; }

        //
        l = strlen(ac);
        for(i=0; i<l; i++) { if(ac[i]==ch) { return 1; } }

        //
        return 0;
}

//
void RepNonOk(BYTE *s)
{
	int i,i2,l;

	//
	l = strlen(s);
	//
	for(i=0; i<l; i++)
	{
		if( !isok(s[i]) ) s[i] = '_';
	}

	//
}

//
int isok(BYTE ch)
{
        BYTE *ac="������.,+-*^#:;!?$/\\@|(){}[]<>\"'=%&_\n ";
        int i,l;

        //
        if( isalnum(ch) ) { return 1; }

        //
        l = strlen(ac);
        for(i=0; i<l; i++) { if(ac[i]==ch) { return 1; } }

        //
        return 0;
}

//
void OkWord(BYTE *s)
{
	int i,i2,l,x;
	static BYTE str[32768],str2[32768];

	//
	l = strlen(s);
	//
	if(l>8000) { strcpy(s, "UNTITLED"); return; }

	//
	strcpy(str, s);
	strcpy(str2, s);

	//
	LowerCaseString(str2);

	//
	for(i=0,x=0; i<l; i++)
	{
		//
		if( isok(str[i]) ) { s[x++]=str[i]; }
	}
	s[x++] = 0;

	//
}

//
void RemoveControlCodes(BYTE *p)
{
        int i,i2,l;

        //
        l = strlen(p);
        for(i=0; i<l; i++)
        {
                if(p[i]==0x0A) { p[i]=' '; }
                if(p[i]==0x0D) { p[i]=' '; }
        }

        //
}

//
DWORD GetTickCount(void)
{
	struct timeval t;

	//
	gettimeofday(&t, NULL);

	//
	return (t.tv_sec*1000)+(t.tv_usec/1000);
}

//
int ch2num(BYTE ch)
{
	BYTE *chars="abcdefghijklmnopqrstuvwxyz���0123456789_"; // 40
	int i,i2,l;

	//
	l = strlen(chars);

	//
	for(i=0; i<l; i++)
	{
		if(ch==chars[i]) { return TRUE; }
	}

	//
	return FALSE;
}

// [Big Character Array] [Which Line #] [Destination String]
void GetLine(BYTE *buf, int l_buf, int which, BYTE *dst)
{
        int i,i2,i3,i4,x,nr;

        //
        for(i=0,nr=0,x=0; i<l_buf; i++)
        {
                //
                if(buf[i]=='\n') { nr++; continue; }
                if(nr==which)
                {
                        dst[x++] = buf[i];
                }
        }
        dst[x++] = 0;
}

// [Big Character Array] [Which String #] [Destination String]
void GetString(BYTE *buf, int l_buf, int which, BYTE *dst)
{
        int i,i2,i3,i4,x,nr;

        //
        for(i=0,nr=0,x=0; i<l_buf; i++)
        {
                //
                if(buf[i]==' ') { nr++; continue; }
                if(nr==which)
                {
                        dst[x++] = buf[i];
                }
        }
        dst[x++] = 0;
}

//
//----------------------------------------------------------------------------------
//
void GetOnlyPath(char *fn, char *path)
{
        int i,i2,i3,i4,l;

        //
        l = strlen(fn);

        //
        for(i=l-1; fn[i]!='/' && i>0; i--);

        //
        strcpy(path, fn);
        path[i]=0;

        //
}

