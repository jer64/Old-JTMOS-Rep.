#!/usr/bin/perl
##########################################################################
#
# NFO archiver.
#
##########################################################################
#
use POSIX;
#
require "$ENV{'HOME'}/sdb/bin/tools.pl";

#
$SDB =          "$NWPUB_CGIBASE/sdb";   # search database root directory
$CID =          "$SDB/cid";             # central index
$LISTS =        "$SDB/cid/lists";       # list files directory
$DADI =         "$SDB/cid/data";        # data files
$DICT =         "$SDB/cid/dict";        # big index with dictionaries

#
main();

############################################################################
#
sub Fetch
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$fn,$fnn,$f,$name);

	#
	if( !(-e $_[0]) ) { return(); }

	#
	@lst = LoadList($_[0]);

	#
	$str = $_[0];
	$str =~ s/^.*\/(.*)$/$1/;
	print $gf "$str\n";
	for($i=0; $i<($#lst+1); $i++)
	{
		if($lst[$i] ne "")
		{
			print $gf "$lst[$i]\n";
		}
	}
	print $gf "\n";
}

############################################################################
#
sub FetchRep
{
	#
	Fetch($_[0]);
	remove($_[0]);
}

############################################################################
#
sub ArchiveDir
{
	my ($i,$i2,$i3,$i4,@lst,@lst2,$str,$fn,$fnn,$f,$name);

	#
	loop: for($i=0; $i<10000000; $i++)
	{
		#
		$fnn = "$_[0]/$i";

		#
		if( !(-e "$fnn.nfo") ) { last loop; }

		##############################################################
		#
		$fn = "$_[0]/x$i.dar";

		#
		open($gf, ">>$fn") || die "can't write $fn\n";
		FetchRep("$fnn.nfo");
		FetchRep("$fnn.als");
		FetchRep("$fnn.vls");
		FetchRep("$fnn.ils");
		FetchRep("$fnn.lin");
		close($gf);
		print STDERR "$fn\n";
	}
}

############################################################################
#
sub main
{
	my ($i,$i2,$i3,$i4,@lst,$str);

	# Read list of directories.
	print STDERR "Searching for directories at $DATA ...\n";
	@lst = LoadList("find $DATA -type d|");
	print STDERR "Found $#lst directories.\n";

	#
	for($i=0; $i<($#lst+1); $i++)
	{
		$str = $lst[$i];
		if( $str ne "" )
		{
			ArchiveDir($str);
		}
	}
}

