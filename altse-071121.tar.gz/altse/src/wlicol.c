//--------------------------------------------------------------------------------------------
//
// wlicol.c
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "selib.h"

//--------------------------------------------------------------------------------------------
//
int Store(char *content, DWORD sid)
{
	FILE *f;
	static char str[WLI_BLS],tmp[WLI_BLS],bigfn[WLI_BLS];
	DWORD offs,l,i,i2,d1;
	int fd;

	//
//	fprintf(stderr, "Content = '%s'\n", content);

	//
	sprintf(bigfn, "%s%d.dat", WLI_BIGFN, sid/0x10000);

	//
	fd = open(bigfn, O_CREAT|O_WRONLY, 0666);
	if(fd<0)
	{
		fprintf(stderr, "Can't open file %s for writing.\n", bigfn);
		return 2;
	}
	offs = (sid&0xFFFF)*WLI_BLS;
	lseek(fd, offs, SEEK_SET);
	i = strlen(content);

//	fprintf(stderr, "Writing %d bytes at offset 0x%x.\n", i, offs);
	if(i>(WLI_BLS-DAR_SZ)) { i=WLI_BLS-DAR_SZ; }
	write(fd, content, i);

	//
	if( ((WLI_BLS-DAR_SZ)-i)>0 )
	{
		memset(tmp, 0, WLI_BLS-DAR_SZ);
		write(fd, tmp, (WLI_BLS-DAR_SZ)-i);
	}
	close(fd);

	//
	return 0;
}

//--------------------------------------------------------------------------------------------
//
int wlicol(const char *fn, DWORD sid)
{
	FILE *f;
	static char l1[WLI_BLS],l2[WLI_BLS],l3[WLI_BLS],l4[WLI_BLS],l5[WLI_BLS],
		str[WLI_BLS],str2[WLI_BLS],big[WLI_BLS];
	int l,i,i2;
	char *p;

	// READ.
	//
        if(!strcmp(fn,"|"))
        {
                f = stdin;
        }
        else
        {
                f = fopen(fn, "rb");
        }
	if(f==NULL) { fprintf(stderr, "File not found (%s).\n", fn); return 1; }
	//
	for(i=0; i<(WLI_BLS-2); i++)
	{
		if(!feof(f))
		{
			big[i] = fgetc(f);
		}
		else
		{
			big[i]=0;
		}
	}
	for(; !feof(f); ) { fgetc(f); }
	big[i]=0;
	//
	fclose(f);

	// STORE IN BIG WLI DATABASE.
	//
	Store(big, sid);
}

//--------------------------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
	DWORD i;

        //
        if(argc<2)
        {
                //
                fprintf(stderr, "wlicol [NNNNNN.wli] (receives input from the WLI file)\n");
                fprintf(stderr, "wlicol NNNN         (receives input from STDIN)\n");
                return 0;
        }

	//
	AltseLoadConfig();

        //
        if(!strstr(argv[1],".wli"))
        {
                sscanf(argv[1], "%d", &i);
                wlicol("|", i);
        }
        else
        {
                i = n2i(argv[1]);
                wlicol(argv[1], i);
        }

	//
	return 0;
}

