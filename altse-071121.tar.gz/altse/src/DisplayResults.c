/////////////////////////////////////////////////////////////////////////////
//
void DisplayResults(INDE *in)
{
	int i;
	ENT *e;

	//
	for(i=0; i<in->n_ent; i++)
	{
		//
		e = in->ent[i];

		//
		printf("%s %x %d %d\n",
			(char*)e->tiny, e->csum_w1, e->loc, e->gid);
	}

	//	
}
