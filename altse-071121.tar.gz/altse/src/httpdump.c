//
#include <stdio.h>
#include "selib.h"
#include "gethtmlpage.h"

//
#define N_MAX_LIST	100000

//
static char *list[N_MAX_LIST];
static int n_list;

//
int isEndOfUrl(int ch)
{
	//
	if(ch==' ' || ch=='\"' || ch=='\'' ||
		ch=='\n' || ch=='\r' || ch=='\t')
	{
		return TRUE;
	}

	//
	return FALSE;
}

//
int xchars(char *s, int ch)
{
	int i,i2,l,c;

	//
	l = strlen(s);
	for(i=0,c=0; i<l; i++)
	{
		if(s[i]==ch) { c++; }
	}

	//
	return c;
}

//
void GetOnlyHost(char *s)
{
	int i,l;

	// Require http://.
	if( strncmp(s,"http://",7) ) { return; }

	// Get past http://
	strcpy(s,s+7);

	//
	l = strlen(s);
	for(i=0; i<l; i++)
	{
		if(s[i]=='/') break;
	}
	s[i]=0;
}

//
void AddToList(char *s)
{
	int i;

	//
	for(i=0; i<n_list; i++)
	{
		if(!strcmp(list[i],s)) { return; } // already in list?
	}

	//
	i = n_list;
	if(list[i]==NULL) list[i] = malloc(256);
	strcpy(list[i], s);
	n_list++;
}

//
void ViewLinks(char *host, char *path)
{
	BYTE *h;
	int i,i2,i3,i4,l;
	static char str[8192];

	//
	if(!strcmp(path,"/"))
	{
		strcpy(path,"");
	}

	//
	h = GetHtmlPage(host, path);
	if(h==NULL)
	{
		fprintf(stderr, "Not in database: host=%s, path=%s\n",
			host,path);
		return;
	}

	//
	l = strlen(h);

	// Extract links.

	//
	fprintf(stdout, "%s\n", h);

	//
	return;
}

//
void InitList(void)
{
	static int once=0;

	//
	if(!once)
	{
		memset(list,0,sizeof(list));
		once++;
	}
	n_list=0;
}

//
int main(int argc, char **argv)
{
	//
	InitList();

	//
	AltseLoadConfig();

	//
	if(argc<3)
	{
		//
		fprintf(stderr, "Usage: htmldump [host] [path]\n");
		return 0;
	}

	//
	ViewLinks(argv[1], argv[2]);

	//
	return 0;
}

//
