//
#ifndef __INCLUDED_INDE_SAVERESULTS_H__
#define __INCLUDED_INDE_SAVERESULTS_H__

//
void SaveResults(INDE *in);

#endif

