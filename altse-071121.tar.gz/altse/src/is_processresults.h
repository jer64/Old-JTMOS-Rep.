#ifndef __INCLUDED_PROCESSRESULTS_H__
#define __INCLUDED_PROCESSRESULTS_H__

//
int ProcessResults(IS *is);

#endif
