//
#ifndef __INCLUDED_INDE_FS_H__
#define __INCLUDED_INDE_FS_H__

//
#define MAX_FDX_RANKS	200
// STDIO FILE* type buffering.
#define FDX_BUF_SZ		(1024*64)
#define FDX_BUF_OVERFLOW	1024

//
int WriteDic(INDE *in, int rnk, DWORD val);
int WriteDir(INDE *in, int rnk, DWORD val);
int FlushDic(INDE *in, int rnk);
int FlushDir(INDE *in, int rnk);
int CloseDic(INDE *in, int id, int really_close);
int PreAlDic(int fd, DWORD offs, DWORD to_al);
int OpenDic(INDE *in, BYTE *s, DWORD iiii,
                int rank);

#endif


