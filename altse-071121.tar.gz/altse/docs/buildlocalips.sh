#!/bin/bash
# FOR TESTING

## BESIDES THIS, REMEMBER:
## add altse.co.nr 192.168.0.3 to /etc/hosts
sudo ip address add 192.168.0.3/24 brd + dev eth0 

