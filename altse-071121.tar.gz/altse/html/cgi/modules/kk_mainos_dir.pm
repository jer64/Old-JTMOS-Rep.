$KK_MAINOS = ("
                <A HREF=\"http://www.kultakaivos.info\" class=dark>
                <IMG SRC=\"$IMAGES_URL/banners/kultakaivos_banner.png\" border=0>
                </A>
");

1;

