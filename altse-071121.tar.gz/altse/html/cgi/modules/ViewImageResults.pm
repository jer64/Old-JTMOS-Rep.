# ViewImageResults.pm - view of the image results.
require "./modules/GetPageImagesFromCache.pm";
require "./modules/GetPageImages.pm";

##################################################################################################################
#
# Display image search results.
#
sub ViewImageResults
{
	my ($i,$i2,$i3,$i4,$found,$tree,$lisa,$title,$fna,$score,@sp,$id,$ST,
		$str,$str2,$con);

	# Text view.
	####$so{'start'};
	$ST = $so{'start'};
	# Keeps annoying thumbnails away.
	my $MIN_SIZE_FOR_IMAGES = 3999;

	#
	@COT = (
		"F0F0F0",
		"E0E0E0"
		);
		
	
	#
	print("
<LI><A HREF=\"/cache/DonaldTrump.html\">
Donald Trump Gallery
</A></LI>
<LI>
<A HREF=\"/cache/VladimirPutin.html\">
Vladimir Putin Gallery
</A></LI>
<LI>
<A HREF=\"/cache/XiJinping.html\">
Xi Jinping Gallery
</A></LI>

	");

	#
	if($ORGQ =~ /site:/)
	{
$str = $so{'q'};
$str =~ s/site:\S*//;
$con .= ("

<table cellpadding=2 cellspacing=0 width=100%>
<tr>

<td width=30% bgcolor=#E0E0FF>
<div align=center>
<a href=\"/?cmd=vimages&q=$str\" class=dark>> $so{'W_SEARCH_ALL_WEB_SITES'}</a><br>
</div>
</td>

<td width=30% bgcolor=#E0E0F8>
<div align=center>
<font color=black>
<b>$keyword</b>
</font>
</div>
</td>

<td width=30% bgcolor=#E0E0F0>
<div align=center>
<font color=#000000>$site</font>
</div>
</td>

</tr>
</table>
                        ");
	}

	## Build list of all images that the search gives.
	## This is done by "manual robot labour" (slow work)
	## made by running dardump for each page ID.
	# @il = image list (array)
	my (@il,%gotpageid,@imgs,$imgnr,$images_visible);
	my $st = time;
	# GO THROUGH EACH PAGE AND *FETCH THE IMAGES LIST* FROM EACH.
	for($i=0; $i<($#results+1) && (time-$st)<60; $i++) {
		# "$url|$tofn2|$url|$path|$metades\n";
		@sp2 = split(/ /, $results[$i]);
		my $pident = $sp2[1];
		
		# Process each page once, avoid duplicates.
		#Bprint "pident=$pident<BR>";
		if(!$gotpageid{$pident}) {
			$gotpageid{$pident}++;
			# Get images for this page.
			my @tmplnks = GetPageImagesFromCache($pident,0);
			push(@imgs, @tmplnks);
		}
	}

	#
	$LAST_PAGE = (($#imgs+1) / $images_per_page)+1;

	#
	$con .= ("
	<DIV ALIGN=CENTER>
		<TABLE cellspacing=0 cellpadding=0>
		<TR>
		<TD>
		");

	#
	$con .= ("<P>Found <B>$#imgs</B> image(s) for <B>\"$so{'q'}\"</B>.</P>");

	# To find the original URLs the images were downloaded from:
	my (%image_url);
	my @orig = LoadList("$DB/wwwimages/already.txt");
	# Format:
	# 0: http://images.cdn3.porn5.com/0/950/950110/220/8.jpg
	# 1: /home/vai/db/wwwimages/2536/220x175/253653_14.jpg
	# etc...
	@orig = reverse sort @orig;

	#
	for($i=0; $i<($#orig+1); $i++)
	{
		@sp = split(/\|/, $orig[$i]);
		# size url localpath path title metades
		
		$hashcode = $sp[2];
		$hashcode =~ s/^.*\/([0-9]+\_[0-9]+)\.[a-z]+$/$1/;
		$image_all{$hashcode} = $orig[$i];
		$image_url{$hashcode} = $sp[1];
		$image_path{$hashcode} = $sp[3];
		$image_title{$hashcode} = $sp[4];
		$image_metades{$hashcode} = $sp[5];
		$image_size{$hashcode} = $sp[0];
		#print "saving to hash: $hashcode = $image_all{$hashcode}<BR>\n";
	}
	
	#
	my (@sizes);

	# Check out if we can exclude small images.
	my $si = $so{'start'};
	my (%eximages);
        for($i2=0,$i=$si,$imgnr=$si,$images_visible=0; $i<($#imgs+1) && $images_visible<$images_per_page; $i++)
        {
		# size url localpathtoimage internet-path-to-image title metades

		my $ifn = "$DB/".$imgs[$i+0];
		my $url = $imgs[$i];
		#Bprint "imgs $i = \"".$imgs[$i]."\"<BR>\n";
		if( (1==1 || -e $ifn) && !$eximages{ $url } )
		{
			#
			my $image_target_url = $ifn;
			$image_target_url =~ s/^\/home\/vai\/db//;
			my $local_target = $image_target_url;
			#
			my $which_page = $image_target_url;
			$which_page =~ s/^.*\/([0-9]+_[0-9]+)\.[a-z]+/$1/;

			$eximages{ $image_url{$which_page} }++;
			#
			#print "sizes $i2 = \"".$image_all{$which_page}."\"<BR>\n";
			my $q = $so{'q'};
			my $xtra = "";
			#if( $image_all{$which_page} =~ /$q/i)
			#{
			#	$xtra = "99";
			#A}
			$sizes[$i2] = $xtra . $image_all{$which_page};
			$i2++;
		}
		else
		{
			$con .= "<LI>NOT FOUND: \"$ifn\"</LI>\n";
		}
        }
 
 	#       
        #@sizes = reverse sort @sizes;
#	my $q = $so{'q'};
#	@sizes = LoadList("cat $DB/wwwimages/already.txt|grep -i \"$q\"|");
	@sizes = reverse sort @sizes;

	# TODO: cache all images and make thumbnails
	#	e.g. make an image bot that crawls these links
	
	#
	my $si = $so{'start'};
	for($i=$si,$imgnr=$si,$images_visible=0; $i<($#sizes+1) && $images_visible<$images_per_page; $i++) {
		$thimg = "";
		# This file name has an absolute path.
		# sp: size:0 url:1 localpath:2 path:3 title:4 metades:5
		my (@sp) = split(/\|/, $sizes[$i]);
		my $size = $sp[0];	
		my $ifn = $sp[2];
		my $url = $sp[1];
		my $metades = $sp[6];
		my $title = $sp[5];
		my $path = $sp[4];
		my $host = $sp[1];
		$host =~ s/^http[s]\/\/([^\/]+)\/.*$/$1/;
		if(-e "$ifn")
		{
			#
			my $origurl;

			# TODO
			#my $pageid = $imgs[$imgnr];
			#$pageid =~ s/^.*\/([0-9]+).*$/$1/;
			#LoadVars("dardump $pageid $so{'indexnr'}|");
	
			#
			my $localfn = $ifn;
			#my $localfn_size = -s $localfn;
			#if($localfn_size > $MIN_SIZE_FOR_IMAGES)
			#{
				#
				my $image_target_url = $ifn;
				$image_target_url =~ s/^\/home\/vai\/db//;
				#$image_target_url =~ s/220x175\///;
				my $local_target = $image_target_url;
				#
				my $which_page = $image_target_url;
				$which_page =~ s/^.*\/([0-9]+_[0-9]+)\.[a-z]+/$1/;

				$origurl = $image_url{$which_page};
				$origtitle = $image_title{$which_page};
				$origmetades = $image_metades{$which_page};
				$origpath = $image_path{$which_page};
 				$orighost = $image_host{$which_page};
 				if($origurl ne "")
				{
					$alt_tag = $origurl;
					$alt_tag =~ s/^http:\/\///g;
					$alt_tag =~ s/[^a-zA-Z0-9]./_/g;
					if(!$got{$alt_tag})
					{
						$got{$alt_tag}++;
					}
					else
					{
						goto skip;
					}
				}
				else
				{
					$origurl = $ifn;
					$alt_tag = "$so{'q'}, Alternative Search Engine Technology";
				}
	
			$local_target =~ s/^http:\/\/[a-z\.0-9]+(\/)/$1/;
					#$local_target = $DB . "/" . $local_target;

				#print "origurl=$origurl .. $image_target_url: " . $which_page . "... \$image_url{$which_page}=" . $image_url{$which_page} . " $imgs[$imgnr]" . "<BR>";


					## if using cached image target: if( !(-e $local_target) ) {
				#if( !(-e $local_target) )
				#		{
				#	# Cached image not found:
				#	$con .=  ("
				#		<IMG SRC=\"$imgs[$imgnr]\" alt=\"$alt_tag\" title=\"$alt_tag\" border=2>
				#	");
				#}
				#else
				#{
					$path =~ s/^.*$//;
					$cuttitle = $title;
					$cutpath = $path;
					$cuttitle =~ s/^(.{300}).*$/$1 .../;
					$cutpath =~ s/^(.{300}).*$/$1 .../;
					$shorttitle = $title;
					$shorttitle =~ s/^(.{50}).*$/$1/;
					$hoststr = "$host$path";
					$hoststr =~ s/^(.{30}).*(.{30})/$1 ... $2/;
					$query = $so{'q'};
					$cuttitle =~ s/\$query/\<font color\=\'red\'\>$1\<\/font\>/g;
					$cuttitle =~ s/^a//;
					#my $searchregex = $so{'q'};
					#$cuttitle =~ s/($searchregex)(?=[^>]*<)/<span class="highlight">$1<\/span>/gi

				my $search_for_this = "/?q=$shorttitle&st=text&noajax=TRUE&indexnr=0&cmd=go";
				
				$image_action_url = "http://$ENV{'SERVER_NAME'}/?cmd=previewimage&imageurl=$origurl&fulltitle=$title&noajax=TRUE";

				$con .= ("
					<DIV style='display: inline;
					    float: right;
					    width: 300px;
					    border: 3px solid #E0E0E0;
					    padding: 10px;'>
					
					<FONT SIZE='3' color='#000000'><B>$cuttitle</B></FDNT><BR>
					<FONT SIZE='1' color='green'>$cutpath</FONT><BR>

					<A HREF=\"$image_action_url\"
						target=\"_blank\">
					Preview image
					</A>
					
					<BR>
					<A HREF=\"$origurl\" class=\"goldlink\">
						<IMG SRC=\"$origurl\" alt=\"$sp[2]\" title=\"$alt_tag\" border=2
								width=300 height=225>
					</A>
					
					<BR>
					<A HREF=\"$host$path\">
					$hoststr
					</A>



<!----
<IFRAME SRC=\"http://www.facebook.com/widgets/like.php?href=$origurl\">
</IFRAME>
---->

					</DIV>
					
					<BR>

					");
				if($images_visible%4==3) { $con .= "</TR></TABLE>"; }
				#}

				## Add new HTML-line.
				#if( (($images_visible)%4)==3 && $images_visible) {
				#		$con .=  "<BR>\n";
				#}

				# Count how many images visible
				$images_visible++;
			#}
skip:
			$imgnr++;
		}
	}

	#
	$con .= ("
		</TD>
		</TR>
		</TABLE>
	</DIV>
		");

	# Show immediately text search if images not found:
	if(!$images_visible) {
		my $redirect_to = "/?cmd=go&q=$so{'q'}&st=text&indexnr=0";

		#print("
		#<meta http-equiv=\"refresh\" content=\"0; url=$redirect_to\">		
		#");
	}

	#
	return $con;
}

1;
