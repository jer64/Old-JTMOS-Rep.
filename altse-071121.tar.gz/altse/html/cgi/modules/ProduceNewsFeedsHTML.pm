# RSS/XML parser.
require "./modules/JsArray.pm";

#
sub ProduceNewsFeedsHTML
{
	my (@lst,@index,$i,$i2,$con);

	#
	@index = LoadList("find cache/rss/ -maxdepth 1 -name '*.list'|sort|");

	#
	for($i=0; $i<($#index+1); $i++) {
		my $title = $index[$i];
		$title =~ s/\.[a-z]+$//;
		$title =~ s/^\/.+\/([^\/]+)$/$1/;
		$title =~ s/_/ /g;
		$title =~ tr/[a-z���]/[A-Z���]/;
		$con .= ("
<B><P>$title
</P></B>
");
		$con .= ProduceHtmlList($index[$i]);
	}

	#
	return $con;
}

#
sub ProduceHtmlList
{
	my (@lst,@index,$i,$i2,$con, $url,$des);

	#
	if( !(-e $_[0]) ) { return (); }

	#
	@lst = LoadList($_[0]);
	
	#
	for($i=0; $i<($#lst+1); $i++) {
		my $des = $lst[$i+0];
		my $url = $lst[$i+1];
		if($url=~/^http:\/\//) {
			$con .= ("
<A HREF=\"$url\" class=\"darkul\">
<LI class=rss_news_item>$des</LI>
</A>
");
			$i++;
		}
	}

	#
	return $con;
}

#
sub ProduceNewsFeedsJSBOXHTML
{
	my (@lst,@index,$i,$i2,$con,$tab,$tab_title);

	#
	@index = LoadList("find cache/rss/ -maxdepth 1 -name '*.list'|sort|");

	#
	for($i=0; $i<($#index+1); $i++) {
		$tab_title[$i] = $index[$i];
		$tab_title[$i] =~ s/\.[a-z]+$//;
		$tab_title[$i] =~ s/^\/.+\/([^\/]+)$/$1/;
		$tab_title[$i] =~ s/_/ /g;
		$tab_title[$i] =~ tr/[a-z���]/[A-Z���]/;
		$tab[$i] .= ("
<B><P>$tab_title[$i]
</P></B>
");
		$tab[$i] .= ProduceHtmlList($index[$i]);
	}

	#
	$con .= ("
<SCRIPT LANGUAGE=\"JavaScript\">
var NewsTab = new Array();
");
	#
	for($i=0; $i<($#tab+1); $i++) {
		#
		$con .= "NewsTab[$i] = \"" . JsArray($tab[$i]) . "\";\n";
	}
	#
	$con .= ("

function SwitchNewsTab(pagenr)
{
	document.getElementById('tab_content').innerHTML = NewsTab[pagenr];
}

</SCRIPT>
");

	#
	my $width1 = int(100/($#tab+1));
	$con .= ("

<TABLE width=100% cellspacing=0 cellpadding=4 bgcolor=\"#E0FFE0\">
<TR valing=\"top\">
<TD>

<b>Select section:</b>

<TABLE width=100% cellspacing=0 cellpadding=4 valign=\"top\">
<TR valing=\"top\">
");
	#
	for($i=0; $i<($#tab+1); $i++) {
		#
		$con .= ("
<TD width=\"$width1\%\" valign=\"top\">
<FONT SIZE=1>
<A HREF=\"JavaScript:SwitchNewsTab($i)\" class=\"newsfeed_selector_link\">
$tab_title[$i]
</A>
</FONT>
</TD>
");
	}

	#
	$con .= ("
</TR>
</TABLE>

</TD>
</TR>
</TABLE>
");

	#
	$con .= ("
<TABLE>
<TR>
<TD id=\"tab_content\" name=\"tab_content\">
");
	#
	$con .= ("
</TD>
</TR>
</TABLE>
");

	#
	$con .= ("
<SCRIPT LANGUAGE=\"JavaScript\">
SwitchNewsTab(0);
</SCRIPT>
	");

	#
	return $con;
}

1;

