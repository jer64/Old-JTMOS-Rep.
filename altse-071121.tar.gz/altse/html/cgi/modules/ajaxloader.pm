$AJAXONBUTTON = ("onclick=\"document.getElementById('ldr').style.display='';\"");
$AJAXLDRGIF = "/images/ajaxloader.gif";
$LOADERHTML = ("
<DIV id=\"ldr\" name=\"ldr\" style=\"display: none; font-size: 1px;\">
<table cellspacing=0 cellpadding=2 width=70
	style=\"background:#FFFFFF; \"><tr><td>
<IMG SRC=\"$AJAXLDRGIF\" VALIGN=\"top\"> 
<font size=1>searching</font>
</td></tr></table>
</DIV>
");

1;
