//----------------------------------------------------------------------------------
//
// unrdf.c - extract RDF file.
// (C) 2003-2013 Jari Tuominen.
// GPL-licensed.
//
#include <stdio.h>
#include "selib.h"
#include "gethtmlpage.h"

//----------------------------------------------------------------------------------
//
int fhunt(FILE *f, char *for_what)
{
	int i,i2,i3,i4,l,found,fc,ch,where;

	//
	l = strlen(for_what);
	//
	for(fc=0; !feof(f); )
	{
		//
		if( (ch = fgetc(f))<0 ) { return -1; }

		//
		if(ch==for_what[fc])
		{
			if(!fc) { where=ftell(f); }
			fc++;
			if(fc==l)
			{
				return where;
			}
		}
		else
		{
			fc=0;
		}
	}

	//
	return -1;
}

//----------------------------------------------------------------------------------
//
void GetTopicString(FILE *f, char *topic)
{
	int i,i2,ch;

	//
	for(; !feof(f) && ch!='\"'; ) { ch=fgetc(f); }
	for(i=0,ch=0; !feof(f) && ch!='\"' && i<8000; )
	{
		ch = fgetc(f);	
		topic[i++] = ch;
	}
	if(i)
		topic[i-1]=0;
}

//----------------------------------------------------------------------------------
//
void UnRDF(char *fn)
{
	static BYTE *buf,*tmp;
	static int l_buf,sz,i,i2,i3,i4,offs1,offs2,offs3;
	static FILE *f,*f2;
	static char *TopicOpen= "<Topic r:id=\"";
	static char *TopicClose="<Topic r:id=\"";
	///////////static char *TopicClose="</Topic>";
	static char topic[8192];
	static char path[8192],fn2[8192],str[8192],str2[8192],
			str3[8192],str4[8192];

	//
	f = fopen(fn, "rb");
	if(f==NULL)
	{
		//
		fprintf(stderr, "File not found: %s\n",
			fn);
		return;
	}

	//
	fseek(f,0,SEEK_END); sz = ftell(f); fseek(f,0,SEEK_SET);

	//
	for(; !feof(f); )
	{
		//
		if( (offs1=fhunt(f, TopicOpen))<0 ) break;
		if( (offs2=fhunt(f, TopicClose))<0 ) break;
		offs3 = ftell(f);

		//
		fseek(f,offs1,SEEK_SET);
		GetTopicString(f, topic);

		//
		fprintf(stdout, "%s %.8x %.8x (%d)\n",
			topic, offs1,offs3,
			offs3-offs1);

		//
		if( !(strstr(path,"content")) ) {
			sprintf(path, "%s/directory/content/%s",
				database_path,
				topic);
		} else {
			sprintf(path, "%s/directory/%s",
				database_path,
				topic);
		}
		//
		GetOnlyPath(path, str);
		GetOnlyPath(str, str2);
		GetOnlyPath(str2, str3);
		mkdir(str3, 0777);
		mkdir(str2, 0777);
		mkdir(str, 0777);
		mkdir(path, 0777);
	//	fprintf(stderr, "> mkdir \"%s\" - ", path);
	//	fprintf(stderr, "mkdir \"%s\" - ", str);
	//	fprintf(stderr, "mkdir \"%s\" - ", str2);
	//	fprintf(stderr, "mkdir \"%s\"\n",  str3);

		//
		sprintf(fn2, "%s/index.rdf",
			path);

		//
		f2 = fopen(fn2, "wb");
		if(f2==NULL) { fprintf(stderr, "Can't write file: %s\n", fn2); sleep(100); abort(); }
		tmp = malloc((offs3-offs1)+8000); if(tmp==NULL) abort();
		fseek(f,offs1,SEEK_SET);
		fread(tmp, offs3-offs1,1, f);
		fwrite(tmp, offs3-offs1,1, f2);
		free(tmp);
		fclose(f2);

past:
		//
		fseek(f,offs2-10,SEEK_SET);
	}

	//
	fclose(f);

	//
}

//----------------------------------------------------------------------------------
//
int main(int argc, char **argv)
{
	//
	if(argc<2)
	{
		fprintf(stderr, "Usage: unrdf [RDF file]\n");
		return 0;
	}

	//
        AltseLoadConfig();

	//
	UnRDF(argv[1]);

	//
	return 0;
}

