#!/bin/bash
echo "Pass 1"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Asian Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_asian_porn.html
echo "Pass 2"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Asian Babes&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_asian_babes.html
echo "Pass 3"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Cartoon&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_cartoon.html
echo "Pass 4"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=American Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_american_porn.html
echo "Pass 5"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Russian Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_russian_porn.html
echo "Pass 6"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Finnish Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_finnish_porn.html
echo "Pass 7"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Swedish Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_swedish_porn.html
echo "Pass 8"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Pussy&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_pussy.html
echo "Pass 9"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Chinese Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_chinese_porn.html
echo "Pass 10"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Czech Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_czech_porn.html
echo "Pass 11"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Babes&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_babes.html
echo "Pass 12"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Cartoon&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_cartoon.html
echo "Pass 13"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Videos&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_videos.html
echo "Pass 14"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Anal&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_anal.html
echo "Pass 15"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Gangbang&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_gangbang.html
echo "Pass 16"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Thai Porn&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_thai_porn.html
echo "Pass 17"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Blowjob&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_blowjob.html
echo "Pass 18"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Brunette&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_brunette.html
echo "Pass 19"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Hentai&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_hentai.html
echo "Pass 20"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Japanese Babes&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_porn.html
echo "Pass 21"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Bikinis&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_bikinis.html
echo "Pass 22"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Nudist&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_nudist.html
echo "Pass 23"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Philippine&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_philippine.html
echo "Pass 24"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Japanese Babes&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_japanese_babes.html
echo "Pass 25"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Bukkake&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_bukkake.html
echo "Pass 26"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Lesbian&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_lesbian.html
echo "Pass 27"
screen -d -m lynx -source "http://www.pornokaivos.com/?cmd=go&q=Gay&st=image&indexnr=0&start=&noajax=TRUE" \
	\> image_gay.html
